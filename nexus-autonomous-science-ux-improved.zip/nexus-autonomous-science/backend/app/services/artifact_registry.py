"""Immutable scientific artifact metadata registration and checksum deduplication."""
from __future__ import annotations
from uuid import uuid4
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.models.entities import ScientificArtifact, ScientificSample, Experiment
from app.services.audit import record_event
from app.services.domain_registry import get_domain


def register_artifact(db: Session, payload: dict) -> ScientificArtifact:
    digest = payload["sha256"].lower()
    duplicate = db.scalar(select(ScientificArtifact).where(ScientificArtifact.sha256 == digest))
    if duplicate:
        return duplicate
    lab = payload["laboratory_code"].upper()
    domain = get_domain(lab)["domain"]
    if payload["domain"] != domain:
        raise ValueError(f"Artifact domain does not match {lab}")
    if payload.get("sample_id"):
        sample = db.get(ScientificSample, payload["sample_id"])
        if not sample:
            raise ValueError("Artifact references an unknown sample")
        if sample.laboratory_code != lab:
            raise ValueError("Artifact and sample must belong to the same laboratory")
    if payload.get("experiment_id"):
        experiment = db.get(Experiment, payload["experiment_id"])
        if not experiment:
            raise ValueError("Artifact references an unknown experiment")
        if experiment.laboratory_code != lab:
            raise ValueError("Artifact and experiment must belong to the same laboratory")
    artifact = ScientificArtifact(
        id=str(uuid4()), artifact_code=payload["artifact_code"], sha256=digest,
        storage_uri=payload["storage_uri"], media_type=payload["media_type"],
        artifact_type=payload.get("artifact_type", "raw_data"), byte_size=payload["byte_size"],
        domain=domain, laboratory_code=lab, sample_id=payload.get("sample_id"),
        experiment_id=payload.get("experiment_id"), origin=payload["origin"],
        metadata_json=payload.get("metadata", {}), parent_artifact_ids=payload.get("parent_artifact_ids", []),
        synthetic=bool(payload.get("synthetic", False)),
    )
    db.add(artifact)
    db.flush()
    record_event(db, "SCIENTIFIC_ARTIFACT_REGISTERED", "artifact", artifact.id,
                 actor="artifact-registry", payload={"sha256": digest, "origin": artifact.origin, "synthetic": artifact.synthetic})
    return artifact


def validate_artifact_parents(db: Session, artifact_id: str) -> dict:
    artifact = db.get(ScientificArtifact, artifact_id)
    if not artifact:
        raise KeyError(artifact_id)
    missing = [ref for ref in artifact.parent_artifact_ids if not db.get(ScientificArtifact, ref)]
    return {"artifact_id": artifact.id, "valid": not missing, "missing_parent_ids": missing,
            "parent_count": len(artifact.parent_artifact_ids), "immutable": True}
