"""Build immutable, provenance-linked training snapshots from eligible measurements."""
from __future__ import annotations
import hashlib
import json
from uuid import uuid4
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.models.entities import Measurement, ScientificSample, TrainingDatasetSnapshot
from app.services.model_intelligence.features import align_feature_rows, describe_sample
from app.services.model_intelligence.splits import group_holdout_indices, split_manifest

QUALITY_RANK = {"pending": 0, "preliminary": 1, "accepted": 2, "rejected": -1, "quarantined": -2}


def build_training_snapshot(db: Session, *, dataset_key: str, domain: str, target_property: str,
                            allowed_origins: list[str], include_synthetic: bool,
                            minimum_quality: str = "accepted", test_fraction: float = 0.2,
                            random_seed: int = 17) -> TrainingDatasetSnapshot:
    if minimum_quality not in QUALITY_RANK:
        raise ValueError("Unknown minimum quality status")
    query = select(Measurement).order_by(Measurement.recorded_at.asc())
    records = db.scalars(query).all()
    sample_cache: dict[str, ScientificSample] = {}
    rows: list[dict[str, float]] = []
    targets: list[float] = []
    groups: list[str] = []
    measurement_ids: list[str] = []
    units: set[str] = set()
    skipped: dict[str, int] = {}

    def skip(reason: str):
        skipped[reason] = skipped.get(reason, 0) + 1

    for measurement in records:
        if measurement.property_name != target_property:
            continue
        if measurement.origin not in allowed_origins:
            skip("origin_not_allowed"); continue
        if measurement.synthetic and not include_synthetic:
            skip("synthetic_excluded"); continue
        if QUALITY_RANK.get(measurement.quality_status, -1) < QUALITY_RANK[minimum_quality]:
            skip("quality_below_threshold"); continue
        sample = sample_cache.get(measurement.sample_id)
        if sample is None:
            sample = db.get(ScientificSample, measurement.sample_id)
            if sample is None:
                sample = db.scalar(select(ScientificSample).where(ScientificSample.code == measurement.sample_id))
            if sample:
                sample_cache[measurement.sample_id] = sample
        if sample is None:
            skip("sample_identity_unresolved"); continue
        if sample.domain != domain:
            skip("domain_mismatch"); continue
        if sample.identity_status not in {"verified", "provisional"}:
            skip("sample_identity_not_reviewed"); continue
        try:
            feature_row = describe_sample(domain, sample.composition)
        except ValueError:
            skip("unsupported_sample_representation"); continue
        rows.append(feature_row)
        targets.append(float(measurement.value))
        groups.append(sample.id)
        measurement_ids.append(measurement.id)
        units.add(measurement.unit)

    if len(units) > 1:
        raise ValueError(f"Target measurements contain incompatible units: {sorted(units)}")
    if len(rows) < 4:
        raise ValueError(f"Only {len(rows)} eligible measurements; at least four are required for a training snapshot")
    feature_names, aligned_rows = align_feature_rows(rows)
    train_indices, test_indices = group_holdout_indices(groups, test_fraction=test_fraction, seed=random_seed)
    split = split_manifest(groups, train_indices, test_indices, random_seed)
    record_payload = [
        {"measurement_id": measurement_ids[index], "sample_id": groups[index], "features": aligned_rows[index], "target": targets[index]}
        for index in range(len(rows))
    ]
    material = json.dumps(record_payload, sort_keys=True, separators=(",", ":"))
    digest = hashlib.sha256(material.encode("utf-8")).hexdigest()
    synthetic = any(db.get(Measurement, measurement_ids[index]).synthetic for index in range(len(measurement_ids)))
    snapshot = TrainingDatasetSnapshot(
        id=str(uuid4()), dataset_key=dataset_key, version="1.0.0", domain=domain,
        target_property=target_property, feature_names=feature_names,
        source_measurement_ids=measurement_ids, source_sample_ids=sorted(set(groups)),
        records_json=record_payload, target_unit=next(iter(units), "dimensionless"),
        split_manifest=split,
        quality_report={
            "eligible_rows": len(rows), "source_records_examined": len(records),
            "skipped": skipped, "minimum_quality": minimum_quality,
            "allowed_origins": allowed_origins, "synthetic_included": include_synthetic,
            "feature_schema": feature_names,
            "identity_policy": "verified_or_provisional_sample_identity_required",
        },
        content_hash=digest, row_count=len(rows), status="ready_for_research_training",
        synthetic=synthetic,
    )
    db.add(snapshot)
    db.flush()
    return snapshot
