"""Train and register auditable regression baselines from immutable dataset snapshots."""
from __future__ import annotations
from uuid import uuid4
from sqlalchemy.orm import Session
from app.models.entities import ScientificModel, ScientificModelEvaluation, TrainingDatasetSnapshot
from app.services.model_intelligence.metrics import regression_metrics
from app.services.model_intelligence.ridge import RidgeBaseline


def train_baseline(db: Session, *, dataset: TrainingDatasetSnapshot, model_key: str,
                   model_name: str, version: str, alpha: float = 1.0,
                   minimum_training_rows: int = 8) -> tuple[ScientificModel, ScientificModelEvaluation]:
    if dataset.status != "ready_for_research_training":
        raise ValueError("Dataset snapshot is not eligible for research training")
    records = dataset.records_json
    if len(records) < minimum_training_rows:
        raise ValueError(f"Need at least {minimum_training_rows} rows; found {len(records)}")
    train_indices = dataset.split_manifest.get("train_indices", [])
    test_indices = dataset.split_manifest.get("test_indices", [])
    if not train_indices or not test_indices:
        raise ValueError("Dataset is missing a non-empty group holdout manifest")
    groups = dataset.split_manifest
    if groups.get("overlap_groups"):
        raise ValueError("Dataset split manifest contains sample leakage")
    train_rows = [records[index]["features"] for index in train_indices]
    train_targets = [float(records[index]["target"]) for index in train_indices]
    test_rows = [records[index]["features"] for index in test_indices]
    test_targets = [float(records[index]["target"]) for index in test_indices]
    baseline = RidgeBaseline.fit(train_rows, train_targets, alpha=alpha)
    predictions = [baseline.predict(row)["value"] for row in test_rows]
    metrics = regression_metrics(test_targets, predictions)
    model_manifest = baseline.to_dict()
    model = ScientificModel(
        id=str(uuid4()), model_key=model_key, version=version, name=model_name,
        model_type="ridge_regression_baseline", supported_domains=[dataset.domain],
        supported_modalities=["tabular"], prediction_targets=[dataset.target_property],
        training_dataset_id=dataset.id,
        hyperparameters={"alpha": alpha, "parameters": model_manifest,
                         "train_row_count": len(train_rows), "feature_names": dataset.feature_names},
        metrics={"holdout": metrics, "train_row_count": len(train_rows), "test_row_count": len(test_rows)},
        uncertainty_profile={"method": "in_sample_residual_standard_deviation", "calibrated": False,
                             "residual_std": baseline.residual_std},
        limitations=[
            "Small transparent baseline; not a scientific foundation model.",
            "Uncertainty is an uncalibrated residual-based interval.",
            "No independent experimental validation is implied by this training run.",
            "Model requires domain and sample applicability review before any research use.",
        ],
        status="research_only", model_uri=f"db://scientific-models/{model_key}/{version}",
        synthetic=dataset.synthetic,
    )
    db.add(model)
    evaluation = ScientificModelEvaluation(
        id=str(uuid4()), model_id=model.id, dataset_id=dataset.id,
        split_name="group_holdout", metrics=metrics,
        subgroup_metrics={"train_test": {"train_rows": len(train_rows), "test_rows": len(test_rows)}},
        calibration_metrics={"calibration_status": "not_calibrated", "coverage_claim": None},
        applicability_report={"domain": dataset.domain, "target": dataset.target_property,
                              "feature_schema": dataset.feature_names, "group_overlap": []},
        promotion_recommendation="hold_for_scientist_review",
        synthetic=dataset.synthetic,
    )
    db.add(evaluation)
    db.flush()
    return model, evaluation
