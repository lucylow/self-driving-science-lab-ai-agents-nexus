"""Deterministic authorization gates. Agents may propose; governance authorizes."""

from app.core.errors import GovernanceError

PHYSICAL_ACTIONS = {"synthesize", "dispense", "heat", "cool", "pressurize", "move_robot", "instrument_start"}


def validate_execution_request(experiment, *, requested_mode: str) -> None:
    if requested_mode == "physical":
        raise GovernanceError(
            "Physical execution is not enabled in this starter application. "
            "Connect a locally governed edge gateway and complete hardware acceptance testing first."
        )
    if requested_mode not in {"simulation", "computational"}:
        raise GovernanceError("Only simulation or computational demo execution is enabled.")
    if experiment.status != "approved":
        raise GovernanceError("Experiment must have an approved governance record before execution.")
    if experiment.governance.get("physical_execution"):
        raise GovernanceError("Demo mode blocks experiments marked for physical execution.")


def validate_agent_permission(permission_level: str, action: str) -> None:
    if action in PHYSICAL_ACTIONS:
        raise GovernanceError("Agent permissions cannot authorize physical laboratory actions.")
    if permission_level not in {"propose_only", "analyze", "simulate"}:
        raise GovernanceError("Unknown or elevated agent permission level.")
