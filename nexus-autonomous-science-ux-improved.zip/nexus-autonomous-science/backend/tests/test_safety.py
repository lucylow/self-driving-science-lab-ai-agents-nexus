import pytest
from types import SimpleNamespace
from app.core.errors import GovernanceError
from app.services.safety import validate_execution_request


def test_unapproved_experiment_cannot_run():
    experiment = SimpleNamespace(status="awaiting_approval", governance={"physical_execution": False})
    with pytest.raises(GovernanceError):
        validate_execution_request(experiment, requested_mode="simulation")


def test_physical_mode_is_blocked_even_when_approved():
    experiment = SimpleNamespace(status="approved", governance={"physical_execution": False})
    with pytest.raises(GovernanceError):
        validate_execution_request(experiment, requested_mode="physical")
