"use client";

import { useCallback, useEffect, useState } from "react";
import { Activity, GitBranch, Play, RefreshCw, Scale, ShieldCheck } from "lucide-react";
import { api, ApiError } from "@/lib/api";
import type { ResearchClaim, WorkflowRun } from "@/types";
import { Panel } from "@/components/Panel";
import { StatusPill } from "@/components/StatusPill";

export function ResearchView() {
  const [runs, setRuns] = useState<WorkflowRun[]>([]);
  const [claims, setClaims] = useState<ResearchClaim[]>([]);
  const [objectiveId, setObjectiveId] = useState("OBJ-0001");
  const [batchSize, setBatchSize] = useState(6);
  const [factorA, setFactorA] = useState("0, 1");
  const [factorB, setFactorB] = useState("10, 20");
  const [design, setDesign] = useState<Record<string, unknown> | null>(null);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");

  const refresh = useCallback(async () => {
    try {
      const [nextRuns, nextClaims] = await Promise.all([api.workflowRuns(), api.researchClaims()]);
      setRuns(nextRuns); setClaims(nextClaims); setError("");
    } catch (err) { setError(err instanceof ApiError ? err.message : "Could not load research intelligence records."); }
  }, []);
  useEffect(() => { void refresh(); }, [refresh]);

  const launchWorkflow = async () => {
    setBusy(true); setNotice(""); setError("");
    try {
      const run = await api.startWorkflow({
        workflow_key: "sdl1_candidate_review", laboratory_code: "SDL1",
        objective_id: objectiveId, subject_id: "MAT-00128",
        context: { request: "Review seeded battery-material candidate", requested_by: "Workspace scientist" },
        synthetic: true,
      });
      setNotice(`Workflow ${run.id.slice(0, 8)} completed its analytical nodes and is awaiting scientist review.`);
      await refresh();
    } catch (err) { setError(err instanceof ApiError ? err.message : "Could not start the research workflow."); }
    finally { setBusy(false); }
  };

  const previewDesign = async () => {
    const parse = (text: string) => text.split(",").map((part) => Number(part.trim())).filter((value) => Number.isFinite(value));
    const levelsA = parse(factorA); const levelsB = parse(factorB);
    if (levelsA.length < 2 || levelsB.length < 2) { setError("Each factor needs at least two comma-separated numeric levels."); return; }
    setBusy(true); setError(""); setDesign(null);
    try {
      const result = await api.previewDesign({
        factors: [{ name: "factor_a", levels: levelsA }, { name: "factor_b", levels: levelsB }],
        maximum_runs: 128, center_points: 1, constraints: [],
      });
      setDesign(result.design as Record<string, unknown>);
      setNotice("Computational design matrix generated. It is not a laboratory protocol or execution authorization.");
    } catch (err) { setError(err instanceof ApiError ? err.message : "Design preview failed."); }
    finally { setBusy(false); }
  };

  const latest = runs.slice(0, 5);
  return (
    <div className="research-stack">
      <div className="research-stat-grid">
        <div className="research-stat"><span>WORKFLOW RUNS</span><strong>{runs.length}</strong><small>Persisted supervisor runs</small></div>
        <div className="research-stat"><span>AWAITING REVIEW</span><strong>{runs.filter((run) => run.status === "awaiting_scientist_review").length}</strong><small>Human decision required</small></div>
        <div className="research-stat"><span>SCIENTIFIC CLAIMS</span><strong>{claims.length}</strong><small>Evidence-linked records</small></div>
        <div className="research-stat"><span>AUTO EXECUTION</span><strong>OFF</strong><small>Analysis only</small></div>
      </div>
      <div className="research-two-column">
        <Panel title="SDL1 candidate review workflow" subtitle="A traceable multi-agent sequence using registered specialist capabilities.">
          <div className="research-flow-list">
            {["Objective compiler", "Composition validation", "Candidate ranking", "Evidence review", "Governance summary"].map((label, index) => <div key={label}><span className="flow-step-number">0{index + 1}</span><span>{label}</span><i>{index === 4 ? "HUMAN REVIEW" : "ANALYSIS"}</i></div>)}
          </div>
          <label className="research-full-label">Research objective ID<input value={objectiveId} onChange={(event) => setObjectiveId(event.target.value)} /></label>
          <div className="research-inline-notice"><ShieldCheck size={15} /><span>The supervisor can propose and inspect. It cannot approve experiments or authorize hardware.</span></div>
          <button className="button button-primary" onClick={() => void launchWorkflow()} disabled={busy || !objectiveId.trim()}><Play size={13} />Run analytical workflow</button>
        </Panel>
        <Panel title="Computational experiment design" subtitle="Generate a bounded full-factorial parameter matrix for scientist review.">
          <div className="research-form-grid">
            <label>Factor A levels<input value={factorA} onChange={(event) => setFactorA(event.target.value)} /></label>
            <label>Factor B levels<input value={factorB} onChange={(event) => setFactorB(event.target.value)} /></label>
            <label>Target design batch<select value={batchSize} onChange={(event) => setBatchSize(Number(event.target.value))}><option value={4}>4 candidate runs</option><option value={6}>6 candidate runs</option><option value={8}>8 candidate runs</option><option value={12}>12 candidate runs</option></select></label>
          </div>
          <button className="button button-secondary" onClick={() => void previewDesign()} disabled={busy}><Scale size={13} />Preview design matrix</button>
          {design && <div className="design-preview"><strong>{String(design.run_count)} design points generated</strong><span>{String(design.design_type)} · {String(design.execution_status)}</span></div>}
        </Panel>
      </div>
      <Panel title="Workflow run history" subtitle="Each run preserves its agent nodes, correlation ID and synthetic status." action={<button className="button button-secondary" onClick={() => void refresh()}><RefreshCw size={13} />Refresh</button>}>
        {latest.length === 0 ? <div className="research-empty"><GitBranch size={22} /><strong>No research workflows launched</strong><span>Run the SDL1 candidate review to create the first workflow history record.</span></div> : (
          <div className="research-run-list">{latest.map((run) => <div className="research-run-row" key={run.id}><div className="research-run-icon"><GitBranch size={15} /></div><div className="research-run-copy"><strong>{run.workflow_key.replace(/_/g, " ")}</strong><small>{run.id.slice(0, 14)} · {run.node_history.length} nodes · {run.laboratory_code}</small></div><StatusPill status={run.status} /><span className="research-run-time">{new Date(run.created_at).toLocaleString()}</span></div>)}</div>
        )}
      </Panel>
      <Panel title="Scientific claims registry" subtitle="Claims stay distinct from publications, predictions and experimental observations.">
        {claims.length === 0 ? <div className="research-empty"><Activity size={22} /><strong>No scientific claims registered</strong><span>Register literature and measurement references before asking a scientist to review a claim.</span></div> : (
          <div className="research-claim-list">{claims.slice(0, 6).map((claim) => <div key={claim.id}><div><strong>{claim.statement}</strong><small>{claim.claim_key} · {claim.laboratory_code} · {claim.support_refs.length} supporting refs / {claim.contradiction_refs.length} contradictory refs</small></div><StatusPill status={claim.status} /></div>)}</div>
        )}
      </Panel>
      {notice && <div className="research-feedback success">{notice}</div>}
      {error && <div className="research-feedback error">{error}</div>}
      <div className="research-footnote">Design outputs are parameter-space proposals. Scientific review, protocol validation, resource checks and local safety controls remain independent prerequisites.</div>
    </div>
  );
}
