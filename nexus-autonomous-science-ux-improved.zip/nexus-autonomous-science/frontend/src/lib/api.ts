import type {
  Agent,
  Approval,
  Candidate,
  Dataset,
  EventRecord,
  Experiment,
  Laboratory,
  Measurement,
  Overview,
  TwinOverview,
  ScientificSample, TrainingDatasetSnapshot, ScientificModelRecord, WorkflowRun, ResearchClaim, ResearchCampaign,
} from "@/types";

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
export type ApiErrorKind = "network" | "timeout" | "cancelled" | "http" | "invalid_response";
export class ApiError extends Error {
  status: number;
  kind: ApiErrorKind;
  constructor(message: string, status: number, kind: ApiErrorKind) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.kind = kind;
  }
}
const REQUEST_TIMEOUT_MS = 20_000;
function describeApiError(payload: unknown): string {
  if (!payload || typeof payload !== "object") return "The request could not be completed.";
  const record = payload as { detail?: unknown; message?: unknown };
  const detail = record.detail ?? record.message;
  if (typeof detail === "string" && detail.trim()) return detail.slice(0, 500);
  if (Array.isArray(detail)) {
    const messages = detail.slice(0, 3).map((item) => {
      if (!item || typeof item !== "object") return "Invalid request";
      const error = item as { loc?: unknown[]; msg?: unknown };
      const location = Array.isArray(error.loc) ? error.loc.filter((part) => part !== "body").join(".") : "";
      const message = typeof error.msg === "string" ? error.msg : "Invalid value";
      return location ? `${location}: ${message}` : message;
    });
    return `Please check the request: ${messages.join("; ")}`;
  }
  if (detail && typeof detail === "object") {
    const message = (detail as { message?: unknown }).message;
    if (typeof message === "string") return message.slice(0, 500);
  }
  return "The request could not be completed.";
}
async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const controller = new AbortController();
  let timedOut = false;
  let response: Response | null = null;
  const callerSignal = init?.signal;
  const abortFromCaller = () => controller.abort();
  if (callerSignal?.aborted) controller.abort();
  else callerSignal?.addEventListener("abort", abortFromCaller, { once: true });
  const timer = setTimeout(() => { timedOut = true; controller.abort(); }, REQUEST_TIMEOUT_MS);
  let raw: string;
  try {
    const headers = new Headers(init?.headers);
    if (!headers.has("Content-Type")) headers.set("Content-Type", "application/json");
    response = await fetch(`${API_URL}${path}`, {
      ...init, headers, signal: controller.signal, cache: "no-store",
    });
    raw = await response.text();
  } catch {
    if (timedOut) throw new ApiError("NEXUS API request timed out. Check the service and try again; no offline mutation was applied.", 408, "timeout");
    if (callerSignal?.aborted) throw new ApiError("NEXUS API request was cancelled.", 499, "cancelled");
    if (response) throw new ApiError("The API response was interrupted. Refresh before retrying to confirm whether the change was saved.", 502, "invalid_response");
    throw new ApiError("NEXUS API is unavailable. Start the FastAPI service or use local demo records.", 0, "network");
  } finally {
    clearTimeout(timer);
    callerSignal?.removeEventListener("abort", abortFromCaller);
  }
  let payload: unknown = null;
  if (raw.trim()) {
    try { payload = JSON.parse(raw); }
    catch {
      if (response.ok) throw new ApiError("The API returned an unreadable response. Refresh before retrying.", 502, "invalid_response");
      payload = null;
    }
  }
  if (!response.ok) throw new ApiError(describeApiError(payload), response.status, "http");
  if (response.status === 204 || !raw.trim()) return undefined as T;
  return payload as T;
}
export const api = {
  overview: () => request<Overview>("/api/overview"),
  labs: () => request<Laboratory[]>("/api/labs"),
  agents: () => request<Agent[]>("/api/agents"),
  candidates: () => request<Candidate[]>("/api/discovery/candidates"),
  experiments: () => request<Experiment[]>("/api/experiments"),
  approvals: () => request<Approval[]>("/api/governance/approvals"),
  datasets: () => request<Dataset[]>("/api/data/datasets"),
  measurements: () => request<Measurement[]>("/api/data/measurements"),
  events: () => request<EventRecord[]>("/api/events?limit=50"),
  twin: () => request<TwinOverview>("/api/twin"),
  runAgent: (id: string, task: string) => request<{ status: string; output: Record<string, unknown> }>(`/api/agents/${id}/run`, {
    method: "POST", body: JSON.stringify({ task, context: {} }),
  }),
  createExperiment: (payload: Record<string, unknown>) => request<Experiment>("/api/experiments", {
    method: "POST", body: JSON.stringify(payload),
  }),
  requestApproval: (experimentId: string, reason: string) => request<Approval>(`/api/governance/experiments/${experimentId}/request-approval`, {
    method: "POST", body: JSON.stringify({ requested_by: "Workspace scientist", reason }),
  }),
  decideApproval: (id: string, decision: "approved" | "rejected", note: string) => request<{ approval: Approval; experiment_status: string }>(`/api/governance/approvals/${id}/decision`, {
    method: "POST", body: JSON.stringify({ decision, reviewer: "Workspace supervisor", note }),
  }),
  simulateExperiment: (id: string) => request<{ experiment: Experiment; result: Record<string, unknown> }>(`/api/experiments/${id}/simulate`, {
    method: "POST", body: JSON.stringify({}),
  }),
  nextBatch: () => request<{ candidates: Candidate[]; notices: string[] }>("/api/discovery/next-batch?batch_size=3"),
  samples: () => request<ScientificSample[]>("/api/samples"),
  createSample: (payload: Record<string, unknown>) => request<ScientificSample>("/api/samples", { method: "POST", body: JSON.stringify(payload) }),
  verifySample: (id: string, reviewer: string, evidenceRefs: string[]) => request<ScientificSample>(`/api/samples/${id}/verify`, { method: "POST", body: JSON.stringify({ reviewer, evidence_refs: evidenceRefs }) }),
  trainingDatasets: () => request<TrainingDatasetSnapshot[]>("/api/model-intelligence/datasets"),
  buildTrainingDataset: (payload: Record<string, unknown>) => request<TrainingDatasetSnapshot>("/api/model-intelligence/datasets/build", { method: "POST", body: JSON.stringify(payload) }),
  scientificModels: () => request<ScientificModelRecord[]>("/api/model-intelligence/models"),
  trainScientificModel: (payload: Record<string, unknown>) => request<{ model: ScientificModelRecord; evaluation: { metrics?: Record<string, number>; [key: string]: unknown } }>("/api/model-intelligence/train", { method: "POST", body: JSON.stringify(payload) }),
  workflowRuns: () => request<WorkflowRun[]>("/api/orchestration/runs"),
  startWorkflow: (payload: Record<string, unknown>) => request<WorkflowRun>("/api/orchestration/runs", { method: "POST", body: JSON.stringify(payload) }),
  researchClaims: () => request<ResearchClaim[]>("/api/research-sources/claims"),
  previewDesign: (payload: Record<string, unknown>) => request<{ design: Record<string, unknown>; constraints: Record<string, unknown>; ready_for_scientist_review: boolean }>("/api/research-intelligence/design/full-factorial", { method: "POST", body: JSON.stringify(payload) }),
  scienceCalculator: (path: string, values: Record<string, unknown>) => request<Record<string, unknown>>(`/api/science-calculators/${path}`, { method: "POST", body: JSON.stringify({ values }) }),
  campaigns: () => request<ResearchCampaign[]>("/api/research-campaigns"),
  createCampaign: (payload: Record<string, unknown>) => request<ResearchCampaign>("/api/research-campaigns", { method: "POST", body: JSON.stringify(payload) }),
  approveCampaign: (id: string, reviewer: string, note: string) => request<ResearchCampaign>(`/api/research-campaigns/${id}/approve`, { method: "POST", body: JSON.stringify({ reviewer, note }) }),
  launchCampaignStage: (id: string, context: Record<string, unknown>) => request<ResearchCampaign>(`/api/research-campaigns/${id}/launch-next-stage`, { method: "POST", body: JSON.stringify({ context }) }),
  reviewCampaignStage: (id: string, decision: "accepted" | "rejected", reviewer: string, note: string) => request<ResearchCampaign>(`/api/research-campaigns/${id}/review-stage`, { method: "POST", body: JSON.stringify({ decision, reviewer, note }) }),
  cancelCampaign: (id: string, actor: string, reason: string) => request<ResearchCampaign>(`/api/research-campaigns/${id}/cancel`, { method: "POST", body: JSON.stringify({ actor, reason }) }),
  advancedCalibrateTwin: (payload: Record<string, unknown>) => request<Record<string, unknown>>("/api/advanced-research/digital-twins/calibrations", { method: "POST", body: JSON.stringify(payload) }),
  advancedValidateTwin: (id: string, payload: Record<string, unknown>) => request<Record<string, unknown>>(`/api/advanced-research/digital-twins/calibrations/${id}/validate`, { method: "POST", body: JSON.stringify(payload) }),
  advancedProposeBatch: (payload: Record<string, unknown>) => request<Record<string, unknown>>("/api/advanced-research/sequential-design/propose", { method: "POST", body: JSON.stringify(payload) }),
  advancedPropagateUncertainty: (payload: Record<string, unknown>) => request<Record<string, unknown>>("/api/advanced-research/uncertainty/linear-propagation", { method: "POST", body: JSON.stringify(payload) }),
  advancedCreateExchange: (payload: Record<string, unknown>) => request<Record<string, unknown>>("/api/advanced-research/cross-lab/exchange-envelope", { method: "POST", body: JSON.stringify(payload) }),
  advancedVerifyExchange: (payload: Record<string, unknown>) => request<Record<string, unknown>>("/api/advanced-research/cross-lab/verify-envelope", { method: "POST", body: JSON.stringify(payload) }),
  advancedFederatedPreview: (payload: Record<string, unknown>) => request<Record<string, unknown>>("/api/advanced-research/federated/aggregate", { method: "POST", body: JSON.stringify(payload) }),
  advancedMonitorResiduals: (payload: Record<string, unknown>) => request<Record<string, unknown>>("/api/advanced-research/drift/residuals", { method: "POST", body: JSON.stringify(payload) }),
  advancedSimulateBattery: (payload: Record<string, unknown>) => request<Record<string, unknown>>("/api/advanced-research/simulation/battery", { method: "POST", body: JSON.stringify({ parameters: payload }) }),
  advancedFederatedModelUpdates: (payload: Record<string, unknown>) => request<Record<string, unknown>>("/api/advanced-research/federated/model-updates/aggregate", { method: "POST", body: JSON.stringify(payload) }),
  advancedRepeatability: (payload: Record<string, unknown>) => request<Record<string, unknown>>("/api/advanced-research/repeatability/summarize", { method: "POST", body: JSON.stringify(payload) }),
  advancedLabEffects: (payload: Record<string, unknown>) => request<Record<string, unknown>>("/api/advanced-research/labs/effects/summarize", { method: "POST", body: JSON.stringify(payload) }),
};
