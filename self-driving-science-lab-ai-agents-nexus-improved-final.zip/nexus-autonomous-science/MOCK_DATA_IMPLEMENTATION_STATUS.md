# Mock data implementation status

## Completed

- Deterministic generator with fixed UTC timestamps, seed control, configurable per-category counts, and `demo`, `small`, `medium`, and `large` CLI scales.
- Separate JSON exports for each data category and a dataset metadata file.
- 23 linked categories covering programs through reports, including 2,000 observations; the large profile generates 11,265 records.
- Referential-integrity, timestamp-order, and synthetic-provenance validation.
- Read-only paginated, searchable, sortable API, with program filtering.
- Research dashboard project explorer with calculated counts, search, program filter, pagination, and linked project detail records (hypotheses, proposals, executions, observations, findings).
- Transparent synthetic belief updates and expected-information-gain-per-compute-hour next-experiment rankings that exclude completed proposals.
- Project analysis API and dashboard metrics for sample size, mean, median, sample SD, standard error, and a small-sample-aware 95% mean interval; missing/invalid/duplicate data, uncertainty gaps, and potential outliers are flagged explicitly. Outliers remain included.
- Quality-versus-compute Pareto analysis with an interactive hard compute cap; infeasible candidates are excluded from the frontier and failed attempts still count toward compute cost.
- Guarded reset utility, documentation, and regression tests.
- Exported large fixture set: 11,265 records across 23 JSON category files, approximately 4.7 MB uncompressed.

## Validation performed

- `python -m pytest -o addopts='' -q`: 244 tests passed.
- `python -m compileall -q app tests scripts`: passed.
- `python scripts/generate_mock_data.py --seed 42 --scale large`: generated 11,265 records, including 15 programs, 60 projects, and 2,000 observations.
- `python scripts/validate_mock_data.py`: all checked references, timestamps, metric ranges, and provenance markers valid.
- Frontend `npm run typecheck`: passed.
- Frontend `npm run lint` (TypeScript check): passed.
- Frontend `npm run build`: passed.
- Live HTTP smoke test for project analysis, source hash, and confidence-interval response: passed.
- Live HTTP smoke test for Pareto ranking, source hash, and hard compute cap: passed.
- `git diff --check`: passed.

## Remaining work

- Expand UI exploration beyond the project table to hypotheses, experiments, executions, evaluations, agent activity, compute, findings, and reports.
- Add client-side views for the five walkthroughs and richer comparisons/visualizations.
- Connect generated research fixtures to persistent database seed/migration workflows only if a deployment explicitly wants them; the current API keeps the synthetic universe isolated from operational laboratory records.
- Perform browser-level visual and interaction testing in a running browser session.
