# NEXUS Autonomous Science Network

**A governed, multi-agent operating-system foundation for eight connected self-driving laboratories.**

NEXUS is a full-stack starter application for coordinating scientific objectives, specialist agent workflows, candidate discovery, experiment proposals, human review, digital-twin simulations, scientific data quality, and provenance. The initial demonstrator is an AI-assisted inorganic solid-state electrolyte discovery workflow in SDL1. The platform is designed so that other laboratories keep their own domain methods while sharing identity, workflow, data, governance, and learning infrastructure.

> **Important operating boundary:** this repository is a software foundation and deterministic demonstration environment. Seed records and digital-twin outputs are synthetic. Physical laboratory execution, robotic motion, synthesis, liquid handling, instrument start commands, and biological wet-lab operations are deliberately disabled. AI agents can analyze and propose; deterministic software gates and qualified humans govern consequential actions.

---

## 1. Product scope

The repository implements the foundations described in the NEXUS science-lab specification:

- Eight laboratories, SDL0–SDL7, with distinct scientific responsibilities.
- A seeded registry of 100 specialist agent capability profiles across ten departments.
- Versionable scientific objectives and a conservative objective compiler.
- A hypothesis and candidate-material foundation for the SDL1 battery-materials demonstration.
- Experiment lifecycle state transitions with explicit review stages.
- Approval requests and review decisions.
- A digital-twin simulation path that produces explicitly synthetic outputs.
- Experiment selection and multi-objective candidate ranking baselines.
- Resource-schedule previews that do not reserve equipment.
- Scientific data records, data-quality assessments, and six data-layer views.
- Audit events, lineage helpers, agent contracts, model cards, and capability manifests.
- Instrument and robotics adapter contracts that do not issue physical commands.
- A Next.js dashboard with a local demo fallback when the backend is offline.

The foundation intentionally favors clear contracts and testable baselines over fake claims of autonomous scientific capability. For example, the registry has 100 specialist profiles, but those profiles are not 100 independently trained models or 100 live LLM processes.

## 2. Eight-laboratory network

| Lab | Name | Primary scientific remit |
|---|---|---|
| SDL0 | AI & Robotics | Agent research, robotics simulation, instrumentation interfaces, reliability, and safety engineering |
| SDL1 | Inorganic Materials | Crystal structures, defects, ionic transport, electrochemistry, batteries, semiconductors, and catalysis |
| SDL2 | Organic Chemistry | Molecular discovery, reaction mechanisms, synthesis feasibility, purification, and analytical confirmation |
| SDL3 | Medicinal Chemistry | Structure–activity research, binding and selectivity evidence, assay quality, and metabolic-stability measurements |
| SDL4 | Polymers | Molecular architecture, crystallization, phase behavior, rheology, mechanics, and degradation |
| SDL5 | Formulations | Composition, compatibility, stability, particle attributes, and batch consistency |
| SDL6 | Organoids & Organ-on-Chip | Biological-model provenance, imaging, functional characterization, mechanobiology, and replication |
| SDL7 | Scale-up & Process Engineering | Reaction kinetics, mixing, heat and mass transfer, telemetry, scale-up, and manufacturing feasibility |

All labs share persistent identities, objectives, hypotheses, samples, experiments, data contracts, provenance, agent permissions, model governance, approval workflows, and audit trails. They do **not** share one generic scientific method.

## 3. Architecture

```mermaid
flowchart TB
  UI[Next.js / React command centre] --> API[FastAPI application]
  API --> DB[(SQLAlchemy database)]
  API --> REG[Lab and agent registries]
  API --> OBJ[Objective and hypothesis services]
  API --> ORCH[Workflow preview / future LangGraph adapter]
  API --> OPT[Active-learning and candidate ranking]
  API --> GOV[Lifecycle, approval and policy gates]
  API --> TWIN[Digital-twin simulation]
  API --> DATA[Data quality and provenance]
  REG --> SDL0[SDL0 · AI & Robotics]
  REG --> SDL1[SDL1 · Inorganic Materials]
  REG --> SDL2[SDL2 · Organic Chemistry]
  REG --> SDL3[SDL3 · Medicinal Chemistry]
  REG --> SDL4[SDL4 · Polymers]
  REG --> SDL5[SDL5 · Formulations]
  REG --> SDL6[SDL6 · Organoids]
  REG --> SDL7[SDL7 · Process Engineering]
  GOV --> HUMAN[Qualified scientist / operator review]
  TWIN --> SYNTH[Clearly labelled synthetic outputs]
  DATA --> TRACE[Audit and provenance records]
```

### Application stack

- **Frontend:** Next.js 16, React 19, TypeScript, Recharts 3, Lucide.
- **Backend:** Python 3.11+, FastAPI, Pydantic 2, SQLAlchemy 2.
- **Local database:** SQLite for zero-friction startup; PostgreSQL can be configured with `NEXUS_DATABASE_URL`.
- **Tests:** pytest and FastAPI TestClient.
- **Future integration boundaries:** LangGraph, BoTorch/Ax/Atlas, pgvector, Neo4j, MLflow, ASE, pymatgen, RDKit, PyTorch, OpenCV, ROS 2, MoveIt 2, Gazebo, MuJoCo, Isaac Sim, Opentrons, object storage, and instrument-vendor adapters.

Optional production-scale technologies are documented as integration targets, not falsely represented as active dependencies in this starter.

## 4. Repository layout

```text
nexus-autonomous-science/
├── backend/
│   ├── app/
│   │   ├── api/                 # REST routes
│   │   ├── core/                # Settings, DB, errors, logging
│   │   ├── models/              # SQLAlchemy entities
│   │   ├── schemas/             # API / scientific data contracts
│   │   └── services/
│   │       ├── agents/          # Domain-specific specialist services
│   │       └── integrations/    # Instrument and storage contracts
│   ├── tests/                   # Unit and contract tests
│   ├── requirements.txt
│   └── .env.example
├── frontend/
│   ├── app/                     # Next.js app entry and global styling
│   └── src/
│       ├── components/          # Reusable application components
│       ├── features/            # Overview, labs, agents, discovery, etc.
│       ├── lib/                 # API client and deterministic fallback
│       └── types/               # Shared TypeScript contracts
├── docker-compose.yml
├── Makefile
└── README.md
```

## 5. Local development

### Prerequisites

- Python 3.11 or newer.
- Node.js 20.9 or newer and npm (Node.js 26 LTS is the current recommended baseline).

### Start the API

```bash
cd backend
python -m venv .venv
source .venv/bin/activate       # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload --port 8000
```

The API creates its schema and seeds the synthetic demo dataset at startup. Open:

- API health: `http://localhost:8000/health`
- Interactive API docs: `http://localhost:8000/docs`
- OpenAPI schema: `http://localhost:8000/openapi.json`

### Start the web application

In a second terminal:

```bash
cd frontend
npm install
cp .env.example .env.local
npm run dev
```

Open `http://localhost:3000`. The API URL is controlled by `NEXT_PUBLIC_API_URL` in `frontend/.env.local`.

The dashboard has a local demo fallback. That fallback is for interface exploration only; it does not replace the API's persistence, event history, or governance checks.

### Start with Docker Compose

```bash
docker compose up --build
```

The web app is exposed on port 3000 and the API on port 8000. The backend database is persisted in a named Docker volume. For local development without Docker, use the commands above.

## 6. Demo walkthrough

1. Open **Command center** to review the eight-lab network, active experiment states, key metrics, and recent audit events.
2. Open **Lab network** and inspect SDL0–SDL7. Research program labels are domain-specific.
3. Open **Agent operations** to inspect the 100 specialist capability profiles, departments, permissions, and demo task execution.
4. Open **Materials discovery** to review the synthetic SDL1 electrolyte candidate set and transparent ranking components.
5. Open **Experiments**, create an experiment proposal, and inspect its detail panel.
6. Request approval. The proposal moves through deterministic review states and appears in **Governance**.
7. Approve the proposal as a human reviewer. Approval only allows the synthetic demonstration flow.
8. Run **Digital-twin simulation** from an approved experiment. It produces labelled synthetic values and audit events.
9. Open **Scientific data** to inspect new records, evidence origin, quality classification, and data layers.
10. Open **Digital twin** to inspect instrument/workflow/lab twin status and the persistent physical-control-disabled flag.

A seed approval (`APR-0001`) is included to make the governance interface immediately demonstrable.

## 7. Experiment lifecycle and governance

The lifecycle state machine is deliberately explicit:

```text
draft
  -> validated
  -> feasibility_review
  -> resource_review
  -> safety_review
  -> awaiting_approval
  -> approved
  -> scheduled
  -> prepared
  -> executing
  -> data_acquisition
  -> data_validation
  -> scientific_interpretation
  -> model_update (optional)
  -> completed
```

Failure, cancellation, and quarantine are explicit terminal or recovery states. Invalid transitions return a conflict response rather than silently mutating the experiment.

### Five states the product must never conflate

1. **Scientific intent:** what the scientist wants to learn.
2. **Proposed action:** what an agent suggests.
3. **Authorized action:** what passed deterministic checks and the relevant approval workflow.
4. **Observed result:** what a validated instrument or computational method actually produced.
5. **Scientific conclusion:** what can reasonably be inferred, with limitations and uncertainty.

The current starter's simulation path only generates synthetic demo outputs. An approval record does not make physical execution available. The request schema excludes `physical` mode; the authorization service independently rejects physical execution; mock instrument adapters reject physical actions.

## 8. Scientific evidence and data model

The application separates these evidence origins:

- `measured_value`
- `computational_result`
- `model_prediction`
- `literature_value`
- `human_observation`
- `inferred_value`
- `synthetic_simulation`

The starter database models laboratories, agents, objectives, hypotheses, candidates, experiments, approvals, measurements, datasets, audit events, and instruments.

The NEXUS data fabric describes six logical layers:

| Layer | Purpose | Starter status |
|---|---|---|
| Raw | Original instrument files, images, spectra, streams, and source artifacts | Adapter required |
| Validated | Schema, identity, unit, calibration, and quality checks | Baseline checks available |
| Processed | Normalized/transformed records and extracted features | Integration target |
| Scientific | Measurements, observations, and interpretation records | Demo records available |
| AI | Features, training data, predictions, and evaluation results | Model/data integration target |
| Knowledge | Hypotheses, mechanisms, conclusions, and evidence graph | In-process baseline helpers |

Raw evidence should be immutable in a production deployment. A corrected interpretation or unit conversion should create a derived record with a transformation reference; it should not overwrite the original instrument data.

## 9. API map

| Method | Route | Purpose |
|---|---|---|
| GET | `/health` | Process health |
| GET | `/api/overview` | Network and experiment summary |
| GET | `/api/labs` | SDL0–SDL7 registry |
| GET | `/api/agents` | Specialist profiles (filters supported) |
| POST | `/api/agents/{agent_id}/run` | Deterministic agent demo review |
| GET / POST | `/api/objectives` | Objective registry and creation |
| POST | `/api/objectives/compile` | Rule-based objective compilation |
| POST | `/api/objectives/{id}/revise` | Create immutable objective version |
| GET / POST | `/api/experiments` | Experiment registry and proposal creation |
| POST | `/api/experiments/{id}/transition` | Enforce lifecycle transition |
| POST | `/api/experiments/{id}/simulate` | Run approved synthetic twin simulation |
| GET | `/api/governance/approvals` | Approval queue |
| POST | `/api/governance/experiments/{id}/request-approval` | Request review |
| POST | `/api/governance/approvals/{id}/decision` | Approve/reject request |
| GET | `/api/discovery/candidates` | SDL1 candidate register |
| GET | `/api/discovery/next-batch` | Candidate selection preview |
| GET | `/api/data/datasets` | Dataset registry |
| GET | `/api/data/measurements` | Measurement register and quality review |
| GET | `/api/data/quality` | Data quality and layer summary |
| GET | `/api/twin` | Digital-twin status |
| GET | `/api/events` | Append-only event feed |
| POST | `/api/workflow/preview` | Deterministic workflow preview |
| POST | `/api/scheduler/preview` | Advisory slot proposal |
| GET | `/api/models` | Model cards and limitations |
| GET | `/api/science/domains` | Eight domain-specific science capability manifests |
| POST | `/api/science/domains/validate` | Check modality and laboratory-specific quality gates |
| POST | `/api/science/evidence/assess` | Conservative evidence-grade preview |
| POST | `/api/science/evidence/contradictions` | Numeric contradiction report without automatic resolution |
| GET | `/api/agents/evaluation-framework` | Multidimensional agent benchmark definitions |
| POST | `/api/agents/evaluations/preview` | Evaluation preview; never auto-promotes an agent |
| POST | `/api/lineage/validate` | Derived-artifact transformation lineage validation |
| GET | `/api/system/capabilities` | Implemented vs. planned capabilities |

## 10. Multi-agent architecture

The current implementation gives agents identity, purpose, department, lab association, capability tags, run count, last-run metadata, and permission levels. It provides ten departments with ten specialist profiles each. Service modules establish domain-specific boundaries for research intelligence, inorganic materials, organic chemistry, medicinal chemistry, polymer science, formulations, biological systems, process engineering, data intelligence, and governance/reliability.

The deterministic workflow preview is a deliberately small graph:

1. Objective review.
2. Candidate screen.
3. Feasibility review.
4. Human approval checkpoint.

It does not make concurrent LLM calls. A future LangGraph supervisor can replace the preview runner while retaining the same typed inputs, outputs, policy checks, audit events, and interrupt/resume contract.

Agent evaluation should be multidimensional. Track scientific correctness, constraint compliance, uncertainty calibration, schema compliance, tool-call reliability, evidence attribution, reproducibility, human correction rate, recovery behavior, and out-of-domain detection separately. A generic “agent accuracy” score is not enough.

## 11. SDL1 battery-materials demonstrator

The initial workflow is designed around solid-state electrolyte candidates and the scientific objective:

> Identify candidate inorganic solid-state electrolytes with promising ionic transport, electrochemical stability, and practical synthesis feasibility.

The seeded data uses familiar candidate families as demonstration labels. All seed candidate properties and rankings are synthetic illustrative values. They are not literature values, measured material performance, or recommendations for synthesis.

The objective's three illustrative dimensions are:

- Ionic conductivity.
- Electrochemical stability.
- Synthesis feasibility.

A production implementation should bring in source-identified structures and datasets, ensure a valid crystallographic representation, establish model training and validation splits, add calibrated uncertainty and applicability-domain checks, and connect any eventual physical protocol to local review and instrument-specific acceptance testing.

## 12. Testing

```bash
cd backend
pytest -q
python -m compileall -q app tests
```

Tests cover lifecycle transitions, safety gates, data-quality rules, candidate optimization, objective compilation, and instrument adapter boundaries.

A full end-to-end integration test should verify this closed loop:

1. Create a synthetic objective.
2. Register a sample.
3. Create a proposal.
4. Request and decide approval.
5. Run only the synthetic twin path.
6. Ingest synthetic measurements.
7. Validate data quality.
8. Confirm origin labels and lineage.
9. Reconstruct audit history.
10. Verify the physical-control flag remains false.

## 13. Production hardening backlog

This is a foundation, not a production-certified laboratory control system. Before real deployment, implement and validate at least:

### Identity and security

- Authentication and role-based authorization.
- Lab/workspace tenancy and resource-level access controls.
- Secrets management and signed service-to-service identity.
- Audit retention, access policies, encryption, backup, and recovery.
- API rate limits, request size limits, and operational threat modelling.

### Data infrastructure

- PostgreSQL migrations with Alembic.
- S3/MinIO raw artifact storage with content hashes and retention policies.
- pgvector or a dedicated vector service for embeddings.
- Neo4j or an equivalent persistent evidence graph.
- Versioned scientific data contracts and migration tooling.
- Unit validation with a mature dimensional-analysis library.
- Immutable raw datasets and reproducible transformation records.

### AI / scientific ML

- Domain-labelled benchmark datasets and held-out evaluation.
- Model cards, model registry, training data lineage, and evaluation gates.
- Calibrated uncertainty and out-of-domain detection.
- Domain-specific molecular, crystal, image, spectral, and time-series representations.
- Active-learning algorithms validated against historical decision replays.
- LLM outputs treated as untrusted proposals, schema-validated before use.
- Scientific claim attribution and contradictory-evidence retention.

### Agent orchestration

- LangGraph supervisor with typed state and interrupt/resume support.
- Bounded retries, deadlines, idempotency keys, circuit breakers, and tracing.
- Explicit agent capabilities and least-privilege permissions.
- Agent benchmark promotion lifecycle and shadow deployment.
- Human escalation for unresolved disagreement or out-of-domain inputs.

### Robotics and laboratory equipment

- A local edge gateway physically separated from the cloud API.
- Vendor-specific drivers and machine-readable capability manifests.
- Hardware interlocks, emergency stop, local operator controls, and safety validation.
- Simulation-to-real acceptance testing and workspace-specific validation.
- Idempotent command handling and four-stage acknowledgements: received, validated, accepted, completed.
- Instrument calibration tracking, maintenance history, clock synchronization, and fault recovery.
- Qualified domain experts and local safety approvals for each protocol.

### Observability and operations

- OpenTelemetry traces, Prometheus metrics, and structured log correlation IDs.
- Durable workflow/event bus such as NATS or Kafka.
- Worker queues, dead-letter queues, and checkpoint persistence.
- CI security scanning, dependency pinning, SBOM, backups, and disaster recovery tests.
- SLOs for API availability, ingestion lag, event durability, and workflow recovery.

## 14. Important limitations

- The 100 agents are registry profiles with deterministic demo execution, not 100 active AI model instances.
- The objective compiler is a rule-based baseline, not a scientific language model.
- Candidate ranks are illustrative heuristic outputs, not calibrated Bayesian optimization.
- No trained property-prediction weights are shipped.
- The digital twin is a deterministic demo simulator, not a validated physical system twin.
- No ROS 2 or vendor hardware driver is enabled.
- No physical instrument, robot, chemical, biological, or synthesis operation can be triggered.
- Local fallback data may be used by the UI when the API is offline; fallback interactions are not persisted.
- Authentication, multi-tenant controls, database migrations, and production-grade deployment controls remain to be implemented.

## 15. Development principles

1. Scientists remain the scientific authority.
2. Predictions are not measurements.
3. Simulation success is not physical validation.
4. Raw evidence is never silently overwritten.
5. Contradictory evidence remains visible.
6. Agent permissions are explicit and narrow.
7. Approval is a workflow event, not a checkbox shortcut.
8. Every conclusion should be traceable to evidence and transformations.
9. Cross-lab knowledge transfer must check domain shift, methods, units, and instrument differences.
10. Every capability must be tested against measurable acceptance criteria.

---

## License and use

No license has been selected in this starter. Add a project-appropriate license before public distribution. Do not deploy this starter as a controller for live laboratory equipment without the engineering, security, hardware, and safety validation described above.

## 16. Volume II additions

The second implementation volume extends the foundation with domain-specific computational methods, persistent multi-stage research campaigns, hash-linked workflow checkpoints, 24 domain-specific agent benchmark cases across SDL0–SDL7, and an event outbox with expiring worker leases and bounded retries.

### New workspaces

- **Research campaigns:** create a programme tied to a lab-matched research objective, request human approval, launch one analytical workflow at a time, and review every stage before advancing.
- **Science methods:** run supported electrochemistry, diffraction, battery, polymer, spectroscopy, kinetics, formulation, microscopy-mask and replicate calculations.
- **Model and agent evaluation:** score schema and constraint compliance, test evidence attribution, and require named human adjudication for scientific correctness.

### New API groups

- `/api/research-campaigns` — staged campaign lifecycle and append-only event history.
- `/api/benchmark-intelligence` — domain benchmark suite catalogue, case scoring and human-reviewed aggregation.
- `/api/science-calculators` — computational scientific methods.
- `/api/science-foundations` — contracts, unit semantics, schema versions, provenance and release gates.
- `/api/orchestration/runs/{id}/checkpoints` — workflow checkpoint inspection and integrity.
- `/api/outbox` — event leasing, acknowledgement, retries, lease recovery and metrics.

See [`docs/VOLUME_II_ENGINEERING_EXPANSION.md`](docs/VOLUME_II_ENGINEERING_EXPANSION.md) for module maps, lifecycle rules and route details.

The additional services remain analysis-only. Campaign approval is not approval to run a physical experiment, and benchmark eligibility is not production promotion. Run database migrations before upgrading an existing deployment; the starter still does not include Alembic migration files.

The **146-test** count in [`docs/VOLUME_II_VALIDATION.md`](docs/VOLUME_II_VALIDATION.md) is a historical Volume II snapshot, not the current repository result. Current verification is recorded in [`docs/testing/distributed-systems-testing.md`](docs/testing/distributed-systems-testing.md).


## 17. Volume III additions — advanced research and multi-lab learning

Volume III adds calibrated digital-twin utilities, uncertainty propagation and ranking, sequential design, value-of-information analysis, simplified scientific simulations, multi-fidelity correction, Bayesian evidence updates, sensitivity and replication analysis, sensor fusion, sample custody, evidence synthesis, lab-effect diagnostics, repeatability analysis, blocked computational design assignments, and cross-laboratory data/model-transfer services.

The new routes are mounted under `/api/advanced-research`. The `Advanced Research` frontend workspace exposes selected methods for interactive review. Federated parameter-delta aggregation produces a review artefact only; it does not update or release a model. The privacy ledger is an accounting control, not a complete differential-privacy implementation. Computational assignment plans do not assign physical samples.

See [`docs/VOLUME_III_ADVANCED_RESEARCH.md`](docs/VOLUME_III_ADVANCED_RESEARCH.md) for service descriptions, API groups, scientific cautions, and production milestones, and [`docs/VOLUME_III_VALIDATION.md`](docs/VOLUME_III_VALIDATION.md) for the validation scope.

The **207-test** count in [`docs/VOLUME_III_VALIDATION.md`](docs/VOLUME_III_VALIDATION.md) is also historical. Current backend and frontend results are recorded in [`docs/testing/distributed-systems-testing.md`](docs/testing/distributed-systems-testing.md). Physical laboratory execution remains disabled.


## 18. Distributed-systems status and operating limits

This repository remains a modular monolith and a local/demo foundation. It does not provide a production worker fleet, external message broker, authentication, tenant isolation, or physical laboratory control. Do not expose it to untrusted networks or treat browser CORS settings as authorization.

The API now distinguishes process liveness (`GET /health`) from database readiness (`GET /ready`). Request IDs are validated, returned in `X-Request-ID`, exposed to browser clients, and attached to application log records. The Compose API healthcheck uses `/ready`.

The database outbox stores domain events for an external publisher; no publisher is configured. A database unique index enforces one outbox row per `event_key`, and identical retries return the original row while conflicting content is rejected. Leases, bounded retries, recovery, and dead-letter state are implemented. Publication is nevertheless **at-least-once**: a publisher can send an event and crash before acknowledgement, so consumers must deduplicate by durable event identity. SQLite does not provide the row-lock behavior required for multiple concurrent claimers; use a verified PostgreSQL deployment and contention tests before enabling multiple publishers.

Workflow records and hash-linked checkpoints are persisted for synchronous analytical demo runs. They are not an asynchronous job queue. Recovery remains an operator-facing advisory and never resumes work automatically; a recovery boundary can only be a completed checkpoint, and physical-side-effect workflows remain ineligible. Sample identity starts unverified and must use the verification route; synthetic dataset snapshots are rejected at the scientific-model training boundary. Artifact records now validate parent existence/ownership/lineage and scope retries by artifact code, but stored bytes are not verified against supplied digests.

See the [current-state assessment](docs/architecture/current-state-assessment.md), [distributed architecture](docs/architecture/distributed-systems-architecture.md), [consistency guide](docs/architecture/data-consistency.md), [reliability guide](docs/operations/reliability-guide.md), [queue operations guide](docs/operations/queue-operations.md), [security architecture](docs/security/distributed-security.md), and [distributed testing strategy](docs/testing/distributed-systems-testing.md) for the verified scope and remaining work.
