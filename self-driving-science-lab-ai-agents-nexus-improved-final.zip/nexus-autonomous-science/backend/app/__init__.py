"""NEXUS application package."""
