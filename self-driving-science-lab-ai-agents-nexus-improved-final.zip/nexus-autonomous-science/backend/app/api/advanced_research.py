"""Advanced digital-twin, sequential-design and cross-lab research APIs."""
from __future__ import annotations
from hashlib import sha256
import json
from uuid import uuid4
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field, ConfigDict
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.entities import (DigitalTwinCalibrationRecord, AdvancedResearchAnalysisRecord,
                                 PrivacyBudgetLedgerRecord, LabExchangeEnvelopeRecord)
from app.services.audit import record_event
from app.services.advanced_research.twin_calibration import (fit_affine_calibrator,
    predict_calibrated, validate_calibrator, group_holdout_split)
from app.services.advanced_research.uncertainty_propagation import (propagate_monte_carlo,
    split_conformal_radius, apply_conformal_interval, decompose_uncertainty)
from app.services.advanced_research.sequential_design import (propose_sequential_batch,
    pareto_front)
from app.services.advanced_research.multi_lab_exchange import (create_exchange_envelope,
    verify_exchange_envelope, compatibility_matrix, payload_digest)
from app.services.advanced_research.federated_aggregation import aggregate_lab_statistics
from app.services.advanced_research.model_transfer import evaluate_model_transfer, transfer_learning_plan
from app.services.advanced_research.drift_monitoring import residual_monitor, compare_feature_windows
from app.services.advanced_research.digital_twin_ensemble import combine_twin_predictions, twin_fidelity_card
from app.services.advanced_research.value_of_information import (expected_value_of_sample_information,
    rank_information_actions, stopping_decision)
from app.services.advanced_research.simulation_models import (simulate_lumped_thermal_response,
    simulate_first_order_kinetics, simulate_simple_battery_discharge, simulate_cstr_concentration,
    arrhenius_rate_ratio)
from app.services.advanced_research.multi_fidelity import (fit_fidelity_bridge, correct_low_fidelity,
    rank_multi_fidelity)
from app.services.advanced_research.bayesian_evidence import update_hypothesis_probability, compare_hypotheses
from app.services.advanced_research.replication_planning import (estimate_replicates_for_mean_precision,
    replicate_summary)
from app.services.advanced_research.sensitivity_analysis import (finite_difference_sensitivity,
    one_at_a_time_scenarios)
from app.services.advanced_research.protocol_diff import (compare_protocol_versions, protocol_compatibility)
from app.services.advanced_research.lab_capacity import capacity_preview
from app.services.advanced_research.sensor_fusion import validate_sensor_stream, fuse_scalar_sensors, align_sensor_events
from app.services.advanced_research.sample_custody import create_custody_record, transition_custody, verify_custody_chain
from app.services.advanced_research.evidence_synthesis import synthesize_claim_evidence, build_evidence_matrix
from app.services.advanced_research.twin_observability import assess_twin_health, compare_twin_sync
from app.services.advanced_research.failure_attribution import rank_failure_hypotheses, propose_discriminating_checks
from app.services.advanced_research.uncertainty_ranking import robust_candidate_ranking, interval_dominance
from app.services.advanced_research.data_interoperability import compare_dataset_contracts, validate_mapping_rules, convert_measurement_value
from app.services.advanced_research.method_selection import recommend_methods
from app.services.advanced_research.federated_model_updates import (aggregate_model_deltas, compare_federated_rounds)
from app.services.advanced_research.lab_effects import summarize_lab_effects
from app.services.advanced_research.blocked_assignment import create_blocked_assignment, audit_assignment
from app.services.advanced_research.repeatability import repeatability_summary, bland_altman_summary

from app.services.advanced_research.privacy_ledger import (create_privacy_ledger, get_privacy_ledger, ledger_snapshot, preflight_release, commit_release, pause_ledger)
from app.services.advanced_research.federated_aggregation import PrivacyBudget

router = APIRouter(prefix="/advanced-research", tags=["advanced research and digital twin intelligence"])


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class TwinCalibrationRequest(StrictModel):
    model_id: str = Field(min_length=2, max_length=120)
    model_version: str = Field(default="0.1.0", max_length=40)
    domain: str = Field(min_length=2, max_length=64)
    feature_names: list[str] = Field(min_length=1, max_length=20)
    records: list[dict] = Field(min_length=5, max_length=5000)
    ridge: float = Field(default=1e-8, ge=0, le=1000)
    created_by: str = Field(default="NEXUS scientist", min_length=2, max_length=120)
    synthetic: bool = True


class TwinPredictionRequest(StrictModel):
    features: dict[str, float]


class TwinValidationRequest(StrictModel):
    validation_domain: str
    records: list[dict] = Field(min_length=5, max_length=5000)


class UncertaintyRequest(StrictModel):
    means: dict[str, float]
    standard_deviations: dict[str, float]
    coefficients: dict[str, float]
    intercept: float = 0.0
    correlation: list[list[float]] | None = None
    samples: int = Field(default=5000, ge=100, le=500000)
    seed: int = 11
    lower_quantile: float = Field(default=.025, ge=0, le=1)
    upper_quantile: float = Field(default=.975, ge=0, le=1)


class ConformalRequest(StrictModel):
    actual: list[float] = Field(min_length=5, max_length=100000)
    predicted: list[float] = Field(min_length=5, max_length=100000)
    alpha: float = Field(default=.1, gt=0, lt=1)
    group_ids: list[str] | None = None


class BatchDesignRequest(StrictModel):
    candidates: list[dict] = Field(min_length=1, max_length=10000)
    feature_names: list[str] = Field(min_length=1, max_length=40)
    best_observed: float
    direction: str = "maximize"
    strategy: str = "expected_improvement"
    batch_size: int = Field(default=4, ge=1, le=100)
    constraints: list[dict] = Field(default_factory=list, max_length=100)
    feature_ranges: dict[str, tuple[float, float]] = Field(default_factory=dict)
    family_key: str = "family"
    max_per_family: int = Field(default=1, ge=1, le=100)
    diversity_weight: float = Field(default=.15, ge=0, le=100)
    cost_exponent: float = Field(default=1, ge=0, le=4)


class ExchangeRequest(StrictModel):
    source_laboratory: str
    target_laboratory: str
    subject_type: str
    subject_id: str
    domain: str
    schema_version: str = "1.0.0"
    payload: dict
    evidence_origin: str
    synthetic: bool = True
    classification: str = "internal"
    consent_scope: str = "research_review_only"
    allowed_fields: list[str] | None = None
    shared_secret: str | None = None


class ExchangeVerifyRequest(StrictModel):
    envelope: dict
    shared_secret: str | None = None
    require_signature: bool = True


class FederatedAggregationRequest(StrictModel):
    contributions: list[dict] = Field(min_length=2, max_length=8)
    feature_names: list[str] = Field(min_length=1, max_length=50)
    minimum_labs: int = Field(default=3, ge=2, le=8)
    minimum_total_records: int = Field(default=30, ge=2)
    clip_norm: float = Field(default=10, gt=0)


class PrivacyLedgerCreateRequest(StrictModel):
    ledger_key: str = Field(min_length=3, max_length=120)
    epsilon_limit: float = Field(gt=0)
    delta_limit: float = Field(gt=0, lt=1)


class PrivacyReleaseRequest(StrictModel):
    epsilon: float = Field(gt=0)
    delta: float = Field(gt=0, lt=1)
    count: int = Field(default=1, ge=1, le=10000)


class FederatedPrivateRequest(FederatedAggregationRequest):
    ledger_key: str = Field(min_length=3, max_length=120)
    epsilon: float = Field(gt=0)
    delta: float = Field(gt=0, lt=1)
    release_key: str = Field(min_length=3, max_length=140)


class ModelTransferRequest(StrictModel):
    model_card: dict
    source_context: dict
    target_context: dict
    source_validation: dict | None = None
    target_holdout_metrics: dict | None = None
    maximum_smd: float = Field(default=.25, gt=0, le=10)


class ResidualMonitorRequest(StrictModel):
    residuals: list[float] = Field(min_length=5, max_length=100000)
    baseline_mean: float = 0
    baseline_sd: float | None = Field(default=None, gt=0)
    ewma_smoothing: float = Field(default=.2, gt=0, le=1)
    cusum_allowance: float = Field(default=.5, ge=0)
    cusum_threshold: float = Field(default=5, gt=0)


class TwinEnsembleRequest(StrictModel):
    predictions: list[dict] = Field(min_length=2, max_length=100)
    correlation: list[list[float]] | None = None
    disagreement_threshold: float = Field(default=2, gt=0)


class VoIRequest(StrictModel):
    current_best_utility: float
    posterior_best_utilities: list[float] = Field(min_length=1, max_length=100000)
    experiment_cost: float = Field(default=0, ge=0)
    delay_cost: float = Field(default=0, ge=0)
    risk_penalty: float = Field(default=0, ge=0)


class StopPolicyRequest(StrictModel):
    remaining_budget: float = Field(ge=0)
    minimum_budget: float = Field(ge=0)
    best_recent_improvement: float = Field(ge=0)
    improvement_tolerance: float = Field(ge=0)
    uncertainty_reduction_possible: bool
    unresolved_hard_constraints: list[str] = Field(default_factory=list)
    minimum_evidence_grade_met: bool


class SimulationRequest(StrictModel):
    model_config = ConfigDict(extra="forbid")
    parameters: dict[str, float]


class FidelityBridgeRequest(StrictModel):
    paired: list[dict] = Field(min_length=5, max_length=10000)
    low_key: str = "low_fidelity"
    high_key: str = "high_fidelity"
    group_key: str = "group_id"


class BayesianUpdateRequest(StrictModel):
    prior_probability: float = Field(gt=0, lt=1)
    evidence_items: list[dict] = Field(min_length=1, max_length=1000)
    independence_assumption: bool = False


class ReplicationRequest(StrictModel):
    pilot_standard_deviation: float = Field(gt=0)
    desired_half_width: float = Field(gt=0)
    confidence: float = .95
    minimum_replicates: int = Field(default=3, ge=2)
    maximum_replicates: int = Field(default=10000, ge=3)


class SensitivityRequest(StrictModel):
    parameters: dict[str, float]
    coefficients: dict[str, float]
    intercept: float = 0.0
    relative_step: float = Field(default=1e-4, gt=0, lt=.1)


class CapacityRequest(StrictModel):
    resources: list[dict] = Field(min_length=1, max_length=500)
    tasks: list[dict] = Field(min_length=1, max_length=5000)
    start_at: str | None = None


def _safe(call, *args, **kwargs):
    try:
        return call(*args, **kwargs)
    except (ValueError, TypeError, KeyError, ZeroDivisionError) as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


def _persist_analysis(db: Session, analysis_type: str, request: dict, result: dict,
                      *, laboratory_code: str = "SDL0", domain: str = "advanced_research",
                      created_by: str = "NEXUS analyst", synthetic: bool = False):
    digest = sha256(json.dumps(request, sort_keys=True, default=str).encode()).hexdigest()
    row = AdvancedResearchAnalysisRecord(
        id=str(uuid4()), analysis_key=f"ARA-{uuid4().hex[:12].upper()}",
        analysis_type=analysis_type, laboratory_code=laboratory_code, domain=domain,
        request_digest=digest, request_json=request, result_json=result,
        evidence_origin=result.get("evidence_type", "computational_result"),
        synthetic=synthetic, created_by=created_by)
    db.add(row)
    record_event(db, "ADVANCED_RESEARCH_ANALYSIS_CREATED", "analysis", row.id,
                 actor=created_by, payload={"analysis_type": analysis_type, "request_digest": digest,
                                            "synthetic": synthetic})
    return row


@router.post("/digital-twins/calibrations", status_code=201)
def fit_twin_calibration(request: TwinCalibrationRequest, db: Session = Depends(get_db)):
    result = _safe(fit_affine_calibrator, request.records, feature_names=request.feature_names,
                   ridge=request.ridge, model_id=request.model_id, model_version=request.model_version,
                   domain=request.domain)
    # Identical calibration datasets may be fitted repeatedly; each fit is a distinct artifact.
    result["calibrator_id"] = f"CAL-{uuid4().hex[:12].upper()}"
    result["synthetic_training_data"] = request.synthetic
    row = DigitalTwinCalibrationRecord(id=str(uuid4()), calibrator_key=result["calibrator_id"],
        model_id=request.model_id, model_version=request.model_version, domain=request.domain,
        feature_names=request.feature_names, calibrator_json=result,
        status="research_calibration_candidate", created_by=request.created_by)
    db.add(row)
    record_event(db, "DIGITAL_TWIN_CALIBRATION_FITTED", "twin_calibration", row.id,
                 actor=request.created_by, payload={"model_id": request.model_id, "domain": request.domain,
                                                    "training_record_count": len(request.records)})
    db.commit()
    return row


@router.get("/digital-twins/calibrations")
def list_twin_calibrations(domain: str | None = None, db: Session = Depends(get_db)):
    query = select(DigitalTwinCalibrationRecord).order_by(DigitalTwinCalibrationRecord.created_at.desc())
    if domain: query = query.where(DigitalTwinCalibrationRecord.domain == domain)
    return db.scalars(query.limit(200)).all()


@router.post("/digital-twins/calibrations/{calibration_id}/predict")
def predict_with_twin_calibration(calibration_id: str, request: TwinPredictionRequest,
                                  db: Session = Depends(get_db)):
    row = db.get(DigitalTwinCalibrationRecord, calibration_id)
    if not row: raise HTTPException(status_code=404, detail="Calibration record not found")
    return _safe(predict_calibrated, row.calibrator_json, request.features)


@router.post("/digital-twins/calibrations/{calibration_id}/validate")
def validate_twin_calibration(calibration_id: str, request: TwinValidationRequest,
                              db: Session = Depends(get_db)):
    row = db.get(DigitalTwinCalibrationRecord, calibration_id)
    if not row: raise HTTPException(status_code=404, detail="Calibration record not found")
    result = _safe(validate_calibrator, row.calibrator_json, request.records,
                   validation_domain=request.validation_domain)
    row.validation_json = result
    row.status = result["status"]
    record_event(db, "DIGITAL_TWIN_CALIBRATION_VALIDATED", "twin_calibration", row.id,
                 actor="advanced-research", payload={"status": result["status"], "metrics": result.get("metrics")})
    db.commit()
    return {"calibration": row, "validation": result}


@router.post("/digital-twins/group-holdout")
def twin_group_holdout(request: TwinCalibrationRequest):
    return _safe(group_holdout_split, request.records)


@router.post("/uncertainty/linear-propagation")
def uncertainty_linear(request: UncertaintyRequest):
    missing = set(request.means) - set(request.coefficients)
    if missing: raise HTTPException(status_code=422, detail=f"Missing coefficients for: {sorted(missing)}")
    if set(request.coefficients) != set(request.means):
        raise HTTPException(status_code=422, detail="Coefficient keys must exactly match input variables")
    evaluator = lambda values: request.intercept + sum(request.coefficients[key] * values[key] for key in request.means)
    return _safe(propagate_monte_carlo, means=request.means,
                 standard_deviations=request.standard_deviations, evaluator=evaluator,
                 samples=request.samples, correlation=request.correlation, seed=request.seed,
                 quantiles=(request.lower_quantile, request.upper_quantile))


@router.post("/uncertainty/conformal-calibration")
def conformal_calibration(request: ConformalRequest):
    return _safe(split_conformal_radius, request.actual, request.predicted,
                 alpha=request.alpha, group_ids=request.group_ids)


@router.post("/uncertainty/conformal-intervals")
def conformal_intervals(predictions: list[float], calibration: dict):
    return _safe(apply_conformal_interval, predictions, calibration)


@router.post("/uncertainty/decompose")
def uncertainty_decomposition(payload: dict):
    return _safe(decompose_uncertainty, **payload)


@router.post("/sequential-design/propose")
def sequential_design(request: BatchDesignRequest, db: Session = Depends(get_db)):
    result = _safe(propose_sequential_batch, **request.model_dump())
    row = _persist_analysis(db, "sequential_design", request.model_dump(), result)
    db.commit()
    return {"analysis": row, "proposal": result}


@router.post("/sequential-design/pareto-front")
def sequential_pareto(payload: dict):
    return _safe(pareto_front, payload.get("records", []), payload.get("objectives", []))


@router.post("/cross-lab/exchange-envelope", status_code=201)
def create_exchange(request: ExchangeRequest, db: Session = Depends(get_db)):
    result = _safe(create_exchange_envelope, **request.model_dump())
    manifest = result["manifest"]
    row = LabExchangeEnvelopeRecord(id=str(uuid4()), transfer_key=manifest["transfer_id"],
        source_laboratory=manifest["source_laboratory"], target_laboratory=manifest["target_laboratory"],
        subject_type=manifest["subject_type"], subject_id=manifest["subject_id"], domain=manifest["domain"],
        classification=manifest["classification"], consent_scope=manifest["consent_scope"],
        payload_sha256=manifest["payload_sha256"], manifest_json=manifest,
        integrity_status=result["integrity_status"])
    db.add(row)
    record_event(db, "LAB_EXCHANGE_ENVELOPE_CREATED", "exchange_envelope", row.id,
                 actor="advanced-research", payload={"source": row.source_laboratory,
                 "target": row.target_laboratory, "digest": row.payload_sha256})
    db.commit()
    return {"record": row, "envelope": result}


@router.post("/cross-lab/verify-envelope")
def verify_exchange(request: ExchangeVerifyRequest):
    return _safe(verify_exchange_envelope, request.envelope,
                 shared_secret=request.shared_secret, require_signature=request.require_signature)


@router.post("/cross-lab/compatibility")
def check_cross_lab_compatibility(payload: dict):
    return _safe(compatibility_matrix, **payload)


@router.post("/federated/aggregate")
def federated_aggregate(request: FederatedAggregationRequest, db: Session = Depends(get_db)):
    result = _safe(aggregate_lab_statistics, request.contributions, feature_names=request.feature_names,
                   minimum_labs=request.minimum_labs, minimum_total_records=request.minimum_total_records,
                   clip_norm=request.clip_norm, add_gaussian_noise=False)
    row = _persist_analysis(db, "federated_aggregate_preview", request.model_dump(), result,
                            domain="privacy_aware_science")
    db.commit()
    return {"analysis": row, "aggregate": result,
            "notice": "No formal privacy guarantee is claimed; this endpoint only returns aggregate means after minimum-cohort checks and contribution clipping."}


@router.post("/privacy-ledgers", status_code=201)
def create_privacy_budget_ledger(request: PrivacyLedgerCreateRequest, db: Session = Depends(get_db)):
    try:
        row = create_privacy_ledger(db, **request.model_dump())
        record_event(db, "PRIVACY_BUDGET_LEDGER_CREATED", "privacy_ledger", row.id,
                     actor="advanced-research", payload={"ledger_key": row.ledger_key,
                     "epsilon_limit": row.epsilon_limit, "delta_limit": row.delta_limit})
        db.commit()
        return ledger_snapshot(row)
    except ValueError as exc:
        db.rollback()
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@router.get("/privacy-ledgers/{ledger_key}")
def read_privacy_budget_ledger(ledger_key: str, db: Session = Depends(get_db)):
    try:
        return ledger_snapshot(get_privacy_ledger(db, ledger_key))
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Privacy ledger not found") from exc


@router.post("/privacy-ledgers/{ledger_key}/preflight")
def privacy_budget_preflight(ledger_key: str, request: PrivacyReleaseRequest,
                             db: Session = Depends(get_db)):
    try:
        row = get_privacy_ledger(db, ledger_key)
        return preflight_release(row, **request.model_dump())
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Privacy ledger not found") from exc


@router.post("/privacy-ledgers/{ledger_key}/pause")
def pause_privacy_budget_ledger(ledger_key: str, payload: dict, db: Session = Depends(get_db)):
    try:
        row = get_privacy_ledger(db, ledger_key, lock=True)
        result = pause_ledger(row, reason=str(payload.get("reason", "")))
        record_event(db, "PRIVACY_BUDGET_LEDGER_PAUSED", "privacy_ledger", row.id,
                     actor=str(payload.get("actor", "NEXUS scientist")), payload={"reason": payload.get("reason")})
        db.commit()
        return result
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Privacy ledger not found") from exc
    except ValueError as exc:
        db.rollback()
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@router.post("/federated/aggregate-private")
def federated_aggregate_private(request: FederatedPrivateRequest, db: Session = Depends(get_db)):
    try:
        ledger = get_privacy_ledger(db, request.ledger_key, lock=True)
        check = preflight_release(ledger, epsilon=request.epsilon, delta=request.delta)
        if not check["allowed"]:
            raise HTTPException(status_code=409, detail={"message": "Privacy budget exhausted", "preflight": check})
        budget = PrivacyBudget(epsilon_limit=ledger.epsilon_limit, delta_limit=ledger.delta_limit,
                               epsilon_spent=ledger.epsilon_spent, delta_spent=ledger.delta_spent,
                               release_count=ledger.release_count)
        result = aggregate_lab_statistics(request.contributions, feature_names=request.feature_names,
            minimum_labs=request.minimum_labs, minimum_total_records=request.minimum_total_records,
            clip_norm=request.clip_norm, add_gaussian_noise=True, epsilon=request.epsilon,
            delta=request.delta, budget=budget)
        if result.get("status") != "aggregate_created":
            db.rollback()
            return result
        snapshot = commit_release(ledger, epsilon=request.epsilon, delta=request.delta,
            release_key=request.release_key, metadata={"lab_count": result["lab_count"],
            "feature_names": request.feature_names, "mechanism": "gaussian_prototype"})
        analysis_request = request.model_dump(exclude={"ledger_key", "release_key"})
        row = _persist_analysis(db, "federated_noisy_aggregate", analysis_request, result,
                                domain="privacy_aware_science")
        record_event(db, "PRIVACY_BUDGET_RELEASE_COMMITTED", "privacy_ledger", ledger.id,
                     actor="advanced-research", payload={"release_key": request.release_key,
                     "epsilon": request.epsilon, "delta": request.delta,
                     "analysis_id": row.id})
        db.commit()
        return {"analysis": row, "aggregate": result, "privacy_budget": snapshot,
                "notice": "Prototype Gaussian perturbation and basic-composition ledger only; no formal DP guarantee is asserted."}
    except KeyError as exc:
        db.rollback()
        raise HTTPException(status_code=404, detail="Privacy ledger not found") from exc
    except ValueError as exc:
        db.rollback()
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@router.post("/model-transfer/evaluate")
def model_transfer_review(request: ModelTransferRequest):
    return _safe(evaluate_model_transfer, **request.model_dump())


@router.post("/model-transfer/plan")
def model_transfer_plan(payload: dict):
    return _safe(transfer_learning_plan, **payload)


@router.post("/drift/residuals")
def monitor_residuals(request: ResidualMonitorRequest):
    return _safe(residual_monitor, **request.model_dump())


@router.post("/drift/features")
def monitor_feature_windows(payload: dict):
    return _safe(compare_feature_windows, **payload)


@router.post("/digital-twins/ensemble")
def combine_twins(request: TwinEnsembleRequest):
    return _safe(combine_twin_predictions, **request.model_dump())


@router.post("/digital-twins/fidelity-card")
def create_twin_fidelity_card(payload: dict):
    from app.services.advanced_research.digital_twin_ensemble import twin_fidelity_card as build_card
    return _safe(build_card, **payload)


@router.post("/value-of-information/evaluate")
def value_of_information(request: VoIRequest):
    return _safe(expected_value_of_sample_information, **request.model_dump())


@router.post("/value-of-information/rank")
def rank_voi(payload: dict):
    from app.services.advanced_research.value_of_information import rank_information_actions
    return _safe(rank_information_actions, payload.get("actions", []))


@router.post("/stopping-policy/evaluate")
def stop_policy(request: StopPolicyRequest):
    return _safe(stopping_decision, **request.model_dump())


@router.post("/simulation/thermal")
def simulation_thermal(request: SimulationRequest):
    return _safe(simulate_lumped_thermal_response, **request.parameters)


@router.post("/simulation/kinetics")
def simulation_kinetics(request: SimulationRequest):
    return _safe(simulate_first_order_kinetics, **request.parameters)


@router.post("/simulation/battery")
def simulation_battery(request: SimulationRequest):
    return _safe(simulate_simple_battery_discharge, **request.parameters)


@router.post("/simulation/cstr")
def simulation_cstr(request: SimulationRequest):
    return _safe(simulate_cstr_concentration, **request.parameters)


@router.post("/simulation/arrhenius")
def simulation_arrhenius(request: SimulationRequest):
    return _safe(arrhenius_rate_ratio, **request.parameters)


@router.post("/multi-fidelity/bridge", status_code=201)
def fit_fidelity(request: FidelityBridgeRequest, db: Session = Depends(get_db)):
    result = _safe(fit_fidelity_bridge, **request.model_dump())
    row = _persist_analysis(db, "multi_fidelity_bridge", request.model_dump(), result)
    db.commit()
    return {"analysis": row, "bridge": result}


@router.post("/multi-fidelity/correct")
def correct_fidelity(payload: dict):
    return _safe(correct_low_fidelity, float(payload["value"]), payload["bridge"])


@router.post("/multi-fidelity/rank")
def rank_fidelity(payload: dict):
    return _safe(rank_multi_fidelity, payload.get("candidates", []),
                 best_observed=payload["best_observed"], high_fidelity_budget=payload["high_fidelity_budget"],
                 uncertainty_weight=payload.get("uncertainty_weight", 1.0))


@router.post("/hypotheses/bayesian-update")
def update_bayesian_evidence(request: BayesianUpdateRequest):
    return _safe(update_hypothesis_probability, **request.model_dump())


@router.post("/hypotheses/compare")
def compare_bayesian_hypotheses(payload: dict):
    return _safe(compare_hypotheses, payload.get("priors", {}), payload.get("likelihoods", {}))


@router.post("/replication/estimate")
def estimate_replication(request: ReplicationRequest):
    return _safe(estimate_replicates_for_mean_precision, **request.model_dump())


@router.post("/replication/summarize")
def summarize_replicates(payload: dict):
    return _safe(replicate_summary, payload.get("values", []))


@router.post("/sensitivity/linear")
def sensitivity_linear(request: SensitivityRequest):
    if set(request.parameters) != set(request.coefficients):
        raise HTTPException(status_code=422, detail="Parameter and coefficient keys must match")
    evaluator = lambda values: request.intercept + sum(request.coefficients[k] * values[k] for k in values)
    return _safe(finite_difference_sensitivity, parameters=request.parameters,
                 evaluator=evaluator, relative_step=request.relative_step)


@router.post("/sensitivity/one-at-a-time")
def sensitivity_oat(payload: dict):
    parameters = payload.get("parameters", {})
    coefficients = payload.get("coefficients", {})
    if set(parameters) != set(coefficients):
        raise HTTPException(status_code=422, detail="Parameter and coefficient keys must match")
    evaluator = lambda values: float(payload.get("intercept", 0)) + sum(float(coefficients[k]) * values[k] for k in values)
    return _safe(one_at_a_time_scenarios, parameters=parameters, ranges=payload.get("ranges", {}),
                 evaluator=evaluator, points_per_parameter=int(payload.get("points_per_parameter", 5)))


@router.post("/protocols/compare")
def protocol_diff(payload: dict):
    return _safe(compare_protocol_versions, payload.get("previous", {}), payload.get("current", {}))


@router.post("/protocols/compatibility")
def protocol_check(payload: dict):
    return _safe(protocol_compatibility, payload.get("protocol", {}), domain=payload.get("domain", ""),
                 sample_types=payload.get("sample_types", []),
                 instrument_capabilities=payload.get("instrument_capabilities", []))


@router.post("/capacity/preview")
def capacity_schedule(request: CapacityRequest):
    return _safe(capacity_preview, **request.model_dump())


@router.post("/sensors/validate-stream")
def validate_advanced_sensor_stream(payload: dict):
    return _safe(validate_sensor_stream, payload.get("stream", []),
                 maximum_gap_seconds=payload.get("maximum_gap_seconds"))


@router.post("/sensors/fuse")
def fuse_advanced_sensors(payload: dict):
    return _safe(fuse_scalar_sensors, payload.get("observations", []),
                 expected_timestamp=payload.get("expected_timestamp"),
                 maximum_time_offset_seconds=payload.get("maximum_time_offset_seconds", 1.0),
                 outlier_z_threshold=payload.get("outlier_z_threshold", 3.5))


@router.post("/sensors/align-events")
def align_advanced_sensor_events(payload: dict):
    return _safe(align_sensor_events, payload.get("events", []),
                 tolerance_seconds=float(payload.get("tolerance_seconds", 0)))


@router.post("/samples/custody", status_code=201)
def create_sample_custody(payload: dict, db: Session = Depends(get_db)):
    result = _safe(create_custody_record, **payload)
    row = _persist_analysis(db, "sample_custody_record", payload, result,
                            laboratory_code=result["source_laboratory"], domain="sample_custody")
    db.commit()
    return {"analysis": row, "custody": result}


@router.post("/samples/custody/transition")
def transition_sample_custody(payload: dict, db: Session = Depends(get_db)):
    result = _safe(transition_custody, payload.get("record", {}),
        next_state=payload.get("next_state", ""), actor=payload.get("actor", ""),
        evidence_refs=payload.get("evidence_refs", []), reason=payload.get("reason", ""),
        human_attestation=bool(payload.get("human_attestation", False)))
    row = _persist_analysis(db, "sample_custody_transition", payload, result,
        laboratory_code=result["target_laboratory"], domain="sample_custody", created_by=str(payload.get("actor", "system")))
    db.commit()
    return {"analysis": row, "custody": result}


@router.post("/samples/custody/verify")
def verify_sample_custody(payload: dict):
    return _safe(verify_custody_chain, payload.get("record", {}))


@router.post("/evidence/synthesize")
def synthesize_advanced_evidence(payload: dict, db: Session = Depends(get_db)):
    result = _safe(synthesize_claim_evidence, payload.get("claim", {}), payload.get("evidence", []))
    row = _persist_analysis(db, "evidence_synthesis", payload, result,
                            domain=result.get("domain", "unknown"), laboratory_code=str(payload.get("laboratory_code", "SDL0")))
    db.commit()
    return {"analysis": row, "synthesis": result}


@router.post("/evidence/matrix")
def advanced_evidence_matrix(payload: dict):
    return _safe(build_evidence_matrix, payload.get("claim_ids", []), payload.get("evidence_rows", []))


@router.post("/digital-twins/health")
def assess_advanced_twin_health(payload: dict):
    return _safe(assess_twin_health, **payload)


@router.post("/digital-twins/synchronization")
def compare_advanced_twin_sync(payload: dict):
    return _safe(compare_twin_sync, **payload)


@router.post("/failure/triage")
def triage_advanced_failure(payload: dict, db: Session = Depends(get_db)):
    result = _safe(rank_failure_hypotheses, observations=payload.get("observations", []),
        candidate_causes=payload.get("candidate_causes"), severity_weights=payload.get("severity_weights"))
    row = _persist_analysis(db, "failure_triage", payload, result,
                            domain=str(payload.get("domain", "unknown")),
                            laboratory_code=str(payload.get("laboratory_code", "SDL0")))
    db.commit()
    return {"analysis": row, "triage": result}


@router.post("/failure/discriminating-checks")
def failure_discriminating_checks(payload: dict):
    return _safe(propose_discriminating_checks, payload.get("top_hypotheses", []))


@router.post("/candidates/robust-ranking")
def robust_candidate_review(payload: dict, db: Session = Depends(get_db)):
    result = _safe(robust_candidate_ranking, payload.get("candidates", []),
        objective=payload.get("objective", ""), direction=payload.get("direction", "maximize"),
        risk_aversion=float(payload.get("risk_aversion", 1.0)),
        minimum_interval_coverage=payload.get("minimum_interval_coverage"))
    row = _persist_analysis(db, "uncertainty_aware_candidate_ranking", payload, result)
    db.commit()
    return {"analysis": row, "ranking": result}


@router.post("/candidates/interval-dominance")
def candidate_interval_dominance(payload: dict):
    return _safe(interval_dominance, payload.get("left", {}), payload.get("right", {}),
                 objective=payload.get("objective", ""), direction=payload.get("direction", "maximize"))


@router.post("/data-interoperability/contracts/compare")
def compare_interoperability_contracts(payload: dict):
    return _safe(compare_dataset_contracts, payload.get("source", {}), payload.get("target", {}))


@router.post("/data-interoperability/mappings/validate")
def validate_interoperability_mapping(payload: dict):
    return _safe(validate_mapping_rules, payload.get("mapping", {}),
        source_fields=payload.get("source_fields", []), target_fields=payload.get("target_fields", []),
        required_target_fields=payload.get("required_target_fields", []))


@router.post("/data-interoperability/units/convert")
def convert_interoperability_value(payload: dict):
    return _safe(convert_measurement_value, payload.get("value"), scale=payload.get("scale"),
        offset=payload.get("offset", 0), source_unit=payload.get("source_unit", ""),
        target_unit=payload.get("target_unit", ""))


@router.post("/methods/recommend")
def recommend_advanced_methods(payload: dict):
    return _safe(recommend_methods, **payload)


@router.get("/analyses")
def list_analyses(analysis_type: str | None = None, laboratory_code: str | None = None,
                  db: Session = Depends(get_db)):
    query = select(AdvancedResearchAnalysisRecord).order_by(AdvancedResearchAnalysisRecord.created_at.desc())
    if analysis_type: query = query.where(AdvancedResearchAnalysisRecord.analysis_type == analysis_type)
    if laboratory_code: query = query.where(AdvancedResearchAnalysisRecord.laboratory_code == laboratory_code.upper())
    return db.scalars(query.limit(200)).all()


# ---------------------------------------------------------------------------
# Volume III — federation, cross-site diagnostics and computational study design
# ---------------------------------------------------------------------------

@router.post("/federated/model-updates/aggregate")
def aggregate_federated_model_updates(payload: dict, db: Session = Depends(get_db)):
    result = _safe(aggregate_model_deltas, payload.get("updates", []),
        expected_model_id=payload.get("expected_model_id", ""),
        expected_version=payload.get("expected_version", ""),
        parameter_names=payload.get("parameter_names", []),
        minimum_labs=int(payload.get("minimum_labs", 3)),
        maximum_client_weight=float(payload.get("maximum_client_weight", .4)),
        clip_norm=float(payload.get("clip_norm", 1.0)),
        aggregation=payload.get("aggregation", "weighted_mean"))
    row = _persist_analysis(db, "federated_model_delta_aggregation", payload, result,
        domain="federated_model_research", laboratory_code="SDL0",
        created_by=str(payload.get("review_owner", "NEXUS federation service")))
    db.commit()
    return {"analysis": row, "aggregation": result}


@router.post("/federated/model-updates/compare-rounds")
def compare_federated_model_rounds(payload: dict):
    return _safe(compare_federated_rounds, payload.get("rounds", []))


@router.post("/labs/effects/summarize")
def summarize_cross_lab_effects(payload: dict, db: Session = Depends(get_db)):
    result = _safe(summarize_lab_effects, payload.get("observations", []),
        value_key=payload.get("value_key", "value"),
        lab_key=payload.get("lab_key", "laboratory_code"),
        minimum_per_lab=int(payload.get("minimum_per_lab", 2)),
        shrinkage=bool(payload.get("shrinkage", True)))
    row = _persist_analysis(db, "cross_laboratory_effect_diagnostics", payload, result,
        domain=str(payload.get("domain", "cross_laboratory")), laboratory_code="SDL0")
    db.commit()
    return {"analysis": row, "diagnostics": result}


@router.post("/design/blocked-assignment", status_code=201)
def create_computational_blocked_assignment(payload: dict, db: Session = Depends(get_db)):
    result = _safe(create_blocked_assignment, units=payload.get("units", []),
        arms=payload.get("arms", []), block_key=payload.get("block_key", "block_id"),
        unit_key=payload.get("unit_key", "unit_id"), seed=int(payload.get("seed", 17)),
        allocation_ratio=payload.get("allocation_ratio"))
    row = _persist_analysis(db, "computational_blocked_assignment", payload, result,
        domain=str(payload.get("domain", "computational_design")), laboratory_code=str(payload.get("laboratory_code", "SDL0")),
        created_by=str(payload.get("created_by", "NEXUS design service")), synthetic=True)
    db.commit()
    return {"analysis": row, "assignment": result}


@router.post("/design/blocked-assignment/audit")
def audit_computational_blocked_assignment(payload: dict):
    return _safe(audit_assignment, payload.get("plan", {}),
        expected_unit_ids=payload.get("expected_unit_ids", []), arms=payload.get("arms", []))


@router.post("/repeatability/summarize")
def summarize_research_repeatability(payload: dict, db: Session = Depends(get_db)):
    result = _safe(repeatability_summary, payload.get("replicates", []),
        group_key=payload.get("group_key", "sample_id"), value_key=payload.get("value_key", "value"))
    row = _persist_analysis(db, "repeatability_summary", payload, result,
        domain=str(payload.get("domain", "measurement_science")),
        laboratory_code=str(payload.get("laboratory_code", "SDL0")),
        synthetic=bool(payload.get("synthetic", False)))
    db.commit()
    return {"analysis": row, "repeatability": result}


@router.post("/repeatability/bland-altman")
def summarize_method_agreement(payload: dict):
    return _safe(bland_altman_summary, payload.get("method_a", []), payload.get("method_b", []))
