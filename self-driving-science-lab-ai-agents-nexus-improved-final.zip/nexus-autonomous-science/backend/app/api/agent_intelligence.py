"""Multi-agent plan compilation, debate and permission previews."""
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from typing import Any
from app.services.agent_intelligence.task_graph import compile_task_graph, ready_nodes
from app.services.agent_intelligence.debate import compose_scientific_debate
from app.services.agent_intelligence.retry_policy import plan_retry
from app.services.agent_intelligence.permissions import authorize_agent_action
from app.services.agent_intelligence.output_validation import validate_agent_output

router = APIRouter(prefix="/agent-intelligence", tags=["agent intelligence reliability"])


class TaskGraphRequest(BaseModel):
    nodes: list[dict[str, Any]] = Field(min_length=1, max_length=300)
    completed_nodes: list[str] = Field(default_factory=list)


class DebateRequest(BaseModel):
    proposition: str = Field(min_length=8, max_length=4000)
    positions: list[dict[str, Any]] = Field(min_length=2, max_length=20)
    allowed_evidence_refs: list[str] = Field(default_factory=list)


class RetryRequest(BaseModel):
    failure_code: str
    attempt: int = Field(default=1, ge=1)
    maximum_attempts: int = Field(default=3, ge=1, le=10)
    base_delay_seconds: float = Field(default=1, ge=0, le=60)
    task_kind: str = "analysis"


class PermissionRequest(BaseModel):
    permission_level: str
    action: str
    explicitly_allowed: list[str] | None = None


class OutputValidationRequest(BaseModel):
    output: dict[str, Any]
    allowed_evidence_refs: list[str] = Field(default_factory=list)
    allowed_finding_types: list[str] | None = None


@router.post("/task-graph/compile")
def compile_graph(request: TaskGraphRequest):
    try:
        result = compile_task_graph(request.nodes)
        result["ready_nodes"] = ready_nodes(request.nodes, set(request.completed_nodes))
        return result
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.post("/debate/compose")
def compose_debate(request: DebateRequest):
    try:
        return compose_scientific_debate(proposition=request.proposition, positions=request.positions,
                                         allowed_evidence_refs=set(request.allowed_evidence_refs))
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.post("/retry/plan")
def retry_plan(request: RetryRequest):
    try:
        return plan_retry(**request.model_dump())
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.post("/permissions/check")
def permission_check(request: PermissionRequest):
    return authorize_agent_action(**request.model_dump())


@router.post("/outputs/validate")
def output_validate(request: OutputValidationRequest):
    return validate_agent_output(request.output,
                                 allowed_evidence_refs=set(request.allowed_evidence_refs),
                                 allowed_finding_types=set(request.allowed_finding_types) if request.allowed_finding_types else None)
