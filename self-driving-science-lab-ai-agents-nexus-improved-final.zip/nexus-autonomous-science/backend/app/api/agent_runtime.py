"""Capability-checked agent tasks and persisted run history."""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.entities import Agent
from app.schemas.extension import AgentTaskRequest
from app.services.agent_runtime import dispatch_task, get_agent_run_history, AgentRuntimeError

router = APIRouter(prefix="/agent-runtime", tags=["agent runtime"])


@router.get("/runs")
def run_history(
    agent_id: str | None = None,
    limit: int = Query(default=100, ge=1, le=500),
    db: Session = Depends(get_db),
):
    return get_agent_run_history(db, limit=limit, agent_id=agent_id)


@router.post("/tasks", status_code=201)
def submit_task(request: AgentTaskRequest, db: Session = Depends(get_db)):
    agent = db.get(Agent, request.agent_id)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    try:
        run = dispatch_task(db, agent=agent, task_type=request.task_type,
                            input_contract=request.input_contract,
                            correlation_id=request.correlation_id)
        db.commit()
        return run
    except AgentRuntimeError as exc:
        db.rollback()
        raise HTTPException(status_code=422, detail=str(exc)) from exc
