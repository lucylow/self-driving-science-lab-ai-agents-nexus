"""Agent registry and safe, deterministic demo dispatch."""

from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.entities import Agent
from app.schemas.contracts import AgentRunRequest
from app.services.audit import record_event
from app.services.safety import validate_agent_permission

router = APIRouter(prefix="/agents", tags=["agents"])


@router.get("")
def list_agents(department: str | None = None, laboratory_code: str | None = None, db: Session = Depends(get_db)):
    query = select(Agent).order_by(Agent.id)
    if department:
        query = query.where(Agent.department == department)
    if laboratory_code:
        query = query.where(Agent.laboratory_code == laboratory_code.upper())
    agents = db.scalars(query).all()
    return [{
        "id": a.id, "agent_key": a.agent_key, "name": a.name, "department": a.department,
        "laboratory_code": a.laboratory_code, "purpose": a.purpose, "status": a.status,
        "permission_level": a.permission_level, "capabilities": a.capabilities,
        "run_count": a.run_count, "last_run_at": a.last_run_at, "synthetic": a.synthetic,
    } for a in agents]


@router.post("/{agent_id}/run")
def run_agent(agent_id: str, request: AgentRunRequest, db: Session = Depends(get_db)):
    agent = db.get(Agent, agent_id)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    validate_agent_permission(agent.permission_level, "analyze")
    agent.status = "running"
    agent.run_count += 1
    agent.last_run_at = datetime.now(timezone.utc)
    # A deterministic response makes the orchestration boundary testable without claiming
    # that a foundation model or real scientific instrument was invoked.
    output = {
        "agent_id": agent.id,
        "agent_name": agent.name,
        "task": request.task,
        "result_type": "demo_agent_response",
        "summary": f"{agent.name} completed a local demo review. Connect a validated model adapter to replace this baseline.",
        "capabilities_used": agent.capabilities,
        "recommendations": ["Review linked evidence", "Check uncertainty and domain applicability", "Obtain scientist sign-off before consequential use"],
        "synthetic": True,
    }
    agent.status = "idle"
    record_event(db, "AGENT_DEMO_RUN_COMPLETED", "agent", agent.id, actor="demo-orchestrator", payload={"task": request.task, "synthetic": True})
    db.commit()
    return {"status": "completed", "output": output}
