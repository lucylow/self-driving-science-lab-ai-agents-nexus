"""Scientific artifact metadata registry API."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.entities import ScientificArtifact
from app.schemas.extension import ArtifactRegister
from app.services.artifact_registry import register_artifact, validate_artifact_parents

router = APIRouter(prefix="/artifacts", tags=["scientific artifacts"])


@router.get("")
def list_artifacts(laboratory_code: str | None = None, sample_id: str | None = None,
                  db: Session = Depends(get_db)):
    query = select(ScientificArtifact).order_by(ScientificArtifact.created_at.desc())
    if laboratory_code:
        query = query.where(ScientificArtifact.laboratory_code == laboratory_code.upper())
    if sample_id:
        query = query.where(ScientificArtifact.sample_id == sample_id)
    return db.scalars(query.limit(500)).all()


@router.post("", status_code=201)
def create_artifact(request: ArtifactRegister, db: Session = Depends(get_db)):
    try:
        row = register_artifact(db, request.model_dump())
        db.commit()
        return row
    except ValueError as exc:
        db.rollback()
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.get("/{artifact_id}/validate-parents")
def validate_parents(artifact_id: str, db: Session = Depends(get_db)):
    try:
        return validate_artifact_parents(db, artifact_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Artifact not found") from exc
