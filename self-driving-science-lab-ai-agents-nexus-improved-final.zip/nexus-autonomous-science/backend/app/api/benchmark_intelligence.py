"""API for domain-specific agent benchmark suites and reviewer-scored cases."""
from fastapi import APIRouter, HTTPException

from app.services.agent_benchmark_suites import (
    aggregate_benchmark_results, get_benchmark_case, list_benchmark_suites,
    score_benchmark_case,
)

router = APIRouter(prefix="/benchmark-intelligence", tags=["agent benchmark intelligence"])


@router.get("/suites")
def benchmark_suites():
    return list_benchmark_suites()


@router.get("/cases/{case_id}")
def benchmark_case(case_id: str):
    try:
        return get_benchmark_case(case_id).to_dict()
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Benchmark case not found") from exc


@router.post("/score-case")
def score_case(request: dict):
    try:
        return score_benchmark_case(
            case_id=str(request.get("case_id", "")),
            output=request.get("output") or {},
            scientific_adjudication=request.get("scientific_adjudication"),
            reviewer=request.get("reviewer"),
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Benchmark case not found") from exc
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.post("/aggregate")
def aggregate_case_results(request: dict):
    try:
        return aggregate_benchmark_results(
            agent_id=str(request.get("agent_id", "")),
            benchmark_id=str(request.get("benchmark_id", "")),
            case_results=request.get("case_results") or [],
            minimum_cases=int(request.get("minimum_cases", 30)),
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
