"""System capability manifest to make adapters and gaps visible to the frontend."""

from fastapi import APIRouter

router = APIRouter(prefix="/system", tags=["system capabilities"])


@router.get("/capabilities")
def capabilities():
    return {
        "version": "0.1.0",
        "labs": ["SDL0", "SDL1", "SDL2", "SDL3", "SDL4", "SDL5", "SDL6", "SDL7"],
        "shared_services": {
            "objective_compiler": "rule_based_baseline",
            "agent_registry": "100 seeded capability profiles",
            "workflow_orchestration": "deterministic_preview_graph",
            "experiment_lifecycle": "implemented_state_machine",
            "human_approval": "implemented",
            "digital_twin": "synthetic_simulation_only",
            "scientific_data_quality": "baseline_checks",
            "provenance": "event_and_lineage_baseline",
            "active_learning": "utility_functions_not_calibrated",
            "model_registry": "in_process_contract",
            "robotics": "simulation_review_contract_only",
            "instrument_integration": "mock_adapter_only",
        },
        "not_enabled": [
            "physical instrument control", "robot motion execution", "liquid handling", "chemical synthesis",
            "biological wet-lab execution", "validated scientific property models", "production authentication",
            "multi-tenant authorization", "regulated-data compliance certification",
        ],
        "architecture_adapters_to_add": [
            "PostgreSQL + Alembic", "object storage (S3/MinIO)", "pgvector / Neo4j",
            "LangGraph supervisor", "MLflow model registry", "BoTorch/Ax optimization",
            "ROS 2 edge gateway", "vendor instrument drivers", "Prometheus/OpenTelemetry",
        ],
    }
