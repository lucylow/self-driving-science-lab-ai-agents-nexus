"""Scientific data registry, measurement quality, and provenance-facing views."""

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.entities import Dataset, Measurement
from app.services.data_quality import assess_measurement

router = APIRouter(prefix="/data", tags=["scientific data"])


@router.get("/datasets")
def datasets(db: Session = Depends(get_db)):
    return db.scalars(select(Dataset).order_by(Dataset.domain, Dataset.name)).all()


@router.get("/measurements")
def measurements(db: Session = Depends(get_db)):
    rows = db.scalars(select(Measurement).order_by(Measurement.recorded_at.desc())).all()
    return [{
        "id": row.id, "experiment_id": row.experiment_id, "sample_id": row.sample_id,
        "property_name": row.property_name, "value": row.value, "unit": row.unit,
        "uncertainty": row.uncertainty, "origin": row.origin, "quality_status": row.quality_status,
        "raw_artifact_uri": row.raw_artifact_uri, "metadata": row.metadata_json,
        "synthetic": row.synthetic, "quality_assessment": assess_measurement({
            "value": row.value, "unit": row.unit, "sample_id": row.sample_id, "origin": row.origin,
        }).to_dict(),
    } for row in rows]


@router.get("/quality")
def quality_summary(db: Session = Depends(get_db)):
    rows = db.scalars(select(Measurement)).all()
    assessments = [assess_measurement({"value": row.value, "unit": row.unit, "sample_id": row.sample_id, "origin": row.origin}) for row in rows]
    return {
        "measurement_count": len(rows),
        "synthetic_count": sum(row.synthetic for row in rows),
        "measured_count": sum(row.origin == "measured" for row in rows),
        "quarantined_count": sum(item.status == "quarantined" for item in assessments),
        "preliminary_count": sum(item.status == "preliminary" for item in assessments),
        "synthetic_or_derived_count": sum(item.status == "synthetic_or_derived" for item in assessments),
        "data_layers": [
            {"layer": "raw", "description": "Original instrument and source artifacts", "status": "adapter_required"},
            {"layer": "validated", "description": "Schema, identity, units, and quality checks", "status": "demo_checks_available"},
            {"layer": "processed", "description": "Normalized and transformed representations", "status": "planned"},
            {"layer": "scientific", "description": "Measurements, observations, and interpretations", "status": "demo_records_available"},
            {"layer": "ai", "description": "Features, training datasets, predictions, and evaluations", "status": "planned"},
            {"layer": "knowledge", "description": "Mechanisms, hypotheses, conclusions, and evidence graph", "status": "planned"},
        ],
    }
