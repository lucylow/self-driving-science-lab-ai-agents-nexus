"""Materials discovery candidates, ranking and next-batch recommendations."""

from fastapi import APIRouter, Depends, Query
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.entities import Candidate
from app.services.optimizer import select_next_batch, score_candidate

router = APIRouter(prefix="/discovery", tags=["materials discovery"])


@router.get("/candidates")
def candidates(laboratory_code: str = "SDL1", db: Session = Depends(get_db)):
    rows = db.scalars(select(Candidate).where(Candidate.laboratory_code == laboratory_code.upper()).order_by(Candidate.code)).all()
    return [{**{key: getattr(row, key) for key in ["id", "code", "name", "formula", "family", "domain", "laboratory_code", "predicted_properties", "uncertainty", "feasibility_score", "recommendation_score", "lifecycle_stage", "evidence_type", "synthetic"]}, "ranking": score_candidate({"predicted_properties": row.predicted_properties, "uncertainty": row.uncertainty, "feasibility_score": row.feasibility_score})} for row in rows]


@router.get("/next-batch")
def next_batch(batch_size: int = Query(default=3, ge=1, le=10), db: Session = Depends(get_db)):
    rows = db.scalars(select(Candidate).where(Candidate.laboratory_code == "SDL1")).all()
    payload = [{
        "id": row.id, "code": row.code, "name": row.name, "formula": row.formula,
        "predicted_properties": row.predicted_properties, "uncertainty": row.uncertainty,
        "feasibility_score": row.feasibility_score,
    } for row in rows]
    return {
        "selection_method": "transparent_weighted_demo_heuristic",
        "notices": ["Scores are illustrative and not calibrated scientific predictions.", "Recommendations are proposals; scientist review is required."],
        "candidates": select_next_batch(payload, batch_size),
    }
