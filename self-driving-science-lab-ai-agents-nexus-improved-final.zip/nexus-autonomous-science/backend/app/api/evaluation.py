"""Agent benchmark definitions and review-only evaluation submission endpoint."""

from typing import Any
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from app.services.agent_evaluation import METRIC_DEFINITIONS, evaluate_agent

router = APIRouter(prefix="/agents", tags=["agent evaluation"])


class EvaluationRequest(BaseModel):
    agent_id: str
    benchmark_id: str
    sample_count: int = Field(ge=0)
    metrics: dict[str, float] = Field(default_factory=dict)
    minimum_samples: int = Field(default=30, ge=1)


@router.get("/evaluation-framework")
def evaluation_framework():
    return {
        "metrics": METRIC_DEFINITIONS,
        "minimum_samples_default": 30,
        "promotion_policy": "Recommendation only; human benchmark review is required.",
        "automatic_production_promotion": False,
    }


@router.post("/evaluations/preview")
def evaluation_preview(request: EvaluationRequest):
    try:
        result = evaluate_agent(
            agent_id=request.agent_id,
            benchmark_id=request.benchmark_id,
            sample_count=request.sample_count,
            metrics=request.metrics,
            minimum_samples=request.minimum_samples,
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    return {**result.to_dict(), "saved": False, "production_promotion": False}
