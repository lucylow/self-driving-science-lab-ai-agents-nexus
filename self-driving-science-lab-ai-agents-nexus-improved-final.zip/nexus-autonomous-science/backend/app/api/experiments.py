"""Experiment registry, lifecycle transitions, and digital-twin demonstration runs."""

from uuid import uuid4
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.core.errors import InvalidTransitionError, GovernanceError
from app.models.entities import Candidate, Experiment, Hypothesis, Laboratory, Measurement, Objective
from app.schemas.contracts import ExperimentCreate, TransitionRequest
from app.services.audit import record_event
from app.services.digital_twin import simulate_experiment
from app.services.lifecycle import ensure_transition
from app.services.safety import validate_execution_request

router = APIRouter(prefix="/experiments", tags=["experiments"])


@router.get("")
def list_experiments(laboratory_code: str | None = None, status: str | None = None, db: Session = Depends(get_db)):
    query = select(Experiment).order_by(Experiment.created_at.desc())
    if laboratory_code:
        query = query.where(Experiment.laboratory_code == laboratory_code.upper())
    if status:
        query = query.where(Experiment.status == status)
    return db.scalars(query).all()


@router.post("")
def create_experiment(payload: ExperimentCreate, db: Session = Depends(get_db)):
    laboratory_code = payload.laboratory_code.upper()
    laboratory = db.scalar(select(Laboratory).where(Laboratory.code == laboratory_code))
    if laboratory is None:
        raise HTTPException(status_code=400, detail=f"Unknown laboratory_code: {laboratory_code}")
    objective = db.get(Objective, payload.objective_id) if payload.objective_id else None
    if payload.objective_id and objective is None:
        raise HTTPException(status_code=400, detail="Unknown objective_id")
    if objective and objective.laboratory_code != laboratory_code:
        raise HTTPException(status_code=409, detail="Experiment and objective must belong to the same laboratory.")
    candidate = db.get(Candidate, payload.candidate_id) if payload.candidate_id else None
    if payload.candidate_id and candidate is None:
        raise HTTPException(status_code=400, detail="Unknown candidate_id")
    if candidate and candidate.laboratory_code != laboratory_code:
        raise HTTPException(status_code=409, detail="Experiment and candidate must belong to the same laboratory.")
    hypothesis = db.get(Hypothesis, payload.hypothesis_id) if payload.hypothesis_id else None
    if payload.hypothesis_id and hypothesis is None:
        raise HTTPException(status_code=400, detail="Unknown hypothesis_id")
    if hypothesis and payload.objective_id and hypothesis.objective_id != payload.objective_id:
        raise HTTPException(status_code=409, detail="Hypothesis does not belong to the selected objective.")
    item = Experiment(
        id=str(uuid4()), code=f"EXP-{uuid4().hex[:6].upper()}", title=payload.title,
        laboratory_code=laboratory_code, objective_id=payload.objective_id,
        hypothesis_id=payload.hypothesis_id, candidate_id=payload.candidate_id,
        status="draft", execution_mode=payload.execution_mode, protocol_id=payload.protocol_id,
        protocol_version=payload.protocol_version, owner=payload.owner,
        estimated_duration_minutes=payload.estimated_duration_minutes,
        resource_requirements=payload.resource_requirements, governance=payload.governance,
        result_summary={"evidence_type": "synthetic_demo_record"}, synthetic=True,
    )
    db.add(item)
    record_event(db, "EXPERIMENT_CREATED", "experiment", item.id, actor=payload.owner, payload={"code": item.code, "status": item.status, "synthetic": True})
    db.commit()
    db.refresh(item)
    return item


@router.get("/{experiment_id}")
def get_experiment(experiment_id: str, db: Session = Depends(get_db)):
    item = db.get(Experiment, experiment_id)
    if not item:
        raise HTTPException(status_code=404, detail="Experiment not found")
    measurements = db.scalars(select(Measurement).where(Measurement.experiment_id == item.id)).all()
    return {"experiment": item, "measurements": measurements}


@router.post("/{experiment_id}/transition")
def transition_experiment(experiment_id: str, payload: TransitionRequest, db: Session = Depends(get_db)):
    item = db.get(Experiment, experiment_id)
    if not item:
        raise HTTPException(status_code=404, detail="Experiment not found")
    try:
        ensure_transition(item.status, payload.target_status)
    except InvalidTransitionError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    previous = item.status
    item.status = payload.target_status
    record_event(db, "EXPERIMENT_STATE_CHANGED", "experiment", item.id, actor=payload.actor, payload={"from": previous, "to": item.status, "note": payload.note})
    db.commit()
    db.refresh(item)
    return item


@router.post("/{experiment_id}/simulate")
def simulate_experiment_run(experiment_id: str, db: Session = Depends(get_db)):
    item = db.get(Experiment, experiment_id)
    if not item:
        raise HTTPException(status_code=404, detail="Experiment not found")
    try:
        validate_execution_request(item, requested_mode=item.execution_mode)
    except GovernanceError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc
    candidate = db.get(Candidate, item.candidate_id) if item.candidate_id else None
    result = simulate_experiment(item, candidate)
    # Use lifecycle transitions rather than assigning a terminal state directly.
    path = ["scheduled", "prepared", "executing", "data_acquisition", "data_validation", "scientific_interpretation", "completed"]
    for next_status in path:
        ensure_transition(item.status, next_status)
        previous = item.status
        item.status = next_status
        record_event(db, "EXPERIMENT_STATE_CHANGED", "experiment", item.id, actor="digital-twin", payload={"from": previous, "to": next_status})
    item.result_summary = result
    for record in result["measurements"]:
        measurement = Measurement(
            id=str(uuid4()), experiment_id=item.id, sample_id=f"SYN-{item.candidate_id or item.id}",
            property_name=record["property"], value=record["value"], unit=record["unit"],
            uncertainty=record.get("uncertainty"), origin="simulation", quality_status="synthetic_or_derived",
            raw_artifact_uri=f"demo://experiments/{item.id}/{record['property']}",
            metadata_json={"model_id": result["twin_metadata"]["model_id"], "synthetic": True}, synthetic=True,
        )
        db.add(measurement)
    record_event(db, "SIMULATED_EXPERIMENT_COMPLETED", "experiment", item.id, actor="digital-twin", payload={"measurement_count": len(result["measurements"]), "synthetic": True})
    db.commit()
    return {"experiment": item, "result": result}
