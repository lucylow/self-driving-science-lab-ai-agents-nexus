"""Human approval workflows. No approval endpoint can activate physical equipment."""

from datetime import datetime, timezone
from uuid import uuid4
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.core.errors import InvalidTransitionError
from app.models.entities import Approval, Experiment
from app.schemas.contracts import ApprovalCreate, ApprovalDecision
from app.services.audit import record_event
from app.services.lifecycle import ensure_transition

router = APIRouter(prefix="/governance", tags=["governance"])


@router.get("/approvals")
def list_approvals(status: str | None = None, db: Session = Depends(get_db)):
    query = select(Approval).order_by(Approval.requested_at.desc())
    if status:
        query = query.where(Approval.status == status)
    return db.scalars(query).all()


@router.post("/experiments/{experiment_id}/request-approval")
def request_approval(experiment_id: str, payload: ApprovalCreate, db: Session = Depends(get_db)):
    experiment = db.get(Experiment, experiment_id)
    if not experiment:
        raise HTTPException(status_code=404, detail="Experiment not found")
    if experiment.status in {"completed", "cancelled", "failed", "quarantined", "executing", "data_acquisition"}:
        raise HTTPException(status_code=409, detail=f"Cannot request approval from state '{experiment.status}'.")
    if experiment.status != "awaiting_approval":
        # Walk the deterministic pre-execution review route. This cannot start equipment.
        route = ["validated", "feasibility_review", "resource_review", "safety_review", "awaiting_approval"]
        for target in route:
            if target == experiment.status:
                continue
            try:
                ensure_transition(experiment.status, target)
            except InvalidTransitionError:
                continue
            previous = experiment.status
            experiment.status = target
            record_event(db, "EXPERIMENT_STATE_CHANGED", "experiment", experiment.id, actor=payload.requested_by, payload={"from": previous, "to": target, "reason": "approval workflow"})
            if target == "awaiting_approval":
                break
        if experiment.status != "awaiting_approval":
            # Draft is valid -> validated -> feasibility_review -> resource_review -> safety_review -> awaiting_approval.
            if experiment.status == "draft":
                for target in ["validated", "feasibility_review", "resource_review", "safety_review", "awaiting_approval"]:
                    previous = experiment.status
                    ensure_transition(previous, target)
                    experiment.status = target
                    record_event(db, "EXPERIMENT_STATE_CHANGED", "experiment", experiment.id, actor=payload.requested_by, payload={"from": previous, "to": target})
    approval = Approval(
        id=str(uuid4()), experiment_id=experiment.id, requested_by=payload.requested_by,
        reason=payload.reason, status="pending",
    )
    db.add(approval)
    record_event(db, "APPROVAL_REQUESTED", "experiment", experiment.id, actor=payload.requested_by, payload={"approval_id": approval.id})
    db.commit()
    db.refresh(approval)
    return approval


@router.post("/approvals/{approval_id}/decision")
def decide_approval(approval_id: str, payload: ApprovalDecision, db: Session = Depends(get_db)):
    approval = db.get(Approval, approval_id)
    if not approval:
        raise HTTPException(status_code=404, detail="Approval not found")
    if approval.status != "pending":
        raise HTTPException(status_code=409, detail="Approval has already been decided.")
    experiment = db.get(Experiment, approval.experiment_id)
    if not experiment:
        raise HTTPException(status_code=404, detail="Related experiment not found")
    approval.status = payload.decision
    approval.reviewer = payload.reviewer
    approval.reviewer_note = payload.note
    approval.decided_at = datetime.now(timezone.utc)
    previous = experiment.status
    if payload.decision == "approved":
        if experiment.status != "awaiting_approval":
            raise HTTPException(status_code=409, detail="Experiment is not awaiting approval.")
        ensure_transition(experiment.status, "approved")
        experiment.status = "approved"
    else:
        if experiment.status == "awaiting_approval":
            ensure_transition(experiment.status, "cancelled")
            experiment.status = "cancelled"
    record_event(db, "APPROVAL_DECIDED", "approval", approval.id, actor=payload.reviewer, payload={"decision": payload.decision, "experiment_id": experiment.id, "experiment_state_from": previous, "experiment_state_to": experiment.status})
    db.commit()
    db.refresh(approval)
    return {"approval": approval, "experiment_status": experiment.status}
