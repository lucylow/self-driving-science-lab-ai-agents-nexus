"""Hypothesis evidence append and scientist adjudication endpoints."""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.services.hypothesis_tracker import append_hypothesis_evidence, scientist_decide_hypothesis

router = APIRouter(prefix="/hypothesis-intelligence", tags=["hypothesis intelligence"])


class HypothesisEvidenceRequest(BaseModel):
    observation_id: str
    evidence_type: str = "inconclusive"
    description: str = Field(min_length=5)
    origin: str
    synthetic: bool = True
    provenance_refs: list[str] = Field(min_length=1)


class HypothesisDecisionRequest(BaseModel):
    status: str
    reviewer: str = Field(min_length=2)
    rationale: str = Field(min_length=12)
    evidence_refs: list[str] = Field(min_length=1)


@router.post("/{hypothesis_id}/evidence")
def add_evidence(hypothesis_id: str, request: HypothesisEvidenceRequest, db: Session = Depends(get_db)):
    try:
        row = append_hypothesis_evidence(db, hypothesis_id, **request.model_dump())
        db.commit()
        return row
    except KeyError as exc:
        db.rollback()
        raise HTTPException(status_code=404, detail="Hypothesis not found") from exc
    except ValueError as exc:
        db.rollback()
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.post("/{hypothesis_id}/decision")
def decide_hypothesis(hypothesis_id: str, request: HypothesisDecisionRequest, db: Session = Depends(get_db)):
    try:
        row = scientist_decide_hypothesis(db, hypothesis_id, **request.model_dump())
        db.commit()
        return row
    except KeyError as exc:
        db.rollback()
        raise HTTPException(status_code=404, detail="Hypothesis not found") from exc
    except ValueError as exc:
        db.rollback()
        raise HTTPException(status_code=409, detail=str(exc)) from exc
