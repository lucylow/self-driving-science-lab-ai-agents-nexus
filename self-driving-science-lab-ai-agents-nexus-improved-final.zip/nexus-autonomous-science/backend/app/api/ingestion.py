"""Staged and human-reviewed scientific data ingestion."""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.entities import IngestionJob
from app.services.ingestion_pipeline import create_ingestion_job, validate_ingestion_job, decide_ingestion

router = APIRouter(prefix="/ingestion", tags=["scientific ingestion"])


class IngestionCreate(BaseModel):
    job_code: str = Field(min_length=3, max_length=100)
    artifact_id: str
    laboratory_code: str = Field(pattern=r"^SDL[0-7]$")
    sample_id: str | None = None
    payload: dict
    synthetic: bool = True


class IngestionDecision(BaseModel):
    decision: str = "accept"
    reviewer: str = Field(min_length=2, max_length=120)
    note: str = Field(min_length=8, max_length=2000)


@router.get("/jobs")
def list_jobs(status: str | None = None, db: Session = Depends(get_db)):
    query = select(IngestionJob).order_by(IngestionJob.created_at.desc())
    if status:
        query = query.where(IngestionJob.status == status)
    return db.scalars(query.limit(500)).all()


@router.post("/jobs", status_code=201)
def create_job(request: IngestionCreate, db: Session = Depends(get_db)):
    try:
        row = create_ingestion_job(db, job_code=request.job_code, artifact_id=request.artifact_id,
                                   laboratory_code=request.laboratory_code, sample_id=request.sample_id,
                                   payload=request.payload, synthetic=request.synthetic)
        db.commit()
        return row
    except ValueError as exc:
        db.rollback()
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.post("/jobs/{job_id}/validate")
def validate_job(job_id: str, db: Session = Depends(get_db)):
    try:
        row = validate_ingestion_job(db, job_id)
        db.commit()
        return row
    except KeyError as exc:
        db.rollback()
        raise HTTPException(status_code=404, detail="Ingestion job not found") from exc
    except ValueError as exc:
        db.rollback()
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@router.post("/jobs/{job_id}/decision")
def decide_job(job_id: str, request: IngestionDecision, db: Session = Depends(get_db)):
    try:
        row = decide_ingestion(db, job_id, decision=request.decision,
                               reviewer=request.reviewer, note=request.note)
        db.commit()
        return row
    except KeyError as exc:
        db.rollback()
        raise HTTPException(status_code=404, detail="Ingestion job not found") from exc
    except ValueError as exc:
        db.rollback()
        raise HTTPException(status_code=409, detail=str(exc)) from exc
