"""Laboratory network endpoints."""

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.entities import Laboratory, Instrument

router = APIRouter(prefix="/labs", tags=["laboratories"])


@router.get("")
def list_laboratories(db: Session = Depends(get_db)):
    labs = db.scalars(select(Laboratory).order_by(Laboratory.code)).all()
    instruments = db.scalars(select(Instrument)).all()
    return [{
        "id": lab.id, "code": lab.code, "name": lab.name, "focus": lab.focus,
        "description": lab.description, "status": lab.status, "priority": lab.priority,
        "instrument_count": sum(item.laboratory_code == lab.code for item in instruments),
        "execution_mode": "simulation_only",
    } for lab in labs]


@router.get("/{laboratory_code}")
def get_laboratory(laboratory_code: str, db: Session = Depends(get_db)):
    lab = db.scalar(select(Laboratory).where(Laboratory.code == laboratory_code.upper()))
    if not lab:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="Laboratory not found")
    instruments = db.scalars(select(Instrument).where(Instrument.laboratory_code == lab.code)).all()
    return {
        "id": lab.id, "code": lab.code, "name": lab.name, "focus": lab.focus,
        "description": lab.description, "status": lab.status, "priority": lab.priority,
        "instruments": [{"id": i.id, "name": i.name, "type": i.instrument_type, "status": i.status, "capabilities": i.capabilities} for i in instruments],
    }
