"""Lineage integrity preview endpoint. No raw artifact is modified."""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from app.services.dataset_lineage import TransformationRecord, validate_lineage

router = APIRouter(prefix="/lineage", tags=["data lineage"])


class TransformationInput(BaseModel):
    transformation_id: str
    operation: str
    software_name: str
    software_version: str
    input_artifact_ids: list[str] = Field(min_length=1)
    output_artifact_id: str
    parameters_hash: str
    created_at: str
    actor: str


class LineageValidationRequest(BaseModel):
    transformations: list[TransformationInput]


@router.post("/validate")
def validate_lineage_request(request: LineageValidationRequest):
    try:
        records = [TransformationRecord(**item.model_dump()) for item in request.transformations]
        return validate_lineage(records)
    except (TypeError, ValueError) as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
