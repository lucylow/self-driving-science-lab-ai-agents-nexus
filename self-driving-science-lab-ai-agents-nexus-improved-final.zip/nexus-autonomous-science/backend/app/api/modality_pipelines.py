"""Numerical modality pipeline endpoints; no image, spectral or molecular AI claims."""
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from app.services.model_intelligence.modalities.spectral import validate_spectrum, detect_peak_candidates, integrate_spectrum
from app.services.model_intelligence.modalities.timeseries import temporal_descriptors, segment_time_series
from app.services.model_intelligence.modalities.imaging import validate_image_metadata, measure_binary_mask
from app.services.model_intelligence.modalities.molecular import rdkit_smiles_descriptors
from app.services.model_intelligence.modalities.crystal import inspect_cif_with_pymatgen

router = APIRouter(prefix="/modalities", tags=["multimodal scientific data"])


class SpectrumRequest(BaseModel):
    x: list[float] = Field(min_length=5)
    y: list[float] = Field(min_length=5)
    peak_threshold: float = 0.0


class TimeSeriesRequest(BaseModel):
    points: list[dict] = Field(min_length=3)


class ImageMetadataRequest(BaseModel):
    metadata: dict


class MaskRequest(BaseModel):
    mask: list[list[int]] = Field(min_length=1)
    pixel_size: float = Field(gt=0)


class MolecularRequest(BaseModel):
    smiles: str = Field(min_length=1, max_length=10000)


class CrystalRequest(BaseModel):
    cif_text: str = Field(min_length=1, max_length=2_000_000)


@router.post("/spectra/review")
def spectral_review(request: SpectrumRequest):
    try:
        validation = validate_spectrum(request.x, request.y)
        if not validation["valid"]:
            raise ValueError("; ".join(validation["errors"]))
        peaks = detect_peak_candidates(request.x, request.y, threshold=request.peak_threshold)
        return {"validation": validation, "peak_candidates": peaks,
                "integral": integrate_spectrum(request.x, request.y)}
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.post("/timeseries/descriptors")
def timeseries_descriptors(request: TimeSeriesRequest):
    try:
        return {"descriptors": temporal_descriptors(request.points),
                "segments": segment_time_series(request.points, window_points=max(3, min(10, len(request.points))), stride_points=5)}
    except (ValueError, KeyError) as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.post("/images/metadata-review")
def image_metadata_review(request: ImageMetadataRequest):
    return validate_image_metadata(request.metadata)


@router.post("/images/mask-morphometry")
def mask_morphometry(request: MaskRequest):
    try:
        return measure_binary_mask(request.mask, pixel_size=request.pixel_size)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.post("/molecules/rdkit-descriptors")
def molecular_descriptors(request: MolecularRequest):
    try:
        return rdkit_smiles_descriptors(request.smiles)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.post("/crystals/pymatgen-parse")
def crystal_parse(request: CrystalRequest):
    try:
        return inspect_cif_with_pymatgen(request.cif_text)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
