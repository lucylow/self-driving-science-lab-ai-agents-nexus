"""Advanced, stateless evaluation previews for calibration, OOD and ensembles."""
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from app.services.model_intelligence.evaluation.conformal import fit_absolute_residual_calibrator, apply_conformal_interval
from app.services.model_intelligence.evaluation.ood import fit_applicability_reference, score_applicability
from app.services.model_intelligence.evaluation.ensemble import aggregate_ensemble
from app.services.model_intelligence.evaluation.subgroups import subgroup_regression_metrics
from app.services.model_intelligence.evaluation.monitor import compare_predictions_to_observations

router = APIRouter(prefix="/model-evaluation", tags=["advanced model evaluation"])


class CalibrationRequest(BaseModel):
    actual: list[float] = Field(min_length=5)
    predicted: list[float] = Field(min_length=5)
    alpha: float = Field(default=0.1, gt=0, lt=1)
    future_prediction: float | None = None


class OODReferenceRequest(BaseModel):
    rows: list[dict[str, float]] = Field(min_length=5)
    feature_names: list[str] = Field(min_length=1)
    query: dict[str, float] | None = None
    threshold: float = Field(default=3.5, gt=0)


class EnsembleRequest(BaseModel):
    predictions: list[dict] = Field(min_length=2)


class SubgroupRequest(BaseModel):
    records: list[dict]
    group_key: str
    minimum_group_size: int = Field(default=3, ge=2)


class MonitoringRequest(BaseModel):
    pairs: list[dict] = Field(min_length=3)
    maximum_mean_absolute_error: float | None = Field(default=None, ge=0)


@router.post("/conformal-calibration")
def conformal_calibration(request: CalibrationRequest):
    try:
        calibrator = fit_absolute_residual_calibrator(request.actual, request.predicted, alpha=request.alpha)
        interval = apply_conformal_interval(request.future_prediction, calibrator) if request.future_prediction is not None else None
        return {"calibrator": calibrator, "example_interval": interval}
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.post("/applicability-reference")
def applicability_reference(request: OODReferenceRequest):
    try:
        reference = fit_applicability_reference(request.rows, request.feature_names)
        score = score_applicability(request.query, reference, threshold=request.threshold) if request.query else None
        return {"reference": reference, "query_score": score}
    except (ValueError, KeyError) as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.post("/ensemble")
def ensemble(request: EnsembleRequest):
    try:
        return aggregate_ensemble(request.predictions)
    except (ValueError, KeyError) as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.post("/subgroups")
def subgroup_metrics(request: SubgroupRequest):
    try:
        return subgroup_regression_metrics(request.records, group_key=request.group_key,
                                           minimum_group_size=request.minimum_group_size)
    except (ValueError, KeyError) as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.post("/monitor")
def monitor(request: MonitoringRequest):
    try:
        return compare_predictions_to_observations(request.pairs,
                                                   maximum_mean_absolute_error=request.maximum_mean_absolute_error)
    except (ValueError, KeyError) as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
