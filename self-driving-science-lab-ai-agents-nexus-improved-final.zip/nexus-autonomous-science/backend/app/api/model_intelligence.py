"""Scientific data snapshotting, baseline training, applicability and prediction endpoints."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.entities import ScientificModel, ScientificModelEvaluation, ScientificPrediction, TrainingDatasetSnapshot
from app.schemas.extension import DatasetBuildRequest, ModelTrainRequest, ModelPredictRequest
from app.services.dataset_builder import build_training_snapshot
from app.services.model_training import train_baseline
from app.services.model_governance import applicability_check, promotion_review
from app.services.model_intelligence.ridge import RidgeBaseline
from app.services.audit import record_event

router = APIRouter(prefix="/model-intelligence", tags=["scientific model intelligence"])


@router.post("/datasets/build", status_code=201)
def build_dataset(request: DatasetBuildRequest, db: Session = Depends(get_db)):
    try:
        snapshot = build_training_snapshot(db, **request.model_dump())
        db.commit()
        return snapshot
    except ValueError as exc:
        db.rollback()
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.get("/datasets")
def list_training_datasets(domain: str | None = None, db: Session = Depends(get_db)):
    query = select(TrainingDatasetSnapshot).order_by(TrainingDatasetSnapshot.created_at.desc())
    if domain:
        query = query.where(TrainingDatasetSnapshot.domain == domain)
    return db.scalars(query.limit(200)).all()


@router.post("/train", status_code=201)
def train_model(request: ModelTrainRequest, db: Session = Depends(get_db)):
    dataset = db.get(TrainingDatasetSnapshot, request.dataset_id)
    if not dataset:
        raise HTTPException(status_code=404, detail="Training dataset snapshot not found")
    try:
        model, evaluation = train_baseline(
            db, dataset=dataset, model_key=request.model_key, model_name=request.model_name,
            version=request.version, alpha=request.alpha,
            minimum_training_rows=request.minimum_training_rows,
        )
        record_event(db, "SCIENTIFIC_MODEL_TRAINED", "model", model.id, actor="model-intelligence",
                     payload={"dataset_id": dataset.id, "metrics": evaluation.metrics,
                              "synthetic": model.synthetic})
        db.commit()
        return {"model": model, "evaluation": evaluation}
    except ValueError as exc:
        db.rollback()
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.get("/models")
def list_models(domain: str | None = None, db: Session = Depends(get_db)):
    query = select(ScientificModel).order_by(ScientificModel.created_at.desc())
    models = db.scalars(query.limit(200)).all()
    if domain:
        models = [item for item in models if domain in item.supported_domains]
    return models


@router.get("/models/{model_id}/evaluations")
def get_model_evaluations(model_id: str, db: Session = Depends(get_db)):
    model = db.get(ScientificModel, model_id)
    if not model:
        raise HTTPException(status_code=404, detail="Model not found")
    return db.scalars(select(ScientificModelEvaluation).where(ScientificModelEvaluation.model_id == model_id)
                      .order_by(ScientificModelEvaluation.created_at.desc())).all()


@router.post("/models/{model_id}/promotion-review")
def review_promotion(model_id: str, db: Session = Depends(get_db)):
    model = db.get(ScientificModel, model_id)
    if not model:
        raise HTTPException(status_code=404, detail="Model not found")
    evaluation = db.scalar(select(ScientificModelEvaluation).where(ScientificModelEvaluation.model_id == model_id)
                           .order_by(ScientificModelEvaluation.created_at.desc()))
    if not evaluation:
        raise HTTPException(status_code=409, detail="Model needs an evaluation before promotion review")
    return promotion_review(model, evaluation)


@router.post("/predict", status_code=201)
def predict(request: ModelPredictRequest, db: Session = Depends(get_db)):
    model = db.get(ScientificModel, request.model_id)
    if not model:
        raise HTTPException(status_code=404, detail="Model not found")
    applicability = applicability_check(model, domain=request.domain, modality="tabular",
                                        target=request.target_property, feature_names=list(request.features))
    if not applicability["applicable"]:
        raise HTTPException(status_code=409, detail={"message": "Model is not applicable to this request", "applicability": applicability})
    if not model.hyperparameters.get("parameters"):
        raise HTTPException(status_code=409, detail="Model parameters are unavailable")
    baseline = RidgeBaseline.from_dict(model.hyperparameters["parameters"])
    result = baseline.predict(request.features)
    row = ScientificPrediction(
        id=__import__("uuid").uuid4().__str__(), model_id=model.id,
        subject_type=request.subject_type, subject_id=request.subject_id,
        domain=request.domain, target_property=request.target_property,
        predicted_value=result["value"], unit="model_target_unit",
        uncertainty=result["uncertainty_std"], applicability=applicability,
        input_refs=request.input_refs, evidence_origin="prediction", synthetic=True,
    )
    db.add(row)
    record_event(db, "SCIENTIFIC_PREDICTION_CREATED", "prediction", row.id,
                 actor="model-intelligence", payload={"model_id": model.id, "subject_id": row.subject_id,
                 "origin": "prediction", "synthetic": True})
    db.commit()
    return {"prediction": row, "interval": {"lower_95": result["lower_95"], "upper_95": result["upper_95"]},
            "notice": "Prediction only; not a measurement, calibration claim, or experimental result."}
