"""Model registry demonstration metadata; no trained model weights are bundled."""

from fastapi import APIRouter

router = APIRouter(prefix="/models", tags=["scientific models"])

MODEL_CARDS = [
    {
        "model_id": "nexus-sdl1-twin-demo", "name": "SDL1 Digital Twin Baseline", "version": "0.1.0",
        "supported_domains": ["inorganic_materials"], "supported_modalities": ["tabular"],
        "prediction_targets": ["ionic_conductivity", "stability_score"],
        "calibration_status": "uncalibrated", "training_dataset_refs": ["synthetic-demo"],
        "known_limitations": ["Illustrative deterministic outputs", "No physical validation", "Not suitable for scientific decisions"],
        "synthetic": True,
    },
    {
        "model_id": "nexus-anomaly-baseline", "name": "Scientific Data Quality Baseline", "version": "0.1.0",
        "supported_domains": ["cross_domain"], "supported_modalities": ["tabular", "timeseries"],
        "prediction_targets": ["quality_status"], "calibration_status": "rule_based_not_probabilistic",
        "training_dataset_refs": [], "known_limitations": ["Rule baseline only", "Requires domain-specific thresholds"],
        "synthetic": False,
    },
]


@router.get("")
def list_model_cards():
    return MODEL_CARDS
