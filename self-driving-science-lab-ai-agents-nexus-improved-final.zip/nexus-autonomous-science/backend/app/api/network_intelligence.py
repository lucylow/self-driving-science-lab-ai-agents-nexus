"""Multi-agent network planning, scientific review and dataset auditing APIs."""
from datetime import datetime
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from typing import Any
from app.services.agent_intelligence.dispatch import rank_agent_candidates, compile_dispatch_plan
from app.services.agent_intelligence.message_protocol import create_message, validate_message, detect_message_loop
from app.services.agent_intelligence.consensus import aggregate_scientific_reviews, build_evidence_disagreement_matrix
from app.services.experiment_scheduler_advanced import propose_schedule
from app.services.csv_ingestion import preview_measurement_csv
from app.services.dataset_auditor import audit_training_records, audit_train_test_split, compare_feature_distributions

router = APIRouter(prefix="/network-intelligence", tags=["network intelligence"])

class AgentRankRequest(BaseModel):
    task: dict[str, Any]
    agents: list[dict[str, Any]] = Field(default_factory=list)

class DispatchRequest(BaseModel):
    tasks: list[dict[str, Any]] = Field(min_length=1, max_length=200)
    agents: list[dict[str, Any]] = Field(default_factory=list, max_length=500)
    domain: str
    laboratory_code: str

class MessageRequest(BaseModel):
    message_id: str
    correlation_id: str
    sender_agent_id: str
    recipient_agent_id: str
    message_type: str
    payload: dict[str, Any] = Field(default_factory=dict)
    ttl_seconds: int = Field(default=900, ge=1, le=86400)
    parent_message_id: str | None = None
    evidence_refs: list[str] = Field(default_factory=list)
    known_agents: list[str] = Field(default_factory=list)
    now: datetime | None = None

class ReviewAggregateRequest(BaseModel):
    reviews: list[dict[str, Any]] = Field(default_factory=list, max_length=100)
    minimum_independent_reviewers: int = Field(default=2, ge=1, le=20)
    require_domain_expert: bool = True

class ScheduleRequest(BaseModel):
    jobs: list[dict[str, Any]] = Field(default_factory=list, max_length=500)
    instruments: list[dict[str, Any]] = Field(default_factory=list, max_length=200)
    start_at: datetime | None = None
    buffer_minutes: int = Field(default=5, ge=0, le=1440)

class CsvPreviewRequest(BaseModel):
    csv_text: str = Field(min_length=1, max_length=20 * 1024 * 1024)
    domain: str
    laboratory_code: str
    source_name: str = "uploaded.csv"
    maximum_rows: int = Field(default=50000, ge=1, le=50000)

class DatasetAuditRequest(BaseModel):
    records: list[dict[str, Any]] = Field(min_length=1, max_length=100000)
    feature_names: list[str] = Field(min_length=1)
    target_name: str
    group_name: str = "sample_id"
    maximum_missing_fraction: float = Field(default=0.05, ge=0, lt=1)

class SplitAuditRequest(BaseModel):
    train_records: list[dict[str, Any]]
    test_records: list[dict[str, Any]]
    group_name: str = "sample_id"

class FeatureDriftRequest(BaseModel):
    reference: list[float] = Field(min_length=10, max_length=100000)
    current: list[float] = Field(min_length=10, max_length=100000)
    bins: int = Field(default=10, ge=2, le=100)


def _run(fn, *args, **kwargs):
    try:
        return fn(*args, **kwargs)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except (ValueError, TypeError) as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

@router.post("/agents/rank")
def agent_rank(request: AgentRankRequest):
    return _run(rank_agent_candidates, request.task, request.agents)

@router.post("/agents/dispatch-plan")
def dispatch_plan(request: DispatchRequest):
    return _run(compile_dispatch_plan, tasks=request.tasks, agents=request.agents,
                domain=request.domain, laboratory_code=request.laboratory_code)

@router.post("/agents/messages/validate")
def message_validate(request: MessageRequest):
    data = request.model_dump()
    known = set(data.pop("known_agents")); current = data.pop("now")
    message = _run(create_message, **{key: data[key] for key in (
        "message_id", "correlation_id", "sender_agent_id", "recipient_agent_id",
        "message_type", "payload", "ttl_seconds", "parent_message_id", "evidence_refs")}, now=current)
    result = validate_message(message, known_agents=known, now=current)
    return {"message": message.__dict__, "validation": result}

@router.post("/agents/messages/loop-check")
def message_loop(request: dict[str, Any]):
    # The full loop check is primarily used by internal message-bus adapters.
    from app.services.agent_intelligence.message_protocol import AgentMessage
    try:
        messages = [AgentMessage(**item) for item in request.get("messages", [])]
        return detect_message_loop(messages, maximum_hops=int(request.get("maximum_hops", 12)))
    except (TypeError, ValueError) as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

@router.post("/agents/reviews/aggregate")
def review_aggregate(request: ReviewAggregateRequest):
    return _run(aggregate_scientific_reviews, request.reviews,
                minimum_independent_reviewers=request.minimum_independent_reviewers,
                require_domain_expert=request.require_domain_expert)

@router.post("/agents/reviews/disagreement-matrix")
def disagreement_matrix(request: dict[str, Any]):
    return build_evidence_disagreement_matrix(request.get("reviews", []))

@router.post("/scheduling/propose")
def schedule_proposal(request: ScheduleRequest):
    return _run(propose_schedule, request.jobs, request.instruments,
                start_at=request.start_at, buffer_minutes=request.buffer_minutes)

@router.post("/data/csv-preview")
def csv_preview(request: CsvPreviewRequest):
    return _run(preview_measurement_csv, request.csv_text, domain=request.domain,
                laboratory_code=request.laboratory_code, source_name=request.source_name,
                maximum_rows=request.maximum_rows)

@router.post("/data/dataset-audit")
def dataset_audit(request: DatasetAuditRequest):
    return _run(audit_training_records, request.records, feature_names=request.feature_names,
                target_name=request.target_name, group_name=request.group_name,
                maximum_missing_fraction=request.maximum_missing_fraction)

@router.post("/data/split-audit")
def split_audit(request: SplitAuditRequest):
    return audit_train_test_split(request.train_records, request.test_records, group_name=request.group_name)

@router.post("/data/feature-drift")
def feature_drift(request: FeatureDriftRequest):
    return _run(compare_feature_distributions, request.reference, request.current, bins=request.bins)
