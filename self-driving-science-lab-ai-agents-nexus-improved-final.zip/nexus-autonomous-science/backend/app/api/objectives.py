"""Scientific objective registry and transparent objective compilation."""

from uuid import uuid4
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.entities import Laboratory, Objective
from app.schemas.contracts import ObjectiveCompileRequest, ObjectiveCreate
from app.services.audit import record_event
from app.services.objective_compiler import compile_objective

router = APIRouter(prefix="/objectives", tags=["scientific objectives"])


@router.get("")
def list_objectives(db: Session = Depends(get_db)):
    return db.scalars(select(Objective).order_by(Objective.created_at.desc())).all()


@router.post("")
def create_objective(payload: ObjectiveCreate, db: Session = Depends(get_db)):
    laboratory_code = payload.laboratory_code.upper()
    if db.scalar(select(Laboratory).where(Laboratory.code == laboratory_code)) is None:
        raise HTTPException(status_code=400, detail=f"Unknown laboratory_code: {laboratory_code}")
    code = f"NEXUS-{laboratory_code}-OBJ-{uuid4().hex[:6].upper()}"
    item = Objective(
        id=str(uuid4()), code=code, title=payload.title, domain=payload.domain,
        laboratory_code=laboratory_code, description=payload.description,
        target_properties=payload.target_properties, constraints_json=payload.constraints,
        evidence_requirements=payload.evidence_requirements, governance=payload.governance,
        version=1, status="draft", synthetic=True,
    )
    db.add(item)
    record_event(db, "OBJECTIVE_CREATED", "objective", item.id, actor="scientist", payload={"code": code, "synthetic": True})
    db.commit()
    db.refresh(item)
    return item


@router.post("/compile")
def compile_scientific_objective(payload: ObjectiveCompileRequest):
    return compile_objective(payload.prompt, payload.laboratory_code)


@router.post("/{objective_id}/revise")
def revise_objective(objective_id: str, payload: ObjectiveCreate, db: Session = Depends(get_db)):
    previous = db.get(Objective, objective_id)
    if not previous:
        raise HTTPException(status_code=404, detail="Objective not found")
    # Immutable versioning: create a new record; do not rewrite the objective used by old experiments.
    if payload.laboratory_code.upper() != previous.laboratory_code or payload.domain != previous.domain:
        raise HTTPException(status_code=409, detail="A revision must preserve the objective's laboratory and scientific domain. Create a new objective to change domains.")
    new_item = Objective(
        id=str(uuid4()), code=f"{previous.code}-V{previous.version + 1}",
        title=payload.title, domain=payload.domain, laboratory_code=payload.laboratory_code.upper(),
        description=payload.description, target_properties=payload.target_properties,
        constraints_json=payload.constraints, evidence_requirements=payload.evidence_requirements,
        governance=payload.governance, version=previous.version + 1, status="draft", synthetic=True,
    )
    db.add(new_item)
    record_event(db, "OBJECTIVE_VERSION_CREATED", "objective", new_item.id, actor="scientist", payload={"previous_objective_id": previous.id, "version": new_item.version})
    db.commit()
    db.refresh(new_item)
    return new_item
