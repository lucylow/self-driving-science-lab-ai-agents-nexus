"""Multi-agent workflow supervisor and persistent run history."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.entities import WorkflowRunRecord
from app.services.workflow_checkpoints import list_checkpoints, checkpoint_summary, recovery_plan
from app.schemas.extension import WorkflowStartRequest
from app.services.workflow_supervisor import start_workflow, serialize_workflow

router = APIRouter(prefix="/orchestration", tags=["multi-agent orchestration"])


@router.get("/plans")
def list_workflow_plans():
    from app.services.workflow_supervisor import WORKFLOW_PLANS
    return [{"workflow_key": key, "nodes": plan,
             "physical_execution": False, "human_review_required": True} for key, plan in WORKFLOW_PLANS.items()]


@router.post("/runs", status_code=201)
def create_workflow(request: WorkflowStartRequest, db: Session = Depends(get_db)):
    try:
        run = start_workflow(db, workflow_key=request.workflow_key,
                             laboratory_code=request.laboratory_code,
                             objective_id=request.objective_id, subject_id=request.subject_id,
                             context=request.context, synthetic=request.synthetic)
        db.commit()
        return serialize_workflow(run)
    except ValueError as exc:
        db.rollback()
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.get("/runs")
def list_workflows(laboratory_code: str | None = None, db: Session = Depends(get_db)):
    query = select(WorkflowRunRecord).order_by(WorkflowRunRecord.created_at.desc())
    if laboratory_code:
        query = query.where(WorkflowRunRecord.laboratory_code == laboratory_code.upper())
    return [serialize_workflow(row) for row in db.scalars(query.limit(200)).all()]


@router.get("/runs/{run_id}")
def get_workflow(run_id: str, db: Session = Depends(get_db)):
    row = db.get(WorkflowRunRecord, run_id)
    if not row:
        raise HTTPException(status_code=404, detail="Workflow run not found")
    return serialize_workflow(row)


@router.get("/runs/{run_id}/checkpoints")
def get_workflow_checkpoints(run_id: str, db: Session = Depends(get_db)):
    row = db.get(WorkflowRunRecord, run_id)
    if not row:
        raise HTTPException(status_code=404, detail="Workflow run not found")
    records = list_checkpoints(db, run_id)
    return {"workflow_id": run_id, **checkpoint_summary(records)}


@router.post("/runs/{run_id}/recovery-plan")
def get_recovery_plan(run_id: str, request: dict, db: Session = Depends(get_db)):
    row = db.get(WorkflowRunRecord, run_id)
    if not row:
        raise HTTPException(status_code=404, detail="Workflow run not found")
    records = list_checkpoints(db, run_id)
    return {"workflow_id": run_id, **recovery_plan(
        row, records, operator_requested=bool(request.get("operator_requested", False))) }
