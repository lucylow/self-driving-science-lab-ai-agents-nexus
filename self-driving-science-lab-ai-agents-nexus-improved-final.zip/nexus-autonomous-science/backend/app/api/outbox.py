"""Transactional outbox inspection and broker-adapter acknowledgement."""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.entities import OutboxEvent
from app.schemas.extension import (
    OutboxAcknowledgeRequest,
    OutboxDrainRequest,
    OutboxPrepareRequest,
    OutboxRecoverRequest,
)
from app.services.event_outbox import prepare_delivery_batch, prepare_event_for_delivery, acknowledge_delivery, requeue_expired_leases, outbox_metrics

router = APIRouter(prefix="/outbox", tags=["event delivery"])


@router.get("")
def list_outbox(
    status: str | None = None,
    limit: int = Query(default=100, ge=1, le=500),
    db: Session = Depends(get_db),
):
    query = select(OutboxEvent).order_by(OutboxEvent.created_at.desc()).limit(limit)
    if status:
        query = query.where(OutboxEvent.status == status)
    return db.scalars(query).all()


@router.post("/prepare")
def prepare_batch(request: OutboxDrainRequest, db: Session = Depends(get_db)):
    rows = prepare_delivery_batch(db, batch_size=request.batch_size)
    db.commit()
    return {"events": rows, "count": len(rows),
            "notice": "Prepared for an external broker adapter; no message broker is configured by default."}


@router.post("/{event_id}/acknowledge")
def acknowledge(event_id: str, request: OutboxAcknowledgeRequest, db: Session = Depends(get_db)):
    try:
        event = acknowledge_delivery(
            db,
            event_id,
            success=request.success,
            error=request.error,
            claim_token=request.claim_token,
        )
        db.commit()
        return event
    except KeyError as exc:
        db.rollback()
        raise HTTPException(status_code=404, detail="Outbox event not found") from exc
    except ValueError as exc:
        db.rollback()
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@router.get("/metrics")
def get_outbox_metrics(db: Session = Depends(get_db)):
    return outbox_metrics(db)


@router.post("/recover-expired-leases")
def recover_expired_outbox_leases(request: OutboxRecoverRequest, db: Session = Depends(get_db)):
    try:
        result = requeue_expired_leases(db, max_attempts=request.max_attempts)
        db.commit()
        return {**result, "automatic_broker_delivery": False}
    except ValueError as exc:
        db.rollback()
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.post("/{event_id}/prepare")
def prepare_one_event(event_id: str, request: OutboxPrepareRequest, db: Session = Depends(get_db)):
    try:
        envelope = prepare_event_for_delivery(
            db,
            event_id,
            lease_seconds=request.lease_seconds,
            max_attempts=request.max_attempts,
            base_backoff_seconds=request.base_backoff_seconds,
        )
        db.commit()
        return envelope
    except KeyError as exc:
        db.rollback()
        raise HTTPException(status_code=404, detail="Outbox event not found") from exc
    except ValueError as exc:
        db.commit()
        raise HTTPException(status_code=409, detail=str(exc)) from exc
