"""Persistent research-campaign control plane."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.models.entities import ResearchCampaignRecord
from app.services.research_campaigns import (
    approve_campaign, cancel_campaign, create_campaign, get_campaign_or_raise,
    launch_next_stage, list_campaign_events, review_campaign_stage,
    serialize_campaign,
)

router = APIRouter(prefix="/research-campaigns", tags=["research campaigns"])


@router.post("", status_code=201)
def create_research_campaign(request: dict, db: Session = Depends(get_db)):
    try:
        campaign = create_campaign(
            db, title=str(request.get("title", "")),
            description=str(request.get("description", "")),
            laboratory_code=str(request.get("laboratory_code", "SDL1")),
            objective_id=str(request.get("objective_id", "")),
            workflow_keys=request.get("workflow_keys"),
            constraints=request.get("constraints") or {},
            synthetic=bool(request.get("synthetic", True)),
            actor=str(request.get("actor", "campaign-author")),
        )
        db.commit()
        return serialize_campaign(campaign)
    except (ValueError, KeyError) as exc:
        db.rollback()
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.get("")
def list_research_campaigns(laboratory_code: str | None = None,
                            status: str | None = None, limit: int = 100,
                            db: Session = Depends(get_db)):
    query = select(ResearchCampaignRecord).order_by(ResearchCampaignRecord.created_at.desc())
    if laboratory_code:
        query = query.where(ResearchCampaignRecord.laboratory_code == laboratory_code.upper())
    if status:
        query = query.where(ResearchCampaignRecord.status == status)
    rows = db.scalars(query.limit(min(max(limit, 1), 300))).all()
    return [serialize_campaign(row) for row in rows]


@router.get("/{campaign_id}")
def get_research_campaign(campaign_id: str, db: Session = Depends(get_db)):
    try:
        campaign = get_campaign_or_raise(db, campaign_id)
        return serialize_campaign(campaign, include_events=True,
                                  events=list_campaign_events(db, campaign_id))
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Research campaign not found") from exc


@router.post("/{campaign_id}/approve")
def approve_research_campaign(campaign_id: str, request: dict, db: Session = Depends(get_db)):
    try:
        campaign = get_campaign_or_raise(db, campaign_id)
        approve_campaign(db, campaign, reviewer=str(request.get("reviewer", "")),
                         note=str(request.get("note", "")))
        db.commit()
        return serialize_campaign(campaign)
    except KeyError as exc:
        db.rollback()
        raise HTTPException(status_code=404, detail="Research campaign not found") from exc
    except ValueError as exc:
        db.rollback()
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@router.post("/{campaign_id}/launch-next-stage")
def launch_campaign_stage(campaign_id: str, request: dict, db: Session = Depends(get_db)):
    try:
        campaign = get_campaign_or_raise(db, campaign_id)
        launch_next_stage(db, campaign, subject_id=request.get("subject_id"),
                          context=request.get("context") or {})
        db.commit()
        return serialize_campaign(campaign)
    except KeyError as exc:
        db.rollback()
        raise HTTPException(status_code=404, detail="Research campaign not found") from exc
    except ValueError as exc:
        db.rollback()
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@router.post("/{campaign_id}/review-stage")
def review_campaign(campaign_id: str, request: dict, db: Session = Depends(get_db)):
    try:
        campaign = get_campaign_or_raise(db, campaign_id)
        review_campaign_stage(
            db, campaign, decision=str(request.get("decision", "")),
            reviewer=str(request.get("reviewer", "")), note=str(request.get("note", "")),
        )
        db.commit()
        return serialize_campaign(campaign)
    except KeyError as exc:
        db.rollback()
        raise HTTPException(status_code=404, detail="Research campaign not found") from exc
    except ValueError as exc:
        db.rollback()
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@router.post("/{campaign_id}/cancel")
def cancel_research_campaign(campaign_id: str, request: dict, db: Session = Depends(get_db)):
    try:
        campaign = get_campaign_or_raise(db, campaign_id)
        cancel_campaign(db, campaign, actor=str(request.get("actor", "")),
                        reason=str(request.get("reason", "")))
        db.commit()
        return serialize_campaign(campaign)
    except KeyError as exc:
        db.rollback()
        raise HTTPException(status_code=404, detail="Research campaign not found") from exc
    except ValueError as exc:
        db.rollback()
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@router.get("/{campaign_id}/events")
def get_campaign_events(campaign_id: str, db: Session = Depends(get_db)):
    try:
        campaign = get_campaign_or_raise(db, campaign_id)
        events = list_campaign_events(db, campaign.id)
        from app.services.research_campaigns import verify_campaign_events
        return verify_campaign_events(events) | {"events": [
            {"sequence": row.sequence, "event_type": row.event_type,
             "actor": row.actor, "payload": row.payload,
             "event_hash": row.event_hash,
             "created_at": row.created_at.isoformat() if row.created_at else None}
            for row in events
        ]}
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Research campaign not found") from exc
