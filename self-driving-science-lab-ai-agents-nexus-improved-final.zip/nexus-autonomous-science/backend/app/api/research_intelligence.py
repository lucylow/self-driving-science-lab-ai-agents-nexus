"""Research design, scientific review, digital-twin validation and data drift endpoints."""
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from typing import Any
from app.services.domain_validation import validate_laboratory_record
from app.services.experimental_design import full_factorial_design, validate_factor_constraints
from app.services.multiobjective import pareto_front, weighted_score
from app.services.active_learning_batch import select_batch
from app.services.failure_intelligence import triage_failure
from app.services.digital_twin_validation import validate_twin_predictions
from app.services.protocol_validation import validate_protocol_manifest
from app.services.reproducibility import summarize_replicates, reproducibility_gate
from app.services.data_drift import population_stability_index

router = APIRouter(prefix="/research-intelligence", tags=["research intelligence"])


class DomainRecordRequest(BaseModel):
    payload: dict[str, Any]


class DesignRequest(BaseModel):
    factors: list[dict[str, Any]] = Field(min_length=1, max_length=16)
    maximum_runs: int = Field(default=128, ge=1, le=512)
    center_points: int = Field(default=1, ge=0, le=20)
    constraints: list[dict[str, Any]] = Field(default_factory=list)


class ParetoRequest(BaseModel):
    candidates: list[dict[str, Any]] = Field(min_length=1, max_length=10000)
    directions: dict[str, str]


class WeightedScoreRequest(BaseModel):
    values: dict[str, float]
    ranges: dict[str, tuple[float, float]]
    directions: dict[str, str]
    weights: dict[str, float]


class ActiveLearningRequest(BaseModel):
    candidates: list[dict[str, Any]]
    batch_size: int = Field(default=5, ge=1, le=100)
    exploration: float = Field(default=1.5, ge=0, le=100)
    target: str = "target"
    direction: str = "maximize"
    excluded_ids: list[str] = Field(default_factory=list)


class FailureTriageRequest(BaseModel):
    experiment_id: str
    observed_signals: list[str]
    evidence_refs: list[str] = Field(default_factory=list)
    context: dict[str, Any] = Field(default_factory=dict)


class TwinValidationRequest(BaseModel):
    predicted: list[float] = Field(min_length=3)
    observed: list[float] = Field(min_length=3)
    validation_domain: str
    declared_domain: str
    calibrated_range: tuple[float, float] | None = None


class ProtocolRequest(BaseModel):
    payload: dict[str, Any]


class ReplicateRequest(BaseModel):
    records: list[dict[str, Any]]
    minimum_replicates: int = Field(default=3, ge=2)
    maximum_cv: float | None = Field(default=None, ge=0)


class DriftRequest(BaseModel):
    reference: list[float] = Field(min_length=10)
    current: list[float] = Field(min_length=10)
    bins: int = Field(default=10, ge=2, le=100)


@router.post("/domains/{laboratory_code}/validate")
def domain_validate(laboratory_code: str, request: DomainRecordRequest):
    try:
        return validate_laboratory_record(laboratory_code, request.payload)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Unknown laboratory code") from exc


@router.post("/design/full-factorial")
def create_factorial_design(request: DesignRequest):
    try:
        design = full_factorial_design(request.factors, maximum_runs=request.maximum_runs,
                                       center_points=request.center_points)
        checks = validate_factor_constraints(request.factors, request.constraints)
        return {"design": design, "constraints": checks,
                "ready_for_scientist_review": checks["valid"]}
    except (ValueError, TypeError) as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.post("/optimization/pareto")
def pareto(request: ParetoRequest):
    try:
        return pareto_front(request.candidates, request.directions)
    except (ValueError, KeyError) as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.post("/optimization/weighted-score")
def score_candidate(request: WeightedScoreRequest):
    try:
        return weighted_score(request.values, request.ranges, request.directions, request.weights)
    except (ValueError, KeyError) as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.post("/optimization/active-learning-batch")
def active_learning(request: ActiveLearningRequest):
    try:
        return select_batch(request.candidates, batch_size=request.batch_size,
                            exploration=request.exploration, target=request.target,
                            direction=request.direction, excluded_ids=request.excluded_ids)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.post("/failure/triage")
def failure_triage(request: FailureTriageRequest):
    return triage_failure(experiment_id=request.experiment_id,
                          observed_signals=request.observed_signals,
                          evidence_refs=request.evidence_refs, context=request.context)


@router.post("/digital-twin/validate")
def digital_twin_validate(request: TwinValidationRequest):
    try:
        return validate_twin_predictions(request.predicted, request.observed,
                                         validation_domain=request.validation_domain,
                                         declared_domain=request.declared_domain,
                                         calibrated_range=request.calibrated_range)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.post("/protocols/validate")
def protocol_validate(request: ProtocolRequest):
    return validate_protocol_manifest(request.payload)


@router.post("/reproducibility/review")
def reproducibility_review(request: ReplicateRequest):
    summary = summarize_replicates(request.records)
    return {"summary": summary,
            "gate": reproducibility_gate(summary,
                                         minimum_replicates=request.minimum_replicates,
                                         maximum_cv=request.maximum_cv)}


@router.post("/drift/psi")
def drift_review(request: DriftRequest):
    try:
        return population_stability_index(request.reference, request.current, bins=request.bins)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
