"""Literature registry and evidence-linked scientific claims."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.entities import ResearchSource, ScientificClaim
from app.schemas.research import ResearchSourceCreate, SourceVerification, ScientificClaimCreate, ScientificClaimReview
from app.services.research.literature_registry import register_source, verify_source_metadata, register_claim, review_claim

router = APIRouter(prefix="/research-sources", tags=["literature and scientific claims"])


@router.get("")
def list_sources(db: Session = Depends(get_db)):
    return db.scalars(select(ResearchSource).order_by(ResearchSource.created_at.desc()).limit(500)).all()


@router.post("", status_code=201)
def create_source(request: ResearchSourceCreate, db: Session = Depends(get_db)):
    try:
        row = register_source(db, request.model_dump())
        db.commit()
        return row
    except ValueError as exc:
        db.rollback()
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.post("/{source_id}/verify")
def verify_source(source_id: str, request: SourceVerification, db: Session = Depends(get_db)):
    try:
        row = verify_source_metadata(db, source_id, reviewer=request.reviewer,
                                     verification_refs=request.verification_refs, note=request.note)
        db.commit()
        return row
    except KeyError as exc:
        db.rollback()
        raise HTTPException(status_code=404, detail="Research source not found") from exc
    except ValueError as exc:
        db.rollback()
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.get("/claims")
def list_claims(domain: str | None = None, status: str | None = None, db: Session = Depends(get_db)):
    query = select(ScientificClaim).order_by(ScientificClaim.created_at.desc())
    if domain:
        query = query.where(ScientificClaim.domain == domain)
    if status:
        query = query.where(ScientificClaim.status == status)
    return db.scalars(query.limit(500)).all()


@router.post("/claims", status_code=201)
def create_claim(request: ScientificClaimCreate, db: Session = Depends(get_db)):
    try:
        row = register_claim(db, request.model_dump())
        db.commit()
        return row
    except ValueError as exc:
        db.rollback()
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.post("/claims/{claim_id}/review")
def review_scientific_claim(claim_id: str, request: ScientificClaimReview, db: Session = Depends(get_db)):
    try:
        row = review_claim(db, claim_id, decision=request.decision, reviewer=request.reviewer,
                           note=request.note, checked_refs=request.checked_refs)
        db.commit()
        return row
    except KeyError as exc:
        db.rollback()
        raise HTTPException(status_code=404, detail="Scientific claim not found") from exc
    except ValueError as exc:
        db.rollback()
        raise HTTPException(status_code=409, detail=str(exc)) from exc
