"""Sample registry API."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.entities import ScientificSample
from app.schemas.extension import SampleCreate
from app.services.sample_registry import register_sample, verify_sample_identity, list_sample_ancestry

router = APIRouter(prefix="/samples", tags=["sample registry"])


@router.get("")
def list_samples(laboratory_code: str | None = None, domain: str | None = None,
                 identity_status: str | None = None, db: Session = Depends(get_db)):
    query = select(ScientificSample).order_by(ScientificSample.created_at.desc())
    if laboratory_code:
        query = query.where(ScientificSample.laboratory_code == laboratory_code.upper())
    if domain:
        query = query.where(ScientificSample.domain == domain)
    if identity_status:
        query = query.where(ScientificSample.identity_status == identity_status)
    return db.scalars(query.limit(500)).all()


@router.post("", status_code=201)
def create_sample(request: SampleCreate, db: Session = Depends(get_db)):
    try:
        row = register_sample(db, request.model_dump())
        db.commit()
        return row
    except ValueError as exc:
        db.rollback()
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.post("/{sample_id}/verify")
def verify_sample(sample_id: str, request: dict, db: Session = Depends(get_db)):
    try:
        row = verify_sample_identity(db, sample_id, reviewer=str(request.get("reviewer", "")),
                                     evidence_refs=list(request.get("evidence_refs", [])),
                                     note=str(request.get("note", "")))
        db.commit()
        return row
    except KeyError as exc:
        db.rollback()
        raise HTTPException(status_code=404, detail="Sample not found") from exc
    except ValueError as exc:
        db.rollback()
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.get("/{sample_id}/ancestry")
def sample_ancestry(sample_id: str, db: Session = Depends(get_db)):
    try:
        return {"sample_id": sample_id, "ancestry": list_sample_ancestry(db, sample_id)}
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Sample not found") from exc
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
