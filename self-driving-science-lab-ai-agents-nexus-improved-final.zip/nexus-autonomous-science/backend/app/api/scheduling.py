"""Advisory resource schedule preview; preview does not reserve or lock equipment."""

from datetime import datetime, timezone
from fastapi import APIRouter
from pydantic import BaseModel, Field
from app.services.experiment_scheduler import propose_slots

router = APIRouter(prefix="/scheduler", tags=["experiment scheduling"])


class SchedulePreviewRequest(BaseModel):
    experiment_id: str
    duration_minutes: int = Field(default=60, ge=1, le=10080)
    resource_ids: list[str] = Field(default_factory=list)
    start_at: datetime | None = None
    slot_minutes: int = Field(default=30, ge=5, le=1440)


@router.post("/preview")
def schedule_preview(payload: SchedulePreviewRequest):
    start = payload.start_at or datetime.now(timezone.utc)
    return {
        "experiment_id": payload.experiment_id,
        "slots": propose_slots(
            {"id": payload.experiment_id, "duration_minutes": payload.duration_minutes, "resource_ids": payload.resource_ids},
            start=start, slot_minutes=payload.slot_minutes,
        ),
        "reservation_created": False,
        "requires_human_review": True,
    }
