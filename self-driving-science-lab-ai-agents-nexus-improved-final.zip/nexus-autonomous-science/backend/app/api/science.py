"""Scientific domain registry and evidence review endpoints."""

from typing import Any, Literal
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from app.services.domain_registry import get_domain, list_domains, validate_domain_payload
from app.services.scientific_evidence import assess_evidence, detect_numeric_contradiction

router = APIRouter(prefix="/science", tags=["scientific foundations"])


class EvidenceReviewRequest(BaseModel):
    evidence_id: str = Field(min_length=1)
    origin: Literal[
        "model_hypothesis", "computational_prediction", "validated_computational_prediction",
        "preliminary_measurement", "quality_controlled_measurement",
        "independent_replication", "independent_validation",
    ]
    synthetic: bool = False
    quality_checks: dict[str, bool] = Field(default_factory=dict)
    independent_replicates: int = Field(default=0, ge=0)
    independent_validation_reference: str | None = None


class DomainValidationRequest(BaseModel):
    laboratory_code: str
    payload: dict[str, Any]


class ContradictionRequest(BaseModel):
    subject_id: str
    observation_a_id: str
    observation_b_id: str
    property_name: str
    value_a: float
    value_b: float
    relative_tolerance: float = Field(default=0.25, ge=0.0, le=10.0)


@router.get("/domains")
def domains():
    return list_domains()


@router.get("/domains/{laboratory_code}")
def domain_detail(laboratory_code: str):
    try:
        return get_domain(laboratory_code)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.post("/domains/validate")
def validate_domain(request: DomainValidationRequest):
    try:
        return validate_domain_payload(request.laboratory_code, request.payload)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.post("/evidence/assess")
def evidence_assessment(request: EvidenceReviewRequest):
    return assess_evidence(
        evidence_id=request.evidence_id,
        origin=request.origin,
        synthetic=request.synthetic,
        quality_checks=request.quality_checks,
        independent_replicates=request.independent_replicates,
        independent_validation_reference=request.independent_validation_reference,
    ).to_dict()


@router.post("/evidence/contradictions")
def contradiction_review(request: ContradictionRequest):
    item = detect_numeric_contradiction(
        subject_id=request.subject_id,
        observation_a_id=request.observation_a_id,
        observation_b_id=request.observation_b_id,
        property_name=request.property_name,
        value_a=request.value_a,
        value_b=request.value_b,
        relative_tolerance=request.relative_tolerance,
    )
    return {"contradiction_detected": item is not None, "report": item.__dict__ if item else None}
