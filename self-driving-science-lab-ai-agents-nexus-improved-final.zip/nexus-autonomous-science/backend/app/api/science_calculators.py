"""Domain-science calculation endpoints. Every result is computationally derived."""
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from typing import Any
from app.services.domain_science import (
    calculate_conductivity, summarize_eis_spectrum, fit_arrhenius_conductivity,
    bragg_d_spacing, estimate_lattice_cubic, compare_xrd_peaks,
    summarize_galvanostatic_cycle, calculate_energy_density, summarize_cycle_life,
    calculate_polydispersity, calculate_crystallinity, analyze_tensile_curve,
    baseline_correct, normalize_spectrum, detect_peaks, integrate_spectrum,
    fit_first_order_decay, calculate_mass_balance, validate_mixture,
    calculate_blend_property, analyze_binary_mask, summarize_morphology_batch,
    summarize_replicates, compare_replicate_groups,
)

router = APIRouter(prefix="/science-calculators", tags=["domain science calculators"])

class Payload(BaseModel):
    values: dict[str, Any] = Field(default_factory=dict)


def _call(function, *args, **kwargs):
    try:
        return function(*args, **kwargs)
    except (ValueError, TypeError, KeyError, OverflowError) as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

@router.post("/electrochemistry/conductivity")
def conductivity(payload: Payload):
    return _call(calculate_conductivity, **payload.values)

@router.post("/electrochemistry/eis-summary")
def eis_summary(payload: Payload):
    return _call(summarize_eis_spectrum, **payload.values)

@router.post("/electrochemistry/arrhenius")
def arrhenius(payload: Payload):
    return _call(fit_arrhenius_conductivity, **payload.values)

@router.post("/diffraction/bragg")
def bragg(payload: Payload):
    return _call(bragg_d_spacing, **payload.values)

@router.post("/diffraction/cubic-lattice")
def cubic_lattice(payload: Payload):
    return _call(estimate_lattice_cubic, **payload.values)

@router.post("/diffraction/compare-peaks")
def compare_peaks(payload: Payload):
    return _call(compare_xrd_peaks, **payload.values)

@router.post("/battery/cycle-summary")
def battery_cycle(payload: Payload):
    return _call(summarize_galvanostatic_cycle, **payload.values)

@router.post("/battery/energy-density")
def battery_energy(payload: Payload):
    values = payload.values
    return _call(calculate_energy_density, values.get("voltage_v", []), values.get("capacity_mah_g", []))

@router.post("/battery/cycle-life")
def battery_life(payload: Payload):
    values = payload.values
    return _call(summarize_cycle_life, values.get("cycle_indices", []), values.get("discharge_capacities", []),
                 reference_cycle=values.get("reference_cycle", 1))

@router.post("/polymers/dispersity")
def polymer_dispersity(payload: Payload):
    return _call(calculate_polydispersity, **payload.values)

@router.post("/polymers/crystallinity")
def polymer_crystallinity(payload: Payload):
    return _call(calculate_crystallinity, **payload.values)

@router.post("/polymers/tensile")
def polymer_tensile(payload: Payload):
    return _call(analyze_tensile_curve, **payload.values)

@router.post("/spectroscopy/baseline")
def spectrum_baseline(payload: Payload):
    values = payload.values
    return _call(baseline_correct, values.get("axis", []), values.get("intensity", []), method=values.get("method", "linear_endpoints"))

@router.post("/spectroscopy/normalize")
def spectrum_normalize(payload: Payload):
    return _call(normalize_spectrum, payload.values.get("intensity", []), method=payload.values.get("method", "max_abs"))

@router.post("/spectroscopy/peaks")
def spectrum_peaks(payload: Payload):
    return _call(detect_peaks, payload.values.get("axis", []), payload.values.get("intensity", []),
                 minimum_prominence=payload.values.get("minimum_prominence", 0),
                 minimum_distance_points=payload.values.get("minimum_distance_points", 1))

@router.post("/spectroscopy/integrate")
def spectrum_integrate(payload: Payload):
    return _call(integrate_spectrum, payload.values.get("axis", []), payload.values.get("intensity", []),
                 lower=payload.values.get("lower"), upper=payload.values.get("upper"),
                 clip_negative=payload.values.get("clip_negative", False))

@router.post("/kinetics/first-order")
def first_order(payload: Payload):
    return _call(fit_first_order_decay, payload.values.get("time_s", []), payload.values.get("concentration", []))

@router.post("/process/mass-balance")
def mass_balance(payload: Payload):
    return _call(calculate_mass_balance, **payload.values)

@router.post("/formulations/mixture/validate")
def mixture_validate(payload: Payload):
    return _call(validate_mixture, payload.values.get("components", []), tolerance=payload.values.get("tolerance", 1e-6))

@router.post("/formulations/mixture/blend-property")
def blend_property(payload: Payload):
    return _call(calculate_blend_property, payload.values.get("components", []), property_key=payload.values.get("property_key", ""))

@router.post("/microscopy/mask-morphology")
def mask_morphology(payload: Payload):
    return _call(analyze_binary_mask, payload.values.get("mask", []), pixel_size=payload.values.get("pixel_size", 1.0))

@router.post("/microscopy/morphology-batch")
def morphology_batch(payload: Payload):
    return _call(summarize_morphology_batch, payload.values.get("masks", []), pixel_size=payload.values.get("pixel_size", 1.0))

@router.post("/replicates/summarize")
def replicate_summary(payload: Payload):
    return _call(summarize_replicates, payload.values.get("values", []),
                 expected_unit=payload.values.get("expected_unit"), observed_units=payload.values.get("observed_units"))

@router.post("/replicates/compare")
def replicate_compare(payload: Payload):
    return _call(compare_replicate_groups, payload.values.get("groups", {}))
