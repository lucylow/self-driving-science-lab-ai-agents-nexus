"""Reusable scientific schemas, lineage, data-quality and governance endpoints."""
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from typing import Any
from app.services.scientific_data_contracts import contract_catalogue, convert_unit, validate_measurement_contract
from app.services.schema_registry import default_registry
from app.services.provenance_graph import validate_lineage_graph, trace_to_roots, downstream_impact, validate_artifact_transform
from app.services.quality_rules import default_quality_engine
from app.services.workflow_compiler import compile_workflow, WORKFLOW_TEMPLATES, LAB_DOMAIN
from app.services.science_governance.model_release import evaluate_release_gate, validate_release_transition, compare_champion_challenger, model_rollback_plan

router = APIRouter(prefix="/science-foundations", tags=["science foundations"])
_registry = default_registry()
_quality = default_quality_engine()

class ContractRequest(BaseModel):
    property_name: str
    value: float
    unit: str
    domain: str
    context: dict[str, Any] = Field(default_factory=dict)
    origin: str
    synthetic: bool

class UnitRequest(BaseModel):
    value: float
    source_unit: str
    target_unit: str

class RecordRequest(BaseModel):
    payload: dict[str, Any]
    schema_version: str | None = None

class GraphRequest(BaseModel):
    nodes: list[dict[str, Any]] = Field(default_factory=list)

class TransformRequest(BaseModel):
    parent_ids: list[str]
    declared_transform: str
    tool_version: str
    parameters: dict[str, Any] = Field(default_factory=dict)

class QualityRequest(BaseModel):
    record: dict[str, Any]
    rule_ids: list[str] | None = None

class WorkflowCompileRequest(BaseModel):
    workflow_key: str
    laboratory_code: str
    domain: str
    objective: dict[str, Any]
    context: dict[str, Any] = Field(default_factory=dict)
    synthetic: bool = True

class ReleaseGateRequest(BaseModel):
    model: dict[str, Any]
    evaluation: dict[str, Any]
    approvals: list[dict[str, Any]] = Field(default_factory=list)
    required_domains: list[str] = Field(default_factory=list)
    minimum_holdout_rows: int = 20
    require_uncertainty_calibration: bool = True

class TransitionRequest(BaseModel):
    current_state: str
    next_state: str
    gate_passed: bool = False
    authorized_by: str | None = None

class ChallengerRequest(BaseModel):
    champion: dict[str, Any]
    challenger: dict[str, Any]
    metric: str
    direction: str = "minimize"
    minimum_relative_improvement: float = 0.02

class RollbackRequest(BaseModel):
    current_model_id: str
    previous_model_id: str | None = None
    incident_id: str
    reason: str
    affected_domains: list[str] = Field(default_factory=list)


def _safe(callable_, *args, **kwargs):
    try:
        return callable_(*args, **kwargs)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except (ValueError, TypeError) as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

@router.get("/measurement-contracts")
def list_measurement_contracts():
    return contract_catalogue()

@router.post("/measurement-contracts/validate")
def validate_contract(request: ContractRequest):
    return _safe(validate_measurement_contract, **request.model_dump())

@router.post("/units/convert")
def unit_convert(request: UnitRequest):
    return _safe(convert_unit, request.value, request.source_unit, target_unit=request.target_unit)

@router.get("/schemas")
def list_schemas(domain: str | None = None):
    return _registry.list(domain=domain)

@router.post("/schemas/{schema_key}/validate")
def validate_schema(schema_key: str, request: RecordRequest):
    return _safe(_registry.validate, schema_key, request.payload, request.schema_version)

@router.get("/schemas/{schema_key}/compare")
def compare_schemas(schema_key: str, from_version: str, to_version: str):
    return _safe(_registry.compare, schema_key, from_version, to_version)

@router.post("/lineage/validate")
def lineage_validate(request: GraphRequest):
    return validate_lineage_graph(request.nodes)

@router.post("/lineage/{node_id}/trace")
def lineage_trace(node_id: str, request: GraphRequest):
    return _safe(trace_to_roots, node_id, request.nodes)

@router.post("/lineage/{node_id}/impact")
def lineage_impact(node_id: str, request: GraphRequest):
    return _safe(downstream_impact, node_id, request.nodes)

@router.post("/lineage/transform/validate")
def lineage_transform(request: TransformRequest):
    return _safe(validate_artifact_transform, **request.model_dump())

@router.get("/quality-rules")
def quality_rules():
    return _quality.catalogue()

@router.post("/quality/evaluate")
def quality_evaluate(request: QualityRequest):
    try:
        return _quality.evaluate(request.record, rule_ids=request.rule_ids)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

@router.get("/workflow-compiler/templates")
def workflow_templates():
    return [{"workflow_key": key, "laboratory_code": item["laboratory_code"],
             "node_count": len(item["nodes"]), "laboratory_domain": LAB_DOMAIN[item["laboratory_code"]]}
            for key, item in sorted(WORKFLOW_TEMPLATES.items())]

@router.post("/workflow-compiler/compile")
def workflow_compile(request: WorkflowCompileRequest):
    return _safe(compile_workflow, **request.model_dump())

@router.post("/model-release/gate")
def model_release_gate(request: ReleaseGateRequest):
    return _safe(evaluate_release_gate, **request.model_dump())

@router.post("/model-release/transition/validate")
def model_release_transition(request: TransitionRequest):
    return _safe(validate_release_transition, **request.model_dump())

@router.post("/model-release/challenger-review")
def challenger_review(request: ChallengerRequest):
    return _safe(compare_champion_challenger, **request.model_dump())

@router.post("/model-release/rollback-plan")
def rollback_plan(request: RollbackRequest):
    return _safe(model_rollback_plan, **request.model_dump())
