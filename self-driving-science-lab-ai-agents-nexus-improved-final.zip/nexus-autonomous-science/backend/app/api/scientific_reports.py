"""Evidence-index reports for scientific objective workspaces."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.schemas.extension import ScientificReportRequest
from app.services.scientific_reports import build_objective_report

router = APIRouter(prefix="/reports", tags=["scientific reports"])


@router.post("/objective")
def objective_report(request: ScientificReportRequest, db: Session = Depends(get_db)):
    try:
        return build_objective_report(db, request.objective_id,
                                      include_synthetic=request.include_synthetic,
                                      include_predictions=request.include_predictions)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Objective not found") from exc
