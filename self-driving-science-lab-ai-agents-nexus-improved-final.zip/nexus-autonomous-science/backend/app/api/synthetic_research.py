"""Read-only, paginated API for the fictional research-network demonstration bundle."""
from datetime import datetime, timezone
from hashlib import sha256
import json

from fastapi import APIRouter, HTTPException, Query

from app.services.scientific_analysis import analyze_observations
from app.services.scientific_optimization import rank_experiments_by_quality_and_cost
from app.services.synthetic_research import DEFAULT_COUNTS, get_default_research_universe

router = APIRouter(prefix="/synthetic-research", tags=["synthetic research demo"])


@router.get("")
def summary():
    dataset = get_default_research_universe()
    return dataset["metadata"]


@router.get("/analysis/projects/{project_id}")
def analyze_project(project_id: str):
    """Return descriptive, quality-annotated statistics for one project's observations."""
    dataset = get_default_research_universe()
    if project_id not in {row["id"] for row in dataset["projects"]}:
        raise HTTPException(status_code=404, detail=f"Unknown synthetic project: {project_id}")
    observations = [row for row in dataset["observations"] if row["project_id"] == project_id]
    canonical = json.dumps(observations, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("utf-8")
    return {
        "project_id": project_id,
        "input_dataset_version": f"sha256:{sha256(canonical).hexdigest()}",
        "analysis_method": "descriptive_mean_t_interval_95_v1",
        "software_version": "nexus-scientific-analysis/1.0.0",
        "analyzed_at": datetime.now(timezone.utc).isoformat(),
        "analysis": analyze_observations(observations),
        "synthetic": True,
    }


@router.get("/optimization/projects/{project_id}")
def optimize_project(project_id: str, max_compute_hours: float | None = Query(None, gt=0, le=10000)):
    """Return the feasible Pareto frontier for quality and compute use."""
    dataset = get_default_research_universe()
    if project_id not in {row["id"] for row in dataset["projects"]}:
        raise HTTPException(status_code=404, detail=f"Unknown synthetic project: {project_id}")
    experiments = [row for row in dataset["experiments"] if row["project_id"] == project_id]
    experiment_ids = {row["id"] for row in experiments}
    executions = [row for row in dataset["executions"] if row["experiment_id"] in experiment_ids]
    inputs = json.dumps({"experiments": experiments, "executions": executions}, sort_keys=True, separators=(",", ":")).encode("utf-8")
    result = rank_experiments_by_quality_and_cost(experiments, executions, max_compute_hours=max_compute_hours)
    return {
        "project_id": project_id,
        "input_dataset_version": f"sha256:{sha256(inputs).hexdigest()}",
        "analyzed_at": datetime.now(timezone.utc).isoformat(),
        "synthetic": True,
        **result,
    }


@router.get("/records/{category}")
def list_records(
    category: str,
    offset: int = Query(0, ge=0),
    limit: int = Query(25, ge=1, le=100),
    q: str | None = Query(None, max_length=120),
    program_id: str | None = Query(None, max_length=40),
    project_id: str | None = Query(None, max_length=40),
    sort_by: str = Query("id", pattern="^(id|name|status|created_at|acquisition_score|quality_score|value|posterior_probability)$"),
    descending: bool = False,
):
    if category not in DEFAULT_COUNTS:
        raise HTTPException(status_code=404, detail=f"Unknown synthetic record category: {category}")
    dataset = get_default_research_universe()
    items = dataset[category]
    if program_id:
        projects = {item["id"] for item in dataset["projects"] if item["program_id"] == program_id}
        experiment_ids = {item["id"] for item in dataset["experiments"] if item["project_id"] in projects}
        execution_ids = {item["id"] for item in dataset["executions"] if item["experiment_id"] in experiment_ids}
        finding_ids = {item["id"] for item in dataset["findings"] if item["project_id"] in projects}
        linked = {"projects": "id", "objectives": "project_id", "hypotheses": "project_id", "experiments": "project_id",
            "executions": "project_id", "observations": "project_id", "models": "project_id", "agent_activities": "project_id", "findings": "project_id",
            "iterations": "project_id", "reports": "project_id"}
        if category == "programs":
            items = [x for x in items if x["id"] == program_id]
        elif category in linked:
            field = linked[category]
            items = [x for x in items if x.get(field) in projects]
        elif category in {"evaluations", "compute_jobs", "failures"}:
            items = [x for x in items if x.get("execution_id") in execution_ids]
        elif category == "insights":
            items = [x for x in items if x.get("finding_id") in finding_ids]
        elif category == "decisions":
            items = [x for x in items if x.get("experiment_id") in experiment_ids]
        elif category == "references":
            hypothesis_ids = {x["id"] for x in dataset["hypotheses"] if x["project_id"] in projects}
            items = [x for x in items if x.get("hypothesis_id") in hypothesis_ids]
        elif category == "datasets":
            dataset_ids = {x["id"] for x in items if x["project_id"] in projects}
            items = [x for x in items if x["id"] in dataset_ids]
        elif category == "dataset_versions":
            dataset_ids = {x["id"] for x in dataset["datasets"] if x["project_id"] in projects}
            items = [x for x in items if x.get("dataset_id") in dataset_ids]
    if project_id:
        if project_id not in {row["id"] for row in dataset["projects"]}:
            raise HTTPException(status_code=404, detail=f"Unknown synthetic project: {project_id}")
        project_experiments = {row["id"] for row in dataset["experiments"] if row["project_id"] == project_id}
        project_executions = {row["id"] for row in dataset["executions"] if row["project_id"] == project_id}
        project_findings = {row["id"] for row in dataset["findings"] if row["project_id"] == project_id}
        project_hypotheses = {row["id"] for row in dataset["hypotheses"] if row["project_id"] == project_id}
        project_datasets = {row["id"] for row in dataset["datasets"] if row["project_id"] == project_id}
        project_filter_fields = {"projects": "id", "objectives": "project_id", "hypotheses": "project_id", "experiments": "project_id",
            "executions": "project_id", "observations": "project_id", "models": "project_id", "agent_activities": "project_id",
            "findings": "project_id", "datasets": "project_id", "iterations": "project_id", "reports": "project_id"}
        if category in project_filter_fields:
            field = project_filter_fields[category]
            items = [row for row in items if row.get(field) == project_id]
        elif category in {"evaluations", "compute_jobs", "failures"}:
            items = [row for row in items if row.get("execution_id") in project_executions]
        elif category == "insights":
            items = [row for row in items if row.get("finding_id") in project_findings]
        elif category == "decisions":
            items = [row for row in items if row.get("experiment_id") in project_experiments]
        elif category == "references":
            items = [row for row in items if row.get("hypothesis_id") in project_hypotheses]
        elif category == "dataset_versions":
            items = [row for row in items if row.get("dataset_id") in project_datasets]
    if q:
        needle = q.casefold()
        items = [item for item in items if needle in " ".join(str(value) for value in item.values() if value is not None).casefold()]
    items = sorted(items, key=lambda row: str(row.get(sort_by, "")), reverse=descending)
    return {"category": category, "total": len(items), "offset": offset, "limit": limit,
        "items": items[offset:offset + limit], "synthetic": True}
