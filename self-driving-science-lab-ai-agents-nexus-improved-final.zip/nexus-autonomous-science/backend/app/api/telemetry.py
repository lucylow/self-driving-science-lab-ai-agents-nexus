"""Dashboard overview, digital twin status and append-only event feed."""

from fastapi import APIRouter, Depends
from sqlalchemy import func, select
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.entities import Agent, Approval, AuditEvent, Candidate, Experiment, Laboratory, Measurement
from app.services.digital_twin import twin_overview

router = APIRouter(tags=["platform telemetry"])


@router.get("/overview")
def overview(db: Session = Depends(get_db)):
    counts = {
        "laboratories": db.scalar(select(func.count()).select_from(Laboratory)) or 0,
        "agents": db.scalar(select(func.count()).select_from(Agent)) or 0,
        "experiments": db.scalar(select(func.count()).select_from(Experiment)) or 0,
        "candidates": db.scalar(select(func.count()).select_from(Candidate)) or 0,
        "measurements": db.scalar(select(func.count()).select_from(Measurement)) or 0,
        "pending_approvals": db.scalar(select(func.count()).select_from(Approval).where(Approval.status == "pending")) or 0,
    }
    statuses = db.execute(select(Experiment.status, func.count()).group_by(Experiment.status)).all()
    active_agents = db.scalar(select(func.count()).select_from(Agent).where(Agent.status == "running")) or 0
    latest_events = db.scalars(select(AuditEvent).order_by(AuditEvent.created_at.desc()).limit(8)).all()
    return {
        "counts": counts,
        "experiment_status": {status: count for status, count in statuses},
        "active_agents": active_agents,
        "network_status": "demo_online",
        "execution_mode": "simulation_only",
        "synthetic_data_notice": "Seeded records and digital-twin results are synthetic demonstrations.",
        "recent_events": [{"id": e.id, "event_type": e.event_type, "actor": e.actor, "subject_type": e.subject_type, "subject_id": e.subject_id, "created_at": e.created_at, "payload": e.payload} for e in latest_events],
    }


@router.get("/twin")
def get_twin_overview():
    return twin_overview()


@router.get("/events")
def events(limit: int = 50, db: Session = Depends(get_db)):
    limit = max(1, min(limit, 200))
    rows = db.scalars(select(AuditEvent).order_by(AuditEvent.created_at.desc()).limit(limit)).all()
    return [{"id": e.id, "event_type": e.event_type, "actor": e.actor, "component": e.component, "subject_type": e.subject_type, "subject_id": e.subject_id, "correlation_id": e.correlation_id, "payload": e.payload, "created_at": e.created_at} for e in rows]
