"""Diagnostic API for synchronized sensor stream review."""
from fastapi import APIRouter, HTTPException
from app.schemas.extension import TimeSeriesReviewRequest
from app.services.sensor_intelligence import review_timeseries

router = APIRouter(prefix="/telemetry-intelligence", tags=["sensor intelligence"])


@router.post("/review")
def review_stream(request: TimeSeriesReviewRequest):
    try:
        return review_timeseries([item.model_dump() for item in request.points],
                                 expected_interval_seconds=request.expected_interval_seconds,
                                 drift_window=request.drift_window)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
