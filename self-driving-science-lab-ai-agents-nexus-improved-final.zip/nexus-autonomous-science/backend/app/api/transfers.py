"""Cross-laboratory evidence transfer with target-scientist review."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.entities import CrossLabTransfer
from app.schemas.extension import TransferProposeRequest, TransferDecisionRequest
from app.services.cross_lab_transfer import propose_transfer, decide_transfer

router = APIRouter(prefix="/transfers", tags=["cross-laboratory collaboration"])


@router.post("", status_code=201)
def create_transfer(request: TransferProposeRequest, db: Session = Depends(get_db)):
    try:
        transfer = propose_transfer(db, request.model_dump())
        db.commit()
        return transfer
    except (ValueError, KeyError) as exc:
        db.rollback()
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.get("")
def list_transfers(status: str | None = None, target_laboratory: str | None = None,
                   db: Session = Depends(get_db)):
    query = select(CrossLabTransfer).order_by(CrossLabTransfer.created_at.desc())
    if status:
        query = query.where(CrossLabTransfer.status == status)
    if target_laboratory:
        query = query.where(CrossLabTransfer.target_laboratory == target_laboratory.upper())
    return db.scalars(query.limit(200)).all()


@router.post("/{transfer_id}/decision")
def transfer_decision(transfer_id: str, request: TransferDecisionRequest,
                      db: Session = Depends(get_db)):
    try:
        transfer = decide_transfer(db, transfer_id, decision=request.decision,
                                   reviewer=request.reviewer, note=request.note)
        db.commit()
        return transfer
    except KeyError as exc:
        db.rollback()
        raise HTTPException(status_code=404, detail="Transfer not found") from exc
    except ValueError as exc:
        db.rollback()
        raise HTTPException(status_code=409, detail=str(exc)) from exc
