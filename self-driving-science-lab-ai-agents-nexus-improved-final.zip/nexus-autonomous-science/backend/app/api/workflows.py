"""Preview agent workflows without committing scientific or physical actions."""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.entities import Candidate, Objective
from app.services.workflow_graph import WorkflowState, run_discovery_workflow

router = APIRouter(prefix="/workflow", tags=["workflow orchestration"])


@router.post("/preview")
def preview_discovery_workflow(objective_id: str | None = None, db: Session = Depends(get_db)):
    objective = db.get(Objective, objective_id) if objective_id else db.scalar(select(Objective).order_by(Objective.created_at).limit(1))
    if objective is None:
        raise HTTPException(status_code=404, detail="No objective is available. Create one first.")
    candidates = db.scalars(select(Candidate).where(Candidate.laboratory_code == objective.laboratory_code)).all()
    state = WorkflowState(
        objective={
            "id": objective.id,
            "description": objective.description,
            "target_properties": objective.target_properties,
            "constraints": objective.constraints_json,
        },
        candidate_records=[{
            "id": candidate.id, "code": candidate.code, "name": candidate.name,
            "family": candidate.family, "predicted_properties": candidate.predicted_properties,
            "uncertainty": candidate.uncertainty, "feasibility_score": candidate.feasibility_score,
        } for candidate in candidates],
    )
    result = run_discovery_workflow(state)
    return {
        "workflow": "sdl1_discovery_preview",
        "objective_id": objective.id,
        "messages": result.messages,
        "ranked_candidates": result.ranking,
        "feasibility": result.feasibility,
        "approval_checkpoint": result.approval_checkpoint,
        "synthetic": True,
        "physical_execution_enabled": False,
    }
