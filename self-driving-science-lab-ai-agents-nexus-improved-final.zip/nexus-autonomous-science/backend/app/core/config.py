"""Typed application settings for the NEXUS API."""

from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = "NEXUS Autonomous Science Network"
    environment: str = "development"
    database_url: str = "sqlite:///./nexus.db"
    cors_origins: str = "http://localhost:3000"
    demo_mode: bool = True
    log_level: str = "INFO"

    model_config = SettingsConfigDict(
        env_prefix="NEXUS_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    @property
    def allowed_origins(self) -> list[str]:
        return [origin.strip() for origin in self.cors_origins.split(",") if origin.strip()]


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
