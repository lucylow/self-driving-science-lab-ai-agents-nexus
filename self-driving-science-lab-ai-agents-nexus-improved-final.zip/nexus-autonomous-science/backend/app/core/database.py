"""Database setup. SQLite is the frictionless local default; PostgreSQL is supported by URL."""

from collections.abc import Generator
from sqlalchemy import create_engine, inspect, text
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker
from app.core.config import settings


connect_args = {"check_same_thread": False} if settings.database_url.startswith("sqlite") else {}
engine = create_engine(settings.database_url, connect_args=connect_args, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, expire_on_commit=False)


class Base(DeclarativeBase):
    pass


def get_db() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def create_schema() -> None:
    # Import models before create_all so their tables are registered on Base.metadata.
    from app.models import entities  # noqa: F401
    Base.metadata.create_all(bind=engine)
    ensure_outbox_event_key_unique_index(engine)


def ensure_outbox_event_key_unique_index(bind) -> None:
    """Upgrade legacy schemas without deleting or rewriting duplicate event history."""
    from app.models.entities import OutboxEvent

    index = next(index for index in OutboxEvent.__table__.indexes
                 if index.name == "uq_outbox_events_event_key")
    inspector = inspect(bind)
    if "outbox_events" not in inspector.get_table_names():
        return
    indexes = {item["name"]: item for item in inspector.get_indexes("outbox_events")}
    existing = indexes.get(index.name)
    if existing:
        if not existing.get("unique"):
            raise RuntimeError(f"Index {index.name} exists but is not unique")
        return

    with bind.connect() as connection:
        duplicate = connection.execute(text(
            "SELECT event_key, COUNT(*) AS copies FROM outbox_events "
            "GROUP BY event_key HAVING COUNT(*) > 1 LIMIT 1"
        )).first()
    if duplicate:
        raise RuntimeError(
            "Cannot enforce outbox event_key uniqueness: duplicate keys exist. "
            "Preserve the records, review their provenance, and resolve collisions explicitly "
            "before restarting; no rows were modified."
        )

    try:
        index.create(bind=bind, checkfirst=True)
    except Exception as exc:
        # Two processes may race during first startup. Accept only if the intended unique
        # index now exists; otherwise surface the migration failure to the operator.
        indexes = {item["name"]: item for item in inspect(bind).get_indexes("outbox_events")}
        created = indexes.get(index.name)
        if created and created.get("unique"):
            return
        raise RuntimeError(f"Failed to create required index {index.name}") from exc
