"""Domain errors are mapped to explicit HTTP responses by the API layer."""


class NexusError(Exception):
    """Base class for expected domain-level failures."""


class NotFoundError(NexusError):
    pass


class InvalidTransitionError(NexusError):
    pass


class GovernanceError(NexusError):
    pass


class ValidationDomainError(NexusError):
    pass
