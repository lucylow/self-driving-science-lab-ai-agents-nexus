"""Small structured logging setup for local development and container deployments."""

import logging
from app.core.config import settings
from app.core.request_context import request_id_context


class RequestIdFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        record.request_id = request_id_context.get()
        return True


def configure_logging() -> None:
    logging.basicConfig(
        level=getattr(logging, settings.log_level.upper(), logging.INFO),
        format="%(asctime)s %(levelname)s %(name)s request_id=%(request_id)s %(message)s",
    )
    root = logging.getLogger()
    if not any(isinstance(item, RequestIdFilter) for handler in root.handlers for item in handler.filters):
        for handler in root.handlers:
            handler.addFilter(RequestIdFilter())
