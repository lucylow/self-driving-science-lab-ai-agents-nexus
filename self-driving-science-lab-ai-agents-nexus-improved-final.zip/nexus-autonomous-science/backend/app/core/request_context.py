"""Validated HTTP request correlation identifiers for logs and response headers."""
from __future__ import annotations

import re
from contextvars import ContextVar
from uuid import uuid4


request_id_context: ContextVar[str] = ContextVar("nexus_request_id", default="-")
_REQUEST_ID_RE = re.compile(r"[A-Za-z0-9._-]{1,128}\Z")
_REQUEST_ID_HEADER = b"x-request-id"


class RequestContextMiddleware:
    """Echo a safe caller ID or generate one, without trusting arbitrary header text."""

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        incoming = dict(scope.get("headers", [])).get(_REQUEST_ID_HEADER, b"")
        try:
            candidate = incoming.decode("ascii")
        except UnicodeDecodeError:
            candidate = ""
        request_id = candidate if _REQUEST_ID_RE.fullmatch(candidate) else uuid4().hex
        scope.setdefault("state", {})["request_id"] = request_id
        token = request_id_context.set(request_id)

        async def send_with_request_id(message):
            if message["type"] == "http.response.start":
                headers = [
                    (key, value) for key, value in message.get("headers", [])
                    if key.lower() != _REQUEST_ID_HEADER
                ]
                headers.append((_REQUEST_ID_HEADER, request_id.encode("ascii")))
                message["headers"] = headers
            await send(message)

        try:
            await self.app(scope, receive, send_with_request_id)
        finally:
            request_id_context.reset(token)
