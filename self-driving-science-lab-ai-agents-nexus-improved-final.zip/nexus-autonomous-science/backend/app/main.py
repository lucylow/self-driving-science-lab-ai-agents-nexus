"""NEXUS Autonomous Science Network API entry point."""

import logging
from uuid import uuid4
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy import text
from app.api.router import api_router
from app.core.config import settings
from app.core.database import SessionLocal, create_schema, engine
from app.core.errors import (
    InvalidTransitionError,
    NexusError,
    NotFoundError,
    ValidationDomainError,
)
from app.core.logging import configure_logging
from app.core.request_context import RequestContextMiddleware
from app.services.seed import seed_database

configure_logging()
logger = logging.getLogger("nexus.api")


@asynccontextmanager
async def lifespan(_: FastAPI):
    create_schema()
    db = SessionLocal()
    try:
        seed_database(db)
    finally:
        db.close()
    logger.info("NEXUS API started; demo_mode=%s", settings.demo_mode)
    yield
    logger.info("NEXUS API stopped")


app = FastAPI(
    title=settings.app_name,
    version="0.1.0",
    description="Scientific operating-system foundation for SDL0–SDL7. Demo data is synthetic; physical lab execution is disabled.",
    lifespan=lifespan,
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PATCH", "OPTIONS"],
    allow_headers=["*"],
    expose_headers=["X-Request-ID"],
)
app.add_middleware(RequestContextMiddleware)
app.include_router(api_router)


@app.get("/health", tags=["system"])
def health():
    return {"status": "ok", "service": "nexus-api", "version": "0.1.0", "demo_mode": settings.demo_mode}


@app.get("/ready", tags=["system"])
def readiness():
    """Readiness checks only dependencies that are genuinely configured."""
    try:
        with engine.connect() as connection:
            connection.execute(text("SELECT 1"))
    except Exception as exc:
        logger.warning("Database readiness check failed: %s", type(exc).__name__)
        return JSONResponse(
            status_code=503,
            content={"status": "not_ready", "dependencies": {"database": "unavailable"}},
        )
    return {"status": "ready", "dependencies": {"database": "available"}}


@app.exception_handler(NexusError)
async def handle_domain_error(_: Request, exc: NexusError):
    status_code = {
        NotFoundError: 404,
        ValidationDomainError: 422,
        InvalidTransitionError: 409,
    }.get(type(exc), 409)
    return JSONResponse(
        status_code=status_code,
        content={"detail": str(exc), "error_type": exc.__class__.__name__},
    )
@app.exception_handler(Exception)
async def handle_unexpected_error(request: Request, exc: Exception):
    request_id = getattr(request.state, "request_id", None) or uuid4().hex[:12]
    route = request.scope.get("route")
    route_path = getattr(route, "path", "unmatched")
    logger.error("Unhandled API error request_id=%s route=%s", request_id, route_path,
                 exc_info=(type(exc), exc, exc.__traceback__))
    return JSONResponse(
        status_code=500,
        content={"detail": "An unexpected server error occurred.", "request_id": request_id},
        headers={"X-Request-ID": request_id},
    )
