"""Relational records for the scientific operating system.

The schema deliberately stores scientific state and governance state separately.
JSON columns preserve domain-specific fields without flattening every laboratory into
one false universal schema. Production deployments should add migrations with Alembic.
"""

from datetime import datetime, timezone
from sqlalchemy import Boolean, DateTime, Float, ForeignKey, Index, Integer, JSON, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column
from app.core.database import Base


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class Laboratory(Base):
    __tablename__ = "laboratories"
    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    code: Mapped[str] = mapped_column(String(8), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(120))
    focus: Mapped[str] = mapped_column(String(180))
    description: Mapped[str] = mapped_column(Text, default="")
    status: Mapped[str] = mapped_column(String(24), default="online")
    priority: Mapped[str] = mapped_column(String(24), default="standard")
    metadata_json: Mapped[dict] = mapped_column("metadata", JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class Agent(Base):
    __tablename__ = "agents"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    agent_key: Mapped[str] = mapped_column(String(100), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(120))
    department: Mapped[str] = mapped_column(String(80))
    laboratory_code: Mapped[str] = mapped_column(String(8), default="SDL0", index=True)
    purpose: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(24), default="idle")
    permission_level: Mapped[str] = mapped_column(String(32), default="propose_only")
    capabilities: Mapped[list] = mapped_column(JSON, default=list)
    last_run_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    run_count: Mapped[int] = mapped_column(Integer, default=0)
    synthetic: Mapped[bool] = mapped_column(Boolean, default=True)


class Objective(Base):
    __tablename__ = "objectives"
    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    code: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    title: Mapped[str] = mapped_column(String(240))
    domain: Mapped[str] = mapped_column(String(64), index=True)
    laboratory_code: Mapped[str] = mapped_column(String(8), default="SDL1")
    description: Mapped[str] = mapped_column(Text)
    target_properties: Mapped[list] = mapped_column(JSON, default=list)
    constraints_json: Mapped[dict] = mapped_column("constraints", JSON, default=dict)
    evidence_requirements: Mapped[dict] = mapped_column(JSON, default=dict)
    governance: Mapped[dict] = mapped_column(JSON, default=dict)
    version: Mapped[int] = mapped_column(Integer, default=1)
    status: Mapped[str] = mapped_column(String(24), default="active")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    synthetic: Mapped[bool] = mapped_column(Boolean, default=True)


class Hypothesis(Base):
    __tablename__ = "hypotheses"
    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    code: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    objective_id: Mapped[str] = mapped_column(ForeignKey("objectives.id"), index=True)
    statement: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(32), default="proposed")
    evidence_grade: Mapped[str] = mapped_column(String(8), default="E0")
    confidence: Mapped[float] = mapped_column(Float, default=0.0)
    predictions: Mapped[list] = mapped_column(JSON, default=list)
    supporting_observations: Mapped[list] = mapped_column(JSON, default=list)
    contradictory_observations: Mapped[list] = mapped_column(JSON, default=list)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    synthetic: Mapped[bool] = mapped_column(Boolean, default=True)


class Candidate(Base):
    __tablename__ = "candidates"
    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    code: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(180))
    formula: Mapped[str] = mapped_column(String(100), default="")
    family: Mapped[str] = mapped_column(String(120), default="")
    domain: Mapped[str] = mapped_column(String(64), default="inorganic_materials")
    laboratory_code: Mapped[str] = mapped_column(String(8), default="SDL1")
    predicted_properties: Mapped[dict] = mapped_column(JSON, default=dict)
    uncertainty: Mapped[dict] = mapped_column(JSON, default=dict)
    feasibility_score: Mapped[float] = mapped_column(Float, default=0.0)
    recommendation_score: Mapped[float] = mapped_column(Float, default=0.0)
    lifecycle_stage: Mapped[str] = mapped_column(String(40), default="model_candidate")
    evidence_type: Mapped[str] = mapped_column(String(40), default="model_prediction")
    synthetic: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class Experiment(Base):
    __tablename__ = "experiments"
    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    code: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    title: Mapped[str] = mapped_column(String(240))
    laboratory_code: Mapped[str] = mapped_column(String(8), index=True)
    objective_id: Mapped[str | None] = mapped_column(ForeignKey("objectives.id"), nullable=True)
    hypothesis_id: Mapped[str | None] = mapped_column(ForeignKey("hypotheses.id"), nullable=True)
    candidate_id: Mapped[str | None] = mapped_column(ForeignKey("candidates.id"), nullable=True)
    status: Mapped[str] = mapped_column(String(32), default="draft", index=True)
    execution_mode: Mapped[str] = mapped_column(String(24), default="simulation")
    protocol_id: Mapped[str] = mapped_column(String(100), default="unassigned")
    protocol_version: Mapped[str] = mapped_column(String(32), default="1.0.0")
    owner: Mapped[str] = mapped_column(String(120), default="NEXUS scientist")
    estimated_duration_minutes: Mapped[int] = mapped_column(Integer, default=60)
    resource_requirements: Mapped[dict] = mapped_column(JSON, default=dict)
    governance: Mapped[dict] = mapped_column(JSON, default=dict)
    result_summary: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)
    synthetic: Mapped[bool] = mapped_column(Boolean, default=True)


class Approval(Base):
    __tablename__ = "approvals"
    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    experiment_id: Mapped[str] = mapped_column(ForeignKey("experiments.id"), index=True)
    requested_by: Mapped[str] = mapped_column(String(120))
    reviewer: Mapped[str | None] = mapped_column(String(120), nullable=True)
    reason: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(24), default="pending", index=True)
    reviewer_note: Mapped[str] = mapped_column(Text, default="")
    requested_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    decided_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class Measurement(Base):
    __tablename__ = "measurements"
    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    experiment_id: Mapped[str] = mapped_column(ForeignKey("experiments.id"), index=True)
    sample_id: Mapped[str] = mapped_column(String(64), default="SYNTHETIC-SAMPLE")
    property_name: Mapped[str] = mapped_column(String(120))
    value: Mapped[float] = mapped_column(Float)
    unit: Mapped[str] = mapped_column(String(48), default="dimensionless")
    uncertainty: Mapped[float | None] = mapped_column(Float, nullable=True)
    origin: Mapped[str] = mapped_column(String(32), default="simulation")
    quality_status: Mapped[str] = mapped_column(String(24), default="pending")
    raw_artifact_uri: Mapped[str] = mapped_column(String(500), default="")
    metadata_json: Mapped[dict] = mapped_column("metadata", JSON, default=dict)
    recorded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    synthetic: Mapped[bool] = mapped_column(Boolean, default=True)


class Dataset(Base):
    __tablename__ = "datasets"
    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    name: Mapped[str] = mapped_column(String(180))
    domain: Mapped[str] = mapped_column(String(64), index=True)
    data_layer: Mapped[str] = mapped_column(String(32))
    version: Mapped[str] = mapped_column(String(24), default="1.0.0")
    record_count: Mapped[int] = mapped_column(Integer, default=0)
    quality_status: Mapped[str] = mapped_column(String(24), default="preliminary")
    lineage: Mapped[list] = mapped_column(JSON, default=list)
    synthetic: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class AuditEvent(Base):
    __tablename__ = "audit_events"
    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    event_type: Mapped[str] = mapped_column(String(80), index=True)
    actor: Mapped[str] = mapped_column(String(120), default="system")
    component: Mapped[str] = mapped_column(String(120), default="api")
    subject_type: Mapped[str] = mapped_column(String(60))
    subject_id: Mapped[str] = mapped_column(String(64), index=True)
    correlation_id: Mapped[str] = mapped_column(String(64), default="")
    payload: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class Instrument(Base):
    __tablename__ = "instruments"
    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    laboratory_code: Mapped[str] = mapped_column(String(8), index=True)
    name: Mapped[str] = mapped_column(String(160))
    instrument_type: Mapped[str] = mapped_column(String(100))
    status: Mapped[str] = mapped_column(String(24), default="idle")
    capabilities: Mapped[list] = mapped_column(JSON, default=list)
    telemetry: Mapped[dict] = mapped_column(JSON, default=dict)
    requires_local_approval: Mapped[bool] = mapped_column(Boolean, default=True)
    synthetic: Mapped[bool] = mapped_column(Boolean, default=True)
    __table_args__ = (UniqueConstraint("laboratory_code", "name", name="uq_instrument_lab_name"),)


class ScientificSample(Base):
    """Persistent identity for physical, computational, and reference samples."""
    __tablename__ = "scientific_samples"
    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    code: Mapped[str] = mapped_column(String(80), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(180))
    laboratory_code: Mapped[str] = mapped_column(String(8), index=True)
    domain: Mapped[str] = mapped_column(String(64), index=True)
    sample_type: Mapped[str] = mapped_column(String(48), default="material")
    parent_sample_id: Mapped[str | None] = mapped_column(ForeignKey("scientific_samples.id"), nullable=True)
    composition: Mapped[dict] = mapped_column(JSON, default=dict)
    preparation_metadata: Mapped[dict] = mapped_column(JSON, default=dict)
    identity_status: Mapped[str] = mapped_column(String(24), default="unverified")
    lifecycle_status: Mapped[str] = mapped_column(String(24), default="registered")
    provenance: Mapped[dict] = mapped_column(JSON, default=dict)
    synthetic: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class ScientificArtifact(Base):
    """Artifact metadata record; byte persistence and immutability depend on storage policy."""
    __tablename__ = "scientific_artifacts"
    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    artifact_code: Mapped[str] = mapped_column(String(80), unique=True, index=True)
    sha256: Mapped[str] = mapped_column(String(64), index=True)
    storage_uri: Mapped[str] = mapped_column(String(700))
    media_type: Mapped[str] = mapped_column(String(160))
    artifact_type: Mapped[str] = mapped_column(String(48), default="raw_data")
    byte_size: Mapped[int] = mapped_column(Integer, default=0)
    domain: Mapped[str] = mapped_column(String(64), index=True)
    laboratory_code: Mapped[str] = mapped_column(String(8), index=True)
    sample_id: Mapped[str | None] = mapped_column(ForeignKey("scientific_samples.id"), nullable=True)
    experiment_id: Mapped[str | None] = mapped_column(ForeignKey("experiments.id"), nullable=True)
    origin: Mapped[str] = mapped_column(String(32), default="human_observation")
    metadata_json: Mapped[dict] = mapped_column("metadata", JSON, default=dict)
    parent_artifact_ids: Mapped[list] = mapped_column(JSON, default=list)
    synthetic: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class TrainingDatasetSnapshot(Base):
    """Model-training snapshot metadata with source-row lineage."""
    __tablename__ = "training_dataset_snapshots"
    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    dataset_key: Mapped[str] = mapped_column(String(100), index=True)
    version: Mapped[str] = mapped_column(String(24), default="1.0.0")
    domain: Mapped[str] = mapped_column(String(64), index=True)
    target_property: Mapped[str] = mapped_column(String(120))
    feature_names: Mapped[list] = mapped_column(JSON, default=list)
    source_measurement_ids: Mapped[list] = mapped_column(JSON, default=list)
    source_sample_ids: Mapped[list] = mapped_column(JSON, default=list)
    records_json: Mapped[list] = mapped_column(JSON, default=list)
    target_unit: Mapped[str] = mapped_column(String(48), default="dimensionless")
    split_manifest: Mapped[dict] = mapped_column(JSON, default=dict)
    quality_report: Mapped[dict] = mapped_column(JSON, default=dict)
    content_hash: Mapped[str] = mapped_column(String(64), index=True)
    row_count: Mapped[int] = mapped_column(Integer, default=0)
    status: Mapped[str] = mapped_column(String(24), default="draft")
    synthetic: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class ScientificModel(Base):
    """Versioned scientific model metadata; model weights are stored separately."""
    __tablename__ = "scientific_models"
    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    model_key: Mapped[str] = mapped_column(String(100), index=True)
    version: Mapped[str] = mapped_column(String(32), default="0.1.0")
    name: Mapped[str] = mapped_column(String(180))
    model_type: Mapped[str] = mapped_column(String(64))
    supported_domains: Mapped[list] = mapped_column(JSON, default=list)
    supported_modalities: Mapped[list] = mapped_column(JSON, default=list)
    prediction_targets: Mapped[list] = mapped_column(JSON, default=list)
    training_dataset_id: Mapped[str | None] = mapped_column(ForeignKey("training_dataset_snapshots.id"), nullable=True)
    hyperparameters: Mapped[dict] = mapped_column(JSON, default=dict)
    metrics: Mapped[dict] = mapped_column(JSON, default=dict)
    uncertainty_profile: Mapped[dict] = mapped_column(JSON, default=dict)
    limitations: Mapped[list] = mapped_column(JSON, default=list)
    status: Mapped[str] = mapped_column(String(32), default="registered", index=True)
    model_uri: Mapped[str] = mapped_column(String(700), default="")
    synthetic: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class ScientificModelEvaluation(Base):
    __tablename__ = "scientific_model_evaluations"
    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    model_id: Mapped[str] = mapped_column(ForeignKey("scientific_models.id"), index=True)
    dataset_id: Mapped[str] = mapped_column(ForeignKey("training_dataset_snapshots.id"), index=True)
    split_name: Mapped[str] = mapped_column(String(32), default="holdout")
    metrics: Mapped[dict] = mapped_column(JSON, default=dict)
    subgroup_metrics: Mapped[dict] = mapped_column(JSON, default=dict)
    calibration_metrics: Mapped[dict] = mapped_column(JSON, default=dict)
    applicability_report: Mapped[dict] = mapped_column(JSON, default=dict)
    promotion_recommendation: Mapped[str] = mapped_column(String(48), default="hold_for_review")
    synthetic: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class ScientificPrediction(Base):
    __tablename__ = "scientific_predictions"
    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    model_id: Mapped[str] = mapped_column(ForeignKey("scientific_models.id"), index=True)
    subject_type: Mapped[str] = mapped_column(String(40))
    subject_id: Mapped[str] = mapped_column(String(80), index=True)
    domain: Mapped[str] = mapped_column(String(64), index=True)
    target_property: Mapped[str] = mapped_column(String(120))
    predicted_value: Mapped[float] = mapped_column(Float)
    unit: Mapped[str] = mapped_column(String(48), default="dimensionless")
    uncertainty: Mapped[float | None] = mapped_column(Float, nullable=True)
    applicability: Mapped[dict] = mapped_column(JSON, default=dict)
    input_refs: Mapped[list] = mapped_column(JSON, default=list)
    evidence_origin: Mapped[str] = mapped_column(String(32), default="prediction")
    synthetic: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class AgentRunRecord(Base):
    __tablename__ = "agent_run_records"
    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    agent_id: Mapped[str] = mapped_column(String(64), index=True)
    task_type: Mapped[str] = mapped_column(String(80))
    status: Mapped[str] = mapped_column(String(24), default="queued", index=True)
    input_contract: Mapped[dict] = mapped_column(JSON, default=dict)
    output_contract: Mapped[dict] = mapped_column(JSON, default=dict)
    error_summary: Mapped[str] = mapped_column(Text, default="")
    duration_ms: Mapped[int] = mapped_column(Integer, default=0)
    correlation_id: Mapped[str] = mapped_column(String(64), index=True)
    synthetic: Mapped[bool] = mapped_column(Boolean, default=True)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class WorkflowRunRecord(Base):
    __tablename__ = "workflow_run_records"
    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    workflow_key: Mapped[str] = mapped_column(String(100), index=True)
    laboratory_code: Mapped[str] = mapped_column(String(8), index=True)
    objective_id: Mapped[str | None] = mapped_column(ForeignKey("objectives.id"), nullable=True)
    status: Mapped[str] = mapped_column(String(24), default="created", index=True)
    current_node: Mapped[str] = mapped_column(String(100), default="")
    state_json: Mapped[dict] = mapped_column("state", JSON, default=dict)
    node_history: Mapped[list] = mapped_column(JSON, default=list)
    error_summary: Mapped[str] = mapped_column(Text, default="")
    correlation_id: Mapped[str] = mapped_column(String(64), index=True)
    synthetic: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)


class CrossLabTransfer(Base):
    __tablename__ = "cross_lab_transfers"
    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    source_laboratory: Mapped[str] = mapped_column(String(8), index=True)
    target_laboratory: Mapped[str] = mapped_column(String(8), index=True)
    subject_type: Mapped[str] = mapped_column(String(40))
    subject_id: Mapped[str] = mapped_column(String(80), index=True)
    domain: Mapped[str] = mapped_column(String(64), index=True)
    schema_version: Mapped[str] = mapped_column(String(24), default="1.0.0")
    compatibility_report: Mapped[dict] = mapped_column(JSON, default=dict)
    transfer_payload: Mapped[dict] = mapped_column(JSON, default=dict)
    status: Mapped[str] = mapped_column(String(24), default="proposed", index=True)
    reviewed_by: Mapped[str | None] = mapped_column(String(120), nullable=True)
    synthetic: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class OutboxEvent(Base):
    """Transactional outbox for reliable event publication to external brokers."""
    __tablename__ = "outbox_events"
    __table_args__ = (Index("uq_outbox_events_event_key", "event_key", unique=True),)
    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    event_key: Mapped[str] = mapped_column(String(120), index=True)
    aggregate_type: Mapped[str] = mapped_column(String(60), index=True)
    aggregate_id: Mapped[str] = mapped_column(String(80), index=True)
    event_type: Mapped[str] = mapped_column(String(80), index=True)
    payload: Mapped[dict] = mapped_column(JSON, default=dict)
    status: Mapped[str] = mapped_column(String(24), default="pending", index=True)
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    last_error: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    published_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class ResearchSource(Base):
    """Registered bibliographic source; metadata alone is not scientific evidence."""
    __tablename__ = "research_sources"
    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    source_key: Mapped[str] = mapped_column(String(140), unique=True, index=True)
    title: Mapped[str] = mapped_column(String(500))
    doi: Mapped[str | None] = mapped_column(String(180), nullable=True, index=True)
    url: Mapped[str] = mapped_column(String(1000), default="")
    publication_year: Mapped[int | None] = mapped_column(Integer, nullable=True)
    venue: Mapped[str] = mapped_column(String(240), default="")
    authors: Mapped[list] = mapped_column(JSON, default=list)
    abstract: Mapped[str] = mapped_column(Text, default="")
    source_type: Mapped[str] = mapped_column(String(32), default="journal_article")
    metadata_json: Mapped[dict] = mapped_column("metadata", JSON, default=dict)
    verification_status: Mapped[str] = mapped_column(String(32), default="metadata_unverified")
    synthetic: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class ScientificClaim(Base):
    """A reviewed scientific proposition linked to explicit source and data records."""
    __tablename__ = "scientific_claims"
    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    claim_key: Mapped[str] = mapped_column(String(120), unique=True, index=True)
    statement: Mapped[str] = mapped_column(Text)
    domain: Mapped[str] = mapped_column(String(64), index=True)
    laboratory_code: Mapped[str] = mapped_column(String(8), index=True)
    claim_type: Mapped[str] = mapped_column(String(48), default="empirical_observation")
    support_refs: Mapped[list] = mapped_column(JSON, default=list)
    contradiction_refs: Mapped[list] = mapped_column(JSON, default=list)
    assumptions: Mapped[list] = mapped_column(JSON, default=list)
    limitations: Mapped[list] = mapped_column(JSON, default=list)
    status: Mapped[str] = mapped_column(String(32), default="draft")
    reviewer: Mapped[str | None] = mapped_column(String(120), nullable=True)
    review_note: Mapped[str] = mapped_column(Text, default="")
    synthetic: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class IngestionJob(Base):
    """Staged scientific-data ingestion with deterministic, reviewable transitions."""
    __tablename__ = "ingestion_jobs"
    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    job_code: Mapped[str] = mapped_column(String(100), unique=True, index=True)
    laboratory_code: Mapped[str] = mapped_column(String(8), index=True)
    domain: Mapped[str] = mapped_column(String(64), index=True)
    artifact_id: Mapped[str] = mapped_column(ForeignKey("scientific_artifacts.id"), index=True)
    sample_id: Mapped[str | None] = mapped_column(ForeignKey("scientific_samples.id"), nullable=True)
    status: Mapped[str] = mapped_column(String(32), default="staged", index=True)
    payload_json: Mapped[dict] = mapped_column("payload", JSON, default=dict)
    validation_report: Mapped[dict] = mapped_column(JSON, default=dict)
    accepted_by: Mapped[str | None] = mapped_column(String(120), nullable=True)
    review_note: Mapped[str] = mapped_column(Text, default="")
    synthetic: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)


class WorkflowCheckpointRecord(Base):
    """Append-only workflow checkpoint with a hash-linked state snapshot."""
    __tablename__ = "workflow_checkpoint_records"
    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    workflow_run_id: Mapped[str] = mapped_column(ForeignKey("workflow_run_records.id"), index=True)
    checkpoint_index: Mapped[int] = mapped_column(Integer)
    checkpoint_key: Mapped[str] = mapped_column(String(120))
    node_id: Mapped[str] = mapped_column(String(120))
    node_status: Mapped[str] = mapped_column(String(32))
    state_snapshot: Mapped[dict] = mapped_column(JSON, default=dict)
    output_snapshot: Mapped[dict] = mapped_column(JSON, default=dict)
    idempotency_key: Mapped[str] = mapped_column(String(128), unique=True, index=True)
    previous_hash: Mapped[str] = mapped_column(String(64), default="")
    checkpoint_hash: Mapped[str] = mapped_column(String(64), index=True)
    physical_side_effects: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    __table_args__ = (UniqueConstraint("workflow_run_id", "checkpoint_index", name="uq_workflow_checkpoint_index"),)


class ResearchCampaignRecord(Base):
    """Long-running scientific programme composed of governed analytical workflows."""
    __tablename__ = "research_campaign_records"
    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    campaign_code: Mapped[str] = mapped_column(String(100), unique=True, index=True)
    title: Mapped[str] = mapped_column(String(240))
    description: Mapped[str] = mapped_column(Text, default="")
    laboratory_code: Mapped[str] = mapped_column(String(8), index=True)
    domain: Mapped[str] = mapped_column(String(64), index=True)
    objective_id: Mapped[str] = mapped_column(ForeignKey("objectives.id"), index=True)
    status: Mapped[str] = mapped_column(String(32), default="awaiting_approval", index=True)
    execution_mode: Mapped[str] = mapped_column(String(32), default="simulation_only")
    stages_json: Mapped[list] = mapped_column("stages", JSON, default=list)
    current_stage_index: Mapped[int] = mapped_column(Integer, default=0)
    constraints_json: Mapped[dict] = mapped_column("constraints", JSON, default=dict)
    approval_json: Mapped[dict] = mapped_column("approval", JSON, default=dict)
    result_summary: Mapped[dict] = mapped_column(JSON, default=dict)
    synthetic: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)


class ResearchCampaignEventRecord(Base):
    """Append-only, hash-linked campaign event history."""
    __tablename__ = "research_campaign_event_records"
    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    campaign_id: Mapped[str] = mapped_column(ForeignKey("research_campaign_records.id"), index=True)
    sequence: Mapped[int] = mapped_column(Integer)
    event_type: Mapped[str] = mapped_column(String(80), index=True)
    actor: Mapped[str] = mapped_column(String(120))
    payload: Mapped[dict] = mapped_column(JSON, default=dict)
    previous_hash: Mapped[str] = mapped_column(String(64), default="")
    event_hash: Mapped[str] = mapped_column(String(64), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    __table_args__ = (UniqueConstraint("campaign_id", "sequence", name="uq_campaign_event_sequence"),)

class DigitalTwinCalibrationRecord(Base):
    """Versioned research calibration artifact for a digital-twin model."""
    __tablename__ = "digital_twin_calibration_records"
    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    calibrator_key: Mapped[str] = mapped_column(String(140), unique=True, index=True)
    model_id: Mapped[str] = mapped_column(String(120), index=True)
    model_version: Mapped[str] = mapped_column(String(40))
    domain: Mapped[str] = mapped_column(String(64), index=True)
    feature_names: Mapped[list] = mapped_column(JSON, default=list)
    calibrator_json: Mapped[dict] = mapped_column("calibrator", JSON, default=dict)
    validation_json: Mapped[dict] = mapped_column("validation", JSON, default=dict)
    status: Mapped[str] = mapped_column(String(40), default="research_calibration_candidate", index=True)
    created_by: Mapped[str] = mapped_column(String(120), default="system")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class AdvancedResearchAnalysisRecord(Base):
    """Persisted computational analysis request and result snapshot."""
    __tablename__ = "advanced_research_analysis_records"
    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    analysis_key: Mapped[str] = mapped_column(String(140), unique=True, index=True)
    analysis_type: Mapped[str] = mapped_column(String(80), index=True)
    laboratory_code: Mapped[str] = mapped_column(String(8), index=True)
    domain: Mapped[str] = mapped_column(String(64), index=True)
    request_digest: Mapped[str] = mapped_column(String(64), index=True)
    request_json: Mapped[dict] = mapped_column("request", JSON, default=dict)
    result_json: Mapped[dict] = mapped_column("result", JSON, default=dict)
    evidence_origin: Mapped[str] = mapped_column(String(40), default="computational_result")
    synthetic: Mapped[bool] = mapped_column(Boolean, default=False)
    created_by: Mapped[str] = mapped_column(String(120), default="system")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class PrivacyBudgetLedgerRecord(Base):
    """Persistent, conservative basic-composition budget for prototype releases."""
    __tablename__ = "privacy_budget_ledger_records"
    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    ledger_key: Mapped[str] = mapped_column(String(120), unique=True, index=True)
    epsilon_limit: Mapped[float] = mapped_column(Float)
    delta_limit: Mapped[float] = mapped_column(Float)
    epsilon_spent: Mapped[float] = mapped_column(Float, default=0.0)
    delta_spent: Mapped[float] = mapped_column(Float, default=0.0)
    release_count: Mapped[int] = mapped_column(Integer, default=0)
    release_history: Mapped[list] = mapped_column(JSON, default=list)
    status: Mapped[str] = mapped_column(String(32), default="active")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, onupdate=utcnow)


class LabExchangeEnvelopeRecord(Base):
    """Audit metadata for a signed transfer envelope; payload bytes are not duplicated."""
    __tablename__ = "lab_exchange_envelope_records"
    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    transfer_key: Mapped[str] = mapped_column(String(140), unique=True, index=True)
    source_laboratory: Mapped[str] = mapped_column(String(8), index=True)
    target_laboratory: Mapped[str] = mapped_column(String(8), index=True)
    subject_type: Mapped[str] = mapped_column(String(40))
    subject_id: Mapped[str] = mapped_column(String(100), index=True)
    domain: Mapped[str] = mapped_column(String(64), index=True)
    classification: Mapped[str] = mapped_column(String(24), default="internal")
    consent_scope: Mapped[str] = mapped_column(String(40), default="research_review_only")
    payload_sha256: Mapped[str] = mapped_column(String(64), index=True)
    manifest_json: Mapped[dict] = mapped_column("manifest", JSON, default=dict)
    integrity_status: Mapped[str] = mapped_column(String(48), default="unsigned_review_required")
    reviewed_by: Mapped[str | None] = mapped_column(String(120), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
