"""Versionable API contracts for objectives, experiments, approvals and measurements."""

from datetime import datetime
from typing import Any, Literal
from pydantic import BaseModel, ConfigDict, Field


class ORMModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)


class ObjectiveCreate(BaseModel):
    title: str = Field(min_length=5, max_length=240)
    domain: str = "inorganic_materials"
    laboratory_code: str = "SDL1"
    description: str = Field(min_length=10)
    target_properties: list[dict[str, Any]] = Field(default_factory=list)
    constraints: dict[str, Any] = Field(default_factory=dict)
    evidence_requirements: dict[str, Any] = Field(default_factory=dict)
    governance: dict[str, Any] = Field(default_factory=lambda: {"scientist_review_required": True})


class ObjectiveOut(ORMModel):
    id: str
    code: str
    title: str
    domain: str
    laboratory_code: str
    description: str
    target_properties: list
    constraints_json: dict
    evidence_requirements: dict
    governance: dict
    version: int
    status: str
    synthetic: bool


class ExperimentCreate(BaseModel):
    title: str = Field(min_length=4, max_length=240)
    laboratory_code: str = "SDL1"
    objective_id: str | None = None
    hypothesis_id: str | None = None
    candidate_id: str | None = None
    protocol_id: str = "screening-protocol"
    protocol_version: str = "1.0.0"
    owner: str = "NEXUS scientist"
    estimated_duration_minutes: int = Field(default=60, ge=1, le=10080)
    resource_requirements: dict[str, Any] = Field(default_factory=dict)
    execution_mode: Literal["simulation", "computational"] = "simulation"
    governance: dict[str, Any] = Field(default_factory=lambda: {
        "approval_required": True,
        "safety_review_required": True,
        "physical_execution": False,
    })


class ExperimentOut(ORMModel):
    id: str
    code: str
    title: str
    laboratory_code: str
    objective_id: str | None
    hypothesis_id: str | None
    candidate_id: str | None
    status: str
    execution_mode: str
    protocol_id: str
    protocol_version: str
    owner: str
    estimated_duration_minutes: int
    resource_requirements: dict
    governance: dict
    result_summary: dict
    created_at: datetime
    updated_at: datetime
    synthetic: bool


class TransitionRequest(BaseModel):
    target_status: str
    actor: str = "NEXUS scientist"
    note: str = ""


class ApprovalCreate(BaseModel):
    requested_by: str = "NEXUS scientist"
    reason: str = Field(min_length=8)


class ApprovalDecision(BaseModel):
    decision: Literal["approved", "rejected"]
    reviewer: str = "Laboratory supervisor"
    note: str = ""


class ObjectiveCompileRequest(BaseModel):
    prompt: str = Field(min_length=12, max_length=4000)
    laboratory_code: str = "SDL1"


class CandidateOut(ORMModel):
    id: str
    code: str
    name: str
    formula: str
    family: str
    domain: str
    laboratory_code: str
    predicted_properties: dict
    uncertainty: dict
    feasibility_score: float
    recommendation_score: float
    lifecycle_stage: str
    evidence_type: str
    synthetic: bool


class AgentRunRequest(BaseModel):
    task: str = "Review current scientific state"
    context: dict[str, Any] = Field(default_factory=dict)


class GenericResult(BaseModel):
    status: str
    detail: str
    data: dict[str, Any] = Field(default_factory=dict)
