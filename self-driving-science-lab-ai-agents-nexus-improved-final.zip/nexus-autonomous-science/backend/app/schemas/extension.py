"""Strict request/response contracts for NEXUS Volume II capabilities."""
from __future__ import annotations
from typing import Any, Literal
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


class SampleCreate(StrictModel):
    code: str = Field(min_length=3, max_length=80)
    name: str = Field(min_length=2, max_length=180)
    laboratory_code: str = Field(pattern=r"^SDL[0-7]$")
    domain: str = Field(min_length=2, max_length=64)
    sample_type: Literal["material", "molecule", "polymer", "formulation", "biological_model", "reference", "control", "process_batch"] = "material"
    parent_sample_id: str | None = None
    composition: dict[str, Any] = Field(default_factory=dict)
    preparation_metadata: dict[str, Any] = Field(default_factory=dict)
    identity_status: Literal["unverified"] = "unverified"
    provenance: dict[str, Any] = Field(default_factory=dict)
    synthetic: bool = True

    @field_validator("code")
    @classmethod
    def normalize_code(cls, value: str) -> str:
        return value.upper()


class ArtifactRegister(StrictModel):
    artifact_code: str = Field(min_length=3, max_length=80)
    sha256: str = Field(pattern=r"^[a-fA-F0-9]{64}$")
    storage_uri: str = Field(min_length=5, max_length=700)
    media_type: str = Field(min_length=3, max_length=160)
    artifact_type: Literal["raw_data", "derived_data", "image", "spectrum", "timeseries", "structure", "report", "model_weights"] = "raw_data"
    byte_size: int = Field(ge=0, le=10**12)
    domain: str = Field(min_length=2, max_length=64)
    laboratory_code: str = Field(pattern=r"^SDL[0-7]$")
    sample_id: str | None = None
    experiment_id: str | None = None
    origin: Literal["measured", "computational", "prediction", "literature", "human_observation", "simulation", "inferred"]
    metadata: dict[str, Any] = Field(default_factory=dict)
    parent_artifact_ids: list[str] = Field(default_factory=list, max_length=100)
    synthetic: bool = False

    @model_validator(mode="after")
    def synthetic_origin_consistency(self):
        if self.origin == "simulation" and not self.synthetic:
            raise ValueError("Simulation artifacts must be marked synthetic.")
        if self.origin == "prediction" and self.artifact_type == "raw_data":
            raise ValueError("A prediction cannot be registered as a raw-data artifact.")
        return self


class DatasetBuildRequest(StrictModel):
    dataset_key: str = Field(min_length=3, max_length=100)
    domain: str = Field(min_length=2, max_length=64)
    target_property: str = Field(min_length=2, max_length=120)
    allowed_origins: list[Literal["measured", "computational", "simulation", "literature", "human_observation"]] = Field(default_factory=lambda: ["measured"])
    include_synthetic: bool = False
    minimum_quality: Literal["pending", "preliminary", "accepted"] = "accepted"
    test_fraction: float = Field(default=0.2, gt=0.05, lt=0.5)
    random_seed: int = 17


class ModelTrainRequest(StrictModel):
    dataset_id: str
    model_key: str = Field(min_length=3, max_length=100)
    model_name: str = Field(min_length=3, max_length=180)
    version: str = "0.1.0"
    alpha: float = Field(default=1.0, ge=0.0, le=1e6)
    minimum_training_rows: int = Field(default=8, ge=4, le=100000)


class ModelPredictRequest(StrictModel):
    model_id: str
    subject_type: Literal["sample", "candidate", "structure", "formulation"]
    subject_id: str = Field(min_length=2, max_length=80)
    domain: str = Field(min_length=2, max_length=64)
    target_property: str = Field(min_length=2, max_length=120)
    features: dict[str, float]
    input_refs: list[str] = Field(default_factory=list)
    allow_out_of_domain: bool = False


class WorkflowStartRequest(StrictModel):
    workflow_key: Literal["sdl1_candidate_review", "cross_lab_evidence_review", "dataset_quality_review"]
    laboratory_code: str = Field(pattern=r"^SDL[0-7]$")
    objective_id: str | None = None
    subject_id: str | None = None
    context: dict[str, Any] = Field(default_factory=dict)
    synthetic: bool = True


class TransferProposeRequest(StrictModel):
    source_laboratory: str = Field(pattern=r"^SDL[0-7]$")
    target_laboratory: str = Field(pattern=r"^SDL[0-7]$")
    subject_type: Literal["sample", "candidate", "dataset", "hypothesis", "model"]
    subject_id: str = Field(min_length=2, max_length=80)
    domain: str = Field(min_length=2, max_length=64)
    schema_version: str = "1.0.0"
    payload: dict[str, Any]
    synthetic: bool = True


class TransferDecisionRequest(StrictModel):
    decision: Literal["accepted", "rejected"]
    reviewer: str = Field(min_length=2, max_length=120)
    note: str = Field(default="", max_length=2000)


class AgentTaskRequest(StrictModel):
    agent_id: str
    task_type: str = Field(min_length=3, max_length=80)
    input_contract: dict[str, Any] = Field(default_factory=dict)
    correlation_id: str | None = None


class OutboxDrainRequest(StrictModel):
    batch_size: int = Field(default=100, ge=1, le=500)


class OutboxPrepareRequest(StrictModel):
    lease_seconds: int = Field(default=300, ge=10, le=3600)
    max_attempts: int = Field(default=5, ge=1, le=20)
    base_backoff_seconds: int = Field(default=30, ge=1, le=86400)


class OutboxAcknowledgeRequest(StrictModel):
    success: bool
    error: str = Field(default="", max_length=2000)
    claim_token: str | None = Field(default=None, min_length=1, max_length=128)


class OutboxRecoverRequest(StrictModel):
    max_attempts: int = Field(default=5, ge=1, le=20)


class TimeSeriesPoint(StrictModel):
    timestamp: float
    value: float
    sensor_id: str
    unit: str


class TimeSeriesReviewRequest(StrictModel):
    points: list[TimeSeriesPoint] = Field(min_length=3, max_length=100000)
    expected_interval_seconds: float | None = Field(default=None, gt=0)
    drift_window: int = Field(default=20, ge=3, le=10000)


class ScientificReportRequest(StrictModel):
    objective_id: str
    include_synthetic: bool = True
    include_predictions: bool = True
