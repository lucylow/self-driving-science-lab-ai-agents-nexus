"""Strict schemas for bibliographic and claim-evidence registration."""
from typing import Any, Literal
from pydantic import BaseModel, ConfigDict, Field


class ResearchSourceCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    source_key: str | None = None
    title: str = Field(min_length=4, max_length=500)
    doi: str | None = None
    url: str = ""
    publication_year: int | None = Field(default=None, ge=1500, le=2200)
    venue: str = ""
    authors: list[str] = Field(default_factory=list)
    abstract: str = ""
    source_type: str = "journal_article"
    metadata: dict[str, Any] = Field(default_factory=dict)
    synthetic: bool = False


class SourceVerification(BaseModel):
    reviewer: str = Field(min_length=2, max_length=120)
    verification_refs: list[str] = Field(min_length=1)
    note: str = ""


class ScientificClaimCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    claim_key: str = Field(min_length=3, max_length=120)
    statement: str = Field(min_length=12, max_length=4000)
    domain: str
    laboratory_code: str = Field(pattern=r"^SDL[0-7]$")
    claim_type: Literal["empirical_observation", "computational_result", "mechanistic_hypothesis", "literature_claim", "method_claim"] = "empirical_observation"
    support_refs: list[str] = Field(default_factory=list)
    contradiction_refs: list[str] = Field(default_factory=list)
    assumptions: list[str] = Field(default_factory=list)
    limitations: list[str] = Field(default_factory=list)
    synthetic: bool = False


class ScientificClaimReview(BaseModel):
    decision: Literal["supported_for_review", "partially_supported", "contradicted", "inconclusive", "rejected"]
    reviewer: str = Field(min_length=2, max_length=120)
    note: str = Field(min_length=12, max_length=4000)
    checked_refs: list[str] = Field(min_length=1)
