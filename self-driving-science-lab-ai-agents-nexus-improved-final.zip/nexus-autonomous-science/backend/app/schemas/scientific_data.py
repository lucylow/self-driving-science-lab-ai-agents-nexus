"""Universal scientific data contracts plus domain-specific validation envelopes."""

from datetime import datetime, timezone
from enum import Enum
from typing import Any
from pydantic import BaseModel, ConfigDict, Field, model_validator


class DataType(str, Enum):
    sample = "sample"
    experiment = "experiment"
    measurement = "measurement"
    observation = "observation"
    spectrum = "spectrum"
    image = "image"
    timeseries = "timeseries"
    structure = "structure"
    simulation = "simulation"
    prediction = "prediction"
    dataset = "dataset"
    feature = "feature"


class EvidenceOrigin(str, Enum):
    measured = "measured"
    computational = "computational"
    prediction = "prediction"
    literature = "literature"
    human_observation = "human_observation"
    simulation = "simulation"
    inferred = "inferred"


class ScientificDataObject(BaseModel):
    model_config = ConfigDict(extra="forbid")
    data_id: str
    data_type: DataType
    laboratory_id: str
    workflow_id: str | None = None
    sample_id: str | None = None
    experiment_id: str | None = None
    source_system: str
    source_instrument: str | None = None
    schema_version: str = "1.0.0"
    origin: EvidenceOrigin
    value: Any | None = None
    unit: str | None = None
    uncertainty: float | None = Field(default=None, ge=0)
    conditions: dict[str, Any] = Field(default_factory=dict)
    metadata: dict[str, Any] = Field(default_factory=dict)
    raw_artifact_uri: str | None = None
    transformation_refs: list[str] = Field(default_factory=list)
    recorded_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    synthetic: bool = False

    @model_validator(mode="after")
    def validate_measurement_context(self):
        if self.data_type == DataType.measurement:
            if not self.sample_id:
                raise ValueError("Measurement records require sample_id.")
            if not self.unit:
                raise ValueError("Measurement records require an explicit unit.")
        if self.origin == EvidenceOrigin.simulation and not self.synthetic:
            raise ValueError("Simulation-origin records must be marked synthetic in this starter schema.")
        return self


class DatasetContract(BaseModel):
    model_config = ConfigDict(extra="forbid")
    dataset_id: str
    domain: str
    dataset_type: str
    schema_version: str = "1.0.0"
    required_fields: list[str] = Field(default_factory=list)
    sample_reference_required: bool = True
    measurement_property: str | None = None
    unit: str | None = None
    method: str | None = None
    conditions_required: list[str] = Field(default_factory=list)
    calibration_reference_required: bool = True
    replicate_information_required: bool = True
    raw_artifact_required: bool = True
    instrument_reference_required: bool = True
    operator_reference_required: bool = True

    def validate_record(self, record: dict[str, Any]) -> list[str]:
        errors = [f"Missing required field: {name}" for name in self.required_fields if record.get(name) is None]
        if self.sample_reference_required and not record.get("sample_id"):
            errors.append("Missing sample_id")
        conditions = record.get("conditions") or {}
        errors.extend(f"Missing condition: {name}" for name in self.conditions_required if conditions.get(name) is None)
        if self.raw_artifact_required and not record.get("raw_artifact_uri"):
            errors.append("Missing raw_artifact_uri")
        return errors
