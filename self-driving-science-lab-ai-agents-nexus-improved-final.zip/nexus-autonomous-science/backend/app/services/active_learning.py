"""Acquisition functions and batch selection interfaces for sequential experiment design."""

from math import erf, exp, pi, sqrt
from statistics import mean
from typing import Any


def normal_pdf(z: float) -> float:
    return exp(-0.5 * z * z) / sqrt(2 * pi)


def normal_cdf(z: float) -> float:
    return 0.5 * (1.0 + erf(z / sqrt(2.0)))


def upper_confidence_bound(mu: float, sigma: float, beta: float = 2.0) -> float:
    return mu + sqrt(max(0.0, beta)) * max(0.0, sigma)


def expected_improvement(mu: float, sigma: float, best_observed: float, xi: float = 0.01) -> float:
    if sigma <= 1e-12:
        return max(0.0, mu - best_observed - xi)
    delta = mu - best_observed - xi
    z = delta / sigma
    return delta * normal_cdf(z) + sigma * normal_pdf(z)


def cost_aware_acquisition(acquisition_value: float, estimated_cost: float, *, cost_weight: float = 1.0) -> float:
    return acquisition_value / (max(estimated_cost, 1e-9) ** max(0.0, cost_weight))


def pareto_front(records: list[dict[str, Any]], objectives: list[tuple[str, str]]) -> list[dict[str, Any]]:
    """Return non-dominated records. Direction is 'max' or 'min'."""
    def dominates(left: dict, right: dict) -> bool:
        comparisons = []
        for key, direction in objectives:
            a, b = float(left.get(key, 0.0)), float(right.get(key, 0.0))
            comparisons.append(a >= b if direction == "max" else a <= b)
        strict = any(
            float(left.get(key, 0.0)) > float(right.get(key, 0.0)) if direction == "max"
            else float(left.get(key, 0.0)) < float(right.get(key, 0.0))
            for key, direction in objectives
        )
        return all(comparisons) and strict
    return [item for item in records if not any(other is not item and dominates(other, item) for other in records)]


def diversify_batch(records: list[dict[str, Any]], *, batch_size: int, family_key: str = "family") -> list[dict[str, Any]]:
    selected: list[dict[str, Any]] = []
    family_counts: dict[str, int] = {}
    for item in sorted(records, key=lambda row: float(row.get("acquisition", row.get("score", 0))), reverse=True):
        family = str(item.get(family_key, "unknown"))
        if family_counts.get(family, 0) >= 1 and len(selected) + 1 < batch_size:
            continue
        selected.append(item)
        family_counts[family] = family_counts.get(family, 0) + 1
        if len(selected) >= batch_size:
            break
    return selected


def baseline_summary(values: list[float]) -> dict:
    return {"count": len(values), "mean": mean(values) if values else None, "status": "descriptive_only"}
