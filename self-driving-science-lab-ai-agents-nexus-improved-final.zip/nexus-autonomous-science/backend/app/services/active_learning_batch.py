"""Uncertainty-aware candidate selection with explicit constraints and duplicate handling."""
from __future__ import annotations
from math import sqrt
from typing import Any


def upper_confidence_bound(mean_value: float, uncertainty: float, *, exploration: float = 1.5,
                           direction: str = "maximize") -> float:
    if uncertainty < 0 or exploration < 0:
        raise ValueError("Uncertainty and exploration must be non-negative")
    sign = 1.0 if direction == "maximize" else -1.0 if direction == "minimize" else None
    if sign is None:
        raise ValueError("direction must be maximize or minimize")
    return sign * float(mean_value) + exploration * float(uncertainty)


def select_batch(candidates: list[dict[str, Any]], *, batch_size: int,
                 exploration: float = 1.5, target: str = "target",
                 direction: str = "maximize", excluded_ids: list[str] | None = None) -> dict:
    if batch_size < 1:
        raise ValueError("batch_size must be positive")
    excluded = set(excluded_ids or [])
    seen: set[str] = set()
    ranked = []
    for candidate in candidates:
        candidate_id = str(candidate.get("id", ""))
        if not candidate_id or candidate_id in seen:
            continue
        seen.add(candidate_id)
        if candidate_id in excluded or candidate.get("feasible") is False:
            continue
        prediction = candidate.get("predictions", {}).get(target)
        if not isinstance(prediction, dict) or prediction.get("mean") is None or prediction.get("uncertainty") is None:
            continue
        score = upper_confidence_bound(float(prediction["mean"]), float(prediction["uncertainty"]),
                                       exploration=exploration, direction=direction)
        ranked.append({"id": candidate_id, "score": score,
                       "mean": float(prediction["mean"]),
                       "uncertainty": float(prediction["uncertainty"]),
                       "selection_reason": "uncertainty_aware_ucb"})
    ranked.sort(key=lambda item: item["score"], reverse=True)
    selected = ranked[:batch_size]
    return {
        "selected": selected,
        "ranked_candidates": ranked,
        "requested_batch_size": batch_size,
        "returned_batch_size": len(selected),
        "acquisition": "upper_confidence_bound",
        "exploration": exploration,
        "target": target,
        "direction": direction,
        "notice": "Acquisition scores prioritize information or predicted utility; they do not certify synthesis feasibility or scientific validity.",
    }
