"""Advanced, reviewable research services for the NEXUS network.

These modules provide deterministic computational methods and decision support.
They do not authorize laboratory actions or claim validated physical fidelity.
"""

__version__ = "0.4.0"

__all__ = [
    "twin_calibration", "uncertainty_propagation", "sequential_design",
    "multi_lab_exchange", "federated_aggregation", "model_transfer",
    "drift_monitoring", "digital_twin_ensemble", "value_of_information",
    "simulation_models", "decision_policy", "research_metrics",
]
