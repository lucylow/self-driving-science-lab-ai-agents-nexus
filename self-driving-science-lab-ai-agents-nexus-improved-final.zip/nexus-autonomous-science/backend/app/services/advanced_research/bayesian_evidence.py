"""Transparent Bayesian evidence updates using declared likelihood ratios."""
from __future__ import annotations
from math import isfinite, exp, log


def update_hypothesis_probability(prior_probability: float, evidence_items: list[dict], *,
                                  independence_assumption: bool = False) -> dict:
    prior = float(prior_probability)
    if not 0 < prior < 1:
        raise ValueError("prior_probability must lie strictly between zero and one")
    if not evidence_items:
        raise ValueError("At least one evidence item is required")
    log_odds = log(prior / (1 - prior))
    used = []
    for item in evidence_items:
        ratio = float(item.get("likelihood_ratio"))
        if not isfinite(ratio) or ratio <= 0:
            raise ValueError("Each likelihood_ratio must be finite and >0")
        if not item.get("evidence_ref"):
            raise ValueError("Every evidence item requires evidence_ref")
        log_odds += log(ratio)
        used.append({"evidence_ref": item["evidence_ref"], "likelihood_ratio": ratio,
                     "direction": "supports" if ratio > 1 else "contradicts" if ratio < 1 else "neutral"})
    posterior = 1 / (1 + exp(-max(-700, min(700, log_odds))))
    return {"prior_probability": prior, "posterior_probability": posterior,
            "posterior_odds": exp(max(-700, min(700, log_odds))), "evidence_items": used,
            "independence_assumption_declared": independence_assumption,
            "status": "review_required" if not independence_assumption else "review_required_independence_assumed",
            "warning": "Likelihood ratios must be externally justified; multiplying dependent evidence can produce severe overconfidence.",
            "scientist_review_required": True}


def compare_hypotheses(priors: dict[str, float], likelihoods: dict[str, list[dict]]) -> dict:
    if set(priors) != set(likelihoods) or len(priors) < 2:
        raise ValueError("At least two hypotheses with matching prior and evidence keys are required")
    results = []
    for key in priors:
        result = update_hypothesis_probability(priors[key], likelihoods[key])
        results.append({"hypothesis_id": key, **result})
    total = sum(item["posterior_probability"] for item in results)
    # Independent binary hypothesis probabilities are not mutually exclusive; do not normalize.
    return {"results": sorted(results, key=lambda row: row["posterior_probability"], reverse=True),
            "probabilities_normalized": False,
            "reason": "Hypotheses may overlap and are updated independently.",
            "scientific_conclusion_automatically_created": False}
