"""Reproducible blocked randomization plans for computational study allocation.

This creates a blinded assignment draft only. It is not a laboratory protocol or
permission to randomize physical samples, patients, animals, or biological materials.
"""
from __future__ import annotations
from collections import defaultdict
from random import Random


def create_blocked_assignment(*, units: list[dict], arms: list[str],
                              block_key: str = "block_id", unit_key: str = "unit_id",
                              seed: int = 17, allocation_ratio: list[int] | None = None) -> dict:
    if not units or len(arms) < 2 or len(set(arms)) != len(arms):
        raise ValueError("Units and at least two unique arms are required")
    if allocation_ratio is None:
        allocation_ratio = [1] * len(arms)
    if len(allocation_ratio) != len(arms) or any(int(value) < 1 for value in allocation_ratio):
        raise ValueError("allocation_ratio must contain one positive integer per arm")
    grouped = defaultdict(list)
    seen = set()
    for unit in units:
        unit_id = str(unit.get(unit_key, ""))
        block = str(unit.get(block_key, "unblocked"))
        if not unit_id or unit_id in seen:
            raise ValueError("Every unit requires a unique unit_id")
        seen.add(unit_id)
        grouped[block].append(unit_id)
    rng = Random(seed)
    assignments = []
    allocation = []
    slots = [arm for arm, ratio in zip(arms, allocation_ratio) for _ in range(int(ratio))]
    for block, identifiers in sorted(grouped.items()):
        rng.shuffle(identifiers)
        local_slots = (slots * ((len(identifiers) + len(slots) - 1) // len(slots)))[:len(identifiers)]
        rng.shuffle(local_slots)
        for unit_id, arm in zip(identifiers, local_slots):
            assignments.append({"unit_id": unit_id, "block_id": block, "assigned_arm": arm})
            allocation.append(arm)
    arm_counts = {arm: allocation.count(arm) for arm in arms}
    return {"assignment_plan": assignments, "arm_counts": arm_counts,
            "block_count": len(grouped), "unit_count": len(units),
            "seed": seed, "allocation_ratio": allocation_ratio,
            "randomization_unit": unit_key,
            "status": "computational_assignment_draft",
            "physical_assignment_executed": False,
            "limitations": ["Odd block sizes can produce arm imbalance.",
                            "No allocation concealment is implemented.",
                            "Eligibility, ethics and domain-specific randomization design require separate review."]}


def audit_assignment(plan: dict, *, expected_unit_ids: list[str], arms: list[str]) -> dict:
    assignments = plan.get("assignment_plan", [])
    ids = [str(row.get("unit_id", "")) for row in assignments]
    unknown_arms = sorted({row.get("assigned_arm") for row in assignments} - set(arms))
    return {"complete_unit_coverage": set(ids) == set(expected_unit_ids),
            "duplicate_unit_ids": sorted({item for item in ids if ids.count(item) > 1}),
            "missing_unit_ids": sorted(set(expected_unit_ids) - set(ids)),
            "unexpected_unit_ids": sorted(set(ids) - set(expected_unit_ids)),
            "unknown_arms": unknown_arms,
            "valid": set(ids) == set(expected_unit_ids) and len(ids) == len(set(ids)) and not unknown_arms,
            "physical_assignment_executed": False}
