"""Version-aware interoperability checks for scientific datasets."""
from __future__ import annotations
from math import isfinite
from typing import Any


REQUIRED_CONTEXT = {"domain", "measurement_method", "unit", "sample_type", "evidence_origin", "provenance_refs"}


def compare_dataset_contracts(source: dict[str, Any], target: dict[str, Any]) -> dict:
    missing_source = sorted(REQUIRED_CONTEXT - set(source))
    missing_target = sorted(REQUIRED_CONTEXT - set(target))
    fields = ["domain", "measurement_method", "unit", "sample_type", "evidence_origin"]
    differences = {key: {"source": source.get(key), "target": target.get(key)}
                   for key in fields if source.get(key) != target.get(key)}
    compatible_units = source.get("unit") == target.get("unit")
    same_method = source.get("measurement_method") == target.get("measurement_method")
    same_domain = source.get("domain") == target.get("domain")
    provenance_source = source.get("provenance_refs")
    provenance_target = target.get("provenance_refs")
    complete_provenance = isinstance(provenance_source, list) and bool(provenance_source) and isinstance(provenance_target, list) and bool(provenance_target)
    blockers = []
    if missing_source or missing_target: blockers.append("required_contract_fields_missing")
    if not compatible_units: blockers.append("unit_conversion_or_semantic_review_required")
    if not same_method: blockers.append("measurement_method_mismatch")
    if not same_domain: blockers.append("domain_mismatch")
    if not complete_provenance: blockers.append("provenance_incomplete")
    return {"compatible_for_direct_mapping": not blockers,
            "source_missing_fields": missing_source, "target_missing_fields": missing_target,
            "field_differences": differences, "blockers": blockers,
            "requires_scientist_review": True,
            "direct_training_reuse_allowed": False,
            "note": "Matching structural contracts do not prove that measurement semantics or experimental populations are equivalent."}


def validate_mapping_rules(mapping: dict[str, str], *, source_fields: list[str], target_fields: list[str],
                           required_target_fields: list[str]) -> dict:
    if not mapping:
        raise ValueError("At least one field mapping is required")
    errors = []
    for source, target in mapping.items():
        if source not in source_fields:
            errors.append({"source_field": source, "reason": "source_field_unknown"})
        if target not in target_fields:
            errors.append({"target_field": target, "reason": "target_field_unknown"})
    mapped_targets = list(mapping.values())
    duplicates = sorted({key for key in mapped_targets if mapped_targets.count(key) > 1})
    if duplicates:
        errors.append({"reason": "multiple_sources_map_to_same_target", "fields": duplicates})
    missing_required = sorted(set(required_target_fields) - set(mapped_targets))
    if missing_required:
        errors.append({"reason": "required_target_fields_unmapped", "fields": missing_required})
    return {"valid": not errors, "errors": errors,
            "mapping": mapping, "transformation_executed": False}


def convert_measurement_value(value: float, *, scale: float, offset: float,
                              source_unit: str, target_unit: str) -> dict:
    x, m, b = float(value), float(scale), float(offset)
    if not all(isfinite(item) for item in [x, m, b]) or m == 0:
        raise ValueError("Value and conversion coefficients must be finite; scale cannot be zero")
    if not source_unit.strip() or not target_unit.strip():
        raise ValueError("Source and target units are required")
    return {"original_value": x, "original_unit": source_unit,
            "converted_value": m * x + b, "converted_unit": target_unit,
            "conversion": {"scale": m, "offset": b},
            "original_preserved": True,
            "warning": "Conversion coefficients must come from a validated unit mapping; this function does not infer dimensional compatibility."}
