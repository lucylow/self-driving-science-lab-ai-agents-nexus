"""Governed decision policy joining optimization output with evidence gates."""
from __future__ import annotations
from typing import Any


def evaluate_candidate_for_review(candidate: dict[str, Any], *, required_domain: str,
                                  required_evidence_grade: str = "E2",
                                  minimum_quality_score: float = .8,
                                  require_uncertainty: bool = True) -> dict:
    grades = {f"E{i}": i for i in range(7)}
    grade = str(candidate.get("evidence_grade", "E0"))
    if required_evidence_grade not in grades or grade not in grades:
        raise ValueError("Unknown evidence grade")
    issues = []
    if candidate.get("domain") != required_domain: issues.append("domain_mismatch")
    if grades[grade] < grades[required_evidence_grade]: issues.append("evidence_grade_below_requirement")
    if candidate.get("synthetic") is True: issues.append("synthetic_record_not_experimental_evidence")
    if require_uncertainty and not candidate.get("uncertainty") and candidate.get("prediction_std") is None:
        issues.append("uncertainty_not_reported")
    quality = candidate.get("quality_score")
    if quality is None or float(quality) < minimum_quality_score: issues.append("quality_threshold_not_met")
    if candidate.get("provenance_complete") is not True: issues.append("provenance_incomplete")
    return {"candidate_id": candidate.get("candidate_id"), "eligible_for_scientist_review": not issues,
            "issues": issues, "evidence_grade": grade,
            "scientific_authority": "scientist", "execution_authorized": False,
            "model_training_eligible": False if issues else "requires_separate_dataset_governance"}


def aggregate_agent_recommendations(recommendations: list[dict], *, hard_constraints: list[str] | None = None) -> dict:
    if not recommendations:
        raise ValueError("At least one agent recommendation is required")
    grouped: dict[str, list[dict]] = {}
    for item in recommendations:
        agent = str(item.get("agent_id", ""))
        if not agent:
            raise ValueError("Each recommendation requires agent_id")
        grouped.setdefault(agent, []).append(item)
    duplicate_agents = [key for key, values in grouped.items() if len(values) > 1]
    if duplicate_agents:
        raise ValueError("Only one recommendation per agent may enter this aggregation")
    blocked = set(hard_constraints or [])
    ranked = []
    for item in recommendations:
        violated = sorted(blocked.intersection(item.get("constraint_violations", [])))
        ranked.append({**item, "blocked_constraints": violated,
                       "eligible": not violated and item.get("evidence_refs") is not None and len(item.get("evidence_refs", [])) > 0})
    ranked.sort(key=lambda row: (row["eligible"], float(row.get("utility_score", 0))), reverse=True)
    return {"recommendations": ranked,
            "consensus_status": "agreement" if len({row.get("candidate_id") for row in ranked if row["eligible"]}) <= 1 else "disagreement_preserved",
            "dissenting_agents": [row["agent_id"] for row in ranked[1:] if ranked and row.get("candidate_id") != ranked[0].get("candidate_id")],
            "hard_constraints": sorted(blocked), "automatic_decision": False,
            "scientist_review_required": True}
