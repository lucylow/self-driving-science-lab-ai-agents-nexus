"""Combine multiple digital-twin predictions without hiding model disagreement."""
from __future__ import annotations
from math import isfinite, sqrt
from statistics import mean


def combine_twin_predictions(predictions: list[dict], *, correlation: list[list[float]] | None = None,
                             disagreement_threshold: float = 2.0) -> dict:
    if len(predictions) < 2:
        raise ValueError("At least two independent model predictions are required")
    means = [float(item.get("mean")) for item in predictions]
    sigmas = [float(item.get("standard_deviation")) for item in predictions]
    model_ids = [str(item.get("model_id", "unknown")) for item in predictions]
    domains = {str(item.get("domain", "unspecified")) for item in predictions}
    if len(set(model_ids)) != len(model_ids):
        raise ValueError("Model ids must be unique; duplicate model outputs are not independent votes")
    if len(domains) != 1:
        return {"status": "blocked_domain_mismatch", "domains": sorted(domains),
                "combined_prediction": None, "physical_control_authorized": False}
    if any(not isfinite(x) for x in means + sigmas) or any(x < 0 for x in sigmas):
        raise ValueError("Prediction means and standard deviations must be finite; deviations non-negative")
    if correlation is None:
        correlation = [[1.0 if i == j else 0.0 for j in range(len(means))] for i in range(len(means))]
    if len(correlation) != len(means) or any(len(row) != len(means) for row in correlation):
        raise ValueError("Correlation dimensions must match prediction count")
    weights = [1.0 / max(sigma * sigma, 1e-12) for sigma in sigmas]
    weighted_mean = sum(weight * value for weight, value in zip(weights, means)) / sum(weights)
    disagreement = max(abs(value - weighted_mean) / max(sigma, 1e-9) for value, sigma in zip(means, sigmas))
    # Variance of weighted sum using supplied pairwise correlations.
    normalized = [weight / sum(weights) for weight in weights]
    variance = sum(normalized[i] * normalized[j] * float(correlation[i][j]) * sigmas[i] * sigmas[j]
                   for i in range(len(means)) for j in range(len(means)))
    variance += sum(normalized[i] * (means[i] - weighted_mean) ** 2 for i in range(len(means)))
    return {"status": "agreement_review" if disagreement <= disagreement_threshold else "model_disagreement_review",
            "domain": next(iter(domains)), "model_ids": model_ids,
            "combined_prediction": {"mean": weighted_mean, "standard_deviation": sqrt(max(0.0, variance))},
            "individual_predictions": predictions, "normalized_weights": normalized,
            "maximum_standardized_disagreement": disagreement,
            "disagreement_threshold": disagreement_threshold,
            "physical_control_authorized": False,
            "interpretation": "Model disagreement is preserved as a review signal; weighted pooling does not prove model independence or calibration."}


def twin_fidelity_card(*, model_id: str, domain: str, model_version: str,
                       calibration_id: str | None, validation: dict | None,
                       operating_range: dict[str, list[float]], limitations: list[str]) -> dict:
    validated = bool(validation and validation.get("valid_for_domain") and
                     validation.get("status") == "validated_for_research_review")
    return {"model_id": model_id, "domain": domain, "model_version": model_version,
            "calibration_id": calibration_id, "validation_status": "research_validated" if validated else "unvalidated",
            "validation_metrics": validation.get("metrics") if validation else None,
            "operating_range": operating_range, "known_limitations": limitations,
            "last_validation_at": validation.get("validated_at") if validation else None,
            "physical_control_authorized": False,
            "required_before_real_integration": ["instrument-specific acceptance testing", "independent holdout validation",
                                                  "failure-mode analysis", "local interlock verification",
                                                  "operator training", "change-control approval"]}
