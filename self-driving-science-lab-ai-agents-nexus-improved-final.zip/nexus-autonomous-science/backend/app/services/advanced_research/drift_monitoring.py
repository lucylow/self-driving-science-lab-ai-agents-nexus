"""Sequential monitoring for residual bias and process drift."""
from __future__ import annotations
from math import isfinite, sqrt
from statistics import mean, pstdev


def ewma(values: list[float], *, smoothing: float = .2, initial: float | None = None) -> dict:
    if not values or not 0 < smoothing <= 1:
        raise ValueError("values must be non-empty and smoothing in (0, 1]")
    numeric = [float(value) for value in values]
    if any(not isfinite(value) for value in numeric):
        raise ValueError("values must be finite")
    current = numeric[0] if initial is None else float(initial)
    path = []
    for value in numeric:
        current = smoothing * value + (1 - smoothing) * current
        path.append(current)
    return {"method": "ewma", "smoothing": smoothing, "final": current,
            "path": path, "observation_count": len(numeric)}


def cusum(values: list[float], *, target: float = 0.0, allowance: float = .5,
          decision_interval: float = 5.0) -> dict:
    if not values or allowance < 0 or decision_interval <= 0:
        raise ValueError("values required; allowance must be >=0 and decision_interval >0")
    numeric = [float(value) for value in values]
    if any(not isfinite(value) for value in numeric):
        raise ValueError("values must be finite")
    positive = negative = 0.0
    signals = []
    positive_path, negative_path = [], []
    for index, value in enumerate(numeric):
        centered = value - target
        positive = max(0.0, positive + centered - allowance)
        negative = min(0.0, negative + centered + allowance)
        positive_path.append(positive)
        negative_path.append(negative)
        if positive > decision_interval or abs(negative) > decision_interval:
            signals.append(index)
    return {"method": "two_sided_cusum", "positive_path": positive_path,
            "negative_path": negative_path, "signal_indices": signals,
            "drift_detected": bool(signals), "decision_interval": decision_interval,
            "allowance": allowance}


def residual_monitor(residuals: list[float], *, baseline_mean: float = 0.0,
                     baseline_sd: float | None = None, ewma_smoothing: float = .2,
                     cusum_allowance: float = .5, cusum_threshold: float = 5.0) -> dict:
    if len(residuals) < 5:
        raise ValueError("At least five residuals are required for monitoring")
    values = [float(item) for item in residuals]
    if any(not isfinite(value) for value in values):
        raise ValueError("Residuals must be finite")
    sd = float(baseline_sd) if baseline_sd is not None else pstdev(values)
    if sd <= 0:
        sd = 1e-12
    standardized = [(value - baseline_mean) / sd for value in values]
    ewma_result = ewma(standardized, smoothing=ewma_smoothing)
    cusum_result = cusum(standardized, allowance=cusum_allowance,
                         decision_interval=cusum_threshold)
    mean_shift = mean(standardized)
    return {"observation_count": len(values), "baseline_mean": baseline_mean,
            "baseline_standard_deviation": sd, "standardized_mean": mean_shift,
            "ewma": ewma_result, "cusum": cusum_result,
            "drift_status": "signal_detected_review_required" if cusum_result["drift_detected"] else "no_signal_detected",
            "automatic_model_update": False,
            "warning": "No signal does not establish stability; monitoring limits and sampling plans need domain review."}


def compare_feature_windows(reference: dict[str, list[float]], current: dict[str, list[float]], *,
                            maximum_smd: float = .25) -> dict:
    if set(reference) != set(current) or not reference:
        raise ValueError("Reference and current windows must have identical non-empty feature keys")
    results = {}
    for key in reference:
        left, right = list(map(float, reference[key])), list(map(float, current[key]))
        if len(left) < 2 or len(right) < 2:
            raise ValueError(f"Feature '{key}' requires at least two values per window")
        pooled = sqrt((pstdev(left) ** 2 + pstdev(right) ** 2) / 2)
        smd = abs(mean(left) - mean(right)) / pooled if pooled > 1e-12 else (0.0 if mean(left) == mean(right) else float("inf"))
        results[key] = {"reference_mean": mean(left), "current_mean": mean(right),
                        "standardized_mean_difference": smd,
                        "flagged": smd > maximum_smd}
    return {"features": results, "flagged_features": [key for key, value in results.items() if value["flagged"]],
            "status": "distribution_shift_review" if any(value["flagged"] for value in results.values()) else "no_large_mean_shift_detected",
            "maximum_smd": maximum_smd,
            "limitation": "Mean-shift statistics do not detect all forms of distribution shift."}
