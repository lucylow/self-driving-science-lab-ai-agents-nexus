"""Evidence synthesis that preserves contradictory observations and provenance."""
from __future__ import annotations
from collections import Counter
from typing import Any


def synthesize_claim_evidence(claim: dict[str, Any], evidence: list[dict]) -> dict:
    if not claim.get("claim_id") or not claim.get("statement") or not claim.get("domain"):
        raise ValueError("Claim requires claim_id, statement and domain")
    if not evidence:
        raise ValueError("At least one evidence record is required")
    valid = []
    errors = []
    for index, row in enumerate(evidence):
        if not row.get("evidence_id") or not row.get("origin") or not row.get("provenance_refs"):
            errors.append({"index": index, "reason": "missing_identity_origin_or_provenance"})
            continue
        if row.get("domain") != claim["domain"]:
            errors.append({"index": index, "reason": "domain_mismatch"})
            continue
        if row.get("synthetic") is True:
            errors.append({"index": index, "reason": "synthetic_record_not_independent_support"})
            continue
        direction = row.get("direction")
        if direction not in {"supports", "contradicts", "neutral", "contextual"}:
            errors.append({"index": index, "reason": "invalid_evidence_direction"})
            continue
        valid.append(row)
    counts = Counter(row["direction"] for row in valid)
    conflict = counts["supports"] > 0 and counts["contradicts"] > 0
    if not valid:
        state = "insufficient_valid_evidence"
    elif conflict:
        state = "contradictory_evidence_requires_review"
    elif counts["supports"] and not counts["contradicts"]:
        state = "supporting_evidence_present_not_conclusive"
    elif counts["contradicts"] and not counts["supports"]:
        state = "contradictory_evidence_present"
    else:
        state = "context_only_or_neutral"
    return {"claim_id": claim["claim_id"], "claim_statement": claim["statement"],
            "domain": claim["domain"], "evidence_count": len(evidence),
            "valid_evidence_count": len(valid), "invalid_evidence": errors,
            "direction_counts": dict(counts), "support_refs": [row["evidence_id"] for row in valid if row["direction"] == "supports"],
            "contradiction_refs": [row["evidence_id"] for row in valid if row["direction"] == "contradicts"],
            "synthesis_status": state,
            "scientific_conclusion_created": False,
            "limitations": ["Evidence count is not evidence strength.",
                            "Dependence between evidence sources is not inferred.",
                            "Differences in methods, conditions and sample provenance require expert review."]}


def build_evidence_matrix(claim_ids: list[str], evidence_rows: list[dict]) -> dict:
    if not claim_ids or len(set(claim_ids)) != len(claim_ids):
        raise ValueError("claim_ids must be non-empty and unique")
    matrix = {claim_id: {"supports": [], "contradicts": [], "context": []} for claim_id in claim_ids}
    for row in evidence_rows:
        claim_id = row.get("claim_id")
        if claim_id not in matrix:
            continue
        direction = row.get("direction")
        bucket = "context" if direction in {"neutral", "contextual"} else direction
        if bucket not in matrix[claim_id]:
            raise ValueError("Invalid evidence direction")
        matrix[claim_id][bucket].append(row.get("evidence_id"))
    return {"claim_ids": claim_ids, "matrix": matrix,
            "missing_claims": [key for key, value in matrix.items() if not any(value.values())],
            "preserves_conflicts": True}
