"""Evidence-weighted failure hypotheses; scores are triage aids, not causal findings."""
from __future__ import annotations
from collections import defaultdict
from math import isfinite


CAUSE_RULES = {
    "instrument_drift": {"calibration_expired", "reference_check_failed", "baseline_shift"},
    "sample_identity_issue": {"label_mismatch", "identity_unverified", "chain_of_custody_gap"},
    "protocol_deviation": {"step_skipped", "protocol_version_mismatch", "operator_override"},
    "environmental_excursion": {"temperature_excursion", "humidity_excursion", "power_instability"},
    "material_or_process_variability": {"unexpected_phase", "batch_variability", "replicate_dispersion"},
    "data_pipeline_error": {"unit_mismatch", "timestamp_error", "parser_failure", "duplicate_record"},
}


def rank_failure_hypotheses(*, observations: list[dict], candidate_causes: list[str] | None = None,
                            severity_weights: dict[str, float] | None = None) -> dict:
    if not observations:
        raise ValueError("At least one failure observation is required")
    allowed_causes = candidate_causes or list(CAUSE_RULES)
    unknown = sorted(set(allowed_causes) - set(CAUSE_RULES))
    if unknown:
        raise ValueError(f"Unknown failure causes: {unknown}")
    evidence_by_cause = defaultdict(list)
    unexplained = []
    for observation in observations:
        code = str(observation.get("signal_code", ""))
        ref = observation.get("evidence_ref")
        reliability = float(observation.get("reliability", 1.0))
        if not ref or not isfinite(reliability) or not 0 <= reliability <= 1:
            raise ValueError("Each observation requires evidence_ref and reliability in [0,1]")
        matched = False
        for cause in allowed_causes:
            if code in CAUSE_RULES[cause]:
                weight = float((severity_weights or {}).get(code, 1.0))
                if weight < 0 or not isfinite(weight):
                    raise ValueError("Severity weights must be finite and non-negative")
                evidence_by_cause[cause].append({"evidence_ref": ref, "signal_code": code,
                                                 "weighted_support": reliability * weight})
                matched = True
        if not matched:
            unexplained.append({"evidence_ref": ref, "signal_code": code})
    ranked = []
    for cause in allowed_causes:
        evidence = evidence_by_cause[cause]
        score = sum(row["weighted_support"] for row in evidence)
        ranked.append({"cause": cause, "triage_score": score,
                       "supporting_evidence_refs": [row["evidence_ref"] for row in evidence]})
    ranked.sort(key=lambda row: row["triage_score"], reverse=True)
    return {"ranked_hypotheses": ranked, "unexplained_observations": unexplained,
            "causal_finding": None, "automatic_repair_authorized": False,
            "required_next_steps": ["inspect source measurements", "compare reference checks", "review protocol and sample provenance",
                                     "form a discriminating follow-up test", "obtain operator/scientist review"],
            "warning": "Signal codes are heuristic associations. Multiple causes may coexist and scores are not calibrated probabilities."}


def propose_discriminating_checks(top_hypotheses: list[str]) -> dict:
    checks = {
        "instrument_drift": ["review calibration certificates", "compare certified reference sample", "inspect sensor residual history"],
        "sample_identity_issue": ["verify label against registration", "reconcile sample custody chain", "inspect parent-child sample links"],
        "protocol_deviation": ["diff protocol versions", "review step acknowledgements", "inspect human override events"],
        "environmental_excursion": ["inspect synchronized environmental telemetry", "review excursion limits", "compare independent sensors"],
        "material_or_process_variability": ["inspect independent replicates", "compare batch genealogy", "review characterization evidence"],
        "data_pipeline_error": ["reparse raw artifact", "validate unit mapping", "check event timestamp and duplicate identifiers"],
    }
    return {"checks": {cause: checks[cause] for cause in top_hypotheses if cause in checks},
            "execution_authorized": False, "requires_operator_review": True}
