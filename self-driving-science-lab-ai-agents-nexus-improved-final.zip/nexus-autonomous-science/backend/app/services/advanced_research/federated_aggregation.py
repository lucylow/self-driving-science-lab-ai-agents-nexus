"""Privacy-aware aggregation of per-lab sufficient statistics.

This is a prototype aggregation pattern, not a certified secure aggregation protocol.
The optional Gaussian perturbation is a teaching/engineering scaffold; formal DP claims
require a threat model, contribution accounting, vetted randomness, composition analysis,
and an external privacy review.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from math import sqrt, log, isfinite
from random import Random
from typing import Any


@dataclass
class PrivacyBudget:
    epsilon_limit: float
    delta_limit: float
    epsilon_spent: float = 0.0
    delta_spent: float = 0.0
    release_count: int = 0

    def __post_init__(self):
        if self.epsilon_limit <= 0 or not 0 < self.delta_limit < 1:
            raise ValueError("Privacy limits must satisfy epsilon>0 and delta in (0,1)")

    def can_spend(self, epsilon: float, delta: float) -> bool:
        return self.epsilon_spent + epsilon <= self.epsilon_limit and self.delta_spent + delta <= self.delta_limit

    def spend(self, epsilon: float, delta: float) -> None:
        if not self.can_spend(epsilon, delta):
            raise ValueError("Privacy budget would be exceeded")
        self.epsilon_spent += epsilon
        self.delta_spent += delta
        self.release_count += 1

    def snapshot(self) -> dict:
        return asdict(self) | {"remaining_epsilon": max(0.0, self.epsilon_limit - self.epsilon_spent),
                               "remaining_delta": max(0.0, self.delta_limit - self.delta_spent)}


def _clip_vector(values: list[float], max_norm: float) -> tuple[list[float], float]:
    norm = sqrt(sum(value * value for value in values))
    if norm <= max_norm or norm == 0:
        return values, 1.0
    scale = max_norm / norm
    return [value * scale for value in values], scale



def _validated_record_count(value: Any) -> int:
    """Reject coercions such as booleans, strings, fractions, NaN, and infinity."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("Every lab contribution must report a positive integer record_count")
    if isinstance(value, float) and (not isfinite(value) or not value.is_integer()):
        raise ValueError("Every lab contribution must report a positive integer record_count")
    count = int(value)
    if count <= 0:
        raise ValueError("Every lab contribution must report a positive integer record_count")
    return count

def aggregate_lab_statistics(contributions: list[dict[str, Any]], *, feature_names: list[str],
                              minimum_labs: int = 3, minimum_total_records: int = 30,
                              clip_norm: float = 10.0, add_gaussian_noise: bool = False,
                              epsilon: float = 1.0, delta: float = 1e-5,
                              budget: PrivacyBudget | None = None,
                              random_seed: int | None = None) -> dict:
    if len(feature_names) == 0 or len(set(feature_names)) != len(feature_names):
        raise ValueError("feature_names must be non-empty and unique")
    if minimum_labs < 2 or minimum_total_records < 2 or clip_norm <= 0:
        raise ValueError("Minimum cohort sizes and clip_norm must be positive")
    lab_ids = [str(row.get("laboratory_code", "")) for row in contributions]
    if len(set(lab_ids)) != len(lab_ids) or any(not value.startswith("SDL") for value in lab_ids):
        raise ValueError("Every contribution must have a unique SDL laboratory code")
    counts = [_validated_record_count(row.get("record_count")) for row in contributions]
    total_records = sum(counts)
    if len(contributions) < minimum_labs:
        return {"status": "suppressed_small_cohort", "lab_count": len(contributions),
                "record_count": total_records, "required_labs": minimum_labs,
                "aggregate": None, "reason": "Minimum laboratory count was not met."}
    if total_records < minimum_total_records:
        return {"status": "suppressed_small_cohort", "lab_count": len(contributions),
                "record_count": total_records, "required_records": minimum_total_records,
                "aggregate": None, "reason": "Minimum pooled record count was not met."}
    clipped, scales = [], {}
    for row, record_count in zip(contributions, counts):
        means = row.get("means", {})
        if set(means) != set(feature_names):
            raise ValueError(f"Lab {row['laboratory_code']} has incomplete feature means")
        vector = [float(means[name]) for name in feature_names]
        if any(not (-1e100 < value < 1e100) for value in vector):
            raise ValueError("Feature means must be finite")
        clip, scale = _clip_vector(vector, clip_norm)
        clipped.append((record_count, clip))
        scales[row["laboratory_code"]] = scale
    if add_gaussian_noise:
        if budget is None:
            raise ValueError("A persistent privacy budget ledger is required for noisy releases")
        if epsilon <= 0 or not 0 < delta < 1:
            raise ValueError("Gaussian mechanism requires epsilon>0 and delta in (0,1)")
        if not budget.can_spend(epsilon, delta):
            raise ValueError("Privacy budget would be exceeded")
        # Conservative prototype bound for a weighted mean of clipped lab-level vectors.
        # Record counts are treated as public; this is not a complete DP accounting proof.
        sensitivity = 2 * clip_norm * max(counts) / total_records
        noise_sigma = sensitivity * sqrt(2 * log(1.25 / delta)) / epsilon
    else:
        noise_sigma = 0.0
    weighted_sums = [0.0] * len(feature_names)
    for count, vector in clipped:
        for index, value in enumerate(vector):
            weighted_sums[index] += count * value
    aggregate_means = [value / total_records for value in weighted_sums]
    rng = Random(random_seed)
    if add_gaussian_noise:
        aggregate_means = [value + rng.gauss(0.0, noise_sigma) for value in aggregate_means]
        budget.spend(epsilon, delta)
    return {"status": "aggregate_created", "lab_count": len(contributions),
            "laboratories": sorted(lab_ids), "record_count": total_records,
            "feature_names": feature_names,
            "aggregate_means": dict(zip(feature_names, aggregate_means)),
            "contribution_clip_scales": scales,
            "noise_added": add_gaussian_noise, "noise_standard_deviation": noise_sigma,
            "privacy_budget": budget.snapshot() if budget else None,
            "raw_records_transmitted": False,
            "limitations": ["This prototype is not a secure aggregation network.",
                            "Clipping aggregate means is not equivalent to per-record user-level clipping.",
                            "No formal differential-privacy guarantee is asserted.",
                            "Contribution authenticity and collusion risks are outside this module."],
            "status_for_science": "hypothesis_generation_only"}


def privacy_release_preflight(budget: PrivacyBudget, *, epsilon: float, delta: float,
                              requested_release_count: int = 1) -> dict:
    if requested_release_count < 1:
        raise ValueError("requested_release_count must be positive")
    total_epsilon = epsilon * requested_release_count
    total_delta = delta * requested_release_count
    return {"allowed_by_basic_composition": budget.can_spend(total_epsilon, total_delta),
            "epsilon_after_release": budget.epsilon_spent + total_epsilon,
            "delta_after_release": budget.delta_spent + total_delta,
            "requested_release_count": requested_release_count,
            "accounting_method": "basic_composition_upper_bound",
            "warning": "Basic composition is conservative but does not replace an audited privacy accountant."}
