"""Prototype aggregation of cross-laboratory model parameter deltas.

This module models the server-side math after local training. It is not secure
aggregation, trusted execution, a formal privacy protocol, or an automatic model release.
"""
from __future__ import annotations
from math import isfinite, sqrt
from statistics import median
from typing import Any


def validate_client_update(update: dict[str, Any], *, expected_model_id: str,
                           expected_version: str, expected_parameters: list[str]) -> dict:
    issues = []
    if update.get("base_model_id") != expected_model_id: issues.append("base_model_id_mismatch")
    if update.get("base_model_version") != expected_version: issues.append("base_model_version_mismatch")
    if not str(update.get("laboratory_code", "")).startswith("SDL"): issues.append("invalid_laboratory_code")
    if update.get("consent_scope") != "approved_parameter_update": issues.append("consent_scope_missing_or_incompatible")
    if update.get("local_validation_status") != "accepted_for_research": issues.append("local_validation_not_accepted")
    delta = update.get("parameter_delta")
    if not isinstance(delta, dict) or set(delta) != set(expected_parameters):
        issues.append("parameter_schema_mismatch")
    else:
        if any(not isfinite(float(value)) for value in delta.values()):
            issues.append("non_finite_parameter_delta")
    record_count = int(update.get("training_record_count", 0))
    if record_count <= 0: issues.append("invalid_training_record_count")
    return {"valid": not issues, "issues": issues,
            "laboratory_code": update.get("laboratory_code"),
            "training_record_count": record_count,
            "raw_training_examples_included": False}


def aggregate_model_deltas(updates: list[dict[str, Any]], *, expected_model_id: str,
                           expected_version: str, parameter_names: list[str],
                           minimum_labs: int = 3, maximum_client_weight: float = 0.4,
                           clip_norm: float = 1.0, aggregation: str = "weighted_mean") -> dict:
    if not updates or not parameter_names or len(set(parameter_names)) != len(parameter_names):
        raise ValueError("Updates and unique parameter_names are required")
    if minimum_labs < 2 or not 0 < maximum_client_weight <= 1 or clip_norm <= 0:
        raise ValueError("Invalid minimum_labs, maximum_client_weight or clip_norm")
    if aggregation not in {"weighted_mean", "coordinate_median"}:
        raise ValueError("aggregation must be weighted_mean or coordinate_median")
    assessments = [validate_client_update(row, expected_model_id=expected_model_id,
                    expected_version=expected_version, expected_parameters=parameter_names) for row in updates]
    valid = [row for row, assessment in zip(updates, assessments) if assessment["valid"]]
    if len(valid) < minimum_labs:
        return {"status": "blocked_insufficient_eligible_labs", "eligible_lab_count": len(valid),
                "required_lab_count": minimum_labs, "client_assessments": assessments,
                "aggregate_parameter_delta": None, "model_update_created": False}
    labs = [row["laboratory_code"] for row in valid]
    if len(set(labs)) != len(labs):
        raise ValueError("Only one update per laboratory is accepted in a federation round")
    clipped_updates, scales = [], {}
    for row in valid:
        vector = [float(row["parameter_delta"][key]) for key in parameter_names]
        norm = sqrt(sum(value * value for value in vector))
        scale = min(1.0, clip_norm / norm) if norm > 0 else 1.0
        scales[row["laboratory_code"]] = scale
        clipped_updates.append([value * scale for value in vector])
    if aggregation == "coordinate_median":
        combined = [median([vector[index] for vector in clipped_updates]) for index in range(len(parameter_names))]
        weights = None
    else:
        counts = [int(row["training_record_count"]) for row in valid]
        raw_weights = [count / sum(counts) for count in counts]
        weights = [min(value, maximum_client_weight) for value in raw_weights]
        total = sum(weights)
        weights = [value / total for value in weights]
        combined = [sum(weights[i] * clipped_updates[i][j] for i in range(len(valid)))
                    for j in range(len(parameter_names))]
    return {"status": "aggregate_ready_for_review", "base_model_id": expected_model_id,
            "base_model_version": expected_version, "eligible_laboratories": sorted(labs),
            "eligible_lab_count": len(labs), "aggregation_method": aggregation,
            "parameter_names": parameter_names,
            "aggregate_parameter_delta": dict(zip(parameter_names, combined)),
            "client_clip_scales": scales, "normalized_client_weights": weights,
            "model_update_created": False, "model_release_authorized": False,
            "training_examples_transmitted": False,
            "limitations": ["Parameter updates can leak information; this endpoint is not cryptographic secure aggregation.",
                            "Client validation statements are assertions that require trusted attestation.",
                            "Clipping parameter deltas is not a complete privacy guarantee.",
                            "A scientist must evaluate cross-site interference, fairness, and target-lab performance."]}


def compare_federated_rounds(rounds: list[dict]) -> dict:
    if not rounds:
        raise ValueError("At least one federation round is required")
    result = []
    for row in rounds:
        delta = row.get("aggregate_parameter_delta", {})
        norm = sqrt(sum(float(value) ** 2 for value in delta.values())) if delta else 0.0
        result.append({"round_id": row.get("round_id"), "model_version": row.get("base_model_version"),
                       "laboratory_count": row.get("eligible_lab_count", 0),
                       "aggregate_delta_norm": norm,
                       "status": row.get("status")})
    return {"rounds": result, "interpretation": "Delta magnitude is descriptive; it does not measure model improvement or scientific validity."}
