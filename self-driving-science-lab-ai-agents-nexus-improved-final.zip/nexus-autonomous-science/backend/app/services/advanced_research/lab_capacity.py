"""Transparent resource-capacity previews for multi-laboratory research queues."""
from __future__ import annotations
from datetime import datetime, timedelta, timezone


def capacity_preview(*, resources: list[dict], tasks: list[dict],
                     start_at: str | None = None) -> dict:
    """Greedy earliest-finish schedule preview; it does not reserve real resources."""
    if not resources:
        raise ValueError("At least one resource is required")
    resource_map = {}
    for item in resources:
        key = str(item.get("resource_id", ""))
        if not key or key in resource_map:
            raise ValueError("Resources require unique resource_id")
        resource_map[key] = {"capabilities": set(item.get("capabilities", [])),
                             "available": 0.0, "name": item.get("name", key)}
    parsed = []
    for item in tasks:
        duration = float(item.get("duration_minutes", 0))
        if duration <= 0:
            raise ValueError("Task durations must be positive")
        parsed.append({**item, "duration_minutes": duration})
    # Stable ordering: highest priority first, then declared arrival order.
    parsed.sort(key=lambda item: (-float(item.get("priority", 0)), str(item.get("task_id", ""))))
    schedule = []
    unscheduled = []
    for task in parsed:
        required = set(task.get("required_capabilities", []))
        candidates = [(entry["available"], key) for key, entry in resource_map.items()
                      if required.issubset(entry["capabilities"])]
        if not candidates:
            unscheduled.append({"task_id": task.get("task_id"), "reason": "no_resource_with_required_capabilities"})
            continue
        available, resource_id = min(candidates)
        finish = available + task["duration_minutes"]
        schedule.append({"task_id": task.get("task_id"), "resource_id": resource_id,
                         "start_offset_minutes": available, "finish_offset_minutes": finish,
                         "duration_minutes": task["duration_minutes"]})
        resource_map[resource_id]["available"] = finish
    total_duration = max((row["finish_offset_minutes"] for row in schedule), default=0.0)
    origin = datetime.fromisoformat(start_at) if start_at else datetime.now(timezone.utc)
    return {"schedule": schedule, "unscheduled": unscheduled,
            "makespan_minutes": total_duration,
            "estimated_completion": (origin + timedelta(minutes=total_duration)).isoformat(),
            "resource_load_minutes": {key: value["available"] for key, value in resource_map.items()},
            "schedule_type": "greedy_capacity_preview", "reservations_created": False,
            "physical_execution_authorized": False,
            "limitations": ["No setup/changeover times unless included in task durations.",
                            "No sample compatibility or safety policy is inferred.",
                            "This does not reserve instruments or personnel."]}
