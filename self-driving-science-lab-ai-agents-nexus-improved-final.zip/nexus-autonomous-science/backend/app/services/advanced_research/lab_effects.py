"""Between-laboratory effect diagnostics and simple empirical-Bayes shrinkage."""
from __future__ import annotations
from math import isfinite
from statistics import mean, variance


def summarize_lab_effects(observations: list[dict], *, value_key: str = "value",
                          lab_key: str = "laboratory_code", minimum_per_lab: int = 2,
                          shrinkage: bool = True) -> dict:
    grouped: dict[str, list[float]] = {}
    for row in observations:
        lab = str(row.get(lab_key, ""))
        value = float(row.get(value_key))
        if not lab.startswith("SDL") or not isfinite(value):
            raise ValueError("Every observation requires an SDL laboratory code and finite value")
        grouped.setdefault(lab, []).append(value)
    if len(grouped) < 2 or any(len(values) < minimum_per_lab for values in grouped.values()):
        raise ValueError("At least two laboratories with sufficient observations are required")
    all_values = [value for values in grouped.values() for value in values]
    grand_mean = mean(all_values)
    within_variances = [variance(values) for values in grouped.values()]
    within = mean(within_variances)
    lab_means = {lab: mean(values) for lab, values in grouped.items()}
    between = variance(list(lab_means.values())) if len(lab_means) > 1 else 0.0
    tau2 = max(0.0, between - within / max(1, minimum_per_lab))
    results = {}
    for lab, values in grouped.items():
        observed_mean = mean(values)
        measurement_variance = within / len(values)
        weight = tau2 / (tau2 + measurement_variance) if shrinkage and tau2 + measurement_variance > 0 else 1.0
        adjusted = grand_mean + weight * (observed_mean - grand_mean)
        results[lab] = {"record_count": len(values), "observed_mean": observed_mean,
                        "within_lab_variance": variance(values), "shrinkage_weight": weight,
                        "partially_pooled_mean": adjusted,
                        "difference_from_grand_mean": observed_mean - grand_mean}
    return {"laboratory_count": len(grouped), "record_count": len(all_values),
            "grand_mean": grand_mean, "within_lab_variance_mean": within,
            "between_lab_mean_variance": between, "estimated_between_lab_variance_component": tau2,
            "laboratory_effects": results,
            "method": "simple_normal_normal_empirical_bayes_shrinkage" if shrinkage else "descriptive_group_means",
            "limitations": ["Exchangeability and normality assumptions are not tested.",
                            "Lab effects may reflect method, instrument, sample or population differences.",
                            "This summary does not identify a causal laboratory effect."]}
