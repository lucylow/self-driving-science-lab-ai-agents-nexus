"""Small dependency-free linear algebra helpers for transparent baselines.

This is intentionally a modest dense-matrix implementation for small scientific
calibration problems. It is not a replacement for BLAS/LAPACK on large workloads.
"""
from __future__ import annotations
from math import isfinite, sqrt
from typing import Sequence

Matrix = list[list[float]]


def _rectangular(matrix: Sequence[Sequence[float]]) -> tuple[int, int]:
    if not matrix:
        raise ValueError("Matrix must not be empty")
    width = len(matrix[0])
    if width == 0 or any(len(row) != width for row in matrix):
        raise ValueError("Matrix must be rectangular and non-empty")
    return len(matrix), width


def transpose(matrix: Sequence[Sequence[float]]) -> Matrix:
    _rectangular(matrix)
    return [list(row) for row in zip(*matrix)]


def matmul(left: Sequence[Sequence[float]], right: Sequence[Sequence[float]]) -> Matrix:
    rows, inner = _rectangular(left)
    inner_right, cols = _rectangular(right)
    if inner != inner_right:
        raise ValueError("Matrix dimensions do not align for multiplication")
    return [[sum(float(left[i][k]) * float(right[k][j]) for k in range(inner))
             for j in range(cols)] for i in range(rows)]


def solve(matrix: Sequence[Sequence[float]], vector: Sequence[float], *, tolerance: float = 1e-12) -> list[float]:
    n, cols = _rectangular(matrix)
    if n != cols or len(vector) != n:
        raise ValueError("Linear solve requires a square matrix and matching vector")
    augmented = [[float(value) for value in row] + [float(vector[i])] for i, row in enumerate(matrix)]
    for column in range(n):
        pivot = max(range(column, n), key=lambda row: abs(augmented[row][column]))
        if abs(augmented[pivot][column]) <= tolerance:
            raise ValueError("Singular or ill-conditioned calibration matrix")
        augmented[column], augmented[pivot] = augmented[pivot], augmented[column]
        scale = augmented[column][column]
        augmented[column] = [value / scale for value in augmented[column]]
        for row in range(n):
            if row == column:
                continue
            factor = augmented[row][column]
            if factor:
                augmented[row] = [a - factor * b for a, b in zip(augmented[row], augmented[column])]
    result = [augmented[row][-1] for row in range(n)]
    if any(not isfinite(value) for value in result):
        raise ValueError("Linear solve produced non-finite coefficients")
    return result


def inverse(matrix: Sequence[Sequence[float]], *, tolerance: float = 1e-12) -> Matrix:
    n, cols = _rectangular(matrix)
    if n != cols:
        raise ValueError("Only square matrices can be inverted")
    columns = [solve(matrix, [1.0 if row == col else 0.0 for row in range(n)], tolerance=tolerance)
               for col in range(n)]
    return transpose(columns)


def quadratic_form(vector: Sequence[float], matrix: Sequence[Sequence[float]]) -> float:
    if len(vector) != len(matrix) or any(len(row) != len(vector) for row in matrix):
        raise ValueError("Quadratic-form dimensions do not match")
    return sum(float(vector[i]) * float(matrix[i][j]) * float(vector[j])
               for i in range(len(vector)) for j in range(len(vector)))


def norm(vector: Sequence[float]) -> float:
    return sqrt(sum(float(value) ** 2 for value in vector))


def dot(left: Sequence[float], right: Sequence[float]) -> float:
    if len(left) != len(right):
        raise ValueError("Vector lengths do not match")
    return sum(float(a) * float(b) for a, b in zip(left, right))
