"""Evidence-driven computational method selection registry."""
from __future__ import annotations

METHODS = {
    "twin_calibration": {"domains": ["inorganic_materials", "polymers", "formulations", "process_engineering"],
                         "input_modalities": ["tabular", "timeseries"], "minimum_independent_groups": 3,
                         "purpose": "correct model outputs with paired observations", "physical_action": False},
    "conformal_intervals": {"domains": ["all"], "input_modalities": ["tabular"],
                             "minimum_independent_groups": 3, "purpose": "calibrate residual-based intervals", "physical_action": False},
    "sequential_design": {"domains": ["all"], "input_modalities": ["tabular", "crystal", "molecular"],
                           "minimum_independent_groups": 0, "purpose": "rank candidate parameter sets", "physical_action": False},
    "sensor_fusion": {"domains": ["all"], "input_modalities": ["timeseries"],
                      "minimum_independent_groups": 2, "purpose": "combine aligned sensor readings", "physical_action": False},
    "multi_fidelity_bridge": {"domains": ["all"], "input_modalities": ["tabular"],
                              "minimum_independent_groups": 3, "purpose": "correct low-fidelity outputs against paired high-fidelity results", "physical_action": False},
}


def recommend_methods(*, domain: str, modalities: list[str], available_groups: int,
                      requested_goal: str | None = None) -> dict:
    if available_groups < 0 or not modalities:
        raise ValueError("available_groups must be non-negative and modalities non-empty")
    recommendations = []
    for key, descriptor in METHODS.items():
        domain_match = "all" in descriptor["domains"] or domain in descriptor["domains"]
        modality_match = bool(set(modalities).intersection(descriptor["input_modalities"]))
        enough_groups = available_groups >= descriptor["minimum_independent_groups"]
        goal_match = not requested_goal or requested_goal.lower() in descriptor["purpose"].lower()
        recommendations.append({"method": key, "purpose": descriptor["purpose"],
                                "domain_match": domain_match, "modality_match": modality_match,
                                "minimum_data_available": enough_groups, "goal_match": goal_match,
                                "recommended": domain_match and modality_match and enough_groups and goal_match,
                                "physical_action": descriptor["physical_action"]})
    return {"domain": domain, "modalities": modalities,
            "recommended_methods": [row for row in recommendations if row["recommended"]],
            "all_assessments": recommendations,
            "note": "Recommendations are method-fit heuristics; a scientist must assess assumptions and study design."}
