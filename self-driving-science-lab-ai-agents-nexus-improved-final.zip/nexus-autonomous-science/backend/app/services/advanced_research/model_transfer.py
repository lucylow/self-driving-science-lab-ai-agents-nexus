"""Cross-lab model applicability review with explicit domain-shift diagnostics."""
from __future__ import annotations
from math import isfinite, sqrt
from statistics import mean, pstdev


def _mean(values: list[float]) -> float:
    return mean(values) if values else 0.0


def standardized_mean_difference(source: list[float], target: list[float]) -> float:
    if len(source) < 2 or len(target) < 2:
        raise ValueError("At least two values per domain are required")
    sx, tx = pstdev(source), pstdev(target)
    pooled = sqrt((sx * sx + tx * tx) / 2)
    return abs(_mean(source) - _mean(target)) / pooled if pooled > 1e-12 else (0.0 if _mean(source) == _mean(target) else float("inf"))


def evaluate_model_transfer(*, model_card: dict, source_context: dict, target_context: dict,
                             source_validation: dict | None = None,
                             target_holdout_metrics: dict | None = None,
                             maximum_smd: float = .25) -> dict:
    source_domain = source_context.get("domain")
    target_domain = target_context.get("domain")
    supported = set(model_card.get("supported_domains", []))
    method_source = source_context.get("measurement_method")
    method_target = target_context.get("measurement_method")
    units_source = source_context.get("unit_system")
    units_target = target_context.get("unit_system")
    checks = {
        "target_domain_declared": target_domain in supported,
        "method_compatible": bool(method_source) and method_source == method_target,
        "unit_compatible": bool(units_source) and units_source == units_target,
        "source_validation_available": bool(source_validation and source_validation.get("valid_for_domain")),
        "target_holdout_available": bool(target_holdout_metrics and int(target_holdout_metrics.get("n", 0)) >= 5),
    }
    shift = {}
    features_source = source_context.get("feature_distributions", {})
    features_target = target_context.get("feature_distributions", {})
    for name in sorted(set(features_source) & set(features_target)):
        shift[name] = standardized_mean_difference(list(map(float, features_source[name])),
                                                   list(map(float, features_target[name])))
    missing_features = sorted(set(features_source) ^ set(features_target))
    severe_shift = [name for name, value in shift.items() if not isfinite(value) or value > maximum_smd]
    checks["feature_support_compatible"] = not missing_features and not severe_shift
    checks["target_metrics_meet_thresholds"] = bool(target_holdout_metrics and
        target_holdout_metrics.get("scientist_reviewed") is True and
        target_holdout_metrics.get("status") == "accepted_for_research")
    passed = all(checks.values())
    return {"source_domain": source_domain, "target_domain": target_domain,
            "model_id": model_card.get("model_id"), "checks": checks,
            "feature_shift_smd": shift, "missing_feature_distributions": missing_features,
            "large_shift_features": severe_shift, "maximum_smd": maximum_smd,
            "recommendation": "eligible_for_target_lab_review" if passed else "do_not_transfer_without_additional_validation",
            "model_training_authorized": False, "experiment_execution_authorized": False,
            "limitations": ["Feature-distribution similarity does not prove conditional invariance.",
                            "Matching units and method labels do not prove measurement equivalence.",
                            "Target-lab validation must use representative independent samples."]}


def transfer_learning_plan(*, source_model_id: str, target_domain: str,
                           target_rows: int, target_labs: int,
                           target_holdout_required: int = 20) -> dict:
    if target_rows < 0 or target_labs < 0 or target_holdout_required < 5:
        raise ValueError("Invalid target-data requirements")
    if target_rows < target_holdout_required:
        route = "collect_target_domain_validation_data"
    elif target_labs < 2:
        route = "single_lab_sensitivity_review"
    else:
        route = "compare_zero_shot_frozen_finetuned_baselines"
    return {"source_model_id": source_model_id, "target_domain": target_domain,
            "target_rows": target_rows, "target_lab_count": target_labs,
            "recommended_route": route,
            "required_evaluations": ["target-only baseline", "frozen source model", "fine-tuned challenger",
                                     "group-aware holdout", "calibration", "out-of-domain detection",
                                     "subgroup analysis", "scientist review"],
            "training_authorized": False, "status": "plan_only"}
