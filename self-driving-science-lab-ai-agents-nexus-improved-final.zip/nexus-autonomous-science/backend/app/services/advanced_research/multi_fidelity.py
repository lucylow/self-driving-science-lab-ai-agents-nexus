"""Paired multi-fidelity correction and fidelity-aware ranking."""
from __future__ import annotations
from math import isfinite
from statistics import mean, pstdev


def fit_fidelity_bridge(paired: list[dict], *, low_key: str = "low_fidelity",
                        high_key: str = "high_fidelity", group_key: str = "group_id") -> dict:
    if len(paired) < 5:
        raise ValueError("At least five paired low/high fidelity samples are required")
    low = [float(row[low_key]) for row in paired]
    high = [float(row[high_key]) for row in paired]
    if any(not isfinite(value) for value in low + high):
        raise ValueError("Fidelity values must be finite")
    center = mean(low)
    variance = sum((value - center) ** 2 for value in low)
    if variance <= 1e-12:
        raise ValueError("Low-fidelity values must vary to fit a bridge")
    slope = sum((x - center) * (y - mean(high)) for x, y in zip(low, high)) / variance
    intercept = mean(high) - slope * center
    predictions = [intercept + slope * value for value in low]
    residuals = [y - p for y, p in zip(high, predictions)]
    groups = {str(row.get(group_key, f"row-{i}")) for i, row in enumerate(paired)}
    return {"bridge_type": "affine_low_to_high", "intercept": intercept, "slope": slope,
            "paired_count": len(paired), "group_count": len(groups),
            "low_range": [min(low), max(low)], "high_range": [min(high), max(high)],
            "residual_bias": mean(residuals), "residual_sd": pstdev(residuals),
            "status": "research_bridge_candidate", "physical_control_authorized": False,
            "limitation": "Low-to-high fidelity agreement is only supported within the paired calibration domain and range."}


def correct_low_fidelity(value: float, bridge: dict) -> dict:
    low, high = bridge["low_range"]
    number = float(value)
    if not isfinite(number):
        raise ValueError("value must be finite")
    extrapolated = number < low or number > high
    corrected = float(bridge["intercept"]) + float(bridge["slope"]) * number
    return {"low_fidelity_value": number, "corrected_high_fidelity_estimate": corrected,
            "bridge_residual_sd": float(bridge["residual_sd"]),
            "extrapolation": extrapolated,
            "status": "extrapolation_review_required" if extrapolated else "within_bridge_range",
            "evidence_type": "model_prediction", "synthetic": False}


def rank_multi_fidelity(candidates: list[dict], *, best_observed: float,
                         high_fidelity_budget: int, uncertainty_weight: float = 1.0) -> dict:
    if high_fidelity_budget < 0 or uncertainty_weight < 0:
        raise ValueError("Budget and uncertainty weight must be non-negative")
    ranked = []
    for candidate in candidates:
        mean_value = float(candidate["corrected_mean"])
        sigma = float(candidate["corrected_sd"])
        cost = float(candidate.get("low_fidelity_cost", 1.0))
        if sigma < 0 or cost <= 0:
            raise ValueError("Candidate uncertainty and cost are invalid")
        improvement = max(0.0, mean_value - best_observed)
        score = (improvement + uncertainty_weight * sigma) / cost
        ranked.append({**candidate, "information_priority": score,
                       "recommend_high_fidelity_check": False})
    ranked.sort(key=lambda item: item["information_priority"], reverse=True)
    for item in ranked[:high_fidelity_budget]:
        item["recommend_high_fidelity_check"] = True
    return {"ranked_candidates": ranked, "high_fidelity_budget": high_fidelity_budget,
            "execution_authorized": False,
            "note": "Priority scores are heuristic and do not replace a calibrated multi-fidelity acquisition model."}
