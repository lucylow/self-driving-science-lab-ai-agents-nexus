"""Integrity-checked, scoped scientific exchange envelopes.

HMAC authenticates an envelope only when the parties protect and rotate the shared
secret correctly. It does not provide encryption, anonymity, or scientific validity.
"""
from __future__ import annotations
from hashlib import sha256
import hmac
import json
from uuid import uuid4
from datetime import datetime, timezone
from typing import Any

LAB_CODES = {f"SDL{i}" for i in range(8)}
ALLOWED_SUBJECT_TYPES = {"sample", "candidate", "dataset", "hypothesis", "model", "measurement", "derived_artifact"}
SENSITIVITY_LEVELS = {"public", "internal", "restricted", "regulated"}


def canonical_json(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str).encode("utf-8")


def payload_digest(payload: dict) -> str:
    return sha256(canonical_json(payload)).hexdigest()


def redact_payload(payload: dict, *, classification: str, allowed_fields: list[str] | None = None,
                    sensitive_keys: set[str] | None = None) -> dict:
    if classification not in SENSITIVITY_LEVELS:
        raise ValueError("Unknown data classification")
    if not isinstance(payload, dict):
        raise ValueError("Exchange payload must be an object")
    sensitive = {key.lower() for key in (sensitive_keys or {
        "operator_email", "operator_name", "patient_id", "subject_id", "donor_id",
        "accession_number", "phone", "address", "personal_notes", "api_key", "token",
    })}
    allow = set(allowed_fields) if allowed_fields is not None else None

    def is_sensitive(key: Any) -> bool:
        lowered = str(key).lower()
        return (lowered in sensitive or
                any(term in lowered for term in ("password", "secret", "credential", "private_key")))

    def clean(value: Any, *, top_level: bool = False) -> Any:
        if isinstance(value, dict):
            result = {}
            for key, nested in value.items():
                if is_sensitive(key):
                    continue
                if top_level and allow is not None and key not in allow:
                    continue
                result[key] = clean(nested)
            return result
        if isinstance(value, list):
            return [clean(item) for item in value]
        if isinstance(value, tuple):
            return [clean(item) for item in value]
        return value

    return clean(payload, top_level=True)


def create_exchange_envelope(*, source_laboratory: str, target_laboratory: str,
                             subject_type: str, subject_id: str, domain: str,
                             schema_version: str, payload: dict,
                             evidence_origin: str, synthetic: bool,
                             classification: str = "internal",
                             consent_scope: str = "research_review_only",
                             allowed_fields: list[str] | None = None,
                             shared_secret: str | None = None,
                             transfer_id: str | None = None) -> dict:
    source, target = source_laboratory.upper(), target_laboratory.upper()
    if source not in LAB_CODES or target not in LAB_CODES or source == target:
        raise ValueError("Source and target must be two distinct SDL0-SDL7 laboratories")
    if subject_type not in ALLOWED_SUBJECT_TYPES:
        raise ValueError("Unsupported exchange subject type")
    if not subject_id.strip() or not domain.strip() or not schema_version.strip():
        raise ValueError("Subject id, domain and schema version are required")
    if consent_scope not in {"research_review_only", "approved_analysis", "aggregated_statistics"}:
        raise ValueError("Unsupported consent scope")
    if evidence_origin == "synthetic_simulation" and synthetic is not True:
        raise ValueError("Synthetic simulation evidence must carry synthetic=true")
    redacted = redact_payload(payload, classification=classification, allowed_fields=allowed_fields)
    manifest = {
        "transfer_id": transfer_id or f"XFER-{uuid4().hex[:12].upper()}",
        "source_laboratory": source, "target_laboratory": target,
        "subject_type": subject_type, "subject_id": subject_id, "domain": domain,
        "schema_version": schema_version, "evidence_origin": evidence_origin,
        "synthetic": bool(synthetic), "classification": classification,
        "consent_scope": consent_scope, "created_at": datetime.now(timezone.utc).isoformat(),
        "payload_sha256": payload_digest(redacted),
        "provenance_refs": list(redacted.get("provenance_refs", [])),
        "redaction_applied": redacted != payload,
    }
    signature = hmac.new(shared_secret.encode(), canonical_json(manifest), "sha256").hexdigest() if shared_secret else None
    return {"manifest": manifest, "payload": redacted, "signature": signature,
            "signature_algorithm": "HMAC-SHA256" if signature else "unsigned",
            "integrity_status": "signed" if signature else "unsigned_review_required",
            "scientific_reuse_allowed": False,
            "warnings": ["Integrity verification does not establish scientific validity.",
                         "This envelope is not encrypted in transit or at rest.",
                         "Target-laboratory review and local legal/ethics review may still be required."]}


def verify_exchange_envelope(envelope: dict, *, shared_secret: str | None = None,
                             require_signature: bool = True) -> dict:
    manifest, payload = envelope.get("manifest"), envelope.get("payload")
    if not isinstance(manifest, dict) or not isinstance(payload, dict):
        raise ValueError("Envelope must contain manifest and payload objects")
    actual_digest = payload_digest(payload)
    digest_valid = hmac.compare_digest(actual_digest, str(manifest.get("payload_sha256", "")))
    signature = envelope.get("signature")
    if signature and shared_secret:
        expected = hmac.new(shared_secret.encode(), canonical_json(manifest), "sha256").hexdigest()
        signature_valid: bool | None = hmac.compare_digest(expected, str(signature))
    else:
        signature_valid = None
    if require_signature and signature_valid is not True:
        status = "blocked_signature_missing_or_invalid"
    elif not digest_valid:
        status = "blocked_payload_digest_mismatch"
    else:
        status = "integrity_verified_review_required"
    return {"status": status, "digest_valid": digest_valid,
            "signature_valid": signature_valid,
            "source_laboratory": manifest.get("source_laboratory"),
            "target_laboratory": manifest.get("target_laboratory"),
            "scientific_reuse_allowed": False,
            "next_step": "target_scientist_review" if status == "integrity_verified_review_required" else "resolve_integrity_failure"}


def compatibility_matrix(source_domain: str, target_domain: str, *, method: str,
                          unit_system: str, provenance_complete: bool,
                          evidence_origin: str, calibration_domain: str | None = None) -> dict:
    same_domain = source_domain == target_domain
    method_known = bool(method.strip())
    unit_known = bool(unit_system.strip())
    calibrated = calibration_domain == target_domain
    gaps = []
    if not method_known: gaps.append("measurement_method_missing")
    if not unit_known: gaps.append("unit_system_missing")
    if not provenance_complete: gaps.append("provenance_incomplete")
    if not same_domain: gaps.append("cross_domain_review_required")
    if evidence_origin in {"model_prediction", "computational_result", "synthetic_simulation"} and not calibration_domain:
        gaps.append("model_or_simulation_calibration_not_declared")
    return {"source_domain": source_domain, "target_domain": target_domain,
            "same_domain": same_domain, "method_declared": method_known,
            "units_declared": unit_known, "provenance_complete": provenance_complete,
            "calibration_domain_matches_target": calibrated,
            "status": "eligible_for_scientist_review" if not gaps else "review_with_gaps",
            "gaps": gaps, "scientific_reuse_allowed": False}
