"""Database-backed prototype privacy budget ledger with transactional spending."""
from __future__ import annotations
from uuid import uuid4
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.models.entities import PrivacyBudgetLedgerRecord


def create_privacy_ledger(db: Session, *, ledger_key: str, epsilon_limit: float,
                          delta_limit: float) -> PrivacyBudgetLedgerRecord:
    if not ledger_key.strip() or epsilon_limit <= 0 or not 0 < delta_limit < 1:
        raise ValueError("ledger_key, epsilon_limit>0 and delta_limit in (0,1) are required")
    existing = db.scalar(select(PrivacyBudgetLedgerRecord).where(PrivacyBudgetLedgerRecord.ledger_key == ledger_key))
    if existing:
        raise ValueError("Privacy ledger key already exists")
    row = PrivacyBudgetLedgerRecord(id=str(uuid4()), ledger_key=ledger_key,
        epsilon_limit=epsilon_limit, delta_limit=delta_limit,
        epsilon_spent=0.0, delta_spent=0.0, release_count=0,
        release_history=[], status="active")
    db.add(row)
    db.flush()
    return row


def get_privacy_ledger(db: Session, ledger_key: str, *, lock: bool = False) -> PrivacyBudgetLedgerRecord:
    query = select(PrivacyBudgetLedgerRecord).where(
        PrivacyBudgetLedgerRecord.ledger_key == ledger_key)
    if lock:
        query = query.with_for_update()
    row = db.scalar(query)
    if not row:
        raise KeyError(ledger_key)
    return row


def ledger_snapshot(row: PrivacyBudgetLedgerRecord) -> dict:
    return {"ledger_key": row.ledger_key, "epsilon_limit": row.epsilon_limit,
            "delta_limit": row.delta_limit, "epsilon_spent": row.epsilon_spent,
            "delta_spent": row.delta_spent,
            "epsilon_remaining": max(0.0, row.epsilon_limit - row.epsilon_spent),
            "delta_remaining": max(0.0, row.delta_limit - row.delta_spent),
            "release_count": row.release_count, "status": row.status,
            "accounting_method": "basic_composition_upper_bound",
            "warning": "Prototype ledger; not a formal or independently audited privacy guarantee."}


def preflight_release(row: PrivacyBudgetLedgerRecord, *, epsilon: float, delta: float,
                      count: int = 1) -> dict:
    if epsilon <= 0 or not 0 < delta < 1 or count < 1:
        raise ValueError("epsilon>0, delta in (0,1), and count>=1 are required")
    add_epsilon, add_delta = epsilon * count, delta * count
    allowed = row.status == "active" and row.epsilon_spent + add_epsilon <= row.epsilon_limit and row.delta_spent + add_delta <= row.delta_limit
    return {"allowed": allowed, "ledger": ledger_snapshot(row),
            "requested": {"epsilon": add_epsilon, "delta": add_delta, "release_count": count},
            "remaining_after": {"epsilon": max(0.0, row.epsilon_limit - row.epsilon_spent - add_epsilon),
                                "delta": max(0.0, row.delta_limit - row.delta_spent - add_delta)},
            "blocked_reason": None if allowed else "ledger_inactive_or_budget_exceeded"}


def commit_release(row: PrivacyBudgetLedgerRecord, *, epsilon: float, delta: float,
                   release_key: str, metadata: dict | None = None) -> dict:
    if row.status != "active":
        raise ValueError("Privacy ledger is not active")
    if not release_key.strip():
        raise ValueError("release_key is required")
    history = list(row.release_history or [])
    if any(item.get("release_key") == release_key for item in history):
        raise ValueError("Release key has already been recorded")
    check = preflight_release(row, epsilon=epsilon, delta=delta)
    if not check["allowed"]:
        raise ValueError("Privacy budget would be exceeded")
    row.epsilon_spent += epsilon
    row.delta_spent += delta
    row.release_count += 1
    history.append({"release_key": release_key, "epsilon": epsilon, "delta": delta,
                    "metadata": metadata or {}})
    row.release_history = history
    return ledger_snapshot(row)


def pause_ledger(row: PrivacyBudgetLedgerRecord, *, reason: str) -> dict:
    if not reason.strip():
        raise ValueError("A pause reason is required")
    row.status = "paused"
    row.release_history = list(row.release_history or []) + [{"event": "paused", "reason": reason}]
    return ledger_snapshot(row)
