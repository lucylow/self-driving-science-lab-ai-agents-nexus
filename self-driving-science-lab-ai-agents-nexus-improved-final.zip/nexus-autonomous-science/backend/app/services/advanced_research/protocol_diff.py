"""Semantic protocol-version comparison and compatibility checks."""
from __future__ import annotations
from typing import Any


def compare_protocol_versions(previous: dict[str, Any], current: dict[str, Any]) -> dict:
    previous_id = previous.get("protocol_id")
    current_id = current.get("protocol_id")
    if not previous_id or previous_id != current_id:
        raise ValueError("Protocol versions must share the same protocol_id")
    prev_steps = previous.get("steps", [])
    curr_steps = current.get("steps", [])
    if not isinstance(prev_steps, list) or not isinstance(curr_steps, list):
        raise ValueError("Protocol steps must be lists")
    def index_steps(items):
        indexed = {}
        for item in items:
            key = str(item.get("step_id", ""))
            if not key or key in indexed:
                raise ValueError("Every protocol step requires a unique step_id")
            indexed[key] = item
        return indexed
    left, right = index_steps(prev_steps), index_steps(curr_steps)
    added = sorted(set(right) - set(left))
    removed = sorted(set(left) - set(right))
    changed = []
    for key in sorted(set(left) & set(right)):
        fields = sorted(field for field in set(left[key]) | set(right[key]) if left[key].get(field) != right[key].get(field))
        if fields:
            changed.append({"step_id": key, "changed_fields": fields,
                            "previous": {field: left[key].get(field) for field in fields},
                            "current": {field: right[key].get(field) for field in fields}})
    metadata_fields = sorted(field for field in set(previous) | set(current)
                             if field not in {"steps", "protocol_id"} and previous.get(field) != current.get(field))
    return {"protocol_id": previous_id, "previous_version": previous.get("version"),
            "current_version": current.get("version"), "added_steps": added,
            "removed_steps": removed, "changed_steps": changed,
            "changed_metadata_fields": metadata_fields,
            "requires_scientific_revalidation": bool(added or removed or changed or metadata_fields),
            "execution_authorized": False,
            "note": "This diff is descriptive; an expert must decide whether the change affects method validity or risk."}


def protocol_compatibility(protocol: dict, *, domain: str, sample_types: list[str],
                           instrument_capabilities: list[str]) -> dict:
    gaps = []
    if protocol.get("domain") != domain: gaps.append("domain_mismatch")
    declared_samples = set(protocol.get("supported_sample_types", []))
    if not declared_samples.intersection(sample_types): gaps.append("sample_type_not_supported")
    required = set(protocol.get("required_capabilities", []))
    missing = sorted(required - set(instrument_capabilities))
    if missing: gaps.append("instrument_capability_missing")
    return {"compatible": not gaps, "gaps": gaps, "missing_instrument_capabilities": missing,
            "requires_operator_review": True, "physical_execution_authorized": False}
