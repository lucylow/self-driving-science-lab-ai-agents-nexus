"""Repeatability, agreement and within/between-group variance summaries."""
from __future__ import annotations
from math import isfinite, sqrt
from statistics import mean, variance


def repeatability_summary(replicates: list[dict], *, group_key: str = "sample_id",
                          value_key: str = "value") -> dict:
    groups: dict[str, list[float]] = {}
    for row in replicates:
        key = str(row.get(group_key, ""))
        value = float(row.get(value_key))
        if not key or not isfinite(value):
            raise ValueError("Each replicate requires a group identity and finite value")
        groups.setdefault(key, []).append(value)
    if len(groups) < 2 or any(len(values) < 2 for values in groups.values()):
        raise ValueError("At least two groups and two replicates per group are required")
    all_values = [value for values in groups.values() for value in values]
    grand = mean(all_values)
    group_means = [mean(values) for values in groups.values()]
    within_ss = sum(sum((value - mean(values)) ** 2 for value in values) for values in groups.values())
    within_df = sum(len(values) - 1 for values in groups.values())
    within_ms = within_ss / within_df
    between_ss = sum(len(values) * (mean(values) - grand) ** 2 for values in groups.values())
    between_df = len(groups) - 1
    between_ms = between_ss / between_df if between_df else 0.0
    average_n = mean([len(values) for values in groups.values()])
    variance_between = max(0.0, (between_ms - within_ms) / max(average_n, 1.0))
    icc = variance_between / (variance_between + within_ms) if variance_between + within_ms > 0 else None
    return {"group_count": len(groups), "replicate_count": len(all_values),
            "overall_mean": grand, "within_group_mean_square": within_ms,
            "between_group_mean_square": between_ms,
            "estimated_within_group_sd": sqrt(max(0.0, within_ms)),
            "estimated_between_group_variance": variance_between,
            "icc_one_way_random_intercept_approximation": icc,
            "group_means": {key: mean(values) for key, values in groups.items()},
            "limitations": ["Unequal group sizes are approximated with the mean group size.",
                            "ICC depends on population heterogeneity and is not a pure instrument metric.",
                            "The calculation does not adjust for batch, operator or time effects."]}


def bland_altman_summary(method_a: list[float], method_b: list[float]) -> dict:
    if len(method_a) != len(method_b) or len(method_a) < 5:
        raise ValueError("At least five paired method measurements are required")
    a, b = list(map(float, method_a)), list(map(float, method_b))
    if any(not isfinite(value) for value in a + b):
        raise ValueError("Method measurements must be finite")
    differences = [x - y for x, y in zip(a, b)]
    averages = [(x + y) / 2 for x, y in zip(a, b)]
    bias = mean(differences)
    sd = sqrt(variance(differences))
    return {"paired_count": len(a), "mean_bias_a_minus_b": bias,
            "difference_standard_deviation": sd,
            "lower_approximate_95_limit": bias - 1.96 * sd,
            "upper_approximate_95_limit": bias + 1.96 * sd,
            "mean_of_method_averages": mean(averages),
            "interpretation": "Approximate agreement summary; proportional bias, heteroscedasticity and clinical/domain-specific acceptance limits are not assessed."}
