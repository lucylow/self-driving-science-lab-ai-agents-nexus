"""Replication and precision planning using transparent normal approximations."""
from __future__ import annotations
from math import ceil, isfinite, sqrt

_Z = {0.80: 1.2816, 0.90: 1.6449, 0.95: 1.9600, 0.98: 2.3263, 0.99: 2.5758}


def estimate_replicates_for_mean_precision(*, pilot_standard_deviation: float,
                                            desired_half_width: float,
                                            confidence: float = .95,
                                            minimum_replicates: int = 3,
                                            maximum_replicates: int = 10000) -> dict:
    sd, half = float(pilot_standard_deviation), float(desired_half_width)
    if not isfinite(sd) or not isfinite(half) or sd <= 0 or half <= 0:
        raise ValueError("Pilot standard deviation and desired half-width must be finite and positive")
    if confidence not in _Z:
        raise ValueError(f"Supported normal-approximation confidence levels: {sorted(_Z)}")
    if minimum_replicates < 2 or maximum_replicates < minimum_replicates:
        raise ValueError("Invalid replicate bounds")
    n = max(minimum_replicates, ceil((_Z[confidence] * sd / half) ** 2))
    return {"estimated_replicates": n, "within_configured_maximum": n <= maximum_replicates,
            "confidence": confidence, "pilot_sd": sd, "desired_half_width": half,
            "approximation": "normal z-based mean precision estimate",
            "limitations": ["Pilot SD is assumed representative.", "Does not model multiple comparisons or hierarchical variation.",
                            "Does not replace field-specific power analysis.", "Final replicate count requires scientist/statistician review."],
            "physical_execution_authorized": False}


def replicate_summary(values: list[float]) -> dict:
    if len(values) < 2:
        raise ValueError("At least two replicate values are required")
    numeric = [float(value) for value in values]
    if any(not isfinite(value) for value in numeric):
        raise ValueError("Replicate values must be finite")
    center = sum(numeric) / len(numeric)
    variance = sum((value - center) ** 2 for value in numeric) / (len(numeric) - 1)
    sd = sqrt(variance)
    cv = sd / abs(center) if center != 0 else None
    return {"replicate_count": len(numeric), "mean": center, "standard_deviation": sd,
            "coefficient_of_variation": cv, "minimum": min(numeric), "maximum": max(numeric),
            "range": max(numeric) - min(numeric),
            "interpretation": "Descriptive replicate summary; independence and protocol consistency must be assessed separately."}
