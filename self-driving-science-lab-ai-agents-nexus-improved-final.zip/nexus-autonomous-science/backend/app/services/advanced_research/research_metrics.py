"""Operational and scientific-program metrics with explicit denominators."""
from __future__ import annotations
from datetime import datetime
from statistics import mean


def provenance_completeness(records: list[dict], *, required_fields: list[str]) -> dict:
    if not records or not required_fields:
        raise ValueError("records and required_fields must be non-empty")
    per_field = {field: sum(record.get(field) not in (None, "", []) for record in records) / len(records)
                 for field in required_fields}
    complete_count = sum(all(record.get(field) not in (None, "", []) for field in required_fields) for record in records)
    return {"record_count": len(records), "complete_record_count": complete_count,
            "complete_record_fraction": complete_count / len(records),
            "field_completeness": per_field,
            "interpretation": "Completeness is not equivalent to correctness or scientific validity."}


def experiment_cycle_metrics(experiments: list[dict]) -> dict:
    durations = []
    statuses: dict[str, int] = {}
    for row in experiments:
        status = str(row.get("status", "unknown"))
        statuses[status] = statuses.get(status, 0) + 1
        start, end = row.get("started_at"), row.get("completed_at")
        if start and end:
            delta = (datetime.fromisoformat(end) - datetime.fromisoformat(start)).total_seconds() / 3600
            if delta >= 0:
                durations.append(delta)
    return {"experiment_count": len(experiments), "status_counts": statuses,
            "completed_with_timestamps": len(durations),
            "mean_cycle_hours": mean(durations) if durations else None,
            "median_cycle_hours": sorted(durations)[len(durations)//2] if durations else None,
            "note": "Only records with valid start and completion timestamps contribute to duration metrics."}


def data_reuse_score(*, transferred_records: int, reused_records: int,
                     independent_validation_count: int) -> dict:
    if min(transferred_records, reused_records, independent_validation_count) < 0:
        raise ValueError("Counts must be non-negative")
    if reused_records > transferred_records:
        raise ValueError("reused_records cannot exceed transferred_records")
    return {"transferred_records": transferred_records, "reused_records": reused_records,
            "reuse_fraction": reused_records / transferred_records if transferred_records else None,
            "independent_validation_count": independent_validation_count,
            "interpretation": "Reuse counts do not establish transfer validity; independent target-domain validation is reported separately."}
