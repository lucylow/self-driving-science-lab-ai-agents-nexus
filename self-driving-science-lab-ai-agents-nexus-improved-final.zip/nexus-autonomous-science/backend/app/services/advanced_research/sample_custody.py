"""Digital sample-custody records for cross-lab handoff review.

This records attestations and intended custody state. It does not dispatch samples,
operate doors, unlock storage, or verify physical custody without human evidence.
"""
from __future__ import annotations
from datetime import datetime, timezone
from hashlib import sha256
import json
from typing import Any

TRANSITIONS = {
    "registered": {"handoff_requested", "quarantined"},
    "handoff_requested": {"released_by_source", "cancelled", "quarantined"},
    "released_by_source": {"received_by_target", "quarantined"},
    "received_by_target": {"identity_verified", "quarantined"},
    "identity_verified": {"available_for_review", "quarantined"},
    "available_for_review": {"consumed_in_authorized_experiment", "quarantined"},
    "consumed_in_authorized_experiment": set(),
    "cancelled": set(),
    "quarantined": set(),
}


def _hash_event(payload: dict, previous_hash: str = "") -> str:
    encoded = json.dumps({"previous_hash": previous_hash, "payload": payload}, sort_keys=True,
                         separators=(",", ":"), default=str).encode()
    return sha256(encoded).hexdigest()


def create_custody_record(*, sample_id: str, source_laboratory: str,
                           target_laboratory: str, sample_identity_status: str,
                           evidence_refs: list[str] | None = None) -> dict:
    if not sample_id.strip() or not source_laboratory.startswith("SDL") or not target_laboratory.startswith("SDL"):
        raise ValueError("Sample id and valid laboratory codes are required")
    if source_laboratory == target_laboratory:
        raise ValueError("Custody handoff requires different source and target laboratories")
    if sample_identity_status not in {"verified", "unverified", "ambiguous"}:
        raise ValueError("Unsupported sample identity status")
    if sample_identity_status != "verified":
        initial_state = "quarantined"
        reason = "Sample identity is not verified before cross-lab custody workflow."
    else:
        initial_state = "registered"
        reason = "Sample identity marked verified at custody workflow creation; local receipt checks remain required."
    event = {"sequence": 1, "event_type": "CUSTODY_RECORD_CREATED", "actor": "system",
             "from_state": None, "to_state": initial_state,
             "evidence_refs": evidence_refs or [], "timestamp": datetime.now(timezone.utc).isoformat(),
             "reason": reason}
    event["event_hash"] = _hash_event(event)
    return {"sample_id": sample_id, "source_laboratory": source_laboratory,
            "target_laboratory": target_laboratory, "state": initial_state,
            "events": [event], "last_event_hash": event["event_hash"],
            "physical_handoff_executed": False, "status": "digital_custody_record"}


def transition_custody(record: dict[str, Any], *, next_state: str, actor: str,
                       evidence_refs: list[str], reason: str,
                       human_attestation: bool = False) -> dict:
    current = str(record.get("state", ""))
    if next_state not in TRANSITIONS.get(current, set()):
        raise ValueError(f"Invalid custody transition: {current} -> {next_state}")
    if not actor.strip() or not reason.strip():
        raise ValueError("Named actor and transition reason are required")
    if next_state in {"released_by_source", "received_by_target", "identity_verified"} and not human_attestation:
        raise ValueError("Human attestation is required for custody and identity transitions")
    if next_state in {"received_by_target", "identity_verified", "available_for_review"} and not evidence_refs:
        raise ValueError("Evidence references are required for target receipt and verification states")
    if next_state == "consumed_in_authorized_experiment":
        raise ValueError("Sample consumption must be recorded by the governed experiment workflow")
    sequence = len(record.get("events", [])) + 1
    event = {"sequence": sequence, "event_type": "SAMPLE_CUSTODY_TRANSITION",
             "actor": actor, "from_state": current, "to_state": next_state,
             "evidence_refs": evidence_refs, "reason": reason,
             "human_attestation": human_attestation,
             "timestamp": datetime.now(timezone.utc).isoformat()}
    event["previous_hash"] = record.get("last_event_hash", "")
    event["event_hash"] = _hash_event(event, event["previous_hash"])
    updated = {**record, "state": next_state,
               "events": list(record.get("events", [])) + [event],
               "last_event_hash": event["event_hash"]}
    return updated


def verify_custody_chain(record: dict) -> dict:
    previous = ""
    errors = []
    for index, event in enumerate(record.get("events", []), start=1):
        event_without_hash = {key: value for key, value in event.items() if key not in {"event_hash", "previous_hash"}}
        declared_previous = event.get("previous_hash", "")
        if declared_previous != previous:
            errors.append({"sequence": index, "issue": "previous_hash_mismatch"})
        expected = _hash_event(event_without_hash, previous if index > 1 else "")
        if expected != event.get("event_hash"):
            errors.append({"sequence": index, "issue": "event_hash_mismatch"})
        previous = event.get("event_hash", "")
    return {"valid": not errors, "errors": errors,
            "event_count": len(record.get("events", [])),
            "current_state": record.get("state"),
            "physical_handoff_executed": False}
