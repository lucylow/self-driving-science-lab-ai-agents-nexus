"""Finite-difference local sensitivity and one-at-a-time scenario analysis."""
from __future__ import annotations
from math import isfinite
from typing import Callable


def finite_difference_sensitivity(*, parameters: dict[str, float], evaluator: Callable[[dict[str, float]], float],
                                  relative_step: float = 1e-4) -> dict:
    if not parameters or not 0 < relative_step < .1:
        raise ValueError("parameters must be non-empty and relative_step in (0, 0.1)")
    base = {key: float(value) for key, value in parameters.items()}
    if any(not isfinite(value) for value in base.values()):
        raise ValueError("Parameters must be finite")
    baseline = float(evaluator(base))
    if not isfinite(baseline):
        raise ValueError("Evaluator returned non-finite baseline")
    derivatives = {}
    elasticities = {}
    for key, value in base.items():
        step = max(abs(value) * relative_step, relative_step)
        plus, minus = dict(base), dict(base)
        plus[key], minus[key] = value + step, value - step
        f_plus, f_minus = float(evaluator(plus)), float(evaluator(minus))
        if not isfinite(f_plus) or not isfinite(f_minus):
            raise ValueError(f"Evaluator returned non-finite values around {key}")
        derivative = (f_plus - f_minus) / (2 * step)
        derivatives[key] = derivative
        elasticities[key] = derivative * value / baseline if abs(baseline) > 1e-12 else None
    ranked = sorted(derivatives, key=lambda key: abs(derivatives[key]), reverse=True)
    return {"baseline_output": baseline, "local_derivatives": derivatives,
            "local_elasticities": elasticities, "sensitivity_order": ranked,
            "method": "central_finite_difference", "relative_step": relative_step,
            "interpretation": "Local sensitivity near the supplied point; nonlinear effects and interactions may be missed."}


def one_at_a_time_scenarios(*, parameters: dict[str, float], ranges: dict[str, tuple[float, float]],
                            evaluator: Callable[[dict[str, float]], float], points_per_parameter: int = 5) -> dict:
    if points_per_parameter < 2:
        raise ValueError("points_per_parameter must be at least two")
    if set(parameters) != set(ranges):
        raise ValueError("Every parameter must have a corresponding range")
    baseline = {key: float(value) for key, value in parameters.items()}
    baseline_output = float(evaluator(baseline))
    effects = {}
    for key, bounds in ranges.items():
        low, high = map(float, bounds)
        if not low < high or not low <= baseline[key] <= high:
            raise ValueError(f"Invalid or non-containing range for {key}")
        samples = []
        for index in range(points_per_parameter):
            value = low + index * (high - low) / (points_per_parameter - 1)
            scenario = dict(baseline)
            scenario[key] = value
            samples.append({"parameter_value": value, "output": float(evaluator(scenario))})
        effects[key] = samples
    return {"baseline_parameters": baseline, "baseline_output": baseline_output,
            "effects": effects, "method": "one_factor_at_a_time",
            "warning": "This design does not estimate interactions and is not a substitute for factorial or variance-based analysis."}
