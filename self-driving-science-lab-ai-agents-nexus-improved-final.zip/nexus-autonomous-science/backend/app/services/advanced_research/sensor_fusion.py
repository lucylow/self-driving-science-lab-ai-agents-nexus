"""Timestamp-aware scalar sensor fusion with source-level diagnostics."""
from __future__ import annotations
from math import isfinite
from statistics import median
from typing import Any


def validate_sensor_stream(stream: list[dict], *, maximum_gap_seconds: float | None = None) -> dict:
    if len(stream) < 2:
        raise ValueError("A sensor stream requires at least two observations")
    ordered = sorted(stream, key=lambda row: float(row.get("timestamp")))
    errors = []
    seen = set()
    gaps = []
    for index, row in enumerate(ordered):
        sensor = str(row.get("sensor_id", ""))
        timestamp, value = float(row.get("timestamp")), float(row.get("value"))
        if not sensor:
            errors.append({"index": index, "issue": "missing_sensor_id"})
        if not isfinite(timestamp) or not isfinite(value):
            errors.append({"index": index, "issue": "non_finite_timestamp_or_value"})
        key = (sensor, timestamp)
        if key in seen:
            errors.append({"index": index, "issue": "duplicate_sensor_timestamp"})
        seen.add(key)
        if index:
            gaps.append(timestamp - float(ordered[index - 1]["timestamp"]))
    excessive = [index for index, gap in enumerate(gaps) if maximum_gap_seconds is not None and gap > maximum_gap_seconds]
    return {"valid": not errors, "errors": errors, "observation_count": len(stream),
            "time_range": [ordered[0].get("timestamp"), ordered[-1].get("timestamp")],
            "median_inter_observation_gap": median(gaps) if gaps else None,
            "excessive_gap_indices": excessive,
            "ordering_applied": "timestamp_ascending"}


def fuse_scalar_sensors(observations: list[dict[str, Any]], *,
                        expected_timestamp: float | None = None,
                        maximum_time_offset_seconds: float = 1.0,
                        outlier_z_threshold: float = 3.5) -> dict:
    if len(observations) < 2:
        raise ValueError("At least two sensors are required for fusion")
    if maximum_time_offset_seconds < 0 or outlier_z_threshold <= 0:
        raise ValueError("Invalid time tolerance or outlier threshold")
    parsed = []
    for row in observations:
        sensor = str(row.get("sensor_id", ""))
        value, sigma, timestamp = float(row.get("value")), float(row.get("standard_deviation")), float(row.get("timestamp"))
        if not sensor or not all(isfinite(x) for x in [value, sigma, timestamp]) or sigma <= 0:
            raise ValueError("Each sensor requires an id, finite value/timestamp and positive standard deviation")
        parsed.append({"sensor_id": sensor, "value": value, "sigma": sigma, "timestamp": timestamp,
                       "unit": row.get("unit", "unspecified")})
    units = {row["unit"] for row in parsed}
    if len(units) > 1:
        raise ValueError("Sensor fusion requires normalized compatible units")
    target_time = expected_timestamp if expected_timestamp is not None else median([row["timestamp"] for row in parsed])
    time_offsets = {row["sensor_id"]: abs(row["timestamp"] - target_time) for row in parsed}
    out_of_sync = [sensor for sensor, offset in time_offsets.items() if offset > maximum_time_offset_seconds]
    values = [row["value"] for row in parsed]
    center = median(values)
    deviations = [abs(value - center) for value in values]
    mad = median(deviations)
    robust_scale = max(1.4826 * mad, 1e-12)
    outliers = [row["sensor_id"] for row in parsed if abs(row["value"] - center) / robust_scale > outlier_z_threshold]
    accepted = [row for row in parsed if row["sensor_id"] not in outliers and row["sensor_id"] not in out_of_sync]
    if not accepted:
        return {"status": "no_acceptable_sensor_observations", "fused_value": None,
                "excluded_outliers": outliers, "out_of_sync_sensors": out_of_sync,
                "source_observations": parsed}
    weights = [1 / (row["sigma"] ** 2) for row in accepted]
    fused = sum(row["value"] * weight for row, weight in zip(accepted, weights)) / sum(weights)
    uncertainty = (1 / sum(weights)) ** .5
    return {"status": "fused_with_review" if outliers or out_of_sync else "fused",
            "fused_value": fused, "standard_uncertainty": uncertainty,
            "unit": next(iter(units)), "reference_timestamp": target_time,
            "accepted_sensor_ids": [row["sensor_id"] for row in accepted],
            "excluded_outliers": outliers, "out_of_sync_sensors": out_of_sync,
            "time_offsets_seconds": time_offsets, "source_observations": parsed,
            "evidence_type": "derived_observation", "synthetic": False,
            "limitation": "Weighted fusion assumes uncertainty scales are meaningful and remaining sensor errors are independent; common-mode errors are not estimated."}


def align_sensor_events(events: list[dict], *, tolerance_seconds: float) -> dict:
    if not events or tolerance_seconds < 0:
        raise ValueError("Events are required and tolerance must be non-negative")
    ordered = sorted(events, key=lambda row: float(row["timestamp"]))
    clusters: list[list[dict]] = []
    for event in ordered:
        timestamp = float(event["timestamp"])
        if not isfinite(timestamp):
            raise ValueError("Event timestamps must be finite")
        if not clusters or timestamp - float(clusters[-1][0]["timestamp"]) > tolerance_seconds:
            clusters.append([event])
        else:
            clusters[-1].append(event)
    return {"event_clusters": clusters, "cluster_count": len(clusters),
            "tolerance_seconds": tolerance_seconds,
            "warning": "Clustering timestamps does not establish causal ordering or synchronization accuracy."}
