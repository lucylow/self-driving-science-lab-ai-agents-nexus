"""Constraint-aware multi-objective sequential design for computational proposals.

Candidates produced here are parameter suggestions, not executable protocols.
"""
from __future__ import annotations
from math import erf, exp, pi, sqrt, isfinite
from typing import Any


def _cdf(z: float) -> float:
    return .5 * (1 + erf(z / sqrt(2)))


def _pdf(z: float) -> float:
    return exp(-.5 * z * z) / sqrt(2 * pi)


def _validate_candidate(row: dict, features: list[str]) -> None:
    if not isinstance(row.get("candidate_id"), str) or not row["candidate_id"].strip():
        raise ValueError("Every design candidate requires candidate_id")
    for key in features:
        value = float(row.get("parameters", {}).get(key))
        if not isfinite(value):
            raise ValueError(f"Candidate {row['candidate_id']} has invalid parameter {key}")


def evaluate_constraints(parameters: dict[str, float], constraints: list[dict]) -> dict:
    failures = []
    for rule in constraints:
        name = rule.get("parameter")
        if name not in parameters:
            failures.append({"rule": rule, "reason": "missing_parameter"})
            continue
        value = float(parameters[name])
        if rule.get("minimum") is not None and value < float(rule["minimum"]):
            failures.append({"rule": rule, "reason": "below_minimum", "value": value})
        if rule.get("maximum") is not None and value > float(rule["maximum"]):
            failures.append({"rule": rule, "reason": "above_maximum", "value": value})
        if rule.get("allowed_values") is not None and value not in [float(x) for x in rule["allowed_values"]]:
            failures.append({"rule": rule, "reason": "not_in_allowed_values", "value": value})
    return {"feasible": not failures, "violations": failures}


def acquisition_score(mean_prediction: float, standard_deviation: float, best_observed: float, *,
                      direction: str = "maximize", strategy: str = "expected_improvement",
                      exploration: float = .01, cost: float = 1.0, cost_exponent: float = 1.0) -> float:
    mu, sigma, best = float(mean_prediction), max(0.0, float(standard_deviation)), float(best_observed)
    if any(not isfinite(v) for v in [mu, sigma, best, float(cost), float(cost_exponent), float(exploration)]):
        raise ValueError("Acquisition inputs must be finite")
    if direction not in {"maximize", "minimize"}:
        raise ValueError("direction must be maximize or minimize")
    if strategy not in {"expected_improvement", "probability_improvement", "upper_confidence_bound", "lower_confidence_bound"}:
        raise ValueError("Unsupported acquisition strategy")
    if cost <= 0 or cost_exponent < 0:
        raise ValueError("cost must be positive and cost_exponent non-negative")
    oriented_mu = mu if direction == "maximize" else -mu
    oriented_best = best if direction == "maximize" else -best
    if strategy == "upper_confidence_bound":
        value = oriented_mu + sqrt(max(0, 2.0)) * sigma
    elif strategy == "lower_confidence_bound":
        value = oriented_mu - sqrt(max(0, 2.0)) * sigma
    elif sigma <= 1e-12:
        delta = oriented_mu - oriented_best - exploration
        value = max(0.0, delta) if strategy == "expected_improvement" else float(delta > 0)
    else:
        delta = oriented_mu - oriented_best - exploration
        z = delta / sigma
        value = sigma * _pdf(z) + delta * _cdf(z) if strategy == "expected_improvement" else _cdf(z)
    return value / (cost ** cost_exponent)


def _distance(left: dict[str, float], right: dict[str, float], names: list[str], ranges: dict[str, tuple[float, float]]) -> float:
    total = 0.0
    for key in names:
        width = max(1e-12, float(ranges[key][1]) - float(ranges[key][0]))
        total += ((float(left[key]) - float(right[key])) / width) ** 2
    return sqrt(total / max(1, len(names)))


def propose_sequential_batch(candidates: list[dict[str, Any]], *, feature_names: list[str],
                             best_observed: float, direction: str = "maximize",
                             strategy: str = "expected_improvement", batch_size: int = 4,
                             constraints: list[dict] | None = None,
                             feature_ranges: dict[str, tuple[float, float]] | None = None,
                             family_key: str = "family", max_per_family: int = 1,
                             diversity_weight: float = .15, cost_exponent: float = 1.0) -> dict:
    if not candidates:
        raise ValueError("At least one candidate is required")
    if not feature_names or batch_size < 1 or max_per_family < 1:
        raise ValueError("Feature names, positive batch_size, and positive max_per_family are required")
    ranges = feature_ranges or {name: (min(float(row["parameters"][name]) for row in candidates),
                                       max(float(row["parameters"][name]) for row in candidates)) for name in feature_names}
    for name in feature_names:
        if name not in ranges or len(ranges[name]) != 2 or ranges[name][1] < ranges[name][0]:
            raise ValueError(f"Invalid feature range for {name}")
    scored, rejected = [], []
    ids = set()
    for row in candidates:
        _validate_candidate(row, feature_names)
        if row["candidate_id"] in ids:
            raise ValueError("Candidate identifiers must be unique")
        ids.add(row["candidate_id"])
        constraint_report = evaluate_constraints(row.get("parameters", {}), constraints or [])
        if not constraint_report["feasible"]:
            rejected.append({"candidate_id": row["candidate_id"], "violations": constraint_report["violations"]})
            continue
        mean_value = float(row.get("prediction_mean"))
        sigma = float(row.get("prediction_std", 0.0))
        cost = float(row.get("estimated_cost", 1.0))
        if sigma < 0 or not all(isfinite(v) for v in [mean_value, sigma, cost]) or cost <= 0:
            raise ValueError(f"Invalid prediction or cost for {row['candidate_id']}")
        acquisition = acquisition_score(mean_value, sigma, best_observed, direction=direction,
                                        strategy=strategy, cost=cost, cost_exponent=cost_exponent)
        scored.append({**row, "base_acquisition": acquisition, "acquisition": acquisition,
                       "constraint_status": "passed"})
    selected, remaining, family_counts = [], scored[:], {}
    while remaining and len(selected) < batch_size:
        reranked = []
        for row in remaining:
            family = str(row.get(family_key, "unspecified"))
            if family_counts.get(family, 0) >= max_per_family:
                continue
            distances = [_distance(row["parameters"], item["parameters"], feature_names, ranges) for item in selected]
            diversity = min(distances) if distances else 0.0
            score = float(row["base_acquisition"]) + diversity_weight * diversity
            reranked.append((score, row, diversity))
        if not reranked:
            break
        score, best, diversity = max(reranked, key=lambda item: item[0])
        selected.append({**best, "batch_score": score, "diversity_bonus": diversity})
        family = str(best.get(family_key, "unspecified"))
        family_counts[family] = family_counts.get(family, 0) + 1
        remaining = [row for row in remaining if row["candidate_id"] != best["candidate_id"]]
    return {"strategy": strategy, "direction": direction, "best_observed": best_observed,
            "selected": selected, "rejected": rejected,
            "unselected_feasible_count": len(scored) - len(selected),
            "selection_policy": {"batch_size": batch_size, "max_per_family": max_per_family,
                                 "diversity_weight": diversity_weight, "cost_exponent": cost_exponent},
            "scientist_review_required": True, "execution_authorized": False,
            "warning": "Predicted means and uncertainty must be calibrated and applicable before interpreting acquisition scores scientifically."}


def pareto_front(records: list[dict], objectives: list[dict]) -> list[dict]:
    if not objectives:
        raise ValueError("At least one objective is required")
    for objective in objectives:
        if objective.get("direction") not in {"maximize", "minimize"}:
            raise ValueError("Each objective direction must be maximize or minimize")
        if not objective.get("property"):
            raise ValueError("Each objective requires a property")
    def dominates(a: dict, b: dict) -> bool:
        weak, strict = True, False
        for item in objectives:
            key, direction = item["property"], item["direction"]
            x, y = float(a[key]), float(b[key])
            if direction == "maximize":
                weak &= x >= y
                strict |= x > y
            else:
                weak &= x <= y
                strict |= x < y
        return weak and strict
    return [row for row in records if not any(other is not row and dominates(other, row) for other in records)]
