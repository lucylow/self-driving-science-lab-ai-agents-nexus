"""Illustrative low-order digital-twin models for method development only.

The equations are deliberately small teaching models. They are not validated battery,
reactor, material, or instrument simulators and must not be used for operating decisions.
"""
from __future__ import annotations
from math import exp, isfinite


def _positive(name: str, value: float, *, allow_zero: bool = False) -> float:
    number = float(value)
    if not isfinite(number) or (number < 0 if allow_zero else number <= 0):
        rule = "non-negative" if allow_zero else "positive"
        raise ValueError(f"{name} must be finite and {rule}")
    return number


def simulate_lumped_thermal_response(*, ambient_temperature_k: float, initial_temperature_k: float,
                                     thermal_resistance_k_per_w: float, thermal_capacitance_j_per_k: float,
                                     power_w: float, duration_seconds: float, time_step_seconds: float) -> dict:
    ambient = _positive("ambient_temperature_k", ambient_temperature_k)
    temp = _positive("initial_temperature_k", initial_temperature_k)
    resistance = _positive("thermal_resistance_k_per_w", thermal_resistance_k_per_w)
    capacitance = _positive("thermal_capacitance_j_per_k", thermal_capacitance_j_per_k)
    power = _positive("power_w", power_w, allow_zero=True)
    duration = _positive("duration_seconds", duration_seconds)
    step = _positive("time_step_seconds", time_step_seconds)
    if step > duration or step / (resistance * capacitance) > .25:
        raise ValueError("Time step is too large for this explicit lumped model")
    points = []
    time = 0.0
    while time <= duration + 1e-9:
        points.append({"time_s": round(time, 6), "temperature_k": temp})
        loss = (temp - ambient) / resistance
        temp += step * (power - loss) / capacitance
        time += step
        if len(points) > 200000:
            raise ValueError("Requested simulation exceeds point limit")
    return {"model": "single_node_lumped_thermal", "points": points,
            "final_temperature_k": temp, "evidence_type": "synthetic_simulation_output",
            "synthetic": True, "physical_control_authorized": False,
            "assumptions": ["single uniform temperature state", "constant power", "constant thermal resistance and capacitance"],
            "limitations": ["No spatial gradients", "No phase transitions", "No calibrated equipment parameters"]}


def simulate_first_order_kinetics(*, initial_concentration: float, rate_constant_per_s: float,
                                  duration_seconds: float, time_step_seconds: float) -> dict:
    initial = _positive("initial_concentration", initial_concentration, allow_zero=True)
    rate = _positive("rate_constant_per_s", rate_constant_per_s, allow_zero=True)
    duration = _positive("duration_seconds", duration_seconds)
    step = _positive("time_step_seconds", time_step_seconds)
    if step > duration or rate * step > .25:
        raise ValueError("Time step is too large for stable explicit integration")
    concentration, time, points = initial, 0.0, []
    while time <= duration + 1e-9:
        points.append({"time_s": round(time, 6), "concentration": concentration,
                       "conversion_fraction": 1 - concentration / initial if initial else 0.0})
        concentration = max(0.0, concentration - step * rate * concentration)
        time += step
        if len(points) > 200000:
            raise ValueError("Requested simulation exceeds point limit")
    return {"model": "first_order_decay_euler", "points": points,
            "final_concentration": concentration, "evidence_type": "synthetic_simulation_output",
            "synthetic": True, "physical_control_authorized": False,
            "assumptions": ["single first-order pathway", "constant rate coefficient"],
            "limitations": ["No competing reactions", "No transport limitation", "No temperature coupling"]}


def simulate_simple_battery_discharge(*, capacity_ah: float, initial_soc: float,
                                      current_a: float, internal_resistance_ohm: float,
                                      nominal_voltage_v: float, duration_seconds: float,
                                      time_step_seconds: float) -> dict:
    capacity = _positive("capacity_ah", capacity_ah)
    soc = float(initial_soc)
    if not 0 <= soc <= 1:
        raise ValueError("initial_soc must be in [0,1]")
    current = _positive("current_a", current_a, allow_zero=True)
    resistance = _positive("internal_resistance_ohm", internal_resistance_ohm, allow_zero=True)
    nominal = _positive("nominal_voltage_v", nominal_voltage_v)
    duration = _positive("duration_seconds", duration_seconds)
    step = _positive("time_step_seconds", time_step_seconds)
    if step > duration:
        raise ValueError("time step cannot exceed duration")
    time, points = 0.0, []
    while time <= duration + 1e-9:
        voltage = max(0.0, nominal * (.9 + .1 * soc) - current * resistance)
        points.append({"time_s": round(time, 6), "soc_fraction": soc,
                       "terminal_voltage_v": voltage, "current_a": current})
        soc = max(0.0, soc - current * (step / 3600.0) / capacity)
        time += step
        if len(points) > 200000:
            raise ValueError("Requested simulation exceeds point limit")
        if soc <= 0:
            break
    return {"model": "idealized_soc_and_ohmic_drop", "points": points,
            "final_soc_fraction": soc, "evidence_type": "synthetic_simulation_output",
            "synthetic": True, "physical_control_authorized": False,
            "assumptions": ["constant discharge current", "fixed capacity", "linear open-circuit voltage approximation"],
            "limitations": ["Not an electrochemical model", "No temperature, aging, hysteresis, or diffusion effects", "Not suitable for battery safety or BMS use"]}


def simulate_cstr_concentration(*, feed_concentration: float, initial_concentration: float,
                                flow_rate_l_per_s: float, volume_l: float,
                                first_order_rate_per_s: float, duration_seconds: float,
                                time_step_seconds: float) -> dict:
    feed = _positive("feed_concentration", feed_concentration, allow_zero=True)
    concentration = _positive("initial_concentration", initial_concentration, allow_zero=True)
    flow = _positive("flow_rate_l_per_s", flow_rate_l_per_s)
    volume = _positive("volume_l", volume_l)
    rate = _positive("first_order_rate_per_s", first_order_rate_per_s, allow_zero=True)
    duration = _positive("duration_seconds", duration_seconds)
    step = _positive("time_step_seconds", time_step_seconds)
    turnover = flow / volume
    if step > duration or step * (turnover + rate) > .25:
        raise ValueError("Time step is too large for stable explicit integration")
    points, time = [], 0.0
    while time <= duration + 1e-9:
        points.append({"time_s": round(time, 6), "concentration": concentration})
        derivative = turnover * (feed - concentration) - rate * concentration
        concentration = max(0.0, concentration + step * derivative)
        time += step
        if len(points) > 200000:
            raise ValueError("Requested simulation exceeds point limit")
    return {"model": "ideal_cstr_first_order", "points": points,
            "final_concentration": concentration, "evidence_type": "synthetic_simulation_output",
            "synthetic": True, "physical_control_authorized": False,
            "assumptions": ["perfect mixing", "constant volume and flow", "isothermal first-order reaction"],
            "limitations": ["No heat balance", "No nonideal hydrodynamics", "No coupled multiphase effects"]}


def arrhenius_rate_ratio(*, activation_energy_j_mol: float, temperature_reference_k: float,
                         temperature_target_k: float, gas_constant_j_mol_k: float = 8.314462618) -> dict:
    ea = _positive("activation_energy_j_mol", activation_energy_j_mol, allow_zero=True)
    t1 = _positive("temperature_reference_k", temperature_reference_k)
    t2 = _positive("temperature_target_k", temperature_target_k)
    gas = _positive("gas_constant_j_mol_k", gas_constant_j_mol_k)
    ratio = exp(-ea / gas * (1 / t2 - 1 / t1))
    return {"rate_ratio_target_to_reference": ratio, "equation": "k2/k1 = exp[-Ea/R (1/T2 - 1/T1)]",
            "evidence_type": "computational_result", "assumptions": ["same mechanism", "single Arrhenius activation energy"],
            "limitations": ["No phase or mechanism transition model"], "physical_control_authorized": False}
