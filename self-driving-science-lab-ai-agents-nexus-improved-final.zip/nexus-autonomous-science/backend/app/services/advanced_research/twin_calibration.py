"""Auditable weighted affine calibration for digital-twin outputs.

Calibration data must be paired with trusted observations from the declared domain.
A fit is a research artifact, never a physical safety certification.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from hashlib import sha256
from math import isfinite, sqrt
from statistics import mean, median
from typing import Any, Sequence
import json
from .linalg import inverse, solve


def _finite(value: Any, field: str) -> float:
    number = float(value)
    if not isfinite(number):
        raise ValueError(f"{field} must be finite")
    return number


def _quantile(values: Sequence[float], probability: float) -> float:
    if not values:
        raise ValueError("Cannot calculate a quantile from an empty sequence")
    if not 0 <= probability <= 1:
        raise ValueError("Quantile probability must be between 0 and 1")
    ordered = sorted(float(v) for v in values)
    position = (len(ordered) - 1) * probability
    lo = int(position)
    hi = min(len(ordered) - 1, lo + 1)
    fraction = position - lo
    return ordered[lo] * (1 - fraction) + ordered[hi] * fraction


def _design_row(record: dict[str, Any], feature_names: Sequence[str]) -> list[float]:
    features = record.get("features")
    if not isinstance(features, dict):
        raise ValueError("Every calibration record requires a features object")
    return [1.0] + [_finite(features.get(name), f"features.{name}") for name in feature_names]


def _weighted_normal_equations(rows: list[list[float]], targets: list[float], weights: list[float], ridge: float):
    width = len(rows[0])
    gram = [[0.0] * width for _ in range(width)]
    rhs = [0.0] * width
    for row, target, weight in zip(rows, targets, weights):
        for i in range(width):
            rhs[i] += weight * row[i] * target
            for j in range(width):
                gram[i][j] += weight * row[i] * row[j]
    # Do not penalize the intercept.
    for i in range(1, width):
        gram[i][i] += ridge
    return gram, rhs


def _metrics(actual: Sequence[float], predicted: Sequence[float]) -> dict[str, float | int | None]:
    residual = [float(a) - float(p) for a, p in zip(actual, predicted)]
    mae = mean(abs(v) for v in residual)
    rmse = sqrt(mean(v * v for v in residual))
    bias = mean(residual)
    center = mean(actual)
    total = sum((value - center) ** 2 for value in actual)
    r2 = 1.0 - sum(v * v for v in residual) / total if total > 0 else None
    return {"n": len(actual), "mae": mae, "rmse": rmse, "bias": bias, "r2": r2,
            "residual_median": median(residual), "residual_p95_abs": _quantile([abs(v) for v in residual], .95)}


def fit_affine_calibrator(records: list[dict[str, Any]], *, feature_names: list[str],
                          target_key: str = "observed", uncertainty_key: str = "measurement_sigma",
                          ridge: float = 1e-8, model_id: str = "unspecified-twin",
                          model_version: str = "0.1.0", domain: str = "inorganic_materials",
                          operating_ranges: dict[str, tuple[float, float]] | None = None) -> dict[str, Any]:
    """Fit y_observed = beta0 + sum(beta_i * twin_feature_i), using WLS.

    The measurement sigma is interpreted as a standard deviation and the weight is
    inverse variance. Missing sigma defaults to equal weight, not zero uncertainty.
    """
    if not feature_names or len(set(feature_names)) != len(feature_names):
        raise ValueError("feature_names must be non-empty and unique")
    if len(records) < len(feature_names) + 3:
        raise ValueError("Calibration requires at least feature_count + 3 paired records")
    if ridge < 0 or not isfinite(ridge):
        raise ValueError("ridge must be finite and non-negative")
    rows, targets, weights, groups = [], [], [], []
    for index, record in enumerate(records):
        rows.append(_design_row(record, feature_names))
        targets.append(_finite(record.get(target_key), target_key))
        sigma = record.get(uncertainty_key)
        weight = 1.0 if sigma is None else 1.0 / max(_finite(sigma, uncertainty_key) ** 2, 1e-18)
        weights.append(weight)
        groups.append(str(record.get("group_id") or f"row-{index}"))
    gram, rhs = _weighted_normal_equations(rows, targets, weights, ridge)
    coefficients = solve(gram, rhs)
    predicted = [sum(a * b for a, b in zip(row, coefficients)) for row in rows]
    residuals = [target - pred for target, pred in zip(targets, predicted)]
    dof = max(1, len(records) - len(coefficients))
    residual_variance = sum(weight * residual ** 2 for weight, residual in zip(weights, residuals)) / dof
    covariance = [[value * residual_variance for value in row] for row in inverse(gram)]
    standard_errors = [sqrt(max(0.0, covariance[i][i])) for i in range(len(coefficients))]
    feature_ranges = {name: [min(row[i + 1] for row in rows), max(row[i + 1] for row in rows)]
                      for i, name in enumerate(feature_names)}
    groups_sorted = sorted(set(groups))
    record_digest = sha256(json.dumps(records, sort_keys=True, default=str, separators=(",", ":")).encode()).hexdigest()
    return {
        "calibrator_id": f"CAL-{record_digest[:12]}", "model_id": model_id,
        "model_version": model_version, "domain": domain, "feature_names": feature_names,
        "coefficients": {"intercept": coefficients[0], **{name: coefficients[i + 1] for i, name in enumerate(feature_names)}},
        "coefficient_standard_errors": {"intercept": standard_errors[0], **{name: standard_errors[i + 1] for i, name in enumerate(feature_names)}},
        "coefficient_covariance": covariance, "training_metrics": _metrics(targets, predicted),
        "residual_standard_deviation": sqrt(max(0.0, residual_variance)),
        "feature_ranges": feature_ranges, "operating_ranges": operating_ranges or feature_ranges,
        "training_record_count": len(records), "training_group_count": len(groups_sorted),
        "training_group_ids_hash": sha256("|".join(groups_sorted).encode()).hexdigest(),
        "training_data_sha256": record_digest, "ridge_penalty": ridge,
        "fitted_at": datetime.now(timezone.utc).isoformat(), "status": "research_calibration_candidate",
        "physical_control_authorized": False,
        "limitations": ["Requires an independent held-out validation set.",
                        "Affine correction may not capture nonlinear model error.",
                        "Feature ranges are not proof of safe operation.",
                        "Fit quality is not physical system qualification."],
    }


def predict_calibrated(calibrator: dict[str, Any], features: dict[str, float], *,
                       include_parameter_uncertainty: bool = True) -> dict[str, Any]:
    expected = calibrator.get("feature_names", [])
    missing = [name for name in expected if name not in features]
    if missing:
        raise ValueError(f"Missing calibration features: {', '.join(missing)}")
    vector = [1.0] + [_finite(features[name], name) for name in expected]
    coeff = calibrator.get("coefficients", {})
    value = float(coeff.get("intercept", 0.0)) + sum(float(coeff[name]) * float(features[name]) for name in expected)
    outside = [name for name in expected if not calibrator.get("feature_ranges", {}).get(name, [float("-inf"), float("inf" )])[0]
               <= float(features[name]) <= calibrator.get("feature_ranges", {}).get(name, [float("-inf"), float("inf")])[1]]
    variance = float(calibrator.get("residual_standard_deviation", 0.0)) ** 2
    if include_parameter_uncertainty and calibrator.get("coefficient_covariance"):
        covariance = calibrator["coefficient_covariance"]
        variance += sum(vector[i] * covariance[i][j] * vector[j]
                        for i in range(len(vector)) for j in range(len(vector)))
    return {"calibrated_prediction": value, "uncertainty_standard_deviation": sqrt(max(0.0, variance)),
            "outside_calibration_feature_ranges": outside, "applicability": "review_required" if outside else "inside_training_feature_ranges",
            "evidence_type": "model_prediction", "synthetic": bool(calibrator.get("synthetic_training_data", False)),
            "physical_control_authorized": False}


def group_holdout_split(records: list[dict[str, Any]], *, group_key: str = "group_id", holdout_fraction: float = .2,
                        seed: int = 17) -> dict[str, list[dict[str, Any]]]:
    """Deterministic group holdout; no group is split across train and test."""
    if not 0.05 <= holdout_fraction <= 0.5:
        raise ValueError("holdout_fraction must be in [0.05, 0.5]")
    groups = sorted({str(row.get(group_key) or f"row-{i}") for i, row in enumerate(records)})
    if len(groups) < 3:
        raise ValueError("At least three independent groups are required for a group holdout")
    # Hash ordering is deterministic and avoids relying on input order.
    ordered = sorted(groups, key=lambda value: sha256(f"{seed}:{value}".encode()).hexdigest())
    count = max(1, min(len(groups) - 1, round(len(groups) * holdout_fraction)))
    test_groups = set(ordered[:count])
    train, test = [], []
    for index, row in enumerate(records):
        group = str(row.get(group_key) or f"row-{index}")
        (test if group in test_groups else train).append(row)
    if not train or not test:
        raise ValueError("Group split produced an empty partition")
    return {"train": train, "test": test, "train_groups": sorted(set(str(r.get(group_key)) for r in train)),
            "test_groups": sorted(test_groups), "group_overlap": False,
            "warning": "Group holdout reduces leakage risk but does not eliminate temporal or laboratory confounding."}


def validate_calibrator(calibrator: dict[str, Any], records: list[dict[str, Any]], *,
                        validation_domain: str, minimum_rows: int = 5) -> dict[str, Any]:
    if validation_domain != calibrator.get("domain"):
        return {"valid_for_domain": False, "status": "blocked_domain_mismatch", "metrics": None,
                "physical_control_authorized": False}
    if len(records) < minimum_rows:
        raise ValueError(f"At least {minimum_rows} independent validation rows are required")
    actual, predicted, outside = [], [], 0
    for record in records:
        actual.append(_finite(record.get("observed"), "observed"))
        result = predict_calibrated(calibrator, record.get("features", {}))
        predicted.append(result["calibrated_prediction"])
        outside += bool(result["outside_calibration_feature_ranges"])
    metrics = _metrics(actual, predicted)
    metrics["outside_feature_range_count"] = outside
    return {"valid_for_domain": True, "status": "validated_for_research_review" if outside == 0 else "hold_due_to_extrapolation",
            "metrics": metrics, "validation_rows": len(records), "outside_feature_range_count": outside,
            "physical_control_authorized": False,
            "interpretation": "Validation is specific to this domain, data source, and operating envelope."}
