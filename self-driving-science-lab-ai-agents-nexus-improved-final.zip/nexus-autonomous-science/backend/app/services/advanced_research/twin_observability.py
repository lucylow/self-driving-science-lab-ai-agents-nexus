"""Digital-twin operational observability and evidence-envelope assessment."""
from __future__ import annotations
from datetime import datetime, timezone
from math import isfinite


def assess_twin_health(*, model_id: str, model_version: str, domain: str,
                       calibration_date: str | None, last_validation_date: str | None,
                       validation_metrics: dict | None, operating_ranges: dict,
                       current_state: dict, known_limitations: list[str],
                       max_calibration_age_days: int = 180,
                       minimum_validation_rows: int = 20) -> dict:
    now = datetime.now(timezone.utc)
    issues = []
    def parse_date(value: str | None):
        if not value: return None
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)
    calibration_age = None
    if calibration_date:
        calibration_age = max(0, (now - parse_date(calibration_date)).days)
        if calibration_age > max_calibration_age_days: issues.append("calibration_artifact_stale")
    else:
        issues.append("calibration_date_missing")
    if not last_validation_date:
        issues.append("validation_date_missing")
    rows = int((validation_metrics or {}).get("n", 0))
    if rows < minimum_validation_rows: issues.append("validation_sample_count_below_threshold")
    if not validation_metrics or validation_metrics.get("rmse") is None:
        issues.append("validation_metrics_missing")
    range_violations = []
    for name, bounds in operating_ranges.items():
        if name not in current_state:
            range_violations.append({"feature": name, "reason": "current_state_missing"})
            continue
        lower, upper = map(float, bounds)
        value = float(current_state[name])
        if not isfinite(value) or not lower <= value <= upper:
            range_violations.append({"feature": name, "value": value,
                                     "range": [lower, upper], "reason": "outside_declared_range"})
    if range_violations: issues.append("operating_range_violation")
    if not known_limitations: issues.append("known_limitations_not_documented")
    return {"model_id": model_id, "model_version": model_version, "domain": domain,
            "calibration_age_days": calibration_age, "validation_rows": rows,
            "operating_range_violations": range_violations,
            "health_status": "review_required" if issues else "research_monitoring_only",
            "issues": issues, "known_limitations": known_limitations,
            "physical_control_authorized": False,
            "meaning": "Health status is an evidence-readiness diagnostic and not a hardware safety status."}


def compare_twin_sync(*, local_timestamp: str, cloud_timestamp: str,
                      maximum_lag_seconds: float = 5.0) -> dict:
    local = datetime.fromisoformat(local_timestamp.replace("Z", "+00:00"))
    cloud = datetime.fromisoformat(cloud_timestamp.replace("Z", "+00:00"))
    if local.tzinfo is None or cloud.tzinfo is None:
        raise ValueError("Synchronization timestamps must be timezone-aware")
    lag = abs((local - cloud).total_seconds())
    return {"absolute_clock_difference_seconds": lag,
            "within_declared_tolerance": lag <= maximum_lag_seconds,
            "status": "synchronized_within_tolerance" if lag <= maximum_lag_seconds else "sync_review_required",
            "maximum_lag_seconds": maximum_lag_seconds,
            "note": "Clock agreement does not establish sensor acquisition simultaneity or causal alignment."}
