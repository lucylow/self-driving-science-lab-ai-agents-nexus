"""Distribution propagation and split-conformal residual calibration."""
from __future__ import annotations
from math import isfinite, sqrt
from random import Random
from statistics import mean
from typing import Callable, Sequence


def _quantile(values: Sequence[float], p: float) -> float:
    if not values or not 0 <= p <= 1:
        raise ValueError("Non-empty values and p in [0, 1] are required")
    ordered = sorted(float(x) for x in values)
    position = (len(ordered) - 1) * p
    lower = int(position)
    upper = min(len(ordered) - 1, lower + 1)
    frac = position - lower
    return ordered[lower] * (1 - frac) + ordered[upper] * frac


def cholesky(matrix: Sequence[Sequence[float]], *, tolerance: float = 1e-10) -> list[list[float]]:
    n = len(matrix)
    if n == 0 or any(len(row) != n for row in matrix):
        raise ValueError("Covariance matrix must be non-empty and square")
    lower = [[0.0] * n for _ in range(n)]
    for i in range(n):
        for j in range(i + 1):
            if abs(float(matrix[i][j]) - float(matrix[j][i])) > tolerance:
                raise ValueError("Covariance matrix must be symmetric")
            value = float(matrix[i][j]) - sum(lower[i][k] * lower[j][k] for k in range(j))
            if i == j:
                if value < -tolerance:
                    raise ValueError("Covariance matrix must be positive semidefinite")
                lower[i][j] = sqrt(max(0.0, value))
            elif lower[j][j] > tolerance:
                lower[i][j] = value / lower[j][j]
            elif abs(value) > tolerance:
                raise ValueError("Covariance matrix is singular and inconsistent")
    return lower


def propagate_monte_carlo(*, means: dict[str, float], standard_deviations: dict[str, float],
                          evaluator: Callable[[dict[str, float]], float], samples: int = 5000,
                          correlation: list[list[float]] | None = None, seed: int = 11,
                          quantiles: tuple[float, float] = (.025, .975)) -> dict:
    names = list(means)
    if not names or set(names) != set(standard_deviations):
        raise ValueError("means and standard_deviations must have identical non-empty keys")
    if samples < 100 or samples > 500000:
        raise ValueError("samples must be between 100 and 500000")
    mu = [float(means[name]) for name in names]
    sigma = [float(standard_deviations[name]) for name in names]
    if any(not isfinite(v) for v in mu) or any(not isfinite(v) or v < 0 for v in sigma):
        raise ValueError("Input means must be finite and standard deviations finite/non-negative")
    if not 0 <= quantiles[0] < quantiles[1] <= 1:
        raise ValueError("quantiles must be increasing probabilities in [0, 1]")
    if correlation is None:
        correlation = [[1.0 if i == j else 0.0 for j in range(len(names))] for i in range(len(names))]
    if len(correlation) != len(names):
        raise ValueError("Correlation dimensions do not match input variables")
    for i in range(len(names)):
        if abs(float(correlation[i][i]) - 1.0) > 1e-8:
            raise ValueError("Correlation diagonal must equal one")
        for j in range(len(names)):
            if abs(float(correlation[i][j])) > 1.0:
                raise ValueError("Correlation values must lie in [-1, 1]")
    lower = cholesky(correlation)
    rng = Random(seed)
    outputs: list[float] = []
    for _ in range(samples):
        z = [rng.gauss(0.0, 1.0) for _ in names]
        correlated = [sum(lower[i][j] * z[j] for j in range(i + 1)) for i in range(len(names))]
        draw = {name: mu[i] + sigma[i] * correlated[i] for i, name in enumerate(names)}
        value = float(evaluator(draw))
        if not isfinite(value):
            raise ValueError("Evaluator returned a non-finite result")
        outputs.append(value)
    outputs.sort()
    center = mean(outputs)
    variance = sum((value - center) ** 2 for value in outputs) / max(1, len(outputs) - 1)
    return {"method": "monte_carlo", "sample_count": samples, "seed": seed,
            "mean": center, "standard_deviation": sqrt(variance),
            "median": _quantile(outputs, .5), "lower_quantile": _quantile(outputs, quantiles[0]),
            "upper_quantile": _quantile(outputs, quantiles[1]),
            "quantiles": list(quantiles), "input_order": names,
            "correlation_used": correlation,
            "interpretation": "Propagated distribution under the supplied input distributions and evaluator; not a calibrated predictive interval.",
            "evidence_type": "computational_result", "physical_control_authorized": False}


def split_conformal_radius(actual: Sequence[float], predicted: Sequence[float], *, alpha: float = .1,
                            group_ids: Sequence[str] | None = None) -> dict:
    if len(actual) != len(predicted) or len(actual) < 5:
        raise ValueError("At least five paired calibration residuals are required")
    if not 0 < alpha < 1:
        raise ValueError("alpha must be in (0, 1)")
    if group_ids is not None and len(group_ids) != len(actual):
        raise ValueError("group_ids must align with actual and predicted")
    if group_ids is not None and len(set(group_ids)) < 3:
        raise ValueError("At least three groups are required when group_ids are supplied")
    residuals = sorted(abs(float(a) - float(p)) for a, p in zip(actual, predicted))
    # Finite-sample conformal order statistic, clipped at n.
    rank = min(len(residuals), int((len(residuals) + 1) * (1 - alpha) + .999999))
    radius = residuals[rank - 1]
    return {"method": "split_conformal_absolute_residual", "alpha": alpha,
            "nominal_coverage": 1 - alpha, "calibration_count": len(residuals),
            "order_statistic_rank": rank, "radius": radius,
            "group_count": len(set(group_ids)) if group_ids is not None else None,
            "assumption": "Exchangeability of calibration and future examples is required; group identifiers alone do not prove exchangeability.",
            "status": "calibration_artifact_not_model_certificate"}


def apply_conformal_interval(predictions: Sequence[float], calibration: dict) -> list[dict]:
    radius = float(calibration.get("radius", -1))
    if radius < 0 or not isfinite(radius):
        raise ValueError("A valid non-negative conformal radius is required")
    return [{"prediction": float(value), "lower": float(value) - radius,
             "upper": float(value) + radius, "nominal_coverage": calibration.get("nominal_coverage"),
             "interval_type": "split_conformal"} for value in predictions]


def decompose_uncertainty(*, aleatoric: float, epistemic: float, calibration: float = 0.0,
                          distribution_shift: float = 0.0) -> dict:
    components = {"aleatoric": aleatoric, "epistemic": epistemic,
                  "calibration": calibration, "distribution_shift": distribution_shift}
    if any(not isfinite(float(v)) or float(v) < 0 for v in components.values()):
        raise ValueError("Uncertainty components must be finite and non-negative")
    total = sqrt(sum(float(value) ** 2 for value in components.values()))
    return {"components": components, "combined_root_sum_squares": total,
            "dominant_component": max(components, key=components.get),
            "interpretation": "Diagnostic decomposition; components may be dependent and the combination is not automatically probabilistically calibrated."}
