"""Risk-aware candidate comparison using prediction intervals and completeness gates."""
from __future__ import annotations
from math import isfinite


def robust_candidate_ranking(candidates: list[dict], *, objective: str,
                             direction: str = "maximize", risk_aversion: float = 1.0,
                             minimum_interval_coverage: float | None = None) -> dict:
    if not candidates or direction not in {"maximize", "minimize"} or risk_aversion < 0:
        raise ValueError("Candidates, valid direction and non-negative risk_aversion are required")
    ranked = []
    for row in candidates:
        if objective not in row or "standard_deviation" not in row:
            raise ValueError(f"Candidate {row.get('candidate_id')} lacks objective or uncertainty")
        center, sigma = float(row[objective]), float(row["standard_deviation"])
        if not isfinite(center) or not isfinite(sigma) or sigma < 0:
            raise ValueError("Candidate means and standard deviations must be finite; sigma non-negative")
        if minimum_interval_coverage is not None:
            coverage = row.get("interval_coverage")
            if coverage is None or float(coverage) < minimum_interval_coverage:
                ranked.append({**row, "eligible": False, "exclusion_reason": "interval_coverage_below_threshold"})
                continue
        conservative = center - risk_aversion * sigma if direction == "maximize" else center + risk_aversion * sigma
        utility = conservative if direction == "maximize" else -conservative
        ranked.append({**row, "conservative_estimate": conservative,
                       "risk_adjusted_utility": utility, "eligible": True})
    eligible = [row for row in ranked if row.get("eligible")]
    eligible.sort(key=lambda row: row["risk_adjusted_utility"], reverse=True)
    for index, row in enumerate(eligible, start=1):
        row["rank"] = index
    return {"objective": objective, "direction": direction, "risk_aversion": risk_aversion,
            "ranked_candidates": ranked,
            "top_candidate_id": eligible[0].get("candidate_id") if eligible else None,
            "recommendation": "scientist_review" if eligible else "insufficient_eligible_candidates",
            "scientist_review_required": True,
            "warning": "Risk-adjusted ranking is preference-dependent and inherits the calibration limitations of each prediction."}


def interval_dominance(left: dict, right: dict, *, objective: str,
                       direction: str = "maximize") -> dict:
    if direction not in {"maximize", "minimize"}:
        raise ValueError("direction must be maximize or minimize")
    for row in [left, right]:
        if objective not in row or "lower" not in row or "upper" not in row:
            raise ValueError("Both candidates require objective, lower and upper interval bounds")
        if float(row["lower"]) > float(row["upper"]):
            raise ValueError("Interval lower bound cannot exceed upper bound")
    if direction == "maximize":
        left_dominates = float(left["lower"]) > float(right["upper"])
        right_dominates = float(right["lower"]) > float(left["upper"])
    else:
        left_dominates = float(left["upper"]) < float(right["lower"])
        right_dominates = float(right["upper"]) < float(left["lower"])
    return {"left_dominates": left_dominates, "right_dominates": right_dominates,
            "overlap_or_indeterminate": not left_dominates and not right_dominates,
            "interpretation": "Non-overlap is a simple interval comparison, not a statistical significance test."}
