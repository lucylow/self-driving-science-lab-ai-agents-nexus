"""Decision-focused value-of-information approximations for research planning."""
from __future__ import annotations
from math import isfinite, sqrt


def expected_value_of_sample_information(*, current_best_utility: float,
                                          posterior_best_utilities: list[float],
                                          experiment_cost: float,
                                          delay_cost: float = 0.0,
                                          risk_penalty: float = 0.0) -> dict:
    if not posterior_best_utilities:
        raise ValueError("posterior_best_utilities must be non-empty")
    values = [float(value) for value in posterior_best_utilities]
    numbers = [float(current_best_utility), float(experiment_cost), float(delay_cost), float(risk_penalty), *values]
    if any(not isfinite(value) for value in numbers) or min(experiment_cost, delay_cost, risk_penalty) < 0:
        raise ValueError("Utilities and costs must be finite; costs and risk penalty non-negative")
    expected_best_after = sum(max(current_best_utility, value) for value in values) / len(values)
    gross = max(0.0, expected_best_after - current_best_utility)
    net = gross - experiment_cost - delay_cost - risk_penalty
    return {"current_best_utility": current_best_utility,
            "expected_best_utility_after_information": expected_best_after,
            "gross_expected_value_of_information": gross,
            "experiment_cost": experiment_cost, "delay_cost": delay_cost,
            "risk_penalty": risk_penalty, "net_expected_value": net,
            "recommendation": "consider_experiment" if net > 0 else "defer_or_reformulate",
            "assumption": "posterior_best_utilities must be defensible samples from a calibrated decision model; this approximation is not a measured economic outcome."}


def rank_information_actions(actions: list[dict]) -> list[dict]:
    ranked = []
    for action in actions:
        result = expected_value_of_sample_information(
            current_best_utility=float(action["current_best_utility"]),
            posterior_best_utilities=list(action["posterior_best_utilities"]),
            experiment_cost=float(action.get("experiment_cost", 0)),
            delay_cost=float(action.get("delay_cost", 0)),
            risk_penalty=float(action.get("risk_penalty", 0)))
        ranked.append({**action, **result})
    return sorted(ranked, key=lambda item: item["net_expected_value"], reverse=True)


def stopping_decision(*, remaining_budget: float, minimum_budget: float,
                      best_recent_improvement: float, improvement_tolerance: float,
                      uncertainty_reduction_possible: bool, unresolved_hard_constraints: list[str],
                      minimum_evidence_grade_met: bool) -> dict:
    if min(remaining_budget, minimum_budget, best_recent_improvement, improvement_tolerance) < 0:
        raise ValueError("Budget and improvement values must be non-negative")
    reasons = []
    if remaining_budget < minimum_budget: reasons.append("budget_below_minimum_next_experiment_cost")
    if best_recent_improvement <= improvement_tolerance and not uncertainty_reduction_possible:
        reasons.append("no_material_improvement_or_information_gain")
    if unresolved_hard_constraints: reasons.append("unresolved_hard_constraints")
    if not minimum_evidence_grade_met: reasons.append("minimum_evidence_grade_not_met")
    stop = bool(reasons)
    return {"decision": "pause_for_scientist_review" if stop else "continue_candidate_generation",
            "reasons": reasons, "is_automatic_terminal_decision": False,
            "scientist_review_required": True,
            "warning": "A stopping rule is a workflow recommendation, not an instruction to terminate a physical process."}
