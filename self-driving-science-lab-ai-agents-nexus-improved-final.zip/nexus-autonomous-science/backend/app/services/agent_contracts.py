"""Typed contracts shared by agents regardless of implementation vendor."""

from datetime import datetime, timezone
from typing import Any, Literal
from pydantic import BaseModel, Field, ConfigDict


class AgentCapabilityCard(BaseModel):
    model_config = ConfigDict(extra="forbid")
    agent_id: str
    name: str
    version: str = "0.1.0"
    purpose: str
    supported_domains: list[str]
    inputs: list[str]
    outputs: list[str]
    permissions: Literal["propose_only", "analyze", "simulate"] = "propose_only"
    requires_human_review: bool = True


class AgentTask(BaseModel):
    task_id: str
    agent_id: str
    objective_id: str | None = None
    experiment_id: str | None = None
    task_type: str
    input_payload: dict[str, Any] = Field(default_factory=dict)
    deadline_seconds: int = Field(default=60, ge=1, le=3600)


class AgentFinding(BaseModel):
    finding_id: str
    agent_id: str
    task_id: str
    finding_type: str
    summary: str
    evidence_refs: list[str] = Field(default_factory=list)
    confidence: float = Field(ge=0.0, le=1.0)
    uncertainty: dict[str, Any] = Field(default_factory=dict)
    assumptions: list[str] = Field(default_factory=list)
    limitations: list[str] = Field(default_factory=list)
    requires_scientist_review: bool = True
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class AgentFailure(BaseModel):
    task_id: str
    agent_id: str
    failure_code: str
    retryable: bool = False
    detail: str
    recovery_hint: str | None = None
