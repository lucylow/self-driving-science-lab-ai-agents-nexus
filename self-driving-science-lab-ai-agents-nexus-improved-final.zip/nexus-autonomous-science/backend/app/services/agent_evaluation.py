"""Multidimensional agent evaluation contracts for SDL0 benchmark workflows."""

from dataclasses import dataclass, asdict
from math import isfinite
from typing import Any

METRIC_DEFINITIONS = {
    "scientific_correctness": "Agreement with domain-reviewed scientific reference answers.",
    "constraint_compliance": "Rate of satisfying explicit task and domain constraints.",
    "calibration_quality": "Agreement between declared uncertainty and held-out outcomes.",
    "tool_call_reliability": "Successful, correctly scoped tool interactions.",
    "schema_compliance": "Outputs valid against the published response contract.",
    "evidence_attribution": "Claims linked to relevant source records and citations.",
    "reproducibility": "Equivalent results under a versioned replay protocol.",
    "human_correction_rate": "Fraction of outputs requiring a material human correction.",
    "failure_recovery": "Correct escalation or recovery behavior after injected faults.",
    "out_of_domain_detection": "Ability to recognize requests outside declared capabilities.",
}


@dataclass(frozen=True)
class AgentBenchmarkResult:
    agent_id: str
    benchmark_id: str
    sample_count: int
    metrics: dict[str, float]
    limitations: tuple[str, ...]
    promotion_recommendation: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def validate_metric_vector(metrics: dict[str, float]) -> list[str]:
    errors = []
    unknown = set(metrics) - set(METRIC_DEFINITIONS)
    if unknown:
        errors.append(f"Unknown metrics: {', '.join(sorted(unknown))}")
    for name, value in metrics.items():
        if not isinstance(value, (int, float)) or not isfinite(float(value)):
            errors.append(f"Metric {name} must be finite and numeric.")
        elif not 0.0 <= float(value) <= 1.0:
            errors.append(f"Metric {name} must be between 0 and 1.")
    return errors


def evaluate_agent(*, agent_id: str, benchmark_id: str, sample_count: int,
                    metrics: dict[str, float], minimum_samples: int = 30) -> AgentBenchmarkResult:
    errors = validate_metric_vector(metrics)
    if sample_count < 0:
        errors.append("sample_count cannot be negative.")
    if errors:
        raise ValueError(" ".join(errors))

    required = {"scientific_correctness", "constraint_compliance", "schema_compliance", "evidence_attribution", "out_of_domain_detection"}
    missing = sorted(required - set(metrics))
    limitations = []
    if missing:
        limitations.append("Required dimensions not evaluated: " + ", ".join(missing))
    if sample_count < minimum_samples:
        limitations.append(f"Benchmark sample count {sample_count} is below the minimum {minimum_samples}.")

    weak = [name for name, value in metrics.items() if value < 0.8]
    if missing or sample_count < minimum_samples or weak:
        recommendation = "hold_for_review"
    else:
        recommendation = "eligible_for_shadow_deployment_review"
    if weak:
        limitations.append("Metrics below the 0.80 review threshold: " + ", ".join(sorted(weak)))
    return AgentBenchmarkResult(
        agent_id=agent_id, benchmark_id=benchmark_id, sample_count=sample_count,
        metrics={key: float(value) for key, value in metrics.items()},
        limitations=tuple(limitations), promotion_recommendation=recommendation,
    )
