"""Multi-agent reliability primitives: task DAGs, retries, debate, and contract validation."""
