"""Evidence-weighted review aggregation that preserves dissent and abstentions."""
from __future__ import annotations
from typing import Any

VALID_DECISIONS = {"support", "challenge", "abstain", "request_more_evidence"}


def aggregate_scientific_reviews(reviews: list[dict[str, Any]], *,
                                 minimum_independent_reviewers: int = 2,
                                 require_domain_expert: bool = True) -> dict[str, Any]:
    if minimum_independent_reviewers < 1:
        raise ValueError("minimum independent reviewers must be positive")
    valid = []; issues = []
    for index, review in enumerate(reviews):
        decision = review.get("decision")
        reviewer = str(review.get("reviewer_id", "")).strip()
        evidence = list(dict.fromkeys(str(ref) for ref in review.get("evidence_refs", []) if str(ref).strip()))
        if decision not in VALID_DECISIONS:
            issues.append({"index": index, "code": "invalid_decision"}); continue
        if not reviewer:
            issues.append({"index": index, "code": "missing_reviewer"}); continue
        valid.append({**review, "reviewer_id": reviewer, "evidence_refs": evidence})
    unique_reviewers = {item["reviewer_id"] for item in valid}
    if len(unique_reviewers) != len(valid):
        issues.append({"code": "duplicate_reviewer", "message": "A reviewer may contribute only one vote to a decision."})
    if len(unique_reviewers) < minimum_independent_reviewers:
        issues.append({"code": "insufficient_independent_reviewers"})
    if require_domain_expert and not any(item.get("domain_expert") is True for item in valid):
        issues.append({"code": "domain_expert_review_missing"})
    counts = {decision: sum(item["decision"] == decision for item in valid) for decision in sorted(VALID_DECISIONS)}
    supports = [item for item in valid if item["decision"] == "support"]
    challenges = [item for item in valid if item["decision"] == "challenge"]
    abstentions = [item for item in valid if item["decision"] == "abstain"]
    requests = [item for item in valid if item["decision"] == "request_more_evidence"]
    independent_supporters = {item["reviewer_id"] for item in supports}
    independent_challengers = {item["reviewer_id"] for item in challenges}
    shared_evidence = set.intersection(*(set(item["evidence_refs"]) for item in valid)) if valid else set()
    if issues:
        outcome = "insufficient_review" if any(item["code"] in {"insufficient_independent_reviewers", "domain_expert_review_missing"} for item in issues) else "invalid_review_set"
    elif requests:
        outcome = "more_evidence_requested"
    elif supports and challenges:
        outcome = "contested"
    elif supports and not challenges and not abstentions:
        outcome = "reviewers_support"
    elif challenges and not supports and not abstentions:
        outcome = "reviewers_challenge"
    else:
        outcome = "inconclusive"
    return {"outcome": outcome, "review_count": len(valid), "reviewer_count": len(unique_reviewers),
            "decision_counts": counts, "supporting_reviewers": sorted(independent_supporters),
            "challenging_reviewers": sorted(independent_challengers),
            "abstaining_reviewers": sorted(item["reviewer_id"] for item in abstentions),
            "shared_evidence_refs": sorted(shared_evidence), "issues": issues,
            "dissent_preserved": bool(supports and challenges),
            "scientific_claim_status_changed": False,
            "note": "Review aggregation is an advisory summary; a scientist must adjudicate the claim and record rationale."}


def build_evidence_disagreement_matrix(reviews: list[dict[str, Any]]) -> dict[str, Any]:
    by_reviewer = {}
    all_refs = sorted({str(ref) for review in reviews for ref in review.get("evidence_refs", [])})
    for review in reviews:
        reviewer = str(review.get("reviewer_id", "unknown"))
        by_reviewer[reviewer] = {"decision": review.get("decision"),
                                 "evidence_refs": sorted(set(str(ref) for ref in review.get("evidence_refs", []))),
                                 "rationale": str(review.get("rationale", ""))}
    return {"evidence_refs": all_refs, "reviews_by_reviewer": by_reviewer,
            "agreement_fraction": (max((sum(item["decision"] == choice for item in by_reviewer.values()) for choice in VALID_DECISIONS), default=0) / len(by_reviewer)) if by_reviewer else None,
            "dissent_visible": len({item["decision"] for item in by_reviewer.values()}) > 1,
            "note": "Evidence overlap does not establish truth; evidence quality and context remain separately reviewable."}
