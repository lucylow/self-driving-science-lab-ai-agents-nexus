"""Scientific debate record composer that preserves independent positions."""
from __future__ import annotations
from uuid import uuid4


def compose_scientific_debate(*, proposition: str, positions: list[dict],
                              allowed_evidence_refs: set[str]) -> dict:
    if len(positions) < 2:
        raise ValueError("At least two independent positions are required")
    agent_ids = [str(item.get("agent_id", "")) for item in positions]
    if any(not agent for agent in agent_ids) or len(set(agent_ids)) != len(agent_ids):
        raise ValueError("Each debate position must come from a distinct identified agent")
    errors = []
    normalized = []
    for index, position in enumerate(positions):
        stance = position.get("stance")
        if stance not in {"supports", "opposes", "alternative", "uncertain"}:
            errors.append(f"Position {index} has an invalid stance")
        refs = position.get("evidence_refs", [])
        unknown = sorted(set(refs) - allowed_evidence_refs)
        if unknown:
            errors.append(f"Position {index} cites unknown evidence: {unknown}")
        normalized.append({"agent_id": agent_ids[index], "stance": stance,
                           "argument": str(position.get("argument", "")),
                           "assumptions": position.get("assumptions", []),
                           "evidence_refs": refs,
                           "limitations": position.get("limitations", [])})
    if errors:
        raise ValueError(" ".join(errors))
    stances = {item["stance"] for item in normalized}
    consensus = len(stances) == 1 and "uncertain" not in stances
    return {
        "debate_id": str(uuid4()), "proposition": proposition,
        "positions": normalized,
        "stance_distribution": {stance: sum(item["stance"] == stance for item in normalized)
                                for stance in sorted(stances)},
        "consensus_detected": consensus,
        "consensus_strength": "not_assessed",
        "unresolved_disagreements": [] if consensus else [
            "Agents provided non-identical positions; preserve disagreement for scientist review."],
        "winner_selected": False,
        "scientific_truth_determined": False,
        "review_required": True,
    }
