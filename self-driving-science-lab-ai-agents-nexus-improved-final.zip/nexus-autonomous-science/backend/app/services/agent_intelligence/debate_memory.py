"""Versioned debate memory that retains dissent and source references."""
from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone

@dataclass(frozen=True)
class DebateRecord:
    debate_id: str
    proposition_id: str
    proposition_version: int
    positions: tuple[dict, ...]
    evidence_refs: tuple[str, ...]
    unresolved_questions: tuple[str, ...]
    created_at: str


class DebateMemory:
    def __init__(self) -> None:
        self._records: dict[str, list[DebateRecord]] = {}

    def append(self, *, proposition_id: str, proposition_version: int,
               positions: list[dict], evidence_refs: list[str],
               unresolved_questions: list[str]) -> DebateRecord:
        if proposition_version < 1:
            raise ValueError("proposition_version must be positive")
        versions = self._records.setdefault(proposition_id, [])
        if versions and proposition_version < versions[-1].proposition_version:
            raise ValueError("Debate memory cannot move backwards in proposition version")
        record = DebateRecord(
            debate_id=f"DEB-{len(versions)+1:06d}", proposition_id=proposition_id,
            proposition_version=proposition_version, positions=tuple(positions),
            evidence_refs=tuple(sorted(set(evidence_refs))),
            unresolved_questions=tuple(unresolved_questions),
            created_at=datetime.now(timezone.utc).isoformat(),
        )
        versions.append(record)
        return record

    def history(self, proposition_id: str) -> list[dict]:
        return [asdict(record) for record in self._records.get(proposition_id, [])]

    def open_questions(self, proposition_id: str) -> list[str]:
        output = []
        for record in self._records.get(proposition_id, []):
            output.extend(record.unresolved_questions)
        return list(dict.fromkeys(output))
