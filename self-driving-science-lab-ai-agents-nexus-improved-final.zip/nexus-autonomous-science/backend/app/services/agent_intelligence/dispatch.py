"""Capability-based multi-agent dispatch planning with human-only node support."""
from __future__ import annotations
from typing import Any
from app.services.agent_intelligence.task_graph import compile_task_graph

HUMAN_CAPABILITIES = {"human_review", "human_biosafety_review", "human_safety_approval",
                      "model_release_approval", "physical_execution_authorization"}
DISALLOWED_AGENT_CAPABILITIES = {"approve_physical_execution", "disable_safety_interlock",
                                 "override_equipment_interlock", "authorize_hazardous_operation"}


def rank_agent_candidates(task: dict[str, Any], agents: list[dict[str, Any]]) -> dict[str, Any]:
    required = set(task.get("required_capabilities", []))
    domain = task.get("domain")
    lab = task.get("laboratory_code")
    if not required:
        raise ValueError("task must declare at least one required capability")
    ranked = []
    exclusions = []
    for agent in agents:
        agent_id = str(agent.get("id", ""))
        capabilities = set(agent.get("capabilities", []))
        if not agent_id:
            exclusions.append({"agent": "unknown", "reason": "missing_id"}); continue
        if agent.get("status") not in ("idle", "available", "ready"):
            exclusions.append({"agent": agent_id, "reason": "agent_not_available"}); continue
        if capabilities & DISALLOWED_AGENT_CAPABILITIES:
            exclusions.append({"agent": agent_id, "reason": "unsafe_capability_manifest"}); continue
        if not required.issubset(capabilities):
            exclusions.append({"agent": agent_id, "reason": "missing_required_capabilities"}); continue
        if agent.get("permission_level") in ("disabled", "human_only", "read_only") and task.get("execution_class") != "analysis_only":
            exclusions.append({"agent": agent_id, "reason": "permission_level_insufficient"}); continue
        domain_match = domain in agent.get("domains", []) if domain else False
        lab_match = lab == agent.get("laboratory_code") if lab else False
        load = max(0, int(agent.get("active_runs", 0)))
        completed = max(0, int(agent.get("completed_runs", 0)))
        score = len(required) * 10 + (12 if domain_match else 0) + (8 if lab_match else 0) - load * 5
        ranked.append({"agent_id": agent_id, "score": score, "domain_match": domain_match,
                       "laboratory_match": lab_match, "active_runs": load,
                       "completed_runs": completed, "matched_capabilities": sorted(required)})
    ranked.sort(key=lambda item: (-item["score"], item["active_runs"], item["agent_id"]))
    return {"ranked_agents": ranked, "excluded_agents": exclusions,
            "selection_policy": "capability-first; domain/lab affinity is a tie-breaker",
            "human_node": bool(required & HUMAN_CAPABILITIES)}


def compile_dispatch_plan(*, tasks: list[dict[str, Any]], agents: list[dict[str, Any]],
                          domain: str, laboratory_code: str) -> dict[str, Any]:
    """Assign ready DAG nodes. Human review nodes remain unassigned to AI agents."""
    normalized = []
    for task in tasks:
        item = {**task, "domain": domain, "laboratory_code": laboratory_code}
        normalized.append(item)
    try:
        graph = compile_task_graph(normalized)
    except ValueError as exc:
        raise ValueError(f"invalid dispatch task graph: {exc}") from exc
    assignments = []; unresolved = []; assigned_load = {str(agent.get("id")): int(agent.get("active_runs", 0)) for agent in agents}
    task_by_id = {task["node_id"]: task for task in normalized}
    for layer in graph["parallel_layers"]:
        for task_id in layer:
            task = task_by_id[task_id]
            capabilities = set(task.get("required_capabilities", []))
            if capabilities & HUMAN_CAPABILITIES or task.get("execution_class") == "human_review":
                assignments.append({"node_id": task_id, "assignment_type": "human_review",
                                    "assigned_agent_id": None, "status": "awaiting_human"})
                continue
            ranked = rank_agent_candidates(task, agents)["ranked_agents"]
            if not ranked:
                unresolved.append({"node_id": task_id, "reason": "no_eligible_agent"})
                continue
            selected = min(ranked, key=lambda item: (assigned_load.get(item["agent_id"], 0), -item["score"], item["agent_id"]))
            assigned_load[selected["agent_id"]] = assigned_load.get(selected["agent_id"], 0) + 1
            assignments.append({"node_id": task_id, "assignment_type": "agent_analysis",
                                "assigned_agent_id": selected["agent_id"], "status": "planned",
                                "selection_score": selected["score"],
                                "matched_capabilities": selected["matched_capabilities"]})
    return {"valid": not unresolved, "laboratory_code": laboratory_code, "domain": domain,
            "topological_order": graph["topological_order"], "parallel_layers": graph["parallel_layers"],
            "assignments": assignments, "unresolved_tasks": unresolved,
            "physical_execution_authorized": False,
            "note": "Dispatch is a plan; it does not start agents or issue equipment commands."}
