"""Typed, bounded messages for collaboration among specialist agents."""
from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta, timezone
from hashlib import sha256
import json
from typing import Any

MESSAGE_TYPES = {
    "task_request", "task_acknowledgement", "analysis_result", "evidence_reference",
    "challenge", "clarification_request", "review_request", "review_response",
    "failure_notice", "handoff", "workflow_event",
}

@dataclass(frozen=True)
class AgentMessage:
    message_id: str
    correlation_id: str
    sender_agent_id: str
    recipient_agent_id: str
    message_type: str
    payload: dict[str, Any]
    created_at: str
    expires_at: str
    parent_message_id: str | None = None
    evidence_refs: tuple[str, ...] = ()
    schema_version: str = "1.0.0"

    def canonical_hash(self) -> str:
        value = asdict(self)
        value["evidence_refs"] = list(self.evidence_refs)
        encoded = json.dumps(value, sort_keys=True, separators=(",", ":"), default=str).encode()
        return sha256(encoded).hexdigest()


def create_message(*, message_id: str, correlation_id: str, sender_agent_id: str,
                   recipient_agent_id: str, message_type: str, payload: dict[str, Any],
                   ttl_seconds: int = 900, parent_message_id: str | None = None,
                   evidence_refs: list[str] | None = None,
                   now: datetime | None = None) -> AgentMessage:
    current = now or datetime.now(timezone.utc)
    if current.tzinfo is None:
        raise ValueError("message timestamps must be timezone-aware")
    if not all(value.strip() for value in (message_id, correlation_id, sender_agent_id, recipient_agent_id)):
        raise ValueError("message and agent identifiers are required")
    if sender_agent_id == recipient_agent_id:
        raise ValueError("agent cannot message itself through the inter-agent bus")
    if message_type not in MESSAGE_TYPES:
        raise ValueError("unsupported agent message type")
    if ttl_seconds < 1 or ttl_seconds > 86400:
        raise ValueError("message TTL must be between 1 second and 24 hours")
    if not isinstance(payload, dict):
        raise ValueError("message payload must be an object")
    encoded = json.dumps(payload, sort_keys=True, default=str)
    if len(encoded.encode()) > 128_000:
        raise ValueError("message payload exceeds 128 KB limit")
    refs = tuple(dict.fromkeys(str(ref).strip() for ref in (evidence_refs or []) if str(ref).strip()))
    return AgentMessage(message_id=message_id, correlation_id=correlation_id,
        sender_agent_id=sender_agent_id, recipient_agent_id=recipient_agent_id,
        message_type=message_type, payload=payload, created_at=current.isoformat(),
        expires_at=(current+timedelta(seconds=ttl_seconds)).isoformat(),
        parent_message_id=parent_message_id, evidence_refs=refs)


def validate_message(message: AgentMessage, *, known_agents: set[str],
                     now: datetime | None = None, allowed_senders: dict[str, set[str]] | None = None) -> dict[str, Any]:
    current = now or datetime.now(timezone.utc)
    issues = []
    if message.sender_agent_id not in known_agents:
        issues.append("unknown_sender")
    if message.recipient_agent_id not in known_agents:
        issues.append("unknown_recipient")
    if allowed_senders is not None and message.recipient_agent_id in allowed_senders:
        if message.sender_agent_id not in allowed_senders[message.recipient_agent_id]:
            issues.append("sender_not_authorized_for_recipient")
    created = datetime.fromisoformat(message.created_at)
    expires = datetime.fromisoformat(message.expires_at)
    if created.tzinfo is None or expires.tzinfo is None:
        issues.append("naive_timestamp")
    elif current > expires:
        issues.append("message_expired")
    elif expires <= created:
        issues.append("invalid_expiry")
    if message.message_type not in MESSAGE_TYPES:
        issues.append("unsupported_message_type")
    if message.schema_version != "1.0.0":
        issues.append("unsupported_schema_version")
    return {"valid": not issues, "issues": issues, "message_hash": message.canonical_hash(),
            "message_type": message.message_type,
            "evidence_reference_count": len(message.evidence_refs)}


def detect_message_loop(messages: list[AgentMessage], *, maximum_hops: int = 12) -> dict[str, Any]:
    if maximum_hops < 1:
        raise ValueError("maximum_hops must be positive")
    by_id = {item.message_id: item for item in messages}
    issues = []
    for item in messages:
        if item.parent_message_id and item.parent_message_id not in by_id:
            issues.append({"message_id": item.message_id, "code": "missing_parent"})
    max_depth = 0
    for item in messages:
        seen = set(); current = item; depth = 0
        while current.parent_message_id:
            if current.message_id in seen:
                issues.append({"message_id": item.message_id, "code": "message_cycle"}); break
            seen.add(current.message_id); depth += 1
            if depth > maximum_hops:
                issues.append({"message_id": item.message_id, "code": "maximum_hops_exceeded"}); break
            parent = by_id.get(current.parent_message_id)
            if parent is None: break
            current = parent
        max_depth = max(max_depth, depth)
    return {"valid": not issues, "issues": issues, "message_count": len(messages),
            "maximum_observed_hops": max_depth}
