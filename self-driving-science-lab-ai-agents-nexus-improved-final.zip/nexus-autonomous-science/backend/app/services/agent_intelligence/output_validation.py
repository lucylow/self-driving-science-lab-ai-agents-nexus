"""Agent output schema, evidence reference and permission validation."""
from __future__ import annotations
from math import isfinite

REQUIRED_FINDING_FIELDS = {"finding_type", "summary", "confidence", "evidence_refs", "limitations"}


def validate_agent_output(output: dict, *, allowed_evidence_refs: set[str],
                          allowed_finding_types: set[str] | None = None) -> dict:
    errors = []
    if output.get("physical_execution_authorized") is True:
        errors.append("Agent output cannot authorize physical execution")
    if output.get("synthetic") is not True and output.get("handler") == "deterministic_demo_adapter":
        errors.append("Deterministic demo adapter outputs must be labelled synthetic")
    findings = output.get("findings", [])
    if not isinstance(findings, list):
        errors.append("findings must be a list")
        findings = []
    for index, finding in enumerate(findings):
        missing = sorted(REQUIRED_FINDING_FIELDS - set(finding))
        if missing:
            errors.append(f"Finding {index} is missing fields: {missing}")
            continue
        confidence = finding.get("confidence")
        if not isinstance(confidence, (float, int)) or not isfinite(float(confidence)) or not 0 <= confidence <= 1:
            errors.append(f"Finding {index} confidence must be between zero and one")
        unknown_refs = sorted(set(finding.get("evidence_refs", [])) - allowed_evidence_refs)
        if unknown_refs:
            errors.append(f"Finding {index} cites unknown evidence refs: {unknown_refs}")
        if allowed_finding_types is not None and finding.get("finding_type") not in allowed_finding_types:
            errors.append(f"Finding {index} uses an unapproved finding type")
        if not finding.get("limitations"):
            errors.append(f"Finding {index} must include at least one limitation")
    return {"valid": not errors, "errors": errors,
            "finding_count": len(findings), "physical_execution_authorized": False}
