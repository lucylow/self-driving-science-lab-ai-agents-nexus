"""Action-scoped agent permission checks; agent identity is not human authority."""
from __future__ import annotations

AGENT_ACTIONS = {"read_scientific_data", "analyze", "propose", "simulate", "request_human_review"}
FORBIDDEN_AGENT_ACTIONS = {
    "approve_experiment", "execute_physical_experiment", "modify_safety_interlock",
    "override_instrument_alarm", "release_quarantined_sample", "promote_model_to_production",
    "sign_scientific_conclusion",
}


def authorize_agent_action(*, permission_level: str, action: str,
                           explicitly_allowed: list[str] | None = None) -> dict:
    if action in FORBIDDEN_AGENT_ACTIONS:
        return {"authorized": False, "reason": "Action is reserved for an accountable human or local safety controller."}
    if action not in AGENT_ACTIONS:
        return {"authorized": False, "reason": "Action is not in the registered agent action set."}
    level_actions = {
        "propose_only": {"read_scientific_data", "propose", "request_human_review"},
        "analyze": {"read_scientific_data", "analyze", "propose", "request_human_review"},
        "simulate": {"read_scientific_data", "analyze", "propose", "simulate", "request_human_review"},
    }
    permitted = level_actions.get(permission_level, set())
    if explicitly_allowed is not None:
        permitted &= set(explicitly_allowed)
    return {"authorized": action in permitted,
            "permission_level": permission_level,
            "action": action,
            "reason": "permitted_by_agent_capability_policy" if action in permitted else "permission_level_does_not_allow_action"}
