"""Bounded retry planning with idempotency and physical-action prohibitions."""
from __future__ import annotations
from hashlib import sha256
import json

NON_RETRYABLE_FAILURES = {
    "permission_denied", "schema_invalid", "sample_identity_unknown", "safety_interlock_open",
    "physical_execution_blocked", "human_rejection", "protocol_not_approved",
}


def idempotency_key(*, workflow_id: str, node_id: str, input_contract: dict) -> str:
    payload = json.dumps({"workflow_id": workflow_id, "node_id": node_id,
                          "input_contract": input_contract}, sort_keys=True, separators=(",", ":"))
    return sha256(payload.encode("utf-8")).hexdigest()


def plan_retry(*, failure_code: str, attempt: int, maximum_attempts: int = 3,
               base_delay_seconds: float = 1.0, task_kind: str = "analysis") -> dict:
    if attempt < 1 or maximum_attempts < 1 or base_delay_seconds < 0:
        raise ValueError("Invalid retry configuration")
    if task_kind in {"physical_action", "instrument_command", "robot_motion", "sample_transfer"}:
        return {"retry_allowed": False, "reason": "Physical or hardware-facing tasks are never retried by this cloud policy."}
    if failure_code in NON_RETRYABLE_FAILURES:
        return {"retry_allowed": False, "reason": f"Failure '{failure_code}' is non-retryable."}
    if attempt >= maximum_attempts:
        return {"retry_allowed": False, "reason": "Maximum retry attempts reached."}
    delay = min(60.0, base_delay_seconds * (2 ** (attempt - 1)))
    return {"retry_allowed": True, "next_attempt": attempt + 1,
            "delay_seconds": delay, "failure_code": failure_code,
            "idempotency_key_required": True,
            "notice": "Retry is permitted only after verifying no side effect was committed."}
