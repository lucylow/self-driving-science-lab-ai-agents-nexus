"""Dependency-aware DAG compilation for scientific agent tasks."""
from __future__ import annotations
from collections import defaultdict, deque


def compile_task_graph(nodes: list[dict]) -> dict:
    node_ids = [str(node.get("node_id", "")) for node in nodes]
    if any(not value for value in node_ids) or len(node_ids) != len(set(node_ids)):
        raise ValueError("Every task node requires a unique node_id")
    known = set(node_ids)
    incoming = {node_id: 0 for node_id in node_ids}
    outgoing = defaultdict(list)
    for node in nodes:
        dependencies = node.get("depends_on", [])
        if len(dependencies) != len(set(dependencies)):
            raise ValueError(f"Node '{node['node_id']}' has duplicate dependencies")
        for parent in dependencies:
            if parent not in known:
                raise ValueError(f"Node '{node['node_id']}' references unknown dependency '{parent}'")
            if parent == node["node_id"]:
                raise ValueError("Task node cannot depend on itself")
            outgoing[parent].append(node["node_id"])
            incoming[node["node_id"]] += 1
    queue = deque(sorted(node for node, count in incoming.items() if count == 0))
    order = []
    levels = {}
    while queue:
        current = queue.popleft()
        order.append(current)
        levels.setdefault(current, 0)
        for child in sorted(outgoing[current]):
            levels[child] = max(levels.get(child, 0), levels[current] + 1)
            incoming[child] -= 1
            if incoming[child] == 0:
                queue.append(child)
    if len(order) != len(nodes):
        cyclic = sorted(node for node, count in incoming.items() if count > 0)
        raise ValueError(f"Task graph contains a dependency cycle involving: {cyclic}")
    parallel_layers = {}
    for node, level in levels.items():
        parallel_layers.setdefault(level, []).append(node)
    return {
        "valid": True, "topological_order": order,
        "parallel_layers": [sorted(parallel_layers[level]) for level in sorted(parallel_layers)],
        "node_count": len(nodes),
        "edge_count": sum(len(node.get("depends_on", [])) for node in nodes),
        "execution_policy": "dependency_ordered_no_hidden_parallelism",
    }


def ready_nodes(nodes: list[dict], completed: set[str]) -> list[str]:
    known = {node["node_id"] for node in nodes}
    if not completed.issubset(known):
        raise ValueError("Completed node set contains unknown node ids")
    return sorted(node["node_id"] for node in nodes
                  if node["node_id"] not in completed
                  and set(node.get("depends_on", [])).issubset(completed))
