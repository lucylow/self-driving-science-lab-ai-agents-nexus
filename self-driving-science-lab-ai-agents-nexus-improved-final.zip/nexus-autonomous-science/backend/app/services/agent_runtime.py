"""Capability-bound deterministic agent runtime adapter.

This is an execution boundary and demo handler registry, not a claim that LLMs are running.
A production model provider can implement the same interface after independent evaluation.
"""
from __future__ import annotations
from datetime import datetime, timezone
from time import perf_counter
from uuid import uuid4
from sqlalchemy.orm import Session
from app.models.entities import Agent, AgentRunRecord
from app.services.audit import record_event
from app.services.safety import validate_agent_permission

TASK_CAPABILITIES = {
    "inspect_evidence": "evidence_extraction",
    "review_claims": "claim_review",
    "validate_composition": "composition_validation",
    "rank_candidates": "multiobjective_optimization",
    "review_data_quality": "data_quality",
    "review_transfer": "provenance",
    "compile_objective": "objective_parsing",
    "evaluate_model": "model_evaluation",
    "summarize_timeseries": "timeseries",
    "prepare_report": "reporting",
}


class AgentRuntimeError(ValueError):
    pass


def dispatch_task(db: Session, *, agent: Agent, task_type: str, input_contract: dict,
                  correlation_id: str | None = None) -> AgentRunRecord:
    required_capability = TASK_CAPABILITIES.get(task_type)
    if not required_capability:
        raise AgentRuntimeError(f"Unsupported task type '{task_type}'")
    if required_capability not in agent.capabilities:
        raise AgentRuntimeError(f"Agent '{agent.agent_key}' does not declare capability '{required_capability}'")
    validate_agent_permission(agent.permission_level, "analyze")
    run_id = str(uuid4())
    correlation_id = correlation_id or str(uuid4())
    started = datetime.now(timezone.utc)
    timer = perf_counter()
    record = AgentRunRecord(
        id=run_id, agent_id=agent.id, task_type=task_type, status="running",
        input_contract=input_contract, output_contract={}, error_summary="", duration_ms=0,
        correlation_id=correlation_id, synthetic=True, started_at=started,
    )
    db.add(record)
    agent.status = "running"
    agent.run_count += 1
    agent.last_run_at = started
    try:
        output = _run_registered_handler(agent, task_type, input_contract)
        record.output_contract = output
        record.status = "completed"
    except Exception as exc:
        record.status = "failed"
        record.error_summary = str(exc)[:2000]
        raise
    finally:
        record.duration_ms = int((perf_counter() - timer) * 1000)
        record.finished_at = datetime.now(timezone.utc)
        agent.status = "idle"
        record_event(db, "AGENT_TASK_COMPLETED" if record.status == "completed" else "AGENT_TASK_FAILED",
                     "agent_run", record.id, actor=agent.agent_key,
                     payload={"task_type": task_type, "status": record.status, "synthetic": True},
                     correlation_id=correlation_id)
        db.flush()
    return record


def _run_registered_handler(agent: Agent, task_type: str, payload: dict) -> dict:
    """Return a typed, deterministic review envelope; no generated scientific facts."""
    return {
        "agent_id": agent.id,
        "agent_key": agent.agent_key,
        "agent_name": agent.name,
        "task_type": task_type,
        "handler": "deterministic_demo_adapter",
        "capability_verified": TASK_CAPABILITIES[task_type],
        "input_keys": sorted(payload.keys()),
        "summary": f"{agent.name} received a schema-checked {task_type} task.",
        "findings": [],
        "evidence_refs": payload.get("evidence_refs", []),
        "limitations": [
            "No foundation model provider was invoked.",
            "No new scientific measurement or conclusion was generated.",
            "A domain scientist must review evidence before consequential use.",
        ],
        "synthetic": True,
        "requires_scientist_review": True,
    }


def get_agent_run_history(db: Session, *, limit: int = 100, agent_id: str | None = None) -> list[dict]:
    from sqlalchemy import select
    query = select(AgentRunRecord).order_by(AgentRunRecord.started_at.desc()).limit(min(max(limit, 1), 500))
    if agent_id:
        query = query.where(AgentRunRecord.agent_id == agent_id)
    rows = db.scalars(query).all()
    return [{"id": row.id, "agent_id": row.agent_id, "task_type": row.task_type,
             "status": row.status, "input_contract": row.input_contract,
             "output_contract": row.output_contract, "duration_ms": row.duration_ms,
             "correlation_id": row.correlation_id, "synthetic": row.synthetic,
             "started_at": row.started_at, "finished_at": row.finished_at,
             "error_summary": row.error_summary} for row in rows]
