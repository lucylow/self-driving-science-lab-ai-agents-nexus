"""Agent specialization adapters. Dispatch is proposal-only in the starter build."""
