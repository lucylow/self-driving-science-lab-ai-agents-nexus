"""SDL6 biological model and evidence-separation checks."""

from typing import Any

EVIDENCE_CATEGORIES = {"morphology", "gene_expression", "functional_behavior", "biochemical_measurement", "mechanical_environment"}


def validate_biological_model(record: dict[str, Any]) -> dict[str, Any]:
    required = ["model_id", "model_type", "origin_or_donor_reference", "passage_or_generation", "culture_conditions", "ethics_or_biosafety_review_ref"]
    missing = [field for field in required if not record.get(field)]
    return {"status": "blocked_from_experiment_design" if missing else "reviewable", "missing_fields": missing, "biological_model_identity": record.get("model_id")}


def separate_evidence_categories(observations: list[dict[str, Any]]) -> dict[str, Any]:
    grouped: dict[str, list[dict[str, Any]]] = {key: [] for key in EVIDENCE_CATEGORIES}
    unknown = []
    for observation in observations:
        category = observation.get("evidence_category")
        if category in grouped:
            grouped[category].append(observation)
        else:
            unknown.append(observation)
    return {
        "categories": grouped,
        "unknown_category_records": unknown,
        "categories_may_substitute_for_each_other": False,
        "note": "Concordance across distinct evidence categories can strengthen a conclusion but does not make them interchangeable.",
    }


def replication_summary(replicates: list[dict[str, Any]]) -> dict[str, Any]:
    biological_ids = {item.get("biological_replicate_id") for item in replicates if item.get("biological_replicate_id")}
    technical_ids = {item.get("technical_replicate_id") for item in replicates if item.get("technical_replicate_id")}
    return {"record_count": len(replicates), "independent_biological_replicates": len(biological_ids), "technical_replicate_ids": len(technical_ids), "independent_replication_confirmed": len(biological_ids) >= 2}
