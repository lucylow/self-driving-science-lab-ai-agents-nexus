"""Cross-domain SDL data intelligence utilities."""

from typing import Any
from app.services.data_quality import assess_measurement


def inspect_measurement_batch(records: list[dict[str, Any]]) -> dict[str, Any]:
    results = [{"record_id": record.get("record_id"), **assess_measurement(record).to_dict()} for record in records]
    return {
        "record_count": len(records),
        "accepted_for_review": sum(item["status"] in {"preliminary", "synthetic_or_derived"} for item in results),
        "quarantined": sum(item["status"] == "quarantined" for item in results),
        "records": results,
    }


def feature_training_eligibility(record: dict[str, Any]) -> dict[str, Any]:
    blockers = []
    if not record.get("sample_id"):
        blockers.append("sample_identity_missing")
    if not record.get("provenance_refs"):
        blockers.append("provenance_missing")
    if record.get("origin") in {"prediction", "simulation", "inferred"} and not record.get("synthetic_or_derived_label"):
        blockers.append("origin_label_missing")
    if record.get("quality_status") in {"rejected", "quarantined"}:
        blockers.append("quality_status_disqualifies_training")
    return {"eligible_for_training_review": not blockers, "blockers": blockers}
