"""SDL5 formulation composition and batch-consistency helpers."""

from typing import Any


def normalize_composition(components: list[dict[str, Any]]) -> dict[str, Any]:
    errors = []
    total = 0.0
    for item in components:
        try:
            amount = float(item.get("fraction"))
            if amount < 0:
                errors.append("Composition fractions cannot be negative.")
            total += amount
        except (TypeError, ValueError):
            errors.append(f"Invalid fraction for component {item.get('component_id', 'unknown')}.")
    if total <= 0:
        errors.append("Composition total must be positive.")
    normalized = [] if errors else [{**item, "normalized_fraction": float(item["fraction"]) / total} for item in components]
    return {"valid": not errors, "total_original_fraction": total, "components": normalized, "errors": errors}


def compare_batches(batch_records: list[dict[str, Any]], keys: list[str]) -> dict[str, Any]:
    profiles = [{"batch_id": row.get("batch_id"), **{key: row.get(key) for key in keys}} for row in batch_records]
    missing_by_batch = {str(row.get("batch_id")): [key for key in keys if row.get(key) is None] for row in batch_records}
    return {"profiles": profiles, "missing_by_batch": missing_by_batch, "consistency_status": "review_required" if any(missing_by_batch.values()) else "metadata_complete"}
