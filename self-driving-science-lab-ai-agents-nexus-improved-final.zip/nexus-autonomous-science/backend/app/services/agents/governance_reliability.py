"""SDL0 governance and reliability checks for agent outputs and workflow requests."""

from typing import Any

FORBIDDEN_AGENT_PERMISSIONS = {"approve_experiment", "execute_physical", "modify_interlock", "disable_safety"}


def validate_capability_card(card: dict[str, Any]) -> dict[str, Any]:
    errors = []
    if not card.get("agent_id") or not card.get("purpose"):
        errors.append("Agent id and measurable purpose are required.")
    permissions = set(card.get("permissions", []))
    elevated = sorted(permissions & FORBIDDEN_AGENT_PERMISSIONS)
    if elevated:
        errors.append(f"Forbidden permissions declared: {', '.join(elevated)}")
    if not card.get("inputs") or not card.get("outputs"):
        errors.append("Input and output contracts are required.")
    return {"valid": not errors, "errors": errors, "requires_human_review": True}


def evaluate_agent_run(run: dict[str, Any]) -> dict[str, Any]:
    checks = {
        "schema_valid": bool(run.get("schema_valid")),
        "evidence_refs_present": bool(run.get("evidence_refs")),
        "limitations_reported": bool(run.get("limitations")),
        "uncertainty_reported": run.get("uncertainty") is not None,
        "within_permission_scope": not bool(run.get("attempted_elevated_action")),
    }
    return {"checks": checks, "promotion_eligible": all(checks.values()), "human_review_rate": None}
