"""SDL1 materials intelligence baselines; no crystallographic calculations are implied."""

import re
from typing import Any

ELEMENT_TOKEN = re.compile(r"([A-Z][a-z]?)(\d*(?:\.\d+)?)")


def parse_formula_tokens(formula: str) -> dict[str, float]:
    compact = formula.replace(" ", "")
    tokens = ELEMENT_TOKEN.findall(compact)
    reconstructed = "".join(element + amount for element, amount in tokens)
    if not tokens or reconstructed != compact:
        raise ValueError("Formula could not be parsed by the simple token validator.")
    composition: dict[str, float] = {}
    for element, amount in tokens:
        composition[element] = composition.get(element, 0.0) + (float(amount) if amount else 1.0)
    return composition


def validate_candidate(candidate: dict[str, Any]) -> dict[str, Any]:
    errors = []
    try:
        composition = parse_formula_tokens(str(candidate.get("formula", "")))
    except ValueError as exc:
        composition = {}
        errors.append(str(exc))
    if not candidate.get("candidate_id"):
        errors.append("Candidate identity is required.")
    if not candidate.get("domain"):
        errors.append("Materials domain is required.")
    return {
        "syntactic_validity": not errors,
        "composition_tokens": composition,
        "errors": errors,
        "chemical_stability_validated": False,
        "synthesis_feasibility_validated": False,
    }


def compare_property_evidence(records: list[dict[str, Any]], property_name: str) -> dict[str, Any]:
    selected = [record for record in records if record.get("property") == property_name]
    contexts = {str(record.get("measurement_method", "unknown")) for record in selected}
    return {
        "property": property_name,
        "record_count": len(selected),
        "methods": sorted(contexts),
        "directly_comparable": len(contexts) == 1 and "unknown" not in contexts,
        "evidence": selected,
    }
