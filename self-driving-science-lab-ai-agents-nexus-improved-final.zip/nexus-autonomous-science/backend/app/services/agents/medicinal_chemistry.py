"""SDL3 activity and assay context checks. No clinical outcome claims are produced."""

from typing import Any


def matched_pair_delta(reference: dict[str, Any], modified: dict[str, Any], *, activity_key: str) -> dict[str, Any]:
    same_assay = reference.get("assay_id") == modified.get("assay_id")
    same_conditions = reference.get("assay_conditions") == modified.get("assay_conditions")
    left, right = reference.get(activity_key), modified.get(activity_key)
    delta = None if left is None or right is None else float(right) - float(left)
    return {
        "activity_key": activity_key,
        "delta": delta,
        "assay_comparable": same_assay and same_conditions,
        "interpretation": "matched_pair_comparison" if same_assay and same_conditions else "context_mismatch_review_required",
        "clinical_significance": "not_assessed",
    }


def assay_quality_check(record: dict[str, Any]) -> dict[str, Any]:
    required = ["assay_id", "cell_or_target_reference", "reagent_lot", "replicate_count", "positive_control", "negative_control", "instrument_id"]
    missing = [field for field in required if record.get(field) in (None, "", 0)]
    return {
        "status": "review_required" if missing else "metadata_complete_preliminary",
        "missing_fields": missing,
        "replicate_count": record.get("replicate_count"),
        "controls_recorded": bool(record.get("positive_control") and record.get("negative_control")),
    }


def distinguish_binding_evidence(record: dict[str, Any]) -> dict[str, str]:
    return {
        "docking_score": "computational_prediction" if record.get("docking_score") is not None else "not_provided",
        "biophysical_binding": "experimental_measurement" if record.get("binding_measurement") is not None else "not_provided",
        "cellular_activity": "experimental_measurement" if record.get("cellular_activity") is not None else "not_provided",
    }
