"""SDL2 molecular discovery and reaction-record utilities."""

from typing import Any


def validate_reaction_record(record: dict[str, Any]) -> dict[str, Any]:
    required = ["reaction_id", "reactants", "products", "conditions", "measurement_method"]
    missing = [field for field in required if record.get(field) in (None, "", [])]
    return {
        "valid_for_structured_review": not missing,
        "missing_fields": missing,
        "reaction_outcome": record.get("outcome", "unknown"),
        "yield_is_measured": record.get("yield_origin") == "measured",
        "synthesis_success_confirmed": False,
    }


def compare_reaction_conditions(records: list[dict[str, Any]], condition_keys: list[str]) -> dict[str, Any]:
    profiles = []
    for record in records:
        conditions = record.get("conditions", {})
        profiles.append({"reaction_id": record.get("reaction_id"), **{key: conditions.get(key) for key in condition_keys}})
    return {"profiles": profiles, "missing_context": any(any(row.get(key) is None for key in condition_keys) for row in profiles)}


def mark_molecular_evidence_stage(record: dict[str, Any]) -> str:
    if record.get("analytical_confirmation"):
        return "analytically_confirmed"
    if record.get("synthesis_record"):
        return "synthesized_recorded"
    if record.get("computational_characterization"):
        return "computationally_characterized"
    if record.get("structure_validated"):
        return "computationally_validated"
    return "generated_candidate"
