"""SDL4 polymer structure–processing–property context checks."""

from typing import Any


def validate_polymer_metadata(record: dict[str, Any]) -> dict[str, Any]:
    required = ["sample_id", "polymer_family", "molecular_architecture", "molecular_weight_method", "processing_history"]
    missing = [field for field in required if not record.get(field)]
    return {"status": "review_required" if missing else "preliminary", "missing": missing, "synthetic": bool(record.get("synthetic", False))}


def property_comparability(records: list[dict[str, Any]], property_key: str) -> dict[str, Any]:
    methods = sorted({str(record.get("method", "unknown")) for record in records if record.get(property_key) is not None})
    conditions = sorted({str(record.get("test_conditions", "unknown")) for record in records if record.get(property_key) is not None})
    return {
        "property": property_key,
        "method_count": len(methods),
        "condition_profile_count": len(conditions),
        "comparable_without_harmonization": len(methods) == 1 and len(conditions) == 1 and "unknown" not in methods + conditions,
    }


def structure_process_property_links(record: dict[str, Any]) -> list[dict[str, str]]:
    links = []
    for left, right in (("molecular_architecture", "processing_history"), ("processing_history", "microstructure"), ("microstructure", "measured_property")):
        if record.get(left) is not None and record.get(right) is not None:
            links.append({"from": left, "to": right, "status": "metadata_linked_not_causal"})
    return links
