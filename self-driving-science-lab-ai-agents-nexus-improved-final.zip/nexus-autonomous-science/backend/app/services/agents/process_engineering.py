"""SDL7 process engineering and scale-up context tools."""

from typing import Any


def validate_process_run(record: dict[str, Any]) -> dict[str, Any]:
    required = ["run_id", "process_version", "reactor_or_equipment_id", "feed_lot_ids", "temperature_profile", "pressure_profile", "flow_or_mixing_context"]
    missing = [field for field in required if record.get(field) in (None, "", [])]
    return {"status": "review_required" if missing else "metadata_complete_preliminary", "missing_fields": missing}


def compare_scale_context(lab_run: dict[str, Any], target_run: dict[str, Any]) -> dict[str, Any]:
    comparison_keys = ["reactor_geometry", "mixing_regime", "heat_transfer_area", "residence_time", "feed_composition", "measurement_method"]
    differences = [key for key in comparison_keys if lab_run.get(key) != target_run.get(key)]
    return {"differences": differences, "scale_transfer_validated": False, "requires_process_engineer_review": True}


def process_deviation_summary(observed: dict[str, float], target: dict[str, float], tolerances: dict[str, float]) -> dict[str, Any]:
    deviations = {}
    for key, target_value in target.items():
        if key not in observed:
            deviations[key] = {"status": "missing", "delta": None}
            continue
        delta = observed[key] - target_value
        limit = tolerances.get(key)
        deviations[key] = {"status": "within_tolerance" if limit is not None and abs(delta) <= limit else "review", "delta": delta, "tolerance": limit}
    return {"deviations": deviations, "automatic_process_adjustment": False}
