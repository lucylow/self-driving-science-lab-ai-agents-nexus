"""SDL0 scientific research agent utilities."""

from typing import Any


def extract_evidence_record(source: dict[str, Any]) -> dict[str, Any]:
    required = ("source_id", "source_type", "title", "date_accessed")
    missing = [field for field in required if not source.get(field)]
    return {
        "source_id": source.get("source_id"),
        "source_type": source.get("source_type", "unknown"),
        "title": source.get("title", "Untitled source"),
        "claims": source.get("claims", []),
        "missing_metadata": missing,
        "evidence_status": "review_required" if missing else "structured_unverified",
        "note": "Extraction is not verification. Claims require source-level review.",
    }


def identify_research_gaps(objective_terms: set[str], known_evidence: list[dict[str, Any]]) -> dict[str, Any]:
    covered = set()
    for evidence in known_evidence:
        covered.update(str(term).lower() for term in evidence.get("topics", []))
    gaps = sorted(term for term in objective_terms if term.lower() not in covered)
    return {"covered_terms": sorted(covered), "candidate_gaps": gaps, "confidence": "not_estimated", "requires_literature_review": True}


def compare_competing_explanations(explanations: list[dict[str, Any]]) -> dict[str, Any]:
    return {
        "explanations": explanations,
        "consensus": None,
        "disagreement_preserved": True,
        "comparison_dimensions": ["supporting evidence", "contradictory evidence", "assumptions", "testable predictions"],
    }
