"""Scientific artifact metadata registration and parent-lineage validation."""
from __future__ import annotations
from uuid import uuid4
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.models.entities import ScientificArtifact, ScientificSample, Experiment
from app.services.audit import record_event
from app.services.domain_registry import get_domain

MAX_PARENT_DEPTH = 100

def _parent_lineage_issues(
    db: Session, parent_ids: list[str], *, laboratory_code: str, domain: str
) -> list[str]:
    issues: list[str] = []
    missing: set[str] = set()
    visiting: set[str] = set()
    visited: set[str] = set()

    def visit(parent_id: str, depth: int = 0) -> None:
        if depth > MAX_PARENT_DEPTH:
            issues.append(f"Artifact parent lineage exceeds {MAX_PARENT_DEPTH} levels")
            return
        if parent_id in visiting:
            issues.append(f"Artifact parent lineage contains a cycle at '{parent_id}'")
            return
        if parent_id in visited:
            return
        parent = db.get(ScientificArtifact, parent_id)
        if parent is None:
            missing.add(parent_id)
            return
        if parent.laboratory_code != laboratory_code:
            issues.append(f"Parent artifact '{parent_id}' must belong to laboratory {laboratory_code}")
        if parent.domain != domain:
            issues.append(f"Parent artifact '{parent_id}' must belong to domain {domain}")
        visiting.add(parent_id)
        for ancestor_id in parent.parent_artifact_ids or []:
            visit(ancestor_id, depth + 1)
        visiting.remove(parent_id)
        visited.add(parent_id)

    for item_id in parent_ids:
        visit(item_id)
    if missing:
        issues.append(f"Unknown parent artifact IDs: {', '.join(sorted(missing))}")
    return issues


def register_artifact(db: Session, payload: dict) -> ScientificArtifact:
    digest = str(payload["sha256"]).lower()
    if len(digest) != 64 or any(char not in "0123456789abcdef" for char in digest):
        raise ValueError("Artifact sha256 must contain exactly 64 hexadecimal characters")

    lab = str(payload["laboratory_code"]).upper()
    domain = get_domain(lab)["domain"]
    if payload["domain"] != domain:
        raise ValueError(f"Artifact domain does not match {lab}")

    sample_id = payload.get("sample_id")
    if sample_id:
        sample = db.get(ScientificSample, sample_id)
        if not sample:
            raise ValueError("Artifact references an unknown sample")
        if sample.laboratory_code != lab or sample.domain != domain:
            raise ValueError("Artifact and sample must belong to the same laboratory and domain")

    experiment_id = payload.get("experiment_id")
    if experiment_id:
        experiment = db.get(Experiment, experiment_id)
        if not experiment:
            raise ValueError("Artifact references an unknown experiment")
        if experiment.laboratory_code != lab:
            raise ValueError("Artifact and experiment must belong to the same laboratory")

    parent_ids = list(payload.get("parent_artifact_ids", []))
    if len(parent_ids) != len(set(parent_ids)):
        raise ValueError("Artifact parent IDs must not contain duplicates")
    parent_issues = _parent_lineage_issues(db, parent_ids, laboratory_code=lab, domain=domain)
    if parent_issues:
        raise ValueError("; ".join(parent_issues))

    normalized = {
        "artifact_code": payload["artifact_code"],
        "sha256": digest,
        "storage_uri": payload["storage_uri"],
        "media_type": payload["media_type"],
        "artifact_type": payload.get("artifact_type", "raw_data"),
        "byte_size": payload["byte_size"],
        "domain": domain,
        "laboratory_code": lab,
        "sample_id": sample_id,
        "experiment_id": experiment_id,
        "origin": payload["origin"],
        "metadata_json": payload.get("metadata", {}),
        "parent_artifact_ids": parent_ids,
        "synthetic": bool(payload.get("synthetic", False)),
    }

    # Artifact code, not a global hash, is the logical metadata identity. Equal
    # bytes may legitimately be reused by different laboratories or samples.
    existing = db.scalar(select(ScientificArtifact).where(
        ScientificArtifact.artifact_code == normalized["artifact_code"]
    ))
    if existing:
        if all(getattr(existing, field) == value for field, value in normalized.items()):
            return existing
        raise ValueError("Artifact code is already registered with different metadata")

    artifact = ScientificArtifact(id=str(uuid4()), **normalized)
    db.add(artifact)
    db.flush()
    record_event(db, "SCIENTIFIC_ARTIFACT_REGISTERED", "artifact", artifact.id,
                 actor="artifact-registry", payload={"sha256": digest, "origin": artifact.origin,
                                                      "synthetic": artifact.synthetic})
    return artifact


def validate_artifact_parents(db: Session, artifact_id: str) -> dict:
    artifact = db.get(ScientificArtifact, artifact_id)
    if not artifact:
        raise KeyError(artifact_id)
    parent_ids = artifact.parent_artifact_ids or []
    missing = [ref for ref in parent_ids if not db.get(ScientificArtifact, ref)]
    issues = _parent_lineage_issues(db, parent_ids,
                                   laboratory_code=artifact.laboratory_code, domain=artifact.domain)
    return {"artifact_id": artifact.id, "valid": not issues, "missing_parent_ids": missing,
            "parent_count": len(parent_ids), "issues": issues, "immutable": False,
            "immutability_enforced": False}
