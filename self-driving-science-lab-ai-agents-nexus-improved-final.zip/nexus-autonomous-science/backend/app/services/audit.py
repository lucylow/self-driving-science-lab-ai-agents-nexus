"""Append-only application audit events. Corrections are represented as new events."""

from uuid import uuid4
from sqlalchemy.orm import Session
from app.models.entities import AuditEvent


def record_event(
    db: Session,
    event_type: str,
    subject_type: str,
    subject_id: str,
    *,
    actor: str = "system",
    component: str = "api",
    payload: dict | None = None,
    correlation_id: str = "",
) -> AuditEvent:
    event = AuditEvent(
        id=str(uuid4()), event_type=event_type, actor=actor, component=component,
        subject_type=subject_type, subject_id=subject_id,
        payload=payload or {}, correlation_id=correlation_id,
    )
    db.add(event)
    # The outbox row is written in the same transaction as the audit event.
    # A broker adapter must acknowledge delivery before the event becomes published.
    from app.services.event_outbox import enqueue_event
    enqueue_event(
        db,
        event_key=f"audit:{event.id}",
        aggregate_type=subject_type,
        aggregate_id=subject_id,
        event_type=event_type,
        payload={"event_id": event.id, "actor": actor, "component": component,
                 "payload": payload or {}, "correlation_id": correlation_id},
    )
    return event
