"""Idempotent command acknowledgement state model for future edge gateways.

This module models command metadata only. It deliberately does not transport, queue,
translate, or issue a command to a physical instrument.
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Literal

Acknowledgement = Literal["received", "validated", "accepted", "completed", "rejected", "expired"]
ALLOWED_ACK_TRANSITIONS: dict[str, set[str]] = {
    "created": {"received", "expired"},
    "received": {"validated", "rejected", "expired"},
    "validated": {"accepted", "rejected", "expired"},
    "accepted": {"completed", "rejected"},
    "completed": set(),
    "rejected": set(),
    "expired": set(),
}


@dataclass
class CommandEnvelope:
    command_id: str
    idempotency_key: str
    experiment_id: str
    instrument_id: str
    operation: str
    protocol_version: str
    authorization_ref: str | None
    expires_at: datetime
    acknowledgement: str = "created"
    history: list[dict[str, str]] = field(default_factory=list)

    def transition(self, target: Acknowledgement, actor: str = "edge-gateway-contract") -> None:
        allowed = ALLOWED_ACK_TRANSITIONS.get(self.acknowledgement, set())
        if target not in allowed:
            raise ValueError(f"Invalid command acknowledgement transition {self.acknowledgement} -> {target}.")
        self.acknowledgement = target
        self.history.append({
            "state": target,
            "actor": actor,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })


def check_idempotency(envelopes: list[CommandEnvelope], key: str) -> dict[str, str | bool | None]:
    matches = [item for item in envelopes if item.idempotency_key == key]
    if not matches:
        return {"duplicate": False, "existing_command_id": None, "existing_state": None}
    latest = matches[-1]
    return {"duplicate": True, "existing_command_id": latest.command_id, "existing_state": latest.acknowledgement}


def validate_command_envelope(envelope: CommandEnvelope, *, now: datetime | None = None) -> list[str]:
    errors = []
    instant = now or datetime.now(timezone.utc)
    if not envelope.command_id or not envelope.idempotency_key:
        errors.append("Command and idempotency identifiers are required.")
    if not envelope.experiment_id or not envelope.instrument_id:
        errors.append("Experiment and instrument identities are required.")
    if not envelope.protocol_version:
        errors.append("Protocol version is required.")
    if envelope.expires_at.tzinfo is None:
        errors.append("Command expiry must be timezone-aware.")
    elif envelope.expires_at <= instant:
        errors.append("Command has expired.")
    if not envelope.authorization_ref:
        errors.append("An authorization reference is required by the gateway contract.")
    return errors
