"""Explicit, reviewable scientific knowledge packages across SDL0–SDL7."""
from __future__ import annotations
from uuid import uuid4
from sqlalchemy.orm import Session
from app.models.entities import CrossLabTransfer
from app.services.audit import record_event
from app.services.domain_registry import get_domain

REQUIRED_EVIDENCE_FIELDS = {"evidence_origin", "provenance_refs", "uncertainty", "measurement_context"}


def assess_transfer(source_laboratory: str, target_laboratory: str, domain: str,
                    payload: dict) -> dict:
    source = get_domain(source_laboratory)
    target = get_domain(target_laboratory)
    missing = sorted(REQUIRED_EVIDENCE_FIELDS - set(payload))
    origin = payload.get("evidence_origin")
    if origin == "simulation" and payload.get("synthetic") is not True:
        missing.append("simulation_synthetic_label")
    if not isinstance(payload.get("provenance_refs"), list) or not payload.get("provenance_refs"):
        if "provenance_refs" not in missing:
            missing.append("non_empty_provenance_refs")
    same_domain = source["domain"] == target["domain"]
    target_supports_domain = domain == target["domain"]
    return {
        "source_domain": source["domain"], "target_domain": target["domain"],
        "declared_evidence_domain": domain,
        "same_domain_transfer": same_domain,
        "target_domain_match": target_supports_domain,
        "required_fields_missing": missing,
        "compatible_for_review": not missing,
        "scientific_reuse_allowed": False,
        "review_required": True,
        "warnings": [
            "Cross-domain transfer does not imply model applicability.",
            "Destination scientists must review methods, units, conditions, and provenance.",
            "Acceptance does not authorize experiment execution or model training.",
        ],
    }


def propose_transfer(db: Session, payload: dict) -> CrossLabTransfer:
    if payload["source_laboratory"] == payload["target_laboratory"]:
        raise ValueError("A cross-laboratory transfer requires different source and target laboratories")
    report = assess_transfer(payload["source_laboratory"], payload["target_laboratory"], payload["domain"], payload["payload"])
    transfer = CrossLabTransfer(
        id=str(uuid4()), source_laboratory=payload["source_laboratory"],
        target_laboratory=payload["target_laboratory"], subject_type=payload["subject_type"],
        subject_id=payload["subject_id"], domain=payload["domain"],
        schema_version=payload.get("schema_version", "1.0.0"),
        compatibility_report=report, transfer_payload=payload["payload"],
        status="awaiting_review" if report["compatible_for_review"] else "blocked",
        synthetic=bool(payload.get("synthetic", True)),
    )
    db.add(transfer)
    db.flush()
    record_event(db, "CROSS_LAB_TRANSFER_PROPOSED", "transfer", transfer.id,
                 actor="cross-lab-transfer", payload={"source": transfer.source_laboratory,
                 "target": transfer.target_laboratory, "compatible": report["compatible_for_review"]})
    return transfer


def decide_transfer(db: Session, transfer_id: str, *, decision: str, reviewer: str, note: str = "") -> CrossLabTransfer:
    transfer = db.get(CrossLabTransfer, transfer_id)
    if not transfer:
        raise KeyError(transfer_id)
    if transfer.status != "awaiting_review":
        raise ValueError("Only compatible transfers awaiting review can receive a decision")
    if not reviewer.strip():
        raise ValueError("A named reviewer is required")
    transfer.status = decision
    transfer.reviewed_by = reviewer
    transfer.compatibility_report = {**transfer.compatibility_report, "review_note": note,
                                     "scientific_reuse_allowed": False,
                                     "accepted_by_target_scientist": decision == "accepted"}
    record_event(db, "CROSS_LAB_TRANSFER_REVIEWED", "transfer", transfer.id, actor=reviewer,
                 payload={"decision": decision, "note": note})
    db.flush()
    return transfer
