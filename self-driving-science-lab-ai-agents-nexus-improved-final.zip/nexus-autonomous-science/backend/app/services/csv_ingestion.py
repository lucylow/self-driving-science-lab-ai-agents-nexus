"""Bounded CSV preview and quarantine pipeline for scientific measurement tables.

The parser produces a review packet; it never commits observations to the canonical
measurement store. A separate scientist decision is required for ingestion acceptance.
"""
from __future__ import annotations
import csv
import hashlib
import io
import json
import math
from typing import Any
from app.services.scientific_data_contracts import validate_measurement_contract
from app.services.quality_rules import default_quality_engine

MAX_BYTES = 20 * 1024 * 1024
MAX_ROWS = 50_000
REQUIRED_COLUMNS = {"sample_id", "property_name", "value", "unit", "origin", "synthetic"}
ALLOWED_ORIGINS = {"measured", "simulation", "prediction", "literature", "human_observation", "computational"}


def _parse_bool(value: str) -> bool:
    normalized = value.strip().lower()
    if normalized in {"true", "1", "yes"}: return True
    if normalized in {"false", "0", "no"}: return False
    raise ValueError("synthetic must be true or false")


def preview_measurement_csv(content: str | bytes, *, domain: str,
                            laboratory_code: str, source_name: str = "uploaded.csv",
                            maximum_rows: int = MAX_ROWS) -> dict[str, Any]:
    raw = content.encode("utf-8") if isinstance(content, str) else bytes(content)
    if len(raw) > MAX_BYTES:
        raise ValueError("CSV exceeds the 20 MB preview limit")
    if maximum_rows < 1 or maximum_rows > MAX_ROWS:
        raise ValueError("maximum_rows must be between 1 and 50,000")
    try:
        decoded = raw.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise ValueError("CSV must use UTF-8 encoding") from exc
    reader = csv.DictReader(io.StringIO(decoded, newline=""))
    if not reader.fieldnames:
        raise ValueError("CSV header row is missing")
    headers = [str(item).strip() for item in reader.fieldnames]
    if len(headers) != len(set(headers)):
        raise ValueError("CSV headers must be unique")
    missing = sorted(REQUIRED_COLUMNS - set(headers))
    if missing:
        raise ValueError(f"CSV is missing required columns: {', '.join(missing)}")
    if any(not item for item in headers):
        raise ValueError("CSV contains an empty header name")
    seen_hashes: set[str] = set()
    accepted_for_review, quarantine = [], []
    row_count = 0
    engine = default_quality_engine()
    for row_index, raw_row in enumerate(reader, start=2):
        row_count += 1
        if row_count > maximum_rows:
            raise ValueError(f"CSV exceeds configured row limit ({maximum_rows})")
        if None in raw_row:
            quarantine.append({"source_row": row_index, "reason_codes": ["column_count_mismatch"],
                               "raw_row": raw_row})
            continue
        row = {str(key).strip(): (value or "").strip() for key, value in raw_row.items()}
        try:
            value = float(row["value"])
            if not math.isfinite(value): raise ValueError("value must be finite")
            sample_id = row["sample_id"]
            if not sample_id: raise ValueError("sample_id is required")
            origin = row["origin"]
            if origin not in ALLOWED_ORIGINS: raise ValueError("unsupported measurement origin")
            synthetic = _parse_bool(row["synthetic"])
            context_raw = row.get("context_json", "{}") or "{}"
            context = json.loads(context_raw)
            if not isinstance(context, dict): raise ValueError("context_json must decode to an object")
            quality_status = row.get("quality_status", "pending") or "pending"
            normalized = {"sample_id": sample_id, "property_name": row["property_name"],
                          "value": value, "unit": row["unit"], "origin": origin,
                          "synthetic": synthetic, "quality_status": quality_status}
            quality = engine.evaluate(normalized)
            contract = validate_measurement_contract(property_name=row["property_name"], value=value,
                unit=row["unit"], domain=domain, context={**context, "sample_id": sample_id},
                origin=origin, synthetic=synthetic)
            row_hash = hashlib.sha256(json.dumps(row, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
            if row_hash in seen_hashes:
                quarantine.append({"source_row": row_index, "reason_codes": ["duplicate_row_hash"],
                                   "raw_row": row, "row_hash": row_hash})
                continue
            seen_hashes.add(row_hash)
            reasons = []
            if not contract["valid"]:
                reasons.extend(item["code"] for item in contract["issues"])
            if not quality["record_accepted"]:
                reasons.extend(item["rule_id"] for item in quality["failed_rules"] if item["severity"] in {"error", "critical"})
            packet = {"source_row": row_index, "row_hash": row_hash, "normalized_record": normalized,
                      "context": context, "contract_review": contract,
                      "quality_review": quality, "source_name": source_name,
                      "synthetic": synthetic, "ingestion_status": "awaiting_scientist_review"}
            if reasons:
                quarantine.append({"source_row": row_index, "reason_codes": sorted(set(reasons)),
                                   "packet": packet, "raw_row": row})
            else:
                accepted_for_review.append(packet)
        except (ValueError, TypeError, json.JSONDecodeError, KeyError) as exc:
            quarantine.append({"source_row": row_index, "reason_codes": ["parse_or_contract_error"],
                               "message": str(exc), "raw_row": row})
    if row_count == 0:
        raise ValueError("CSV contains a header but no data rows")
    return {"source_name": source_name, "laboratory_code": laboratory_code,
            "domain": domain, "source_sha256": hashlib.sha256(raw).hexdigest(),
            "row_count": row_count, "ready_for_review_count": len(accepted_for_review),
            "quarantine_count": len(quarantine), "ready_for_scientist_review": accepted_for_review,
            "quarantine": quarantine,
            "accepted_into_database": False,
            "training_eligible": False,
            "governance": {"automatic_acceptance": False, "scientist_review_required": True,
                           "raw_source_preserved_by_caller": True}}
