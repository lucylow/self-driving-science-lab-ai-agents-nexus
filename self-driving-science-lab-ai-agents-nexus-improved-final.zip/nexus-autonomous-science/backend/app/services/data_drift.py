"""Feature-distribution monitoring with explicit bins and deterministic PSI."""
from __future__ import annotations
from math import log, isfinite


def population_stability_index(reference: list[float], current: list[float], *, bins: int = 10,
                               epsilon: float = 1e-6) -> dict:
    if len(reference) < 10 or len(current) < 10:
        raise ValueError("At least ten values are required in each drift window")
    if bins < 2 or bins > 100:
        raise ValueError("bins must be between 2 and 100")
    if any(not isfinite(float(value)) for value in reference + current):
        raise ValueError("Drift analysis requires finite numeric values")
    ordered = sorted(float(value) for value in reference)
    boundaries = [ordered[round((len(ordered) - 1) * index / bins)] for index in range(1, bins)]
    def assign(values: list[float]) -> list[int]:
        counts = [0] * bins
        for value in values:
            index = 0
            while index < len(boundaries) and value > boundaries[index]:
                index += 1
            counts[index] += 1
        return counts
    ref_counts, cur_counts = assign(reference), assign(current)
    ref_total, cur_total = len(reference), len(current)
    contributions = []
    for left, right in zip(ref_counts, cur_counts):
        p = max(epsilon, left / ref_total)
        q = max(epsilon, right / cur_total)
        contributions.append((q - p) * log(q / p))
    psi = sum(contributions)
    if psi < 0.1:
        interpretation = "low_distribution_shift"
    elif psi < 0.25:
        interpretation = "moderate_distribution_shift_review"
    else:
        interpretation = "large_distribution_shift_investigate"
    return {"psi": psi, "interpretation": interpretation,
            "reference_count": ref_total, "current_count": cur_total,
            "bin_boundaries": boundaries,
            "reference_proportions": [count / ref_total for count in ref_counts],
            "current_proportions": [count / cur_total for count in cur_counts],
            "warning": "PSI is a monitoring heuristic, not a causal diagnosis or automatic model-retraining trigger."}


def monitor_feature_set(reference_features: dict[str, list[float]], current_features: dict[str, list[float]]) -> dict:
    missing = sorted(set(reference_features) - set(current_features))
    extra = sorted(set(current_features) - set(reference_features))
    reports = {}
    for name in sorted(set(reference_features) & set(current_features)):
        reports[name] = population_stability_index(reference_features[name], current_features[name])
    return {"schema_compatible": not missing and not extra,
            "missing_features": missing, "unexpected_features": extra,
            "feature_reports": reports,
            "model_action": "hold_for_review_if_shift_detected"}
