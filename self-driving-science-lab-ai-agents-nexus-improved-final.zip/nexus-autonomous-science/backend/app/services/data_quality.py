"""Scientific data validation primitives that retain original values and missingness."""

from dataclasses import dataclass, asdict
from math import isfinite
from typing import Any


@dataclass
class QualityResult:
    status: str
    checks: dict[str, str]
    score_components: dict[str, float]
    reasons: list[str]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def assess_measurement(measurement: dict[str, Any]) -> QualityResult:
    checks: dict[str, str] = {}
    reasons: list[str] = []
    value = measurement.get("value")
    unit = measurement.get("unit")
    sample_id = measurement.get("sample_id")
    origin = measurement.get("origin", "unknown")

    checks["numeric_value"] = "passed" if isinstance(value, (int, float)) and isfinite(float(value)) else "failed"
    if checks["numeric_value"] == "failed":
        reasons.append("Measurement value must be a finite numeric value.")
    checks["unit_present"] = "passed" if isinstance(unit, str) and unit.strip() else "failed"
    if checks["unit_present"] == "failed":
        reasons.append("Measurement unit is missing; the record cannot be interpreted safely.")
    checks["sample_identity"] = "passed" if isinstance(sample_id, str) and sample_id.strip() else "failed"
    if checks["sample_identity"] == "failed":
        reasons.append("Sample identity is missing; the record is not eligible for model training.")
    checks["origin_labeled"] = "passed" if origin in {"measured", "simulation", "prediction", "literature", "human_observation"} else "warning"
    if checks["origin_labeled"] == "warning":
        reasons.append("Origin is unknown. Predictions and measurements must remain distinct.")

    hard_failure = any(checks[key] == "failed" for key in ("numeric_value", "unit_present", "sample_identity"))
    if hard_failure:
        status = "quarantined"
    elif origin != "measured":
        status = "synthetic_or_derived"
    else:
        status = "preliminary"
    components = {
        "completeness": sum(v == "passed" for v in checks.values()) / max(len(checks), 1),
        "identity": 1.0 if checks["sample_identity"] == "passed" else 0.0,
        "interpretability": 1.0 if checks["unit_present"] == "passed" else 0.0,
    }
    return QualityResult(status=status, checks=checks, score_components=components, reasons=reasons)


def dataset_quality_summary(records: list[dict[str, Any]]) -> dict[str, Any]:
    if not records:
        return {"records": 0, "accepted": 0, "quarantined": 0, "synthetic": 0, "status": "empty"}
    assessments = [assess_measurement(record) for record in records]
    return {
        "records": len(records),
        "accepted": sum(item.status in {"preliminary", "synthetic_or_derived"} for item in assessments),
        "quarantined": sum(item.status == "quarantined" for item in assessments),
        "synthetic": sum(record.get("origin") != "measured" for record in records),
        "status": "review_required" if any(item.status == "quarantined" for item in assessments) else "preliminary",
    }
