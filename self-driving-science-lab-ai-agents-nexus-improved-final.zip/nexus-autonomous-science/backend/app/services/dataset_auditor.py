"""Pre-training dataset audits for leakage, duplicate identities and quality drift."""
from __future__ import annotations
from collections import Counter, defaultdict
from typing import Any
import math
from app.services.data_drift import population_stability_index


def audit_training_records(records: list[dict[str, Any]], *, feature_names: list[str],
                           target_name: str, group_name: str = "sample_id",
                           maximum_missing_fraction: float = 0.05) -> dict[str, Any]:
    if not records:
        raise ValueError("dataset audit requires at least one record")
    if not feature_names or len(set(feature_names)) != len(feature_names):
        raise ValueError("feature names must be non-empty and unique")
    if not 0 <= maximum_missing_fraction < 1:
        raise ValueError("maximum missing fraction must be in [0, 1)")
    issues = []; counts = Counter(); group_to_rows: dict[str, list[int]] = defaultdict(list)
    target_values = []; synthetic_count = 0; origins = Counter(); units = Counter()
    feature_missing = {name: 0 for name in feature_names}
    duplicate_record_count = 0; seen = set()
    for index, record in enumerate(records):
        group = str(record.get(group_name, "")).strip()
        if not group: issues.append({"row": index, "code": "missing_group_identity"})
        else: group_to_rows[group].append(index)
        if record.get("synthetic") is True: synthetic_count += 1
        origins[str(record.get("origin", "unknown"))] += 1
        units[str(record.get("unit", "unknown"))] += 1
        value = record.get(target_name)
        try:
            numeric_target = float(value)
            if not math.isfinite(numeric_target): raise ValueError
            target_values.append(numeric_target)
        except (TypeError, ValueError):
            issues.append({"row": index, "code": "invalid_target"})
        for name in feature_names:
            item = record.get(name)
            try:
                numeric = float(item)
                if not math.isfinite(numeric): raise ValueError
            except (TypeError, ValueError):
                feature_missing[name] += 1
        canonical = tuple((key, repr(record.get(key))) for key in sorted(record))
        if canonical in seen: duplicate_record_count += 1
        seen.add(canonical)
    missing_fraction = {name: count/len(records) for name, count in feature_missing.items()}
    for name, fraction in missing_fraction.items():
        if fraction > maximum_missing_fraction:
            issues.append({"code": "feature_missingness_exceeds_limit", "feature": name, "fraction": fraction})
    repeated_groups = {group: rows for group, rows in group_to_rows.items() if len(rows) > 1}
    if synthetic_count:
        issues.append({"code": "synthetic_rows_present", "count": synthetic_count})
    if duplicate_record_count:
        issues.append({"code": "duplicate_records", "count": duplicate_record_count})
    if len(units) > 1:
        issues.append({"code": "mixed_units_require_normalization", "units": dict(units)})
    if len(origins) > 1:
        issues.append({"code": "mixed_origins_require_separate_review", "origins": dict(origins)})
    return {"row_count": len(records), "unique_group_count": len(group_to_rows),
            "repeated_group_count": len(repeated_groups),
            "repeated_groups": {key: value for key, value in sorted(repeated_groups.items())},
            "target_valid_count": len(target_values), "feature_missing_fraction": missing_fraction,
            "duplicate_record_count": duplicate_record_count, "synthetic_row_count": synthetic_count,
            "origin_counts": dict(origins), "unit_counts": dict(units),
            "target_range": [min(target_values), max(target_values)] if target_values else None,
            "issues": issues,
            "training_ready": not any(item["code"] in {"missing_group_identity", "invalid_target",
                "feature_missingness_exceeds_limit", "synthetic_rows_present", "mixed_units_require_normalization"}
                for item in issues),
            "note": "Repeated sample groups are expected but must stay within a single split."}


def audit_train_test_split(train_records: list[dict[str, Any]], test_records: list[dict[str, Any]], *,
                           group_name: str = "sample_id") -> dict[str, Any]:
    train_groups = {str(item.get(group_name, "")) for item in train_records}
    test_groups = {str(item.get(group_name, "")) for item in test_records}
    overlap = sorted((train_groups & test_groups) - {""})
    missing_train = sum(not str(item.get(group_name, "")).strip() for item in train_records)
    missing_test = sum(not str(item.get(group_name, "")).strip() for item in test_records)
    return {"valid": not overlap and missing_train == 0 and missing_test == 0,
            "sample_group_overlap": overlap, "overlap_count": len(overlap),
            "missing_group_train_rows": missing_train, "missing_group_test_rows": missing_test,
            "train_group_count": len(train_groups - {""}), "test_group_count": len(test_groups - {""}),
            "leakage_detected": bool(overlap or missing_train or missing_test)}


def compare_feature_distributions(reference: list[float], current: list[float], *, bins: int = 10) -> dict[str, Any]:
    result = population_stability_index(reference, current, bins=bins)
    value = float(result["psi"])
    if value < 0.1: level = "low"
    elif value < 0.25: level = "moderate"
    else: level = "high"
    return {**result, "drift_level": level,
            "automatic_model_update": False,
            "recommendation": "investigate_and_revalidate" if level != "low" else "continue_monitoring"}
