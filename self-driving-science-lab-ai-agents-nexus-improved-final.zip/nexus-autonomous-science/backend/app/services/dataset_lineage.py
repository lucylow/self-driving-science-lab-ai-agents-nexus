"""Append-only dataset transformation lineage and content identity helpers."""

from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from hashlib import sha256
import json
from typing import Any


@dataclass(frozen=True)
class TransformationRecord:
    transformation_id: str
    operation: str
    software_name: str
    software_version: str
    input_artifact_ids: tuple[str, ...]
    output_artifact_id: str
    parameters_hash: str
    created_at: str
    actor: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def canonical_hash(payload: Any) -> str:
    serialized = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)
    return sha256(serialized.encode("utf-8")).hexdigest()


def create_transformation_record(*, transformation_id: str, operation: str,
                                  software_name: str, software_version: str,
                                  input_artifact_ids: list[str], output_artifact_id: str,
                                  parameters: dict[str, Any], actor: str) -> TransformationRecord:
    if not transformation_id or not operation or not output_artifact_id:
        raise ValueError("Transformation identity, operation, and output artifact are required.")
    if not input_artifact_ids:
        raise ValueError("At least one input artifact is required for a derived scientific artifact.")
    if output_artifact_id in input_artifact_ids:
        raise ValueError("A transformation cannot overwrite one of its own source artifacts.")
    return TransformationRecord(
        transformation_id=transformation_id, operation=operation,
        software_name=software_name, software_version=software_version,
        input_artifact_ids=tuple(input_artifact_ids), output_artifact_id=output_artifact_id,
        parameters_hash=canonical_hash(parameters),
        created_at=datetime.now(timezone.utc).isoformat(), actor=actor,
    )


def validate_lineage(records: list[TransformationRecord]) -> dict[str, Any]:
    errors: list[str] = []
    outputs: set[str] = set()
    for record in records:
        if record.output_artifact_id in outputs:
            errors.append(f"Artifact {record.output_artifact_id} has multiple transformation writers.")
        outputs.add(record.output_artifact_id)
        if record.output_artifact_id in record.input_artifact_ids:
            errors.append(f"Transformation {record.transformation_id} is self-referential.")
        if len(set(record.input_artifact_ids)) != len(record.input_artifact_ids):
            errors.append(f"Transformation {record.transformation_id} repeats an input artifact.")
    return {
        "valid": not errors,
        "transformation_count": len(records),
        "derived_artifact_count": len(outputs),
        "errors": errors,
        "raw_artifacts_overwritten": False,
    }
