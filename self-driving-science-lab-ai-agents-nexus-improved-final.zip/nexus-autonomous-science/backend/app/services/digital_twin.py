"""Deterministic demo digital twin. Outputs are synthetic, not instrument observations."""

from hashlib import sha256
from random import Random


def simulate_experiment(experiment, candidate=None) -> dict:
    seed = int(sha256(experiment.id.encode()).hexdigest()[:8], 16)
    rng = Random(seed)
    base = (candidate.predicted_properties if candidate else {}) or {}
    conductivity = float(base.get("ionic_conductivity", 0.001 + rng.random() * 0.003))
    stability = float(base.get("stability_score", 65 + rng.random() * 20))
    return {
        "mode": "digital_twin_simulation",
        "evidence_type": "synthetic_simulation_output",
        "synthetic": True,
        "status": "completed",
        "measurements": [
            {"property": "ionic_conductivity", "value": round(conductivity * (0.92 + rng.random() * 0.16), 7), "unit": "S/cm", "uncertainty": round(conductivity * 0.08, 8)},
            {"property": "stability_score", "value": round(stability + rng.uniform(-3, 3), 2), "unit": "score/100", "uncertainty": 2.5},
        ],
        "twin_metadata": {
            "model_id": "nexus-sdl1-twin-demo",
            "model_version": "0.1.0",
            "validated_operating_range": "illustrative demo envelope only",
            "known_limitations": ["Not calibrated against a physical instrument", "Not suitable for experimental decisions"],
        },
    }


def twin_overview() -> dict:
    return {
        "mode": "simulation_only",
        "synchronized": True,
        "last_sync": "Demo clock · no hardware connected",
        "instrument_twins": 6,
        "workflow_twins": 8,
        "lab_twins": 1,
        "physical_control_enabled": False,
        "calibration_status": "demo_model_unvalidated",
        "warning": "A digital twin is a model, not a guarantee of physical behavior.",
    }
