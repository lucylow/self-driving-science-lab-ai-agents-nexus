"""Digital-twin validation against observations with domain and operating-range checks."""
from __future__ import annotations
from statistics import mean, pstdev
from app.services.model_intelligence.metrics import regression_metrics


def validate_twin_predictions(predicted: list[float], observed: list[float], *,
                              validation_domain: str, declared_domain: str,
                              calibrated_range: tuple[float, float] | None = None) -> dict:
    if len(predicted) != len(observed) or len(predicted) < 3:
        raise ValueError("At least three paired predictions and observations are required")
    if validation_domain != declared_domain:
        return {"valid_for_domain": False, "reason": "domain_mismatch",
                "metrics": None, "deployment_recommendation": "block"}
    if calibrated_range:
        lower, upper = calibrated_range
        outside = [index for index, value in enumerate(observed) if not lower <= float(value) <= upper]
    else:
        outside = []
    metrics = regression_metrics(observed, predicted)
    residuals = [float(actual) - float(estimate) for actual, estimate in zip(observed, predicted)]
    bias = mean(residuals)
    spread = pstdev(residuals)
    out_of_range = bool(outside)
    return {
        "valid_for_domain": True,
        "paired_count": len(predicted),
        "metrics": metrics,
        "residual_bias": bias,
        "residual_standard_deviation": spread,
        "outside_declared_range_indices": outside,
        "calibration_range_status": "outside_range_review" if out_of_range else "within_declared_range" if calibrated_range else "not_declared",
        "deployment_recommendation": "hold_for_review" if out_of_range else "research_validation_only",
        "physical_control_authorized": False,
        "warning": "Agreement on a validation set does not guarantee safe transfer to unseen conditions.",
    }
