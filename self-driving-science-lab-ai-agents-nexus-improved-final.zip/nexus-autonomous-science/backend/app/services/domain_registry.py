"""Domain-specific scientific capability descriptors for SDL0–SDL7."""

from copy import deepcopy
from typing import Any

DOMAIN_REGISTRY: dict[str, dict[str, Any]] = {
    "SDL0": {
        "domain": "autonomous_systems",
        "disciplines": ["agent evaluation", "robotics simulation", "instrument interoperability", "reliability engineering"],
        "modalities": ["tabular", "timeseries", "image", "text", "robot_telemetry"],
        "quality_gates": ["benchmark_reference", "permission_check", "simulation_acceptance", "operator_review"],
    },
    "SDL1": {
        "domain": "inorganic_materials",
        "disciplines": ["electronic structure", "defect chemistry", "crystal structures", "ionic transport", "electrochemistry", "catalysis"],
        "modalities": ["composition", "crystal", "spectral", "tabular", "image", "timeseries"],
        "quality_gates": ["formula_validation", "phase_identification", "measurement_method", "temperature_metadata", "sample_provenance"],
    },
    "SDL2": {
        "domain": "organic_chemistry",
        "disciplines": ["molecular representations", "reaction mechanisms", "synthesis feasibility", "purification", "spectral assignment"],
        "modalities": ["molecular", "reaction_graph", "spectral", "tabular", "text"],
        "quality_gates": ["structure_validation", "reaction_context", "condition_metadata", "analytical_confirmation"],
    },
    "SDL3": {
        "domain": "medicinal_chemistry",
        "disciplines": ["target biology", "molecular recognition", "binding kinetics", "SAR", "assay evidence"],
        "modalities": ["molecular", "protein_structure", "assay_table", "image", "timeseries"],
        "quality_gates": ["assay_identity", "biological_replicates", "control_review", "docking_prediction_labeling"],
    },
    "SDL4": {
        "domain": "polymers",
        "disciplines": ["polymer architecture", "crystallization", "phase behavior", "rheology", "mechanics", "degradation"],
        "modalities": ["polymer_graph", "spectral", "image", "tabular", "timeseries"],
        "quality_gates": ["molecular_weight_context", "thermal_history", "test_geometry", "rheology_protocol"],
    },
    "SDL5": {
        "domain": "formulations",
        "disciplines": ["composition", "compatibility", "stability", "particle attributes", "batch consistency"],
        "modalities": ["composition", "image", "spectral", "tabular", "timeseries"],
        "quality_gates": ["component_identity", "batch_provenance", "storage_conditions", "stability_protocol"],
    },
    "SDL6": {
        "domain": "biological_systems",
        "disciplines": ["organoid models", "cellular signaling", "metabolism", "mechanobiology", "functional characterization"],
        "modalities": ["microscopy", "image_sequence", "assay_table", "timeseries", "biochemical"],
        "quality_gates": ["model_provenance", "culture_conditions", "biosafety_review", "independent_replication"],
    },
    "SDL7": {
        "domain": "process_engineering",
        "disciplines": ["reaction kinetics", "mixing", "heat transfer", "mass transfer", "process telemetry", "scale-up"],
        "modalities": ["timeseries", "sensor_stream", "tabular", "process_graph", "image"],
        "quality_gates": ["sensor_calibration", "clock_alignment", "process_boundary_conditions", "scale_relevance"],
    },
}


def list_domains() -> list[dict[str, Any]]:
    return [{"laboratory_code": code, **deepcopy(spec)} for code, spec in DOMAIN_REGISTRY.items()]


def get_domain(laboratory_code: str) -> dict[str, Any]:
    code = laboratory_code.upper()
    if code not in DOMAIN_REGISTRY:
        raise KeyError(f"Unknown laboratory code: {laboratory_code}")
    return {"laboratory_code": code, **deepcopy(DOMAIN_REGISTRY[code])}


def validate_domain_payload(laboratory_code: str, payload: dict[str, Any]) -> dict[str, Any]:
    domain = get_domain(laboratory_code)
    modality = payload.get("modality")
    missing = [field for field in domain["quality_gates"] if payload.get("quality_gates", {}).get(field) is not True]
    modality_supported = modality in domain["modalities"]
    return {
        "laboratory_code": domain["laboratory_code"],
        "domain": domain["domain"],
        "modality_supported": modality_supported,
        "required_gates_missing": missing,
        "review_required": bool(missing) or not modality_supported,
        "accepted_for_scientific_conclusion": False,
    }
