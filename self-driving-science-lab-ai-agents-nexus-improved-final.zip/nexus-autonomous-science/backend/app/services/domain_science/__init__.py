"""Domain-specific, auditable scientific calculations for the NEXUS laboratories.

These functions operate on supplied observations. They do not control equipment,
create measurements, or replace domain-expert review. Every output is a derived
computational artifact and should be stored with source lineage by callers.
"""

from .electrochemistry import (
    calculate_conductivity,
    summarize_eis_spectrum,
    fit_arrhenius_conductivity,
)
from .diffraction import bragg_d_spacing, compare_xrd_peaks, estimate_lattice_cubic
from .battery import summarize_galvanostatic_cycle, calculate_energy_density, summarize_cycle_life
from .polymer import calculate_polydispersity, calculate_crystallinity, analyze_tensile_curve
from .spectroscopy import baseline_correct, normalize_spectrum, detect_peaks, integrate_spectrum
from .kinetics import fit_first_order_decay, calculate_mass_balance
from .formulation import validate_mixture, calculate_blend_property
from .morphology import analyze_binary_mask, summarize_morphology_batch
from .replicates import summarize_replicates, compare_replicate_groups

__all__ = [
    "calculate_conductivity", "summarize_eis_spectrum", "fit_arrhenius_conductivity",
    "bragg_d_spacing", "compare_xrd_peaks", "estimate_lattice_cubic",
    "summarize_galvanostatic_cycle", "calculate_energy_density", "summarize_cycle_life",
    "calculate_polydispersity", "calculate_crystallinity", "analyze_tensile_curve",
    "baseline_correct", "normalize_spectrum", "detect_peaks", "integrate_spectrum",
    "fit_first_order_decay", "calculate_mass_balance", "validate_mixture",
    "calculate_blend_property", "analyze_binary_mask", "summarize_morphology_batch",
    "summarize_replicates", "compare_replicate_groups",
]
