"""Transparent battery-test arithmetic for reviewed galvanostatic data."""
from __future__ import annotations
import math
from .numerics import finite_vector, paired_vectors, trapezoid_area


def summarize_galvanostatic_cycle(*, charge_capacity_mah_g: float, discharge_capacity_mah_g: float,
                                  cycle_index: int, charge_voltage_v: list[float] | None = None,
                                  charge_capacity_axis_mah_g: list[float] | None = None,
                                  discharge_voltage_v: list[float] | None = None,
                                  discharge_capacity_axis_mah_g: list[float] | None = None) -> dict:
    charge, discharge = float(charge_capacity_mah_g), float(discharge_capacity_mah_g)
    if cycle_index < 1 or charge <= 0 or discharge < 0 or not all(math.isfinite(x) for x in (charge, discharge)):
        raise ValueError("cycle index must be >=1; charge positive; discharge non-negative")
    efficiency = discharge / charge * 100
    energy = None
    if charge_voltage_v is not None and charge_capacity_axis_mah_g is not None:
        q, v = paired_vectors(charge_capacity_axis_mah_g, charge_voltage_v, min_points=2)
        energy = trapezoid_area(q, v)  # mWh/g, numerically equal to Wh/kg
        if any(b <= a for a, b in zip(q, q[1:])):
            raise ValueError("charge capacity axis must increase")
    discharge_energy = None
    if discharge_voltage_v is not None and discharge_capacity_axis_mah_g is not None:
        q, v = paired_vectors(discharge_capacity_axis_mah_g, discharge_voltage_v, min_points=2)
        if any(b <= a for a, b in zip(q, q[1:])):
            raise ValueError("discharge capacity axis must increase")
        discharge_energy = trapezoid_area(q, v)
    return {"cycle_index": cycle_index, "charge_capacity_mah_g": charge,
            "discharge_capacity_mah_g": discharge,
            "coulombic_efficiency_percent": efficiency,
            "charge_energy_wh_kg": energy, "discharge_energy_wh_kg": discharge_energy,
            "origin": "derived_computational_result",
            "limitations": ["Mass normalization and active-material basis must be documented.",
                            "This arithmetic does not establish cell safety or cycle-test validity."]}


def calculate_energy_density(voltage_v, capacity_mah_g) -> dict:
    v, q = paired_vectors(voltage_v, capacity_mah_g, min_points=2)
    if any(value < 0 for value in q) or any(value < 0 for value in v):
        raise ValueError("voltage and capacity must be non-negative")
    if any(b <= a for a, b in zip(q, q[1:])):
        raise ValueError("capacity axis must be strictly increasing")
    value = trapezoid_area(q, v)
    return {"specific_energy_wh_kg": value, "unit": "Wh/kg",
            "origin": "derived_computational_result",
            "note": "Integrates voltage against specific capacity; excludes packaging and inactive mass."}


def summarize_cycle_life(cycle_indices, discharge_capacities, *, reference_cycle: int = 1) -> dict:
    cycles, capacities = paired_vectors(cycle_indices, discharge_capacities, min_points=2)
    if any(value < 1 for value in cycles) or any(value < 0 for value in capacities):
        raise ValueError("cycle indices must be positive and capacities non-negative")
    if len(set(cycles)) != len(cycles):
        raise ValueError("cycle indices must be unique")
    ordered = sorted(zip(cycles, capacities))
    reference = next((cap for cycle, cap in ordered if cycle == reference_cycle), None)
    if reference is None or reference <= 0:
        raise ValueError("reference cycle is absent or has zero capacity")
    rows = [{"cycle": cycle, "capacity_mah_g": capacity,
             "retention_percent": capacity / reference * 100} for cycle, capacity in ordered]
    return {"reference_cycle": reference_cycle, "reference_capacity_mah_g": reference,
            "cycles": rows, "last_cycle_retention_percent": rows[-1]["retention_percent"],
            "origin": "derived_computational_result"}
