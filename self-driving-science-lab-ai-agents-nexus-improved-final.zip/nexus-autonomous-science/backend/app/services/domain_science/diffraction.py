"""Basic powder-diffraction geometry and transparent reference-peak comparison."""
from __future__ import annotations
import math


def bragg_d_spacing(two_theta_degrees: float, wavelength_angstrom: float, *, order: int = 1) -> dict:
    angle = float(two_theta_degrees) / 2.0
    wavelength = float(wavelength_angstrom)
    if not 0 < two_theta_degrees < 180 or wavelength <= 0 or order < 1:
        raise ValueError("2theta must be in (0, 180), wavelength positive, and order >= 1")
    sine = math.sin(math.radians(angle))
    if sine <= 0:
        raise ValueError("invalid Bragg angle")
    return {"d_spacing_angstrom": order * wavelength / (2 * sine),
            "two_theta_degrees": float(two_theta_degrees), "wavelength_angstrom": wavelength,
            "bragg_order": order, "equation": "n lambda = 2 d sin(theta)",
            "origin": "derived_computational_result"}


def estimate_lattice_cubic(d_spacings_angstrom, miller_indices) -> dict:
    ds = [float(x) for x in d_spacings_angstrom]
    hkls = [tuple(int(v) for v in hkl) for hkl in miller_indices]
    if len(ds) != len(hkls) or len(ds) < 2:
        raise ValueError("at least two paired d-spacings and Miller indices are required")
    if any(d <= 0 or not math.isfinite(d) for d in ds):
        raise ValueError("d-spacings must be finite and positive")
    estimates = []
    for d, hkl in zip(ds, hkls):
        if len(hkl) != 3 or sum(v * v for v in hkl) == 0:
            raise ValueError("each Miller index must be a non-zero triplet")
        estimates.append(d * math.sqrt(sum(v * v for v in hkl)))
    avg = sum(estimates) / len(estimates)
    residuals = [value - avg for value in estimates]
    rms = math.sqrt(sum(value * value for value in residuals) / len(residuals))
    return {"cubic_lattice_parameter_angstrom": avg,
            "standard_deviation_angstrom": math.sqrt(sum(v*v for v in residuals) / max(1, len(residuals)-1)),
            "rms_residual_angstrom": rms, "individual_estimates_angstrom": estimates,
            "origin": "derived_computational_result",
            "assumption": "cubic indexing supplied by the user; not an automated structure solution"}


def compare_xrd_peaks(observed_peaks, reference_peaks, *, tolerance_degrees: float = 0.2) -> dict:
    """Compare (2theta, intensity) lists; returns matched references, not phase proof."""
    if tolerance_degrees <= 0:
        raise ValueError("tolerance must be positive")
    observed = [(float(p[0]), float(p[1])) for p in observed_peaks]
    reference = [(float(p[0]), float(p[1])) for p in reference_peaks]
    if not observed or not reference:
        raise ValueError("observed and reference peak lists must be non-empty")
    if any(not math.isfinite(x) or not math.isfinite(y) or y < 0 for x, y in observed + reference):
        raise ValueError("peak values must be finite and intensities non-negative")
    matches, used = [], set()
    for angle, intensity in reference:
        options = [(abs(obs_angle-angle), idx, obs_angle, obs_intensity)
                   for idx, (obs_angle, obs_intensity) in enumerate(observed) if idx not in used]
        if options:
            error, idx, obs_angle, obs_intensity = min(options)
            if error <= tolerance_degrees:
                used.add(idx)
                matches.append({"reference_two_theta": angle, "observed_two_theta": obs_angle,
                                "absolute_error_degrees": error, "reference_intensity": intensity,
                                "observed_intensity": obs_intensity})
    score = len(matches) / len(reference)
    return {"matched_peak_count": len(matches), "reference_peak_count": len(reference),
            "unmatched_observed_peak_count": len(observed) - len(used),
            "reference_coverage": score, "matches": matches,
            "interpretation": "reference-pattern similarity only; not phase identification",
            "origin": "derived_computational_result"}
