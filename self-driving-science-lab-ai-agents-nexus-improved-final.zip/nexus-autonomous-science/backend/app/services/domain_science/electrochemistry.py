"""Electrochemical calculations for SDL1 and related energy workflows."""
from __future__ import annotations

import math
from .numerics import finite_vector, paired_vectors, linear_regression

BOLTZMANN_EV_PER_K = 8.617333262145e-5


def calculate_conductivity(*, resistance_ohm: float, thickness_cm: float,
                           area_cm2: float, resistance_uncertainty_ohm: float | None = None,
                           thickness_uncertainty_cm: float | None = None,
                           area_uncertainty_cm2: float | None = None) -> dict:
    """Calculate bulk conductivity using sigma = L / (R A).

    Inputs use centimetres, square centimetres, and ohms, yielding S/cm.
    Uncertainty is propagated as independent relative standard uncertainties.
    Contact resistance and geometric nonuniformity are not corrected here.
    """
    r, length, area = map(float, (resistance_ohm, thickness_cm, area_cm2))
    if not all(math.isfinite(v) for v in (r, length, area)) or r <= 0 or length <= 0 or area <= 0:
        raise ValueError("resistance, thickness and area must be finite and positive")
    sigma = length / (r * area)
    terms = []
    for uncertainty, value, label in (
        (resistance_uncertainty_ohm, r, "resistance"),
        (thickness_uncertainty_cm, length, "thickness"),
        (area_uncertainty_cm2, area, "area"),
    ):
        if uncertainty is not None:
            u = float(uncertainty)
            if not math.isfinite(u) or u < 0:
                raise ValueError(f"{label} uncertainty must be finite and non-negative")
            terms.append((u / value) ** 2)
    relative = math.sqrt(sum(terms)) if terms else None
    return {
        "value": sigma, "unit": "S/cm", "equation": "sigma = thickness / (resistance * area)",
        "standard_uncertainty": sigma * relative if relative is not None else None,
        "relative_standard_uncertainty": relative,
        "origin": "derived_computational_result", "limitations": [
            "Assumes uniform current density and a valid bulk-resistance estimate.",
            "Does not remove electrode/contact resistance or validate phase purity.",
        ],
    }


def summarize_eis_spectrum(frequency_hz, z_real_ohm, z_imag_ohm, *,
                           expected_frequency_range: tuple[float, float] | None = None) -> dict:
    """Validate and summarize impedance data without fitting an equivalent circuit."""
    f, zr = paired_vectors(frequency_hz, z_real_ohm, min_points=4)
    ff, zi = paired_vectors(frequency_hz, z_imag_ohm, min_points=4)
    if ff != f:
        raise ValueError("frequency arrays differ")
    if any(value <= 0 for value in f):
        raise ValueError("frequency must be positive")
    order = sorted(range(len(f)), key=lambda index: f[index], reverse=True)
    sorted_f = [f[index] for index in order]
    sorted_zr = [zr[index] for index in order]
    sorted_zi = [zi[index] for index in order]
    if len(set(sorted_f)) != len(sorted_f):
        raise ValueError("frequency values must be unique")
    flags = []
    if expected_frequency_range:
        lo, hi = expected_frequency_range
        if lo <= 0 or hi <= lo:
            raise ValueError("expected frequency range is invalid")
        if min(f) < lo or max(f) > hi:
            flags.append("frequency_outside_declared_range")
    if any(right >= left for left, right in zip(sorted_f, sorted_f[1:])):
        flags.append("frequency_order_check_failed")
    if any(not math.isfinite(v) for v in [*zr, *zi]):
        raise ValueError("impedance contains non-finite values")
    magnitude = [math.hypot(a, b) for a, b in zip(zr, zi)]
    return {
        "point_count": len(f), "frequency_min_hz": min(f), "frequency_max_hz": max(f),
        "high_frequency_real_ohm": sorted_zr[0], "low_frequency_real_ohm": sorted_zr[-1],
        "minimum_impedance_magnitude_ohm": min(magnitude),
        "maximum_impedance_magnitude_ohm": max(magnitude),
        "nyquist_imaginary_sign_changes": sum(1 for a, b in zip(sorted_zi, sorted_zi[1:]) if a * b < 0),
        "quality_flags": flags,
        "interpretation": "summary_only; no equivalent-circuit fit was performed",
        "origin": "derived_computational_result",
    }


def fit_arrhenius_conductivity(temperature_k, conductivity_s_cm, *,
                               conductivity_times_temperature: bool = True) -> dict:
    """Fit ln(sigma*T) versus 1/T (or ln(sigma) when explicitly requested)."""
    t, sigma = paired_vectors(temperature_k, conductivity_s_cm, min_points=3)
    if any(value <= 0 for value in t) or any(value <= 0 for value in sigma):
        raise ValueError("temperature and conductivity must be positive")
    y = [math.log(s * temp if conductivity_times_temperature else s) for temp, s in zip(t, sigma)]
    x = [1.0 / value for value in t]
    fit = linear_regression(x, y)
    activation = -fit["slope"] * BOLTZMANN_EV_PER_K
    return {
        **fit, "activation_energy_ev": activation,
        "pre_exponential_factor": math.exp(fit["intercept"]),
        "dependent_variable": "ln(sigma*T)" if conductivity_times_temperature else "ln(sigma)",
        "origin": "derived_computational_result",
        "limitations": ["Arrhenius linearity is an assumption, not a mechanism proof.",
                        "Use only temperatures in a comparable phase and measurement regime."],
    }
