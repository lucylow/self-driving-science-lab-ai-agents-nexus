"""Mixture validation and ideal linear blend calculations for SDL5."""
from __future__ import annotations
import math


def validate_mixture(components: list[dict], *, tolerance: float = 1e-6) -> dict:
    if not components:
        raise ValueError("at least one component is required")
    names, fractions = [], []
    for item in components:
        name = str(item.get("name", "")).strip()
        fraction = float(item.get("fraction", -1))
        if not name or not math.isfinite(fraction) or fraction < 0:
            raise ValueError("each component needs a name and finite non-negative fraction")
        names.append(name); fractions.append(fraction)
    if len(set(names)) != len(names):
        raise ValueError("component names must be unique")
    total = sum(fractions)
    deviation = abs(total - 1.0)
    return {"valid": deviation <= tolerance, "component_count": len(components),
            "fraction_sum": total, "deviation_from_unity": deviation,
            "normalized_fractions": [value / total for value in fractions] if total > 0 else [],
            "normalization_applied": False,
            "note": "Reported fractions are not silently normalized."}


def calculate_blend_property(components: list[dict], *, property_key: str) -> dict:
    validation = validate_mixture(components)
    if not validation["valid"]:
        raise ValueError("mixture fractions must sum to one within declared tolerance")
    values = []
    for item in components:
        if property_key not in item:
            raise ValueError(f"component {item['name']} is missing property {property_key}")
        value = float(item[property_key])
        if not math.isfinite(value):
            raise ValueError("component property must be finite")
        values.append(float(item["fraction"]) * value)
    return {"property": property_key, "ideal_linear_blend_value": sum(values),
            "contributions": values, "origin": "derived_computational_result",
            "limitations": ["Assumes ideal linear mixing.",
                            "Interactions, phase separation and nonlinear mixing are not represented."]}
