"""Introductory kinetic and material-balance calculations."""
from __future__ import annotations
import math
from .numerics import paired_vectors, linear_regression


def fit_first_order_decay(time_s, concentration) -> dict:
    t, c = paired_vectors(time_s, concentration, min_points=3)
    if any(v < 0 for v in t) or any(v <= 0 for v in c):
        raise ValueError("time must be non-negative and concentrations positive")
    if any(b <= a for a, b in zip(t, t[1:])):
        raise ValueError("time values must be strictly increasing")
    fit = linear_regression(t, [math.log(value) for value in c])
    k = -fit["slope"]
    if k <= 0:
        return {**fit, "rate_constant_s_inv": k, "half_life_s": None,
                "fit_status": "not_decay_or_incompatible_with_first_order_model",
                "origin": "derived_computational_result"}
    return {**fit, "rate_constant_s_inv": k, "half_life_s": math.log(2) / k,
            "fit_status": "first_order_model_fit", "origin": "derived_computational_result",
            "limitation": "A good linear fit does not establish the underlying reaction mechanism."}


def calculate_mass_balance(*, inlet_mass_g: float, outlet_mass_g: float,
                           accumulated_mass_g: float = 0.0, generated_mass_g: float = 0.0,
                           consumed_mass_g: float = 0.0) -> dict:
    values = [float(inlet_mass_g), float(outlet_mass_g), float(accumulated_mass_g),
              float(generated_mass_g), float(consumed_mass_g)]
    if any(not math.isfinite(v) or v < 0 for v in values):
        raise ValueError("mass terms must be finite and non-negative")
    inlet, outlet, accumulation, generated, consumed = values
    left = inlet + generated
    right = outlet + accumulation + consumed
    total = max(left, right, 1e-12)
    closure = 1 - abs(left - right) / total
    return {"inlet_mass_g": inlet, "outlet_mass_g": outlet,
            "accumulated_mass_g": accumulation, "generated_mass_g": generated,
            "consumed_mass_g": consumed, "mass_balance_closure_fraction": closure,
            "imbalance_g": left - right, "origin": "derived_computational_result"}
