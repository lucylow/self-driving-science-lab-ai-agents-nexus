"""Two-dimensional binary-mask morphometry for SDL6 and microscopy workflows."""
from __future__ import annotations
import math


def analyze_binary_mask(mask: list[list[int | bool]], *, pixel_size: float = 1.0,
                        perimeter_connectivity: int = 8) -> dict:
    if not mask or not mask[0] or any(len(row) != len(mask[0]) for row in mask):
        raise ValueError("mask must be a non-empty rectangular matrix")
    if perimeter_connectivity not in (4, 8):
        raise ValueError("perimeter connectivity must be 4 or 8")
    scale = float(pixel_size)
    if not math.isfinite(scale) or scale <= 0:
        raise ValueError("pixel size must be finite and positive")
    height, width = len(mask), len(mask[0])
    foreground = {(r, c) for r, row in enumerate(mask) for c, value in enumerate(row) if bool(value)}
    if not foreground:
        return {"area_pixels": 0, "area": 0.0, "perimeter_pixels": 0,
                "circularity": None, "equivalent_diameter": 0.0,
                "bounding_box_pixels": None, "origin": "derived_computational_result"}
    perimeter = 0
    neighbours = ((-1, 0), (1, 0), (0, -1), (0, 1))
    for r, c in foreground:
        perimeter += sum((r + dr, c + dc) not in foreground for dr, dc in neighbours)
    rows = [point[0] for point in foreground]; cols = [point[1] for point in foreground]
    area_pixels = len(foreground); area = area_pixels * scale * scale
    perimeter_scaled = perimeter * scale
    circularity = 4 * math.pi * area_pixels / (perimeter * perimeter) if perimeter else None
    equivalent_diameter = 2 * math.sqrt(area / math.pi)
    return {"area_pixels": area_pixels, "area": area,
            "perimeter_pixels_4_connectivity": perimeter,
            "perimeter": perimeter_scaled, "circularity": circularity,
            "equivalent_diameter": equivalent_diameter,
            "bounding_box_pixels": {"x_min": min(cols), "x_max": max(cols),
                                    "y_min": min(rows), "y_max": max(rows)},
            "image_dimensions_pixels": {"width": width, "height": height},
            "origin": "derived_computational_result",
            "limitations": ["Binary mask quality controls all derived morphology.",
                            "Pixel perimeter is a grid estimate, not a sub-pixel contour fit."]}


def summarize_morphology_batch(masks: list[list[list[int | bool]]], *, pixel_size: float = 1.0) -> dict:
    if not masks:
        raise ValueError("at least one mask is required")
    records = [analyze_binary_mask(mask, pixel_size=pixel_size) for mask in masks]
    areas = [float(item["area"]) for item in records]
    mean_area = sum(areas) / len(areas)
    return {"object_count": len(records), "mean_area": mean_area,
            "area_range": [min(areas), max(areas)], "objects": records,
            "origin": "derived_computational_result",
            "note": "Objects are assumed to be separate masks; touching-object segmentation is upstream."}
