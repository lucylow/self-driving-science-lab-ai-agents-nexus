"""Small numerical primitives with explicit finite-value and shape checks.

The routines intentionally avoid hidden unit conversions. Inputs must already use
consistent units; output metadata records the assumptions made by each analysis.
"""
from __future__ import annotations

import math
from statistics import mean, median, stdev
from typing import Iterable, Sequence


def finite_vector(values: Iterable[float], *, name: str, minimum: int = 2) -> list[float]:
    result = [float(value) for value in values]
    if len(result) < minimum:
        raise ValueError(f"{name} requires at least {minimum} values")
    if any(not math.isfinite(value) for value in result):
        raise ValueError(f"{name} contains a non-finite value")
    return result


def paired_vectors(x: Iterable[float], y: Iterable[float], *, min_points: int = 2) -> tuple[list[float], list[float]]:
    xx = finite_vector(x, name="x", minimum=min_points)
    yy = finite_vector(y, name="y", minimum=min_points)
    if len(xx) != len(yy):
        raise ValueError("x and y must have equal lengths")
    return xx, yy


def linear_regression(x: Sequence[float], y: Sequence[float]) -> dict[str, float]:
    xx, yy = paired_vectors(x, y, min_points=3)
    xbar, ybar = mean(xx), mean(yy)
    denominator = sum((value - xbar) ** 2 for value in xx)
    if denominator <= 1e-18:
        raise ValueError("x values do not span a measurable range")
    slope = sum((a - xbar) * (b - ybar) for a, b in zip(xx, yy)) / denominator
    intercept = ybar - slope * xbar
    fitted = [intercept + slope * value for value in xx]
    residuals = [observed - predicted for observed, predicted in zip(yy, fitted)]
    ss_res = sum(value * value for value in residuals)
    ss_tot = sum((value - ybar) ** 2 for value in yy)
    r_squared = 1.0 - ss_res / ss_tot if ss_tot > 1e-18 else 1.0
    residual_sd = math.sqrt(ss_res / max(1, len(xx) - 2))
    slope_se = residual_sd / math.sqrt(denominator)
    return {
        "slope": slope,
        "intercept": intercept,
        "r_squared": r_squared,
        "residual_standard_deviation": residual_sd,
        "slope_standard_error": slope_se,
        "n": float(len(xx)),
    }


def trapezoid_area(x: Sequence[float], y: Sequence[float]) -> float:
    xx, yy = paired_vectors(x, y, min_points=2)
    if any(right <= left for left, right in zip(xx, xx[1:])):
        raise ValueError("x values must be strictly increasing")
    return sum((xx[i + 1] - xx[i]) * (yy[i] + yy[i + 1]) / 2 for i in range(len(xx) - 1))


def percentile(values: Sequence[float], fraction: float) -> float:
    data = sorted(finite_vector(values, name="values", minimum=1))
    if not 0 <= fraction <= 1:
        raise ValueError("fraction must be between 0 and 1")
    if len(data) == 1:
        return data[0]
    position = fraction * (len(data) - 1)
    lower = int(math.floor(position))
    upper = int(math.ceil(position))
    weight = position - lower
    return data[lower] * (1 - weight) + data[upper] * weight


def robust_summary(values: Sequence[float]) -> dict[str, float | int | None]:
    data = finite_vector(values, name="values", minimum=1)
    avg = mean(data)
    sd = stdev(data) if len(data) > 1 else 0.0
    med = median(data)
    mad = median([abs(value - med) for value in data])
    return {
        "n": len(data), "mean": avg, "median": med, "standard_deviation": sd,
        "standard_error": sd / math.sqrt(len(data)) if len(data) > 1 else None,
        "coefficient_of_variation": abs(sd / avg) if abs(avg) > 1e-15 else None,
        "minimum": min(data), "maximum": max(data), "q25": percentile(data, .25),
        "q75": percentile(data, .75), "median_absolute_deviation": mad,
    }
