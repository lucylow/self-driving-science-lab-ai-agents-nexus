"""Polymer characterization calculations for SDL4."""
from __future__ import annotations
import math
from .numerics import paired_vectors, linear_regression


def calculate_polydispersity(number_average_molar_mass: float, weight_average_molar_mass: float) -> dict:
    mn, mw = float(number_average_molar_mass), float(weight_average_molar_mass)
    if not math.isfinite(mn) or not math.isfinite(mw) or mn <= 0 or mw <= 0:
        raise ValueError("molar masses must be finite and positive")
    return {"number_average_molar_mass": mn, "weight_average_molar_mass": mw,
            "dispersity": mw / mn, "origin": "derived_computational_result",
            "note": "Input molar masses must use the same units and analytical basis."}


def calculate_crystallinity(*, melting_enthalpy_j_g: float, reference_enthalpy_j_g: float,
                             polymer_mass_fraction: float = 1.0) -> dict:
    measured, reference, fraction = map(float, (melting_enthalpy_j_g, reference_enthalpy_j_g, polymer_mass_fraction))
    if not all(math.isfinite(x) for x in (measured, reference, fraction)) or measured < 0 or reference <= 0 or not 0 < fraction <= 1:
        raise ValueError("enthalpies must be valid and polymer mass fraction in (0, 1]")
    percent = measured / (reference * fraction) * 100
    return {"crystallinity_percent": percent, "melting_enthalpy_j_g": measured,
            "reference_enthalpy_j_g": reference, "polymer_mass_fraction": fraction,
            "origin": "derived_computational_result",
            "limitations": ["Reference enthalpy is material-specific.",
                            "Cold crystallization and multiple melting events require explicit correction."]}


def analyze_tensile_curve(*, extension_mm, force_n, initial_length_mm: float,
                          cross_section_mm2: float, elastic_strain_limit: float = 0.01) -> dict:
    extension, force = paired_vectors(extension_mm, force_n, min_points=4)
    length, area = float(initial_length_mm), float(cross_section_mm2)
    if length <= 0 or area <= 0 or elastic_strain_limit <= 0:
        raise ValueError("geometry and elastic range must be positive")
    if any(b < a for a, b in zip(extension, extension[1:])):
        raise ValueError("extension must be monotonic non-decreasing")
    strain = [value / length for value in extension]
    stress = [value / area for value in force]  # N/mm2 = MPa
    elastic = [(eps, sig) for eps, sig in zip(strain, stress) if 0 <= eps <= elastic_strain_limit]
    if len(elastic) < 3:
        raise ValueError("at least three points are required inside the declared elastic strain range")
    fit = linear_regression([x[0] for x in elastic], [x[1] for x in elastic])
    max_index = max(range(len(stress)), key=stress.__getitem__)
    return {"young_modulus_mpa": fit["slope"], "elastic_fit_r_squared": fit["r_squared"],
            "maximum_engineering_stress_mpa": stress[max_index],
            "strain_at_maximum_stress": strain[max_index],
            "engineering_strain": strain, "engineering_stress_mpa": stress,
            "origin": "derived_computational_result",
            "limitations": ["Cross-section is treated as constant.",
                            "Elastic range is user-declared; grip slip and machine compliance are not corrected."]}
