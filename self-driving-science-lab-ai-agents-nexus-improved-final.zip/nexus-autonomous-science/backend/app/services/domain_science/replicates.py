"""Replicate summaries and group comparisons without deleting outliers."""
from __future__ import annotations
from .numerics import robust_summary


def summarize_replicates(values, *, expected_unit: str | None = None,
                         observed_units: list[str] | None = None) -> dict:
    if observed_units is not None:
        if len(observed_units) != len(values):
            raise ValueError("unit list must match replicate count")
        if len(set(observed_units)) > 1:
            raise ValueError("replicates with mixed units cannot be combined")
        if expected_unit and observed_units and observed_units[0] != expected_unit:
            raise ValueError("replicate unit does not match expected unit")
    summary = robust_summary(values)
    return {**summary, "unit": expected_unit or (observed_units[0] if observed_units else None),
            "outlier_policy": "retain_all_values_and_report_robust_summary",
            "origin": "derived_computational_result"}


def compare_replicate_groups(groups: dict[str, list[float]]) -> dict:
    if len(groups) < 2:
        raise ValueError("at least two replicate groups are required")
    summaries = {name: robust_summary(values) for name, values in groups.items()}
    means = [float(item["mean"]) for item in summaries.values()]
    pooled_center = sum(means) / len(means)
    return {"groups": summaries, "between_group_mean_range": max(means) - min(means),
            "unweighted_group_mean": pooled_center,
            "interpretation": "descriptive comparison only; no inferential test performed",
            "origin": "derived_computational_result"}
