"""Signal-safe spectrum utilities for spectroscopy and diffraction traces."""
from __future__ import annotations
import math
from .numerics import paired_vectors, trapezoid_area


def _validate_axis(axis, signal):
    x, y = paired_vectors(axis, signal, min_points=3)
    if any(right <= left for left, right in zip(x, x[1:])):
        raise ValueError("spectral axis must be strictly increasing")
    return x, y


def baseline_correct(axis, intensity, *, method: str = "linear_endpoints") -> dict:
    x, y = _validate_axis(axis, intensity)
    if method != "linear_endpoints":
        raise ValueError("supported baseline method is linear_endpoints")
    span = x[-1] - x[0]
    left = y[0]
    right = y[-1]
    baseline = [left + (right - left) * (value - x[0]) / span for value in x]
    corrected = [value - background for value, background in zip(y, baseline)]
    return {"axis": x, "original_intensity": y, "baseline": baseline,
            "corrected_intensity": corrected, "method": method,
            "origin": "derived_computational_result",
            "warning": "Endpoint interpolation can remove broad real features; inspect before interpretation."}


def normalize_spectrum(intensity, *, method: str = "max_abs") -> dict:
    y = [float(value) for value in intensity]
    if len(y) < 2 or any(not math.isfinite(value) for value in y):
        raise ValueError("intensity requires at least two finite values")
    if method == "max_abs":
        scale = max(abs(value) for value in y)
    elif method == "area_abs":
        scale = sum(abs(value) for value in y)
    else:
        raise ValueError("normalization must be max_abs or area_abs")
    if scale <= 1e-15:
        raise ValueError("cannot normalize a zero spectrum")
    return {"normalized_intensity": [value / scale for value in y], "normalization_method": method,
            "normalization_scale": scale, "origin": "derived_computational_result"}


def detect_peaks(axis, intensity, *, minimum_prominence: float = 0.0,
                 minimum_distance_points: int = 1) -> dict:
    x, y = _validate_axis(axis, intensity)
    if minimum_prominence < 0 or minimum_distance_points < 1:
        raise ValueError("peak prominence must be non-negative and point distance >=1")
    candidates = []
    for i in range(1, len(y) - 1):
        if y[i] > y[i - 1] and y[i] >= y[i + 1]:
            prominence = y[i] - max(min(y[:i + 1]), min(y[i:]))
            if prominence >= minimum_prominence:
                candidates.append((i, prominence))
    candidates.sort(key=lambda item: item[1], reverse=True)
    selected = []
    for index, prominence in candidates:
        if all(abs(index - chosen[0]) >= minimum_distance_points for chosen in selected):
            selected.append((index, prominence))
    selected.sort()
    return {"peaks": [{"index": i, "axis_value": x[i], "intensity": y[i], "prominence": p}
                      for i, p in selected], "peak_count": len(selected),
            "origin": "derived_computational_result",
            "limitations": ["Local-maximum heuristic; not a fitted lineshape model.",
                            "Overlapping peaks and baseline uncertainty require expert review."]}


def integrate_spectrum(axis, intensity, *, lower: float | None = None,
                       upper: float | None = None, clip_negative: bool = False) -> dict:
    x, y = _validate_axis(axis, intensity)
    lo = x[0] if lower is None else float(lower)
    hi = x[-1] if upper is None else float(upper)
    if not x[0] <= lo < hi <= x[-1]:
        raise ValueError("integration bounds must lie inside axis and lower < upper")
    selected = [(xx, yy) for xx, yy in zip(x, y) if lo <= xx <= hi]
    if not selected or selected[0][0] != lo or selected[-1][0] != hi:
        # Linear interpolation makes explicit boundary points rather than silently excluding them.
        def interpolate(target):
            for (xa, ya), (xb, yb) in zip(zip(x, y), zip(x[1:], y[1:])):
                if xa <= target <= xb:
                    return ya + (yb - ya) * (target - xa) / (xb - xa)
            raise ValueError("bound not interpolable")
        selected = [(lo, interpolate(lo)), *selected, (hi, interpolate(hi))]
    sx, sy = [item[0] for item in selected], [item[1] for item in selected]
    if clip_negative:
        sy = [max(0.0, value) for value in sy]
    return {"area": trapezoid_area(sx, sy), "lower": lo, "upper": hi,
            "negative_values_clipped": clip_negative, "origin": "derived_computational_result"}
