"""Domain-specific data validation hooks for the eight NEXUS laboratories."""
from __future__ import annotations
from typing import Any
from app.services.model_intelligence.composition import parse_formula, FormulaError


def _required(payload: dict, fields: list[str]) -> list[str]:
    return [f"Missing required field '{field}'" for field in fields if payload.get(field) in (None, "", [])]


def validate_sdl0(payload: dict) -> dict:
    errors = _required(payload, ["agent_id", "benchmark_id", "benchmark_version"])
    if payload.get("permission_level") not in {"propose_only", "analyze", "simulate"}:
        errors.append("Agent permission level is not in the registered safe set")
    if payload.get("can_execute_physical") is True:
        errors.append("NEXUS agent services cannot declare physical execution authority")
    return {"valid": not errors, "errors": errors, "review_required": True}


def validate_sdl1(payload: dict) -> dict:
    errors = _required(payload, ["formula", "sample_id"])
    composition = None
    if payload.get("formula"):
        try:
            composition = parse_formula(payload["formula"])
        except FormulaError as exc:
            errors.append(str(exc))
    if payload.get("measurement_method") == "electrochemical_impedance_spectroscopy" and not payload.get("temperature_kelvin"):
        errors.append("Temperature metadata is required for this measurement context")
    return {"valid": not errors, "errors": errors, "parsed_composition": composition,
            "note": "Formula syntax does not prove phase purity, structure, stability or transport properties."}


def validate_sdl2(payload: dict) -> dict:
    errors = _required(payload, ["molecular_representation", "representation_type"])
    if payload.get("representation_type") not in {"smiles", "inchi", "molfile", "graph"}:
        errors.append("Unsupported molecular representation type")
    if payload.get("representation_type") == "smiles" and payload.get("molecular_representation"):
        # This is only a non-empty representation check. RDKit is the production parser.
        if any(char.isspace() for char in payload["molecular_representation"]):
            errors.append("SMILES text should not contain whitespace in this input contract")
    return {"valid": not errors, "errors": errors,
            "structure_validation": "adapter_required_rdkit_not_invoked"}


def validate_sdl3(payload: dict) -> dict:
    errors = _required(payload, ["target_id", "assay_id", "assay_method"])
    if payload.get("measurement_type") == "docking_score" and payload.get("evidence_origin") == "measured":
        errors.append("A docking score cannot be labelled as a measured binding affinity")
    if payload.get("assay_id") and not payload.get("biological_replicates"):
        errors.append("Biological replicate metadata is required for assay interpretation")
    return {"valid": not errors, "errors": errors,
            "clinical_claims_authorized": False}


def validate_sdl4(payload: dict) -> dict:
    errors = _required(payload, ["polymer_identity", "thermal_history", "test_method"])
    method = payload.get("test_method")
    method_fields = {
        "rheology": ["shear_rate_unit", "geometry", "temperature"],
        "tensile": ["specimen_geometry", "strain_rate", "conditioning"],
        "thermal": ["heating_rate", "atmosphere", "calibration_reference"],
    }
    errors.extend(_required(payload, method_fields.get(method, [])))
    return {"valid": not errors, "errors": errors}


def validate_sdl5(payload: dict) -> dict:
    errors = _required(payload, ["formulation_id", "components", "batch_id"])
    components = payload.get("components", [])
    if components and not isinstance(components, list):
        errors.append("components must be a list")
    elif components:
        for index, component in enumerate(components):
            if not isinstance(component, dict) or not component.get("component_id") or component.get("fraction") is None:
                errors.append(f"Component {index} requires component_id and fraction")
    if payload.get("fractions_sum") is not None and abs(float(payload["fractions_sum"]) - 1.0) > 1e-4:
        errors.append("Declared component fractions do not sum to one")
    return {"valid": not errors, "errors": errors}


def validate_sdl6(payload: dict) -> dict:
    errors = _required(payload, ["biological_model_id", "passage_or_generation", "culture_conditions", "biosafety_review_ref"])
    if payload.get("independent_replicate_count", 0) < 1:
        errors.append("At least one independent biological replicate reference is required")
    return {"valid": not errors, "errors": errors,
            "biological_material_handling_authorized": False}


def validate_sdl7(payload: dict) -> dict:
    errors = _required(payload, ["process_id", "sensor_calibration_ref", "boundary_conditions", "timebase_ref"])
    if payload.get("scale_factor") is not None and float(payload["scale_factor"]) <= 0:
        errors.append("scale_factor must be positive")
    return {"valid": not errors, "errors": errors,
            "scale_up_readiness": "not_determined_by_schema_validation"}


VALIDATORS = {"SDL0": validate_sdl0, "SDL1": validate_sdl1, "SDL2": validate_sdl2,
              "SDL3": validate_sdl3, "SDL4": validate_sdl4, "SDL5": validate_sdl5,
              "SDL6": validate_sdl6, "SDL7": validate_sdl7}


def validate_laboratory_record(laboratory_code: str, payload: dict[str, Any]) -> dict:
    code = laboratory_code.upper()
    if code not in VALIDATORS:
        raise KeyError(code)
    result = VALIDATORS[code](payload)
    return {"laboratory_code": code, "domain_validation": result,
            "physical_execution_authorized": False}
