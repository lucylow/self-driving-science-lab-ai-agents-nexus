"""Transactional outbox primitives with bounded retries and expiring delivery leases.

The database remains the source of truth. This module intentionally does not talk to
Kafka, NATS, RabbitMQ or an instrument bus; a deployment-specific broker adapter must
publish the returned envelopes and acknowledge them using the claim token.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any
from uuid import uuid4

from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.models.entities import OutboxEvent


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _payload(event: OutboxEvent) -> dict[str, Any]:
    """Return a copy of business payload without internal delivery metadata."""
    data = dict(event.payload or {})
    data.pop("_nexus_delivery", None)
    return data


def _delivery_meta(event: OutboxEvent) -> dict[str, Any]:
    return dict((event.payload or {}).get("_nexus_delivery") or {})


def _set_meta(event: OutboxEvent, **updates: Any) -> None:
    payload = dict(event.payload or {})
    meta = dict(payload.get("_nexus_delivery") or {})
    meta.update(updates)
    payload["_nexus_delivery"] = meta
    event.payload = payload


def enqueue_event(db: Session, *, event_key: str, aggregate_type: str, aggregate_id: str,
                  event_type: str, payload: dict) -> OutboxEvent:
    """Insert one event per key; concurrent duplicate inserts converge on the winner.

    This guarantees one durable outbox row per event_key, not exactly-once broker delivery.
    """
    if not event_key.strip():
        raise ValueError("event_key is required")
    if "_nexus_delivery" in payload:
        raise ValueError("_nexus_delivery is reserved for outbox delivery metadata")

    def existing_or_conflict(existing: OutboxEvent) -> OutboxEvent:
        same_event = (
            existing.aggregate_type == aggregate_type
            and existing.aggregate_id == aggregate_id
            and existing.event_type == event_type
            and _payload(existing) == payload
        )
        if not same_event:
            raise ValueError("event_key was reused with different event content")
        return existing

    lookup = select(OutboxEvent).where(OutboxEvent.event_key == event_key)
    existing = db.scalar(lookup)
    if existing:
        return existing_or_conflict(existing)
    event = OutboxEvent(
        id=str(uuid4()), event_key=event_key, aggregate_type=aggregate_type,
        aggregate_id=aggregate_id, event_type=event_type, payload=dict(payload),
        status="pending", attempts=0,
    )
    try:
        # The savepoint confines a concurrent unique-key violation to this insert, leaving
        # a caller's enclosing domain transaction usable and atomic.
        with db.begin_nested():
            db.add(event)
            db.flush()
    except IntegrityError:
        winner = db.scalar(lookup)
        if winner is None:
            raise
        return existing_or_conflict(winner)
    return event


def _eligible_for_claim(event: OutboxEvent, now: datetime) -> bool:
    if event.status == "pending":
        return True
    meta = _delivery_meta(event)
    if event.status == "delivery_failed":
        retry_at = meta.get("retry_at")
        if not retry_at:
            return True
        try:
            return datetime.fromisoformat(retry_at) <= now
        except (TypeError, ValueError):
            return True
    if event.status == "ready_for_delivery":
        expiry = meta.get("lease_expires_at")
        if not expiry:
            return True
        try:
            return datetime.fromisoformat(expiry) <= now
        except (TypeError, ValueError):
            return True
    return False


def _claim_event(event: OutboxEvent, *, now: datetime, lease_seconds: int,
                 max_attempts: int, base_backoff_seconds: int) -> dict[str, Any] | None:
    if not _eligible_for_claim(event, now):
        return None
    meta = _delivery_meta(event)
    policy_max_attempts = int(meta.get("max_attempts", max_attempts))
    if not 1 <= policy_max_attempts <= 20:
        policy_max_attempts = max_attempts
    policy_backoff = int(meta.get("base_backoff_seconds", base_backoff_seconds))
    if policy_backoff < 1:
        policy_backoff = base_backoff_seconds
    if event.attempts >= policy_max_attempts:
        event.status = "dead_letter"
        _set_meta(event, dead_lettered_at=now.isoformat(), max_attempts=policy_max_attempts)
        return None
    token = uuid4().hex
    event.status = "ready_for_delivery"
    event.attempts += 1
    expires_at = now + timedelta(seconds=lease_seconds)
    _set_meta(
        event, claim_token=token, claimed_at=now.isoformat(),
        lease_expires_at=expires_at.isoformat(), retry_at=None,
        max_attempts=policy_max_attempts, base_backoff_seconds=policy_backoff,
    )
    return {
        "id": event.id, "event_key": event.event_key,
        "aggregate_type": event.aggregate_type, "aggregate_id": event.aggregate_id,
        "event_type": event.event_type, "payload": _payload(event),
        "attempt": event.attempts, "claim_token": token,
        "lease_expires_at": expires_at.isoformat(),
    }


def prepare_event_for_delivery(db: Session, event_id: str, *, lease_seconds: int = 300,
                               max_attempts: int = 5,
                               base_backoff_seconds: int = 30) -> dict[str, Any]:
    """Claim one event by ID; useful for targeted retries and operator inspection."""
    if not 10 <= lease_seconds <= 3600:
        raise ValueError("lease_seconds must be between 10 and 3600")
    if not 1 <= max_attempts <= 20:
        raise ValueError("max_attempts must be between 1 and 20")
    event = db.scalar(select(OutboxEvent).where(OutboxEvent.id == event_id).with_for_update())
    if not event:
        raise KeyError(event_id)
    if event.status not in {"pending", "delivery_failed", "ready_for_delivery"}:
        raise ValueError(f"Event is not claimable from status '{event.status}'")
    envelope = _claim_event(event, now=_utcnow(), lease_seconds=lease_seconds,
                            max_attempts=max_attempts, base_backoff_seconds=base_backoff_seconds)
    if envelope is None:
        if event.status == "dead_letter":
            db.flush()
            raise ValueError("Event has reached its retry limit and was dead-lettered")
        raise ValueError("Event is not due for delivery or its current lease has not expired")
    db.flush()
    return envelope


def prepare_delivery_batch(db: Session, *, batch_size: int = 100,
                           lease_seconds: int = 300, max_attempts: int = 5,
                           base_backoff_seconds: int = 30) -> list[dict]:
    """Claim due events with expiring leases and return broker-ready envelopes.

    On PostgreSQL the row lock prevents multiple workers from claiming the same event.
    SQLite is supported for local tests but does not provide equivalent row-level locks.
    """
    if not 1 <= batch_size <= 500:
        raise ValueError("batch_size must be between 1 and 500")
    if not 10 <= lease_seconds <= 3600:
        raise ValueError("lease_seconds must be between 10 and 3600")
    if not 1 <= max_attempts <= 20:
        raise ValueError("max_attempts must be between 1 and 20")
    now = _utcnow()
    # Recover legacy/expired leases first; this keeps stale worker claims from blocking
    # the normal due-event scan indefinitely.
    requeue_expired_leases(db, max_attempts=max_attempts)
    candidates = db.scalars(
        select(OutboxEvent)
        .where(OutboxEvent.status.in_(["pending", "delivery_failed"]))
        .order_by(OutboxEvent.created_at.asc())
        .limit(5000)
        .with_for_update(skip_locked=True)
    ).all()
    output: list[dict] = []
    for event in candidates:
        if len(output) >= batch_size:
            break
        envelope = _claim_event(event, now=now, lease_seconds=lease_seconds,
                                max_attempts=max_attempts, base_backoff_seconds=base_backoff_seconds)
        if envelope is not None:
            output.append(envelope)
    db.flush()
    return output

def acknowledge_delivery(db: Session, event_id: str, *, success: bool,
                         error: str = "", claim_token: str | None = None,
                         max_attempts: int | None = None,
                         base_backoff_seconds: int = 30,
                         maximum_backoff_seconds: int = 3600) -> OutboxEvent:
    """Acknowledge a broker send; failures use capped exponential retry delays."""
    event = db.scalar(select(OutboxEvent).where(OutboxEvent.id == event_id).with_for_update())
    if not event:
        raise KeyError(event_id)
    if event.status != "ready_for_delivery":
        raise ValueError(f"Event cannot be acknowledged from status '{event.status}'")
    meta = _delivery_meta(event)
    effective_max_attempts = int(meta.get("max_attempts", max_attempts or 5))
    effective_backoff = int(meta.get("base_backoff_seconds", base_backoff_seconds))
    if not 1 <= effective_max_attempts <= 20:
        raise ValueError("max_attempts must be between 1 and 20")
    if effective_backoff < 1:
        raise ValueError("base_backoff_seconds must be positive")
    expected_token = meta.get("claim_token")
    if expected_token and claim_token != expected_token:
        raise ValueError("Claim token is missing or does not match the active delivery lease")
    now = _utcnow()
    lease_expiry = meta.get("lease_expires_at")
    if lease_expiry:
        try:
            expired = datetime.fromisoformat(lease_expiry) <= now
        except (TypeError, ValueError):
            expired = True
        if expired:
            raise ValueError("Delivery lease has expired; recover or reclaim the event before acknowledging")
    if success:
        event.status = "published"
        event.published_at = now
        event.last_error = ""
        _set_meta(event, claim_token=None, lease_expires_at=None,
                  published_acknowledged_at=now.isoformat(), retry_at=None)
    else:
        event.last_error = error[:2000]
        attempts = max(1, event.attempts)
        if attempts >= effective_max_attempts:
            event.status = "dead_letter"
            _set_meta(event, claim_token=None, lease_expires_at=None,
                      dead_lettered_at=now.isoformat(), retry_at=None,
                      max_attempts=effective_max_attempts)
        else:
            delay = min(maximum_backoff_seconds,
                        effective_backoff * (2 ** max(0, attempts - 1)))
            retry_at = now + timedelta(seconds=delay)
            event.status = "delivery_failed"
            _set_meta(event, claim_token=None, lease_expires_at=None,
                      retry_at=retry_at.isoformat(), next_retry_delay_seconds=delay,
                      max_attempts=effective_max_attempts)
    db.flush()
    return event


def requeue_expired_leases(db: Session, *, max_attempts: int = 5) -> dict[str, int]:
    """Recover events held by a worker that disappeared before acknowledgement."""
    now = _utcnow()
    rows = db.scalars(select(OutboxEvent).where(
        OutboxEvent.status == "ready_for_delivery").order_by(OutboxEvent.created_at.asc())).all()
    requeued = dead_lettered = unchanged = 0
    for event in rows:
        meta = _delivery_meta(event)
        expiry = meta.get("lease_expires_at")
        if expiry:
            try:
                expired = datetime.fromisoformat(expiry) <= now
            except ValueError:
                expired = True
        else:
            expired = True
        if not expired:
            unchanged += 1
            continue
        policy_max_attempts = int(meta.get("max_attempts", max_attempts))
        if not 1 <= policy_max_attempts <= 20:
            policy_max_attempts = max_attempts
        if event.attempts >= policy_max_attempts:
            event.status = "dead_letter"
            _set_meta(event, claim_token=None, lease_expires_at=None,
                      dead_lettered_at=now.isoformat(), max_attempts=policy_max_attempts)
            dead_lettered += 1
        else:
            event.status = "delivery_failed"
            retry_at = now
            _set_meta(event, claim_token=None, lease_expires_at=None,
                      retry_at=retry_at.isoformat(), recovery_reason="delivery_lease_expired")
            requeued += 1
    db.flush()
    return {"requeued": requeued, "dead_lettered": dead_lettered,
            "still_leased": unchanged}


def outbox_metrics(db: Session) -> dict[str, Any]:
    rows = db.execute(select(OutboxEvent.status, func.count()).group_by(OutboxEvent.status)).all()
    counts = {status: count for status, count in rows}
    total = sum(counts.values())
    published = counts.get("published", 0)
    return {
        "total": total, "by_status": counts,
        "published_fraction": published / total if total else 0.0,
        "dead_letter_count": counts.get("dead_letter", 0),
        "pending_count": counts.get("pending", 0) + counts.get("delivery_failed", 0),
        "delivery_adapter_configured": False,
        "notice": "Metrics describe database outbox state; no broker connection is configured by this starter.",
    }
