"""Command acknowledgement and idempotency ledger for future edge gateways."""

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from enum import Enum
from hashlib import sha256
from typing import Any


class Acknowledgement(str, Enum):
    received = "received"
    validated = "validated"
    accepted = "accepted"
    completed = "completed"
    rejected = "rejected"
    expired = "expired"


@dataclass
class InstrumentCommand:
    command_id: str
    experiment_id: str
    instrument_id: str
    operation: str
    payload: dict[str, Any]
    protocol_version: str
    authorization_ref: str | None
    idempotency_key: str
    expires_at: datetime
    acknowledgement: Acknowledgement = Acknowledgement.received
    result_ref: str | None = None

    @classmethod
    def create(cls, *, experiment_id: str, instrument_id: str, operation: str, payload: dict,
               protocol_version: str, authorization_ref: str | None, ttl_seconds: int = 60):
        raw = f"{experiment_id}|{instrument_id}|{operation}|{payload}|{protocol_version}"
        key = sha256(raw.encode()).hexdigest()
        now = datetime.now(timezone.utc)
        return cls(
            command_id=f"CMD-{key[:12].upper()}", experiment_id=experiment_id,
            instrument_id=instrument_id, operation=operation, payload=payload,
            protocol_version=protocol_version, authorization_ref=authorization_ref,
            idempotency_key=key, expires_at=now + timedelta(seconds=ttl_seconds),
        )


@dataclass
class CommandLedger:
    commands: dict[str, InstrumentCommand] = field(default_factory=dict)
    idempotency_index: dict[str, str] = field(default_factory=dict)

    def receive(self, command: InstrumentCommand) -> tuple[InstrumentCommand, bool]:
        known = self.idempotency_index.get(command.idempotency_key)
        if known:
            return self.commands[known], True
        self.commands[command.command_id] = command
        self.idempotency_index[command.idempotency_key] = command.command_id
        return command, False

    def advance(self, command_id: str, stage: Acknowledgement) -> InstrumentCommand:
        command = self.commands[command_id]
        if datetime.now(timezone.utc) > command.expires_at and stage not in {Acknowledgement.rejected, Acknowledgement.expired}:
            command.acknowledgement = Acknowledgement.expired
            return command
        allowed = {
            Acknowledgement.received: {Acknowledgement.validated, Acknowledgement.rejected},
            Acknowledgement.validated: {Acknowledgement.accepted, Acknowledgement.rejected},
            Acknowledgement.accepted: {Acknowledgement.completed, Acknowledgement.rejected},
            Acknowledgement.completed: set(), Acknowledgement.rejected: set(), Acknowledgement.expired: set(),
        }
        if stage not in allowed[command.acknowledgement]:
            raise ValueError(f"Invalid acknowledgement transition: {command.acknowledgement} -> {stage}.")
        command.acknowledgement = stage
        return command
