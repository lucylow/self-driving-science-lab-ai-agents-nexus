"""Experiment memory retrieval with transferability warnings."""

from typing import Any


def similarity_score(left: dict[str, Any], right: dict[str, Any], keys: list[str]) -> float:
    if not keys:
        return 0.0
    matches = 0
    for key in keys:
        a, b = left.get(key), right.get(key)
        if a is None or b is None:
            continue
        if isinstance(a, (int, float)) and isinstance(b, (int, float)):
            scale = max(abs(a), abs(b), 1e-9)
            matches += max(0.0, 1.0 - abs(a - b) / scale)
        else:
            matches += 1.0 if a == b else 0.0
    return matches / len(keys)


def retrieve_related_experiments(query: dict[str, Any], records: list[dict[str, Any]], *, context_keys: list[str], limit: int = 5) -> list[dict[str, Any]]:
    ranked = []
    for record in records:
        score = similarity_score(query, record.get("context", {}), context_keys)
        ranked.append({"record": record, "context_similarity": score})
    return sorted(ranked, key=lambda item: item["context_similarity"], reverse=True)[:max(1, limit)]


def transfer_warning(source: dict[str, Any], target: dict[str, Any]) -> list[str]:
    warnings = []
    for key in ("instrument_id", "measurement_method", "temperature", "pressure", "sample_preparation"):
        if source.get(key) != target.get(key):
            warnings.append(f"Context differs for {key}; do not assume direct transferability.")
    if source.get("laboratory_code") != target.get("laboratory_code"):
        warnings.append("Cross-laboratory transfer requires independent target-domain validation.")
    return warnings
