"""Scheduling contracts for shared instruments, people, samples and maintenance windows."""

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any


@dataclass
class ResourceReservation:
    resource_id: str
    start: datetime
    end: datetime
    experiment_id: str
    reservation_type: str

    def overlaps(self, other: "ResourceReservation") -> bool:
        return self.resource_id == other.resource_id and self.start < other.end and other.start < self.end


def validate_reservation(reservation: ResourceReservation, existing: list[ResourceReservation]) -> list[str]:
    if reservation.end <= reservation.start:
        return ["Reservation end must be after reservation start."]
    conflicts = [item for item in existing if reservation.overlaps(item)]
    return [f"Resource {item.resource_id} is already reserved for {item.experiment_id}." for item in conflicts]


def propose_slots(experiment: dict[str, Any], *, start: datetime, slot_minutes: int = 30, count: int = 5,
                  reservations: list[ResourceReservation] | None = None) -> list[dict[str, Any]]:
    reservations = reservations or []
    duration = timedelta(minutes=int(experiment.get("duration_minutes", slot_minutes)))
    resource_ids = experiment.get("resource_ids", [])
    proposals = []
    for index in range(count):
        slot_start = start + timedelta(minutes=slot_minutes * index)
        slot_end = slot_start + duration
        candidate_reservations = [ResourceReservation(resource, slot_start, slot_end, str(experiment.get("id", "proposal")), "instrument") for resource in resource_ids]
        conflicts = [issue for candidate in candidate_reservations for issue in validate_reservation(candidate, reservations)]
        proposals.append({
            "start": slot_start.astimezone(timezone.utc).isoformat(),
            "end": slot_end.astimezone(timezone.utc).isoformat(),
            "available": not conflicts,
            "conflicts": conflicts,
            "reserves_resources": False,
        })
    return proposals
