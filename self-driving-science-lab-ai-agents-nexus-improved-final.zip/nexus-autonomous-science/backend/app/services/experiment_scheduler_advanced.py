"""Explainable, non-reserving schedule proposals for computational planning."""
from __future__ import annotations
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from typing import Any
from app.services.agent_intelligence.task_graph import compile_task_graph


def propose_schedule(jobs: list[dict[str, Any]], instruments: list[dict[str, Any]], *,
                     start_at: datetime | None = None, buffer_minutes: int = 5) -> dict[str, Any]:
    """Greedy earliest-feasible scheduler with dependencies and capability matching.

    This returns a proposal only. It does not reserve resources or issue commands.
    Job dependencies are respected by Kahn topological passes; among concurrently
    ready jobs, higher priority wins and job_id provides a stable tie-break.
    """
    if buffer_minutes < 0:
        raise ValueError("buffer minutes cannot be negative")
    now = start_at or datetime.now(timezone.utc)
    if now.tzinfo is None:
        raise ValueError("start_at must be timezone-aware")
    instrument_map = {str(item["instrument_id"]): item for item in instruments if item.get("instrument_id")}
    if len(instrument_map) != len(instruments):
        raise ValueError("every instrument needs a unique instrument_id")
    job_map = {str(job.get("job_id")): job for job in jobs}
    if len(job_map) != len(jobs) or "" in job_map:
        raise ValueError("every job needs a unique job_id")
    errors = []
    for job_id, job in job_map.items():
        try:
            duration = int(job.get("duration_minutes", 0))
        except (TypeError, ValueError):
            duration = 0
        if duration <= 0:
            errors.append(f"{job_id}: duration_minutes must be positive")
        if not job.get("required_capabilities"):
            errors.append(f"{job_id}: required_capabilities is empty")
        try:
            priority = float(job.get("priority", 0))
            if not __import__("math").isfinite(priority):
                raise ValueError
        except (TypeError, ValueError):
            errors.append(f"{job_id}: priority must be finite numeric data")
    if errors:
        return {"valid": False, "errors": errors, "schedule": [], "execution_status": "proposal_only"}
    graph_nodes = [{"node_id": job_id, "depends_on": [str(dep) for dep in job.get("depends_on", [])]}
                   for job_id, job in job_map.items()]
    try:
        graph = compile_task_graph(graph_nodes)
    except ValueError as exc:
        return {"valid": False, "errors": [str(exc)], "schedule": [], "execution_status": "proposal_only"}
    instrument_slots: dict[str, datetime] = {key: now for key in instrument_map}
    completed_finish: dict[str, datetime] = {}
    schedule, unschedulable, blocked = [], [], []
    processed: set[str] = set()
    remaining = set(job_map)
    while remaining:
        ready = [job_id for job_id in remaining
                 if set(str(dep) for dep in job_map[job_id].get("depends_on", [])).issubset(processed)]
        if not ready:
            # The DAG was validated; this guard catches unexpected scheduler bugs.
            return {"valid": False, "errors": ["dependency scheduler could not identify a ready node"],
                    "schedule": schedule, "execution_status": "proposal_only"}
        ready.sort(key=lambda item: (-float(job_map[item].get("priority", 0)), item))
        for job_id in ready:
            job = job_map[job_id]
            dependencies = [str(dep) for dep in job.get("depends_on", [])]
            if any(dep in unschedulable or dep in blocked for dep in dependencies):
                blocked.append(job_id)
                processed.add(job_id)
                remaining.remove(job_id)
                continue
            required = set(job["required_capabilities"])
            compatible = [instrument_id for instrument_id, instrument in instrument_map.items()
                          if required.issubset(set(instrument.get("capabilities", [])))]
            if not compatible:
                unschedulable.append(job_id)
                processed.add(job_id)
                remaining.remove(job_id)
                continue
            earliest = max([now, *(completed_finish[dep] for dep in dependencies)])
            instrument_id = min(compatible, key=lambda ident: (max(earliest, instrument_slots[ident]), ident))
            start = max(earliest, instrument_slots[instrument_id])
            duration = int(job["duration_minutes"])
            finish = start + timedelta(minutes=duration)
            instrument_slots[instrument_id] = finish + timedelta(minutes=buffer_minutes)
            completed_finish[job_id] = finish
            processed.add(job_id)
            schedule.append({"job_id": job_id, "instrument_id": instrument_id,
                             "start_at": start.isoformat(), "finish_at": finish.isoformat(),
                             "duration_minutes": duration, "priority": float(job.get("priority", 0)),
                             "dependencies": dependencies,
                             "explanation": [f"Instrument supports {', '.join(sorted(required))}.",
                                             "Earliest start respects dependency completion and instrument buffer."]})
            remaining.remove(job_id)
    makespan = max((datetime.fromisoformat(item["finish_at"]) for item in schedule), default=now)
    errors = [f"No compatible instrument for job {job_id}" for job_id in unschedulable]
    errors.extend(f"Job {job_id} blocked because a dependency is unschedulable" for job_id in blocked)
    return {"valid": not unschedulable and not blocked, "errors": errors,
            "schedule": schedule, "topological_order": graph["topological_order"],
            "statuses": {job_id: ("unschedulable" if job_id in unschedulable else "blocked_by_dependency" if job_id in blocked else "scheduled_in_proposal") for job_id in job_map},
            "schedule_start": now.isoformat(),
            "estimated_makespan_minutes": max(0, (makespan-now).total_seconds()/60),
            "resource_reservations_created": False,
            "execution_status": "schedule_proposal_only"}
