"""Transparent computational design-of-experiments primitives.

This creates parameter-space designs only. It does not create physical SOPs, dispense
instructions, temperatures or other instrument commands.
"""
from __future__ import annotations
from itertools import product
from math import prod


def full_factorial_design(factors: list[dict], *, maximum_runs: int = 256,
                          center_points: int = 1) -> dict:
    if not factors:
        raise ValueError("At least one design factor is required")
    names = [str(item.get("name", "")) for item in factors]
    if any(not name for name in names) or len(names) != len(set(names)):
        raise ValueError("Every factor needs a unique non-empty name")
    levels: list[list[float]] = []
    for factor in factors:
        values = factor.get("levels")
        if not isinstance(values, list) or len(values) < 2:
            raise ValueError(f"Factor '{factor['name']}' requires at least two numeric levels")
        numeric = [float(value) for value in values]
        if len(set(numeric)) != len(numeric):
            raise ValueError(f"Factor '{factor['name']}' contains duplicate levels")
        levels.append(numeric)
    count = prod(len(values) for values in levels)
    if count + center_points > maximum_runs:
        raise ValueError(f"Requested design contains {count + center_points} runs, over limit {maximum_runs}")
    combinations = list(product(*levels))
    runs = [{name: value for name, value in zip(names, combination)} for combination in combinations]
    if center_points:
        center = {factor["name"]: sum(levels[index]) / len(levels[index]) for index, factor in enumerate(factors)}
        runs.extend([{**center, "design_role": "center_point"} for _ in range(center_points)])
    for index, run in enumerate(runs, start=1):
        run["design_run"] = index
        run.setdefault("design_role", "factorial_point")
    return {
        "design_type": "full_factorial_with_center_points",
        "factor_names": names,
        "run_count": len(runs),
        "runs": runs,
        "execution_status": "design_only_not_authorized_for_physical_execution",
        "limitations": ["Factor values require domain-specific validation.",
                        "Randomization, blocking and replicate requirements are not inferred.",
                        "This parameter matrix is not a laboratory protocol."],
    }


def validate_factor_constraints(factors: list[dict], constraints: list[dict]) -> dict:
    errors = []
    by_name = {item.get("name"): item for item in factors}
    for rule in constraints:
        name = rule.get("factor")
        if name not in by_name:
            errors.append(f"Constraint references unknown factor '{name}'")
            continue
        values = by_name[name].get("levels", [])
        lower, upper = rule.get("minimum"), rule.get("maximum")
        for value in values:
            number = float(value)
            if lower is not None and number < float(lower):
                errors.append(f"{name} level {number} is below configured bound {lower}")
            if upper is not None and number > float(upper):
                errors.append(f"{name} level {number} is above configured bound {upper}")
    return {"valid": not errors, "errors": errors,
            "execution_authorized": False}
