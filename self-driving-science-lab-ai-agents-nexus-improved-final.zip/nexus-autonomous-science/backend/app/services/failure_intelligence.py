"""Evidence-led failure triage; produces competing explanations, not causal verdicts."""
from __future__ import annotations

RULES = [
    ("instrument_calibration", {"calibration_expired", "reference_standard_failed"}, "Review calibration and reference-standard history."),
    ("sample_identity_or_provenance", {"sample_label_mismatch", "missing_chain_of_custody"}, "Quarantine the affected record and verify sample identity."),
    ("environmental_excursion", {"temperature_excursion", "humidity_excursion", "pressure_excursion"}, "Compare environmental logs with the experiment time window."),
    ("data_pipeline_integrity", {"schema_parse_error", "unit_conversion_error", "timestamp_reversal"}, "Review raw source files and transformation lineage."),
    ("protocol_deviation", {"protocol_step_skipped", "protocol_version_mismatch"}, "Compare operator annotations with the approved protocol version."),
    ("model_applicability", {"out_of_domain_input", "uncalibrated_prediction"}, "Review model applicability and uncertainty before interpreting the prediction."),
    ("sample_or_material_variability", {"replicate_spread_high", "batch_variation_flag"}, "Compare independent samples, synthesis batches and measurement conditions."),
]


def triage_failure(*, observed_signals: list[str], experiment_id: str,
                   evidence_refs: list[str], context: dict | None = None) -> dict:
    signals = set(observed_signals)
    hypotheses = []
    for category, triggers, next_step in RULES:
        matched = sorted(signals & triggers)
        if matched:
            hypotheses.append({"category": category, "matched_signals": matched,
                               "next_review_step": next_step,
                               "status": "plausible_explanation_not_verified"})
    if not evidence_refs:
        hypotheses.append({"category": "insufficient_provenance", "matched_signals": [],
                           "next_review_step": "Attach raw artifacts, timestamps and relevant calibration records.",
                           "status": "evidence_gap"})
    return {
        "experiment_id": experiment_id,
        "observed_signals": sorted(signals),
        "candidate_explanations": hypotheses,
        "evidence_refs": evidence_refs,
        "context": context or {},
        "recommended_disposition": "scientist_or_operator_review",
        "automatic_retry": False,
        "automatic_equipment_change": False,
        "warning": "Signal association does not establish root cause. Preserve the original failed record.",
    }
