"""Hypothesis record validation. The service checks falsifiability, not scientific truth."""

from typing import Any

REQUIRED_KEYS = {"statement", "predictions", "required_measurements"}


def validate_hypothesis(payload: dict[str, Any]) -> dict[str, Any]:
    missing = sorted(REQUIRED_KEYS - payload.keys())
    predictions = payload.get("predictions") or []
    issues: list[str] = []
    if missing:
        issues.append(f"Missing fields: {', '.join(missing)}")
    if not str(payload.get("statement", "")).strip():
        issues.append("A hypothesis statement is required.")
    if not predictions:
        issues.append("At least one measurable prediction is required.")
    for item in predictions:
        if not isinstance(item, dict) or not item.get("property") or not item.get("direction"):
            issues.append("Each prediction requires a property and expected direction.")
            break
    return {
        "valid_for_review": not issues,
        "issues": issues,
        "scientist_review_required": True,
        "note": "Structural validity does not establish that a hypothesis is scientifically correct.",
    }
