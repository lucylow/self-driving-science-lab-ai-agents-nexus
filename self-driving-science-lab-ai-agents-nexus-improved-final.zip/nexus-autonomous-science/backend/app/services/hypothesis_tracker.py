"""Append evidence to hypothesis records without automatic truth promotion."""
from __future__ import annotations
from sqlalchemy.orm import Session
from app.models.entities import Hypothesis
from app.services.audit import record_event

VALID_EVIDENCE_TYPES = {"supporting", "contradictory", "inconclusive"}


def append_hypothesis_evidence(db: Session, hypothesis_id: str, *, observation_id: str,
                               evidence_type: str, description: str, origin: str,
                               synthetic: bool, provenance_refs: list[str]) -> Hypothesis:
    hypothesis = db.get(Hypothesis, hypothesis_id)
    if not hypothesis:
        raise KeyError(hypothesis_id)
    if evidence_type not in VALID_EVIDENCE_TYPES:
        raise ValueError("evidence_type must be supporting, contradictory or inconclusive")
    if not observation_id or not provenance_refs:
        raise ValueError("Hypothesis evidence requires an observation id and provenance references")
    if origin == "simulation" and not synthetic:
        raise ValueError("Simulation evidence must be synthetic")
    record = {"observation_id": observation_id, "description": description,
              "origin": origin, "synthetic": synthetic, "provenance_refs": provenance_refs}
    if evidence_type == "supporting":
        hypothesis.supporting_observations = [*(hypothesis.supporting_observations or []), record]
    elif evidence_type == "contradictory":
        hypothesis.contradictory_observations = [*(hypothesis.contradictory_observations or []), record]
    # Deliberately do not set experimentally_supported or contradicted here.
    if hypothesis.status in {"proposed", "accepted_for_testing"}:
        hypothesis.status = "under_review"
    record_event(db, "HYPOTHESIS_EVIDENCE_APPENDED", "hypothesis", hypothesis.id,
                 actor="hypothesis-tracker", payload={"observation_id": observation_id,
                 "evidence_type": evidence_type, "origin": origin, "synthetic": synthetic})
    db.flush()
    return hypothesis


def scientist_decide_hypothesis(db: Session, hypothesis_id: str, *, status: str,
                                reviewer: str, rationale: str, evidence_refs: list[str]) -> Hypothesis:
    allowed = {"experimentally_supported", "partially_supported", "contradicted", "inconclusive", "superseded"}
    if status not in allowed:
        raise ValueError("Unsupported scientist decision status")
    if not reviewer.strip() or len(rationale.strip()) < 12 or not evidence_refs:
        raise ValueError("Scientist decision requires reviewer, rationale, and evidence references")
    row = db.get(Hypothesis, hypothesis_id)
    if not row:
        raise KeyError(hypothesis_id)
    row.status = status
    row.supporting_observations = [*(row.supporting_observations or []), {
        "review_decision": status, "reviewer": reviewer, "rationale": rationale,
        "evidence_refs": evidence_refs,
    }]
    record_event(db, "HYPOTHESIS_SCIENTIST_DECISION", "hypothesis", row.id, actor=reviewer,
                 payload={"status": status, "evidence_refs": evidence_refs})
    db.flush()
    return row
