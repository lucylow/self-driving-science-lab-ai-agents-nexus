"""Staged data ingestion with sample, artifact, instrument, and domain checks."""
from __future__ import annotations
from uuid import uuid4
from sqlalchemy.orm import Session
from app.models.entities import IngestionJob, ScientificArtifact, ScientificSample, Instrument
from app.services.domain_validation import validate_laboratory_record
from app.services.audit import record_event
from app.services.domain_registry import get_domain

ALLOWED_TRANSITIONS = {
    "staged": {"validated", "quarantined", "failed"},
    "validated": {"accepted", "quarantined", "failed"},
    "quarantined": {"validated", "failed"},
    "accepted": set(), "failed": set(),
}


def create_ingestion_job(db: Session, *, job_code: str, artifact_id: str,
                         laboratory_code: str, sample_id: str | None,
                         payload: dict, synthetic: bool) -> IngestionJob:
    artifact = db.get(ScientificArtifact, artifact_id)
    if not artifact:
        raise ValueError("Ingestion job requires a registered raw artifact")
    lab_code = laboratory_code.upper()
    domain = get_domain(lab_code)["domain"]
    if artifact.laboratory_code != lab_code or artifact.domain != domain:
        raise ValueError("Artifact is not registered for the requested laboratory domain")
    if artifact.artifact_type not in {"raw_data", "image", "spectrum", "timeseries", "structure"}:
        raise ValueError("Ingestion source artifact must be a raw or native scientific modality")
    if sample_id:
        sample = db.get(ScientificSample, sample_id)
        if not sample or sample.laboratory_code != lab_code:
            raise ValueError("Sample identity is not registered in the requested laboratory")
    row = IngestionJob(
        id=str(uuid4()), job_code=job_code, laboratory_code=lab_code, domain=domain,
        artifact_id=artifact_id, sample_id=sample_id, status="staged",
        payload_json=payload, validation_report={}, synthetic=bool(synthetic),
    )
    db.add(row)
    db.flush()
    record_event(db, "DATA_INGESTION_STAGED", "ingestion_job", row.id,
                 actor="ingestion-pipeline", payload={"artifact_id": artifact_id,
                 "domain": domain, "synthetic": synthetic})
    return row


def validate_ingestion_job(db: Session, job_id: str) -> IngestionJob:
    row = db.get(IngestionJob, job_id)
    if not row:
        raise KeyError(job_id)
    if row.status not in {"staged", "quarantined"}:
        raise ValueError(f"Ingestion job cannot be validated from status '{row.status}'")
    artifact = db.get(ScientificArtifact, row.artifact_id)
    sample = db.get(ScientificSample, row.sample_id) if row.sample_id else None
    errors = []
    if not artifact:
        errors.append("Source artifact no longer exists")
    if row.sample_id and not sample:
        errors.append("Sample identity no longer resolves")
    if sample and sample.identity_status not in {"verified", "provisional"}:
        errors.append("Sample identity has not been reviewed")
    if artifact and artifact.synthetic != row.synthetic:
        errors.append("Ingestion job synthetic flag does not match source artifact")
    payload = dict(row.payload_json or {})
    payload.setdefault("sample_id", row.sample_id)
    domain_result = validate_laboratory_record(row.laboratory_code, payload)
    errors.extend(domain_result["domain_validation"]["errors"])
    if row.synthetic and not artifact.synthetic:
        errors.append("Synthetic ingestion cannot relabel a non-synthetic source")
    row.validation_report = {
        "passed": not errors,
        "errors": errors,
        "domain_validation": domain_result,
        "artifact_sha256": artifact.sha256 if artifact else None,
        "sample_identity_status": sample.identity_status if sample else None,
        "validation_policy": "schema_identity_provenance_only",
        "scientific_validity_established": False,
    }
    row.status = "validated" if not errors else "quarantined"
    record_event(db, "DATA_INGESTION_VALIDATED" if not errors else "DATA_INGESTION_QUARANTINED",
                 "ingestion_job", row.id, actor="ingestion-pipeline",
                 payload={"passed": not errors, "error_count": len(errors), "synthetic": row.synthetic})
    db.flush()
    return row


def decide_ingestion(db: Session, job_id: str, *, decision: str,
                     reviewer: str, note: str) -> IngestionJob:
    row = db.get(IngestionJob, job_id)
    if not row:
        raise KeyError(job_id)
    if row.status != "validated":
        raise ValueError("Only validated ingestion jobs can be accepted")
    if decision != "accept":
        row.status = "quarantined"
    else:
        if not reviewer.strip() or len(note.strip()) < 8:
            raise ValueError("Acceptance requires a reviewer and substantive note")
        row.status = "accepted"
        row.accepted_by = reviewer
        row.review_note = note
    record_event(db, "DATA_INGESTION_DECISION", "ingestion_job", row.id,
                 actor=reviewer or "system", payload={"decision": decision,
                 "status": row.status, "synthetic": row.synthetic})
    db.flush()
    return row
