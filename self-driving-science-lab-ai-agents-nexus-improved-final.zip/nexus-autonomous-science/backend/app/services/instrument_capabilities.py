"""Machine-readable instrument capability manifests and compatibility checks."""
from __future__ import annotations
from dataclasses import dataclass, asdict


@dataclass(frozen=True)
class InstrumentCapabilityManifest:
    instrument_id: str
    laboratory_code: str
    instrument_type: str
    supported_operations: tuple[str, ...]
    accepted_sample_types: tuple[str, ...]
    output_types: tuple[str, ...]
    telemetry_fields: tuple[str, ...]
    requires_local_operator: bool = True
    controller_version: str = "unknown"
    manifest_version: str = "1.0.0"

    def to_dict(self) -> dict:
        return asdict(self)


def validate_manifest(payload: dict) -> dict:
    required = ["instrument_id", "laboratory_code", "instrument_type", "supported_operations",
                "accepted_sample_types", "output_types", "telemetry_fields"]
    errors = [f"Missing {key}" for key in required if not payload.get(key)]
    if payload.get("laboratory_code") not in {f"SDL{i}" for i in range(8)}:
        errors.append("Unknown laboratory code")
    if payload.get("requires_local_operator") is not True:
        errors.append("NEXUS requires local operator oversight for instrument adapters")
    if len(set(payload.get("supported_operations", []))) != len(payload.get("supported_operations", [])):
        errors.append("supported_operations contains duplicates")
    return {"valid": not errors, "errors": errors,
            "manifest_is_descriptive_only": True,
            "physical_control_enabled": False}


def check_operation_compatibility(manifest: dict, *, operation: str, sample_type: str) -> dict:
    operation_ok = operation in manifest.get("supported_operations", [])
    sample_ok = sample_type in manifest.get("accepted_sample_types", [])
    return {
        "compatible_for_operator_review": operation_ok and sample_ok,
        "operation_supported": operation_ok,
        "sample_type_supported": sample_ok,
        "operator_review_required": True,
        "controller_interlock_remains_authoritative": True,
        "command_issued": False,
    }
