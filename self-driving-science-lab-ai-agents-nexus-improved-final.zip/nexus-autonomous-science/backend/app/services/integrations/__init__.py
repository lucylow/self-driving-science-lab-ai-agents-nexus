"""Integration boundaries for optional scientific libraries and laboratory hardware."""
