"""Instrument adapter contract and safe mock implementation.

The adapter intentionally cannot command real equipment. A production adapter must live
on a local edge gateway and enforce vendor interlocks independently from this cloud API.
"""

from abc import ABC, abstractmethod
from datetime import datetime, timezone
from typing import Any
from uuid import uuid4


class InstrumentAdapter(ABC):
    @abstractmethod
    def connect(self) -> bool: ...

    @abstractmethod
    def get_status(self) -> dict[str, Any]: ...

    @abstractmethod
    def validate_command(self, command: dict[str, Any]) -> dict[str, Any]: ...

    @abstractmethod
    def submit_command(self, command: dict[str, Any]) -> dict[str, Any]: ...

    @abstractmethod
    def get_result(self, command_id: str) -> dict[str, Any]: ...

    @abstractmethod
    def disconnect(self) -> None: ...


class SimulatedInstrumentAdapter(InstrumentAdapter):
    BLOCKED_OPERATIONS = {"dispense", "synthesize", "heat", "pressurize", "robot_move", "instrument_start"}

    def __init__(self, instrument_id: str):
        self.instrument_id = instrument_id
        self.connected = False
        self.commands: dict[str, dict[str, Any]] = {}

    def connect(self) -> bool:
        self.connected = True
        return self.connected

    def get_status(self) -> dict[str, Any]:
        return {
            "instrument_id": self.instrument_id,
            "connection": "simulated_connected" if self.connected else "disconnected",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "physical_control_enabled": False,
        }

    def validate_command(self, command: dict[str, Any]) -> dict[str, Any]:
        operation = str(command.get("operation", "")).lower()
        if operation in self.BLOCKED_OPERATIONS:
            return {"valid": False, "reason": "Physical operations are blocked by the simulated adapter."}
        return {"valid": True, "reason": "Non-physical demo command accepted for local simulation."}

    def submit_command(self, command: dict[str, Any]) -> dict[str, Any]:
        if not self.connected:
            raise RuntimeError("Instrument adapter is not connected.")
        validation = self.validate_command(command)
        if not validation["valid"]:
            raise PermissionError(validation["reason"])
        command_id = command.get("command_id") or str(uuid4())
        if command_id in self.commands:
            return {"command_id": command_id, "acknowledgement": "already_received", "idempotent_replay": True}
        record = {"command_id": command_id, "payload": command, "acknowledgement": "received", "synthetic": True}
        self.commands[command_id] = record
        return record

    def get_result(self, command_id: str) -> dict[str, Any]:
        if command_id not in self.commands:
            raise KeyError(command_id)
        return {**self.commands[command_id], "result": "simulated_no_hardware_result"}

    def disconnect(self) -> None:
        self.connected = False
