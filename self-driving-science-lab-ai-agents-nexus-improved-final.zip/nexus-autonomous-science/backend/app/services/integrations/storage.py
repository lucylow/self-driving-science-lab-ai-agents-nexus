"""Artifact storage boundary with an in-memory local demo implementation."""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from hashlib import sha256
from typing import BinaryIO
from uuid import uuid4


@dataclass(frozen=True)
class ArtifactReference:
    artifact_id: str
    uri: str
    sha256: str
    byte_length: int
    content_type: str
    synthetic: bool


class ArtifactStore(ABC):
    @abstractmethod
    def put(self, content: bytes, *, content_type: str, synthetic: bool = True) -> ArtifactReference: ...

    @abstractmethod
    def get(self, artifact_id: str) -> bytes: ...


class MemoryArtifactStore(ArtifactStore):
    def __init__(self) -> None:
        self._objects: dict[str, tuple[bytes, ArtifactReference]] = {}

    def put(self, content: bytes, *, content_type: str, synthetic: bool = True) -> ArtifactReference:
        artifact_id = f"ART-{uuid4().hex[:12].upper()}"
        digest = sha256(content).hexdigest()
        reference = ArtifactReference(
            artifact_id=artifact_id, uri=f"memory://artifacts/{artifact_id}",
            sha256=digest, byte_length=len(content), content_type=content_type,
            synthetic=synthetic,
        )
        self._objects[artifact_id] = (content, reference)
        return reference

    def get(self, artifact_id: str) -> bytes:
        if artifact_id not in self._objects:
            raise KeyError(artifact_id)
        return self._objects[artifact_id][0]
