"""Lightweight evidence graph abstraction; a Neo4j adapter can implement the same contract."""

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class KnowledgeNode:
    node_id: str
    node_type: str
    label: str
    properties: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class KnowledgeEdge:
    source_id: str
    target_id: str
    relationship: str
    evidence_refs: tuple[str, ...] = ()


class ScientificKnowledgeGraph:
    ALLOWED_RELATIONSHIPS = {
        "supports", "contradicts", "measured_in", "predicted_by", "derived_from",
        "uses_sample", "tests_hypothesis", "targets_objective", "characterized_by",
        "transferred_from", "interpreted_as",
    }

    def __init__(self) -> None:
        self.nodes: dict[str, KnowledgeNode] = {}
        self.edges: list[KnowledgeEdge] = []

    def add_node(self, node: KnowledgeNode) -> None:
        existing = self.nodes.get(node.node_id)
        if existing and existing != node:
            raise ValueError("Node identity is immutable; create a new versioned node instead.")
        self.nodes[node.node_id] = node

    def add_edge(self, edge: KnowledgeEdge) -> None:
        if edge.source_id not in self.nodes or edge.target_id not in self.nodes:
            raise KeyError("Both edge endpoints must exist before a relationship is recorded.")
        if edge.relationship not in self.ALLOWED_RELATIONSHIPS:
            raise ValueError(f"Unsupported scientific relationship: {edge.relationship}")
        if edge not in self.edges:
            self.edges.append(edge)

    def neighbors(self, node_id: str, relationship: str | None = None) -> list[KnowledgeNode]:
        matches = []
        for edge in self.edges:
            if edge.source_id == node_id and (relationship is None or edge.relationship == relationship):
                matches.append(self.nodes[edge.target_id])
            elif edge.target_id == node_id and (relationship is None or edge.relationship == relationship):
                matches.append(self.nodes[edge.source_id])
        return matches

    def trace_sources(self, node_id: str, max_depth: int = 5) -> list[str]:
        visited: set[str] = set()
        queue = [(node_id, 0)]
        artifacts: list[str] = []
        while queue:
            current, depth = queue.pop(0)
            if current in visited or depth > max_depth:
                continue
            visited.add(current)
            node = self.nodes.get(current)
            if not node:
                continue
            if node.node_type in {"artifact", "measurement", "literature_source"}:
                artifacts.append(current)
            for neighbor in self.neighbors(current):
                if neighbor.node_id not in visited:
                    queue.append((neighbor.node_id, depth + 1))
        return artifacts
