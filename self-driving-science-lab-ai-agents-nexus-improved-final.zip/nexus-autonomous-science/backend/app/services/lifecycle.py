"""Experiment lifecycle state machine with explicit, testable transitions."""

from app.core.errors import InvalidTransitionError

ALLOWED_TRANSITIONS: dict[str, set[str]] = {
    "draft": {"validated", "cancelled"},
    "validated": {"feasibility_review", "cancelled"},
    "feasibility_review": {"resource_review", "awaiting_approval", "cancelled"},
    "resource_review": {"safety_review", "awaiting_approval", "cancelled"},
    "safety_review": {"awaiting_approval", "quarantined", "cancelled"},
    "awaiting_approval": {"approved", "cancelled", "quarantined"},
    "approved": {"scheduled", "cancelled"},
    "scheduled": {"prepared", "cancelled"},
    "prepared": {"executing", "cancelled"},
    "executing": {"data_acquisition", "failed", "quarantined"},
    "data_acquisition": {"data_validation", "failed", "quarantined"},
    "data_validation": {"scientific_interpretation", "quarantined", "failed"},
    "scientific_interpretation": {"model_update", "completed", "quarantined"},
    "model_update": {"completed", "quarantined"},
    "failed": {"quarantined"},
    "quarantined": set(),
    "completed": set(),
    "cancelled": set(),
}


def ensure_transition(current: str, target: str) -> None:
    if target not in ALLOWED_TRANSITIONS.get(current, set()):
        choices = ", ".join(sorted(ALLOWED_TRANSITIONS.get(current, set()))) or "none"
        raise InvalidTransitionError(f"Cannot move experiment from '{current}' to '{target}'. Allowed: {choices}.")
