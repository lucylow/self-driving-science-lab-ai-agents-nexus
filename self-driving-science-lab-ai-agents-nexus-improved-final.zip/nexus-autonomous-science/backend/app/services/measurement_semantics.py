"""Conservative unit semantics baseline. Original instrument values are never overwritten."""

from dataclasses import dataclass


@dataclass(frozen=True)
class UnitDefinition:
    symbol: str
    dimension: str
    scale_to_base: float


UNITS = {
    "S/cm": UnitDefinition("S/cm", "conductivity", 1.0),
    "mS/cm": UnitDefinition("mS/cm", "conductivity", 1e-3),
    "uS/cm": UnitDefinition("uS/cm", "conductivity", 1e-6),
    "K": UnitDefinition("K", "temperature", 1.0),
    "degC": UnitDefinition("degC", "temperature_offset", 1.0),
    "Pa": UnitDefinition("Pa", "pressure", 1.0),
    "kPa": UnitDefinition("kPa", "pressure", 1e3),
    "MPa": UnitDefinition("MPa", "pressure", 1e6),
    "Wh/kg": UnitDefinition("Wh/kg", "specific_energy", 1.0),
    "mAh/g": UnitDefinition("mAh/g", "specific_capacity", 1.0),
    "%": UnitDefinition("%", "fraction_percent", 1.0),
    "score/100": UnitDefinition("score/100", "normalized_score", 1.0),
}


def convert(value: float, source_unit: str, target_unit: str) -> dict:
    if source_unit not in UNITS or target_unit not in UNITS:
        raise ValueError("Unknown unit. Register a reviewed unit definition before conversion.")
    source = UNITS[source_unit]
    target = UNITS[target_unit]
    if source.dimension != target.dimension:
        raise ValueError(f"Incompatible dimensions: {source.dimension} and {target.dimension}.")
    if source.dimension == "temperature_offset":
        raise ValueError("Offset temperature conversions require explicit temperature semantics and are not supported by this baseline.")
    normalized = value * source.scale_to_base / target.scale_to_base
    return {
        "original_value": value,
        "original_unit": source_unit,
        "normalized_value": normalized,
        "normalized_unit": target_unit,
        "transformation": f"value * {source.scale_to_base} / {target.scale_to_base}",
        "unit_registry": "nexus-demo-units-0.1.0",
    }


def validate_unit_presence(value: float | None, unit: str | None) -> list[str]:
    errors = []
    if value is None:
        errors.append("Measurement value is missing.")
    if unit is None or not unit.strip():
        errors.append("Measurement unit is missing.")
    elif unit not in UNITS:
        errors.append(f"Unit '{unit}' is not registered for this application.")
    return errors
