"""Strict model capability and applicability-domain checks."""

from typing import Any


def check_model_applicability(model_card: dict[str, Any], query: dict[str, Any]) -> dict[str, Any]:
    reasons: list[str] = []
    domain = query.get("domain")
    modality = query.get("modality")
    if domain not in model_card.get("supported_domains", []):
        reasons.append("domain_not_supported")
    if modality not in model_card.get("supported_modalities", []):
        reasons.append("modality_not_supported")
    target = query.get("prediction_target")
    if target not in model_card.get("prediction_targets", []):
        reasons.append("prediction_target_not_supported")

    training_range = model_card.get("numeric_training_ranges", {})
    query_features = query.get("numeric_features", {})
    range_checks = {}
    for feature, value in query_features.items():
        bounds = training_range.get(feature)
        if not bounds or len(bounds) != 2:
            range_checks[feature] = "range_not_declared"
            reasons.append(f"training_range_not_declared:{feature}")
        elif float(value) < float(bounds[0]) or float(value) > float(bounds[1]):
            range_checks[feature] = "out_of_domain"
            reasons.append(f"out_of_domain:{feature}")
        else:
            range_checks[feature] = "within_declared_range"

    return {
        "applicable": not reasons,
        "reasons": reasons,
        "range_checks": range_checks,
        "prediction_allowed": not reasons,
        "requires_scientist_review": True,
        "note": "Applicability checks do not establish scientific validity or calibration.",
    }
