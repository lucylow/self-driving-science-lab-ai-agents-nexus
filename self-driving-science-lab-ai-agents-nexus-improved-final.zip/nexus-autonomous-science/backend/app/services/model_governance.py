"""Model lifecycle gates; registration, evaluation, shadow and promotion are distinct."""
from __future__ import annotations
from typing import Any

ALLOWED_STATES = {"registered", "research_only", "candidate_for_shadow", "shadow", "approved", "retired", "blocked"}


def applicability_check(model: Any, *, domain: str, modality: str, target: str,
                        feature_names: list[str] | None = None) -> dict:
    declared = model.hyperparameters.get("feature_names", []) if isinstance(model.hyperparameters, dict) else []
    checks = {
        "domain_supported": domain in model.supported_domains,
        "modality_supported": modality in model.supported_modalities,
        "target_supported": target in model.prediction_targets,
        "feature_schema_supported": feature_names is None or sorted(feature_names) == sorted(declared),
        "not_blocked": model.status not in {"blocked", "retired"},
    }
    return {"applicable": all(checks.values()), "checks": checks,
            "model_status": model.status, "requires_scientist_review": True,
            "limitations": model.limitations}


def promotion_review(model: Any, evaluation: Any, *, minimum_holdout_rows: int = 20,
                     maximum_rmse: float | None = None) -> dict:
    reasons: list[str] = []
    metrics = evaluation.metrics or {}
    if evaluation.split_name != "group_holdout":
        reasons.append("Evaluation must use a group-aware holdout split.")
    row_count = int(metrics.get("n", 0))
    if row_count < minimum_holdout_rows:
        reasons.append(f"Holdout contains {row_count} rows; {minimum_holdout_rows} are required for shadow review.")
    if model.synthetic:
        reasons.append("Synthetic training data cannot be used to promote a scientific model.")
    if model.uncertainty_profile.get("calibrated") is not True:
        reasons.append("Prediction uncertainty has not passed calibration review.")
    if maximum_rmse is not None and float(metrics.get("rmse", float("inf"))) > maximum_rmse:
        reasons.append("Holdout RMSE exceeds the configured review threshold.")
    if not model.hyperparameters.get("feature_names"):
        reasons.append("Model feature schema is missing.")
    return {
        "eligible_for_shadow_review": not reasons,
        "recommendation": "candidate_for_shadow" if not reasons else "hold_for_review",
        "reasons": reasons,
        "human_approval_required": True,
        "physical_execution_authorized": False,
    }
