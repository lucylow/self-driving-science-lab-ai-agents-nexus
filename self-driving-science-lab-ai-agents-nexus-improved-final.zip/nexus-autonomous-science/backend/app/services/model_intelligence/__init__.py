"""Transparent baseline scientific ML: descriptors, splits, regression and metrics.

No included model is represented as a universal scientific foundation model. The
components here are inspectable baselines intended for benchmark and integration work.
"""
