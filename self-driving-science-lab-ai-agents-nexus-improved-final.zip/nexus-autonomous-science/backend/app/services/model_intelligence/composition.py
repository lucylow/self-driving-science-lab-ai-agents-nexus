"""Conservative chemical formula parsing and composition-only descriptors.

The output describes stoichiometry, not crystal structure, oxidation state, defects,
thermodynamic stability, ionic mobility, or any other unobserved physical property.
"""
from __future__ import annotations
from collections import Counter
from math import log
import re
from typing import Iterable

ELEMENTS = set("H He Li Be B C N O F Ne Na Mg Al Si P S Cl Ar K Ca Sc Ti V Cr Mn Fe Co Ni Cu Zn Ga Ge As Se Br Kr Rb Sr Y Zr Nb Mo Tc Ru Rh Pd Ag Cd In Sn Sb Te I Xe Cs Ba La Ce Pr Nd Pm Sm Eu Gd Tb Dy Ho Er Tm Yb Lu Hf Ta W Re Os Ir Pt Au Hg Tl Pb Bi Po At Rn Fr Ra Ac Th Pa U Np Pu Am Cm Bk Cf Es Fm Md No Lr Rf Db Sg Bh Hs Mt Ds Rg Cn Nh Fl Mc Lv Ts Og".split())
TOKEN = re.compile(r"([A-Z][a-z]?|\(|\)|\d+(?:\.\d+)?)")


class FormulaError(ValueError):
    pass


def parse_formula(formula: str) -> dict[str, float]:
    """Parse a neutral element/count formula including nested parentheses.

    Examples: Li7La3Zr2O12, Li1.3Al0.3Ti1.7(PO4)3, Al2(SO4)3, Ca(OH)2.
    Hydrate separators, charge annotations, and isotope notation are rejected.
    """
    if not formula or len(formula) > 160:
        raise FormulaError("Formula must contain between 1 and 160 characters.")
    tokens = TOKEN.findall(formula)
    if "".join(tokens) != formula:
        raise FormulaError("Unsupported formula syntax; use element symbols, counts and parentheses only.")
    index = 0

    def parse_group(nested: bool = False) -> Counter:
        nonlocal index
        counts: Counter = Counter()
        consumed = False
        while index < len(tokens):
            token = tokens[index]
            if token == ")":
                if not nested:
                    raise FormulaError("Unexpected closing parenthesis.")
                index += 1
                return counts
            if token == "(":
                index += 1
                group = parse_group(True)
                if not group:
                    raise FormulaError("Parenthesized groups must contain at least one element.")
                multiplier = _read_multiplier()
                counts.update({element: amount * multiplier for element, amount in group.items()})
                consumed = True
                continue
            if token[0].isdigit():
                raise FormulaError("A count must follow an element or parenthesized group.")
            if token not in ELEMENTS:
                raise FormulaError(f"Unknown element symbol: {token}")
            index += 1
            multiplier = _read_multiplier()
            counts[token] += multiplier
            consumed = True
        if nested:
            raise FormulaError("Unclosed parenthesis.")
        if not consumed:
            raise FormulaError("No elements found.")
        return counts

    def _read_multiplier() -> float:
        nonlocal index
        if index < len(tokens) and tokens[index][0].isdigit():
            number = float(tokens[index])
            index += 1
            if number <= 0 or number > 100000:
                raise FormulaError("Stoichiometric counts must be positive and no greater than 100000.")
            return number
        return 1

    result = parse_group()
    if index != len(tokens):
        raise FormulaError("Could not parse the complete formula.")
    return dict(sorted(result.items()))


def composition_descriptors(formula: str) -> dict[str, float | int | str]:
    counts = parse_formula(formula)
    total = sum(counts.values())
    fractions = {element: amount / total for element, amount in counts.items()}
    entropy = -sum(value * log(value) for value in fractions.values())
    return {
        "formula": formula,
        "element_count": len(counts),
        "atom_count_per_formula_unit": total,
        "stoichiometric_entropy": entropy,
        "stoichiometric_entropy_normalized": entropy / log(len(counts)) if len(counts) > 1 else 0.0,
        **{f"fraction_{element}": fraction for element, fraction in fractions.items()},
        **{f"count_{element}": amount for element, amount in counts.items()},
    }


def descriptor_schema(formulas: Iterable[str]) -> list[str]:
    names: set[str] = set()
    for formula in formulas:
        names.update(composition_descriptors(formula).keys())
    return sorted(names)
