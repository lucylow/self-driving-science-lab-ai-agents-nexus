"""Split-conformal residual intervals for regression baselines.

Calibration rows must be independent of the data used to fit the predictor. This module
computes intervals; it does not guarantee exchangeability or domain validity.
"""
from __future__ import annotations
from math import ceil


def fit_absolute_residual_calibrator(actual: list[float], predicted: list[float], *,
                                     alpha: float = 0.1) -> dict:
    if len(actual) != len(predicted) or len(actual) < 5:
        raise ValueError("At least five aligned calibration observations are required")
    if not 0 < alpha < 1:
        raise ValueError("alpha must be between zero and one")
    residuals = sorted(abs(float(a) - float(p)) for a, p in zip(actual, predicted))
    rank = min(len(residuals), ceil((len(residuals) + 1) * (1 - alpha)))
    quantile = residuals[rank - 1]
    return {
        "calibrator_type": "split_conformal_absolute_residual",
        "alpha": alpha, "nominal_coverage": 1 - alpha,
        "calibration_count": len(residuals), "quantile_rank": rank,
        "absolute_residual_quantile": quantile,
        "calibration_residuals": residuals,
        "calibrated": True,
        "assumptions": ["Calibration and future cases are exchangeable.",
                        "Calibration set was not used to fit the base predictor."],
        "known_limitations": ["Coverage can fail under distribution shift.",
                              "Calibration is not proof of applicability or safety."],
    }


def apply_conformal_interval(prediction: float, calibrator: dict) -> dict:
    if calibrator.get("calibrator_type") != "split_conformal_absolute_residual" or calibrator.get("calibrated") is not True:
        raise ValueError("A validated split-conformal calibrator is required")
    radius = float(calibrator["absolute_residual_quantile"])
    return {"prediction": float(prediction), "lower": float(prediction) - radius,
            "upper": float(prediction) + radius, "radius": radius,
            "nominal_coverage": float(calibrator["nominal_coverage"]),
            "calibration_count": int(calibrator["calibration_count"])}
