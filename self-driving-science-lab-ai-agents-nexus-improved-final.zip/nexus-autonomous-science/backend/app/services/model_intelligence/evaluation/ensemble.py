"""Ensemble aggregation that exposes model disagreement instead of hiding it."""
from __future__ import annotations
from statistics import mean, pstdev


def aggregate_ensemble(predictions: list[dict]) -> dict:
    if len(predictions) < 2:
        raise ValueError("At least two independent model predictions are required")
    targets = {item.get("target") for item in predictions}
    units = {item.get("unit") for item in predictions}
    if len(targets) != 1 or len(units) != 1:
        raise ValueError("Ensemble members must predict the same target with compatible units")
    values = [float(item["value"]) for item in predictions]
    declared_uncertainties = [float(item.get("uncertainty", 0.0)) for item in predictions]
    if any(value < 0 for value in declared_uncertainties):
        raise ValueError("Uncertainty values must be non-negative")
    center = mean(values)
    between_model = pstdev(values)
    within_model = mean(declared_uncertainties)
    return {
        "target": next(iter(targets)), "unit": next(iter(units)),
        "ensemble_mean": center,
        "between_model_standard_deviation": between_model,
        "mean_declared_member_uncertainty": within_model,
        "combined_spread_indicator": (between_model ** 2 + within_model ** 2) ** 0.5,
        "member_count": len(predictions),
        "members": predictions,
        "interpretation": "ensemble_disagreement_is_uncertainty_signal_not_a_probability",
    }
