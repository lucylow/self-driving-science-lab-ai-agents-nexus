"""Research/shadow prediction monitoring with append-only alerts."""
from __future__ import annotations
from statistics import mean


def compare_predictions_to_observations(pairs: list[dict], *, maximum_mean_absolute_error: float | None = None) -> dict:
    if len(pairs) < 3:
        raise ValueError("At least three prediction/observation pairs are required")
    residuals = [float(row["observed"]) - float(row["predicted"]) for row in pairs]
    mae = mean(abs(value) for value in residuals)
    bias = mean(residuals)
    alert = maximum_mean_absolute_error is not None and mae > maximum_mean_absolute_error
    return {
        "pair_count": len(pairs), "mean_absolute_error": mae, "mean_residual_bias": bias,
        "residuals": residuals, "alert": alert,
        "status": "review_required" if alert else "monitoring_only",
        "model_mutation_performed": False,
        "notice": "Monitoring does not retrain, replace, or roll back models automatically.",
    }
