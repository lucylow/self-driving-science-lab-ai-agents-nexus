"""Transparent diagonal-standardized applicability screen."""
from __future__ import annotations
from statistics import mean, pstdev


def fit_applicability_reference(rows: list[dict[str, float]], feature_names: list[str]) -> dict:
    if len(rows) < 5:
        raise ValueError("At least five reference rows are required")
    if not feature_names:
        raise ValueError("feature_names cannot be empty")
    means, scales = {}, {}
    for feature in feature_names:
        values = [float(row[feature]) for row in rows]
        means[feature] = mean(values)
        scales[feature] = pstdev(values) or 1.0
    return {"method": "diagonal_standardized_distance", "feature_names": feature_names,
            "means": means, "scales": scales, "reference_count": len(rows)}


def score_applicability(row: dict[str, float], reference: dict, *, threshold: float = 3.5) -> dict:
    expected = set(reference["feature_names"])
    actual = set(row)
    missing, extra = sorted(expected - actual), sorted(actual - expected)
    if missing or extra:
        return {"applicable": False, "distance": None, "missing_features": missing,
                "unexpected_features": extra, "reason": "feature_schema_mismatch"}
    contributions = {}
    for feature in reference["feature_names"]:
        z = (float(row[feature]) - float(reference["means"][feature])) / float(reference["scales"][feature])
        contributions[feature] = z * z
    distance = (sum(contributions.values()) / max(1, len(contributions))) ** 0.5
    return {"applicable": distance <= threshold, "distance": distance,
            "threshold": threshold, "feature_contributions": contributions,
            "reason": "within_reference_envelope" if distance <= threshold else "out_of_distribution_review",
            "automatic_extrapolation_authorized": False}
