"""Subgroup error analysis to expose performance heterogeneity."""
from __future__ import annotations
from collections import defaultdict
from app.services.model_intelligence.metrics import regression_metrics


def subgroup_regression_metrics(records: list[dict], *, group_key: str,
                                actual_key: str = "actual", predicted_key: str = "predicted",
                                minimum_group_size: int = 3) -> dict:
    groups = defaultdict(list)
    for row in records:
        if row.get(group_key) is None:
            continue
        groups[str(row[group_key])].append(row)
    metrics, insufficient = {}, []
    for name, rows in sorted(groups.items()):
        if len(rows) < minimum_group_size:
            insufficient.append(name)
            continue
        metrics[name] = regression_metrics([row[actual_key] for row in rows],
                                           [row[predicted_key] for row in rows])
    return {"group_key": group_key, "subgroups": metrics,
            "insufficient_groups": insufficient,
            "groups_examined": len(groups),
            "warning": "Subgroup differences may reflect confounding, method changes or sample selection."}
