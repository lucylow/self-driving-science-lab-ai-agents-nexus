"""Domain-aware, schema-stable feature construction utilities."""
from __future__ import annotations
from typing import Any
from app.services.model_intelligence.composition import composition_descriptors


def numeric_features(payload: dict[str, Any], *, prefix: str = "domain") -> dict[str, float]:
    """Extract explicitly declared numeric descriptors; never infer physical meaning."""
    output: dict[str, float] = {}
    for key, value in payload.items():
        if key in {"formula", "smiles", "structure_uri", "notes", "name"}:
            continue
        if isinstance(value, bool):
            continue
        if isinstance(value, (int, float)):
            output[f"{prefix}_{key}"] = float(value)
    return output


def describe_sample(domain: str, composition: dict[str, Any]) -> dict[str, float]:
    """Return only descriptors supported by the recorded sample representation."""
    if domain == "inorganic_materials":
        formula = composition.get("formula")
        if formula:
            raw = composition_descriptors(str(formula))
            return {key: float(value) for key, value in raw.items() if isinstance(value, (int, float))}
    descriptors = numeric_features(composition, prefix=domain.replace("-", "_"))
    if not descriptors:
        raise ValueError(f"No supported numeric descriptor representation for domain '{domain}'")
    return descriptors


def align_feature_rows(rows: list[dict[str, float]]) -> tuple[list[str], list[dict[str, float]]]:
    if not rows:
        raise ValueError("No feature rows supplied")
    feature_names = sorted(set().union(*(row.keys() for row in rows)))
    if not feature_names:
        raise ValueError("Feature rows contain no numeric descriptors")
    aligned = [{name: float(row.get(name, 0.0)) for name in feature_names} for row in rows]
    return feature_names, aligned
