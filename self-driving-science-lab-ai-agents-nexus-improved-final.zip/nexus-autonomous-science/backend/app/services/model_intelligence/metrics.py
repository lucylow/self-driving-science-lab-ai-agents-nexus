"""Small, dependency-light regression metrics and uncertainty checks."""
from __future__ import annotations
from math import isfinite, sqrt
from statistics import mean
from typing import Sequence


def regression_metrics(actual: Sequence[float], predicted: Sequence[float]) -> dict[str, float | int | None]:
    if len(actual) != len(predicted) or not actual:
        raise ValueError("actual and predicted must have equal non-zero lengths")
    if any(not isfinite(float(x)) for x in [*actual, *predicted]):
        raise ValueError("Metrics require finite numeric values")
    errors = [float(p) - float(a) for a, p in zip(actual, predicted)]
    mae = mean(abs(error) for error in errors)
    mse = mean(error * error for error in errors)
    rmse = sqrt(mse)
    center = mean(float(value) for value in actual)
    total = sum((float(value) - center) ** 2 for value in actual)
    residual = sum(error * error for error in errors)
    r2 = 1.0 - residual / total if total > 0 else None
    return {"n": len(actual), "mae": mae, "mse": mse, "rmse": rmse, "r2": r2}


def interval_metrics(actual: Sequence[float], predicted: Sequence[float], radius: Sequence[float]) -> dict[str, float | int]:
    if not (len(actual) == len(predicted) == len(radius)) or not actual:
        raise ValueError("actual, predicted and radius must have equal non-zero lengths")
    if any(float(r) < 0 or not isfinite(float(r)) for r in radius):
        raise ValueError("Interval radii must be finite and non-negative")
    covered = [abs(float(a) - float(p)) <= float(r) for a, p, r in zip(actual, predicted, radius)]
    return {
        "n": len(actual),
        "empirical_coverage": sum(covered) / len(covered),
        "mean_interval_radius": mean(float(value) for value in radius),
        "undercoverage_count": sum(not value for value in covered),
    }


def calibration_error(expected_coverage: float, empirical_coverage: float) -> float:
    if not 0 <= expected_coverage <= 1 or not 0 <= empirical_coverage <= 1:
        raise ValueError("Coverage values must be between zero and one")
    return abs(expected_coverage - empirical_coverage)
