"""Scientific modality encoders. All outputs retain sample identity and source references."""
