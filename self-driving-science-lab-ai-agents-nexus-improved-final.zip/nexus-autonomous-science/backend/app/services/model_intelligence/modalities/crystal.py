"""Optional pymatgen structure adapter and minimal CIF identity checks."""
from __future__ import annotations


def inspect_cif_with_pymatgen(cif_text: str) -> dict:
    if not cif_text or len(cif_text) > 20_000_000:
        raise ValueError("CIF text must be non-empty and below the configured size limit")
    try:
        from pymatgen.io.cif import CifParser
        from io import StringIO
        parser = CifParser(StringIO(cif_text))
        structures = parser.parse_structures(primitive=False)
    except ImportError as exc:
        raise RuntimeError("pymatgen adapter is not installed; structure parsing was not attempted") from exc
    if not structures:
        raise ValueError("No crystal structure could be parsed from the CIF")
    structure = structures[0]
    return {
        "site_count": len(structure.sites),
        "formula": structure.composition.reduced_formula,
        "lattice_parameters_angstrom": list(structure.lattice.abc),
        "lattice_angles_degrees": list(structure.lattice.angles),
        "density_g_cm3_calculated": float(structure.density),
        "space_group": structure.get_space_group_info(),
        "descriptor_origin": "pymatgen_cif_parser",
        "phase_purity_confirmed": False,
    }
