"""Identity-aware multimodal feature joining."""
from __future__ import annotations
from typing import Any


def fuse_modalities(records: dict[str, dict[str, Any]], *, required_modalities: list[str],
                    allow_missing: bool = False) -> dict:
    if not records:
        raise ValueError("At least one modality record is required")
    sample_ids = {str(record.get("sample_id", "")) for record in records.values()}
    if "" in sample_ids or len(sample_ids) != 1:
        raise ValueError("Multimodal fusion requires one consistent non-empty sample_id")
    missing = sorted(set(required_modalities) - set(records))
    if missing and not allow_missing:
        raise ValueError(f"Required modalities are missing: {missing}")
    fused: dict[str, float] = {}
    sources = {}
    for modality, record in records.items():
        features = record.get("features")
        if not isinstance(features, dict) or not features:
            raise ValueError(f"Modality '{modality}' contains no feature mapping")
        for name, value in features.items():
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise ValueError(f"Feature '{modality}.{name}' must be numeric")
            key = f"{modality}__{name}"
            if key in fused:
                raise ValueError(f"Duplicate fused feature '{key}'")
            fused[key] = float(value)
        sources[modality] = record.get("artifact_refs", [])
    return {
        "sample_id": next(iter(sample_ids)),
        "features": fused,
        "modalities_present": sorted(records),
        "modalities_missing": missing,
        "source_artifacts": sources,
        "fusion_status": "complete" if not missing else "partial_with_missingness_preserved",
        "model_training_eligible": False,
        "notice": "Fusion creates a representation only; downstream validation and dataset approval remain required.",
    }
