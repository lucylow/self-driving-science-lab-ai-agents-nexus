"""Image metadata and segmented-mask morphometry contracts.

Pixel-mask measurement is not an image segmentation model and does not establish
biological identity, viability, histology, or clinical significance.
"""
from __future__ import annotations
from math import isfinite


def validate_image_metadata(metadata: dict) -> dict:
    required = ["image_id", "sample_id", "instrument_id", "acquisition_time", "width_px", "height_px", "pixel_size"]
    errors = [f"Missing image metadata '{key}'" for key in required if metadata.get(key) in (None, "")]
    if metadata.get("width_px") is not None and int(metadata["width_px"]) <= 0:
        errors.append("width_px must be positive")
    if metadata.get("height_px") is not None and int(metadata["height_px"]) <= 0:
        errors.append("height_px must be positive")
    if metadata.get("pixel_size") is not None and float(metadata["pixel_size"]) <= 0:
        errors.append("pixel_size must be positive")
    return {"valid": not errors, "errors": errors,
            "segmentation_model_invoked": False,
            "sample_identity_verified": False}


def measure_binary_mask(mask: list[list[int]], *, pixel_size: float) -> dict:
    if not mask or not mask[0] or any(len(row) != len(mask[0]) for row in mask):
        raise ValueError("Mask must be a non-empty rectangular matrix")
    if pixel_size <= 0 or not isfinite(pixel_size):
        raise ValueError("pixel_size must be finite and positive")
    height, width = len(mask), len(mask[0])
    pixels = [(x, y) for y, row in enumerate(mask) for x, value in enumerate(row) if int(value) != 0]
    if not pixels:
        return {"foreground_pixel_count": 0, "area": 0.0, "centroid": None, "bounding_box": None}
    xs, ys = [point[0] for point in pixels], [point[1] for point in pixels]
    return {
        "foreground_pixel_count": len(pixels),
        "area": len(pixels) * pixel_size * pixel_size,
        "centroid": {"x": sum(xs) / len(xs) * pixel_size, "y": sum(ys) / len(ys) * pixel_size},
        "bounding_box": {"x_min": min(xs), "y_min": min(ys), "x_max": max(xs), "y_max": max(ys),
                         "width": max(xs) - min(xs) + 1, "height": max(ys) - min(ys) + 1},
        "image_dimensions": {"width_px": width, "height_px": height},
        "segmentation_origin": "caller_supplied_binary_mask",
        "biological_interpretation": "not_performed",
    }
