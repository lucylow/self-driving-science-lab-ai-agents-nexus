"""Optional RDKit adapter boundary for molecular graph descriptors."""
from __future__ import annotations


def rdkit_smiles_descriptors(smiles: str) -> dict:
    """Generate standard RDKit descriptors only when the optional dependency exists."""
    if not smiles or any(char.isspace() for char in smiles):
        raise ValueError("A non-empty whitespace-free SMILES string is required")
    try:
        from rdkit import Chem
        from rdkit.Chem import Descriptors, rdMolDescriptors
    except ImportError as exc:
        raise RuntimeError("RDKit adapter is not installed; no molecular descriptors were generated") from exc
    molecule = Chem.MolFromSmiles(smiles)
    if molecule is None:
        raise ValueError("RDKit could not parse the molecular representation")
    return {
        "canonical_smiles": Chem.MolToSmiles(molecule),
        "molecular_weight": float(Descriptors.MolWt(molecule)),
        "exact_molecular_weight": float(Descriptors.ExactMolWt(molecule)),
        "logp_calculated": float(Descriptors.MolLogP(molecule)),
        "tpsa_calculated": float(rdMolDescriptors.CalcTPSA(molecule)),
        "h_bond_donors_calculated": int(rdMolDescriptors.CalcNumHBD(molecule)),
        "h_bond_acceptors_calculated": int(rdMolDescriptors.CalcNumHBA(molecule)),
        "rotatable_bonds_calculated": int(rdMolDescriptors.CalcNumRotatableBonds(molecule)),
        "descriptor_origin": "rdkit_computational",
        "experimental_validation": False,
    }
