"""Numerical spectral preprocessing and peak candidates without chemical assignment."""
from __future__ import annotations
from math import isfinite
from statistics import median


def validate_spectrum(x: list[float], y: list[float]) -> dict:
    errors = []
    if len(x) != len(y) or len(x) < 5:
        errors.append("Spectrum x and y arrays must have equal length of at least five")
    if any(not isfinite(float(value)) for value in x + y):
        errors.append("Spectrum contains non-finite values")
    if any(float(right) <= float(left) for left, right in zip(x, x[1:])):
        errors.append("Spectral coordinate values must be strictly increasing")
    return {"valid": not errors, "errors": errors, "point_count": len(x)}


def moving_average(values: list[float], window: int = 5) -> list[float]:
    if window < 1 or window > len(values):
        raise ValueError("window must be between 1 and the number of points")
    half = window // 2
    output = []
    for index in range(len(values)):
        start, end = max(0, index - half), min(len(values), index + half + 1)
        output.append(sum(values[start:end]) / (end - start))
    return output


def rolling_median_baseline(values: list[float], window: int = 21) -> list[float]:
    if window < 3 or window > len(values):
        raise ValueError("window must be >=3 and no longer than the spectrum")
    half = window // 2
    baseline = []
    for index in range(len(values)):
        start, end = max(0, index - half), min(len(values), index + half + 1)
        baseline.append(float(median(values[start:end])))
    return baseline


def detect_peak_candidates(x: list[float], y: list[float], *, threshold: float,
                           minimum_distance_points: int = 2) -> dict:
    validity = validate_spectrum(x, y)
    if not validity["valid"]:
        raise ValueError("; ".join(validity["errors"]))
    if minimum_distance_points < 1:
        raise ValueError("minimum_distance_points must be positive")
    baseline = rolling_median_baseline(y, min(max(3, len(y) // 9), len(y) if len(y) % 2 else len(y) - 1))
    corrected = [float(value) - base for value, base in zip(y, baseline)]
    smoothed = moving_average(corrected, 3)
    candidates = []
    for index in range(1, len(smoothed) - 1):
        if smoothed[index] >= threshold and smoothed[index] > smoothed[index - 1] and smoothed[index] >= smoothed[index + 1]:
            if candidates and index - candidates[-1]["index"] < minimum_distance_points:
                if smoothed[index] > candidates[-1]["intensity"]:
                    candidates.pop()
                else:
                    continue
            candidates.append({"index": index, "coordinate": float(x[index]), "intensity": smoothed[index]})
    return {"peak_candidates": candidates, "count": len(candidates),
            "processing": ["rolling_median_baseline", "moving_average_smoothing", "local_maximum_detection"],
            "chemical_assignment": "not_performed",
            "notice": "Peak candidates require domain-specific calibration and scientist assignment."}


def integrate_spectrum(x: list[float], y: list[float]) -> float:
    validity = validate_spectrum(x, y)
    if not validity["valid"]:
        raise ValueError("; ".join(validity["errors"]))
    return sum((float(x[i + 1]) - float(x[i])) * (float(y[i + 1]) + float(y[i])) / 2 for i in range(len(x) - 1))
