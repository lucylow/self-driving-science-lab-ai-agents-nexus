"""Typed tabular preprocessing with explicit missingness and unit metadata."""
from __future__ import annotations
from math import isfinite
from statistics import median
from typing import Any


def validate_numeric_table(rows: list[dict[str, Any]], *, feature_names: list[str],
                            sample_key: str = "sample_id") -> dict:
    if not rows:
        return {"valid": False, "errors": ["Table is empty"], "row_count": 0}
    errors = []
    if not feature_names or len(feature_names) != len(set(feature_names)):
        errors.append("feature_names must be a non-empty unique list")
    for index, row in enumerate(rows):
        if not row.get(sample_key):
            errors.append(f"Row {index} has no {sample_key}")
        for feature in feature_names:
            value = row.get(feature)
            if value is None:
                continue
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not isfinite(float(value)):
                errors.append(f"Row {index} feature '{feature}' is not finite numeric data")
    return {"valid": not errors, "errors": errors, "row_count": len(rows),
            "feature_count": len(feature_names),
            "missing_counts": {feature: sum(row.get(feature) is None for row in rows) for feature in feature_names},
            "sample_group_count": len({str(row.get(sample_key)) for row in rows if row.get(sample_key)})}


def fit_robust_scaler(rows: list[dict[str, float]], feature_names: list[str]) -> dict:
    if not rows or not feature_names:
        raise ValueError("Rows and feature names are required")
    medians, iqr = {}, {}
    for feature in feature_names:
        values = sorted(float(row[feature]) for row in rows if row.get(feature) is not None)
        if not values:
            raise ValueError(f"Feature '{feature}' has no observed values")
        medians[feature] = median(values)
        q1 = values[int((len(values) - 1) * 0.25)]
        q3 = values[int((len(values) - 1) * 0.75)]
        iqr[feature] = q3 - q1 or 1.0
    return {"scaler_type": "median_iqr", "feature_names": feature_names,
            "medians": medians, "iqr": iqr}


def transform_robust_scaler(row: dict[str, float | None], scaler: dict) -> dict[str, float]:
    names = scaler["feature_names"]
    output = {}
    for feature in names:
        if feature not in row:
            raise ValueError(f"Missing feature '{feature}'")
        value = row[feature]
        if value is None:
            raise ValueError(f"Missing value for '{feature}'; apply a documented missingness strategy first")
        output[feature] = (float(value) - scaler["medians"][feature]) / scaler["iqr"][feature]
    return output


def missingness_profile(rows: list[dict[str, Any]], feature_names: list[str]) -> dict:
    count = max(1, len(rows))
    profile = {}
    for feature in feature_names:
        missing = sum(row.get(feature) is None for row in rows)
        profile[feature] = {"missing_count": missing, "missing_fraction": missing / count,
                            "missingness_state": "complete" if missing == 0 else "partial" if missing < count else "entirely_missing"}
    return {"row_count": len(rows), "features": profile,
            "imputation_performed": False,
            "notice": "Missingness is profiled, not silently imputed."}
