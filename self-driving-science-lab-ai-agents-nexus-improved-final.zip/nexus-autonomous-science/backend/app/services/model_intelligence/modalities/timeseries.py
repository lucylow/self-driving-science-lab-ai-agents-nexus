"""Windowed time-series descriptors with explicit interval and missingness summaries."""
from __future__ import annotations
from math import isfinite
from statistics import mean, median, pstdev


def temporal_descriptors(points: list[dict], *, timestamp_key: str = "timestamp",
                         value_key: str = "value") -> dict:
    if len(points) < 3:
        raise ValueError("At least three time-series points are required")
    ordered = sorted(points, key=lambda item: float(item[timestamp_key]))
    timestamps = [float(item[timestamp_key]) for item in ordered]
    values = [float(item[value_key]) for item in ordered]
    if any(not isfinite(v) for v in timestamps + values):
        raise ValueError("Time-series values must be finite")
    intervals = [b - a for a, b in zip(timestamps, timestamps[1:])]
    if any(value <= 0 for value in intervals):
        raise ValueError("Timestamps must be strictly increasing after ordering")
    center = mean(values)
    variance = pstdev(values) ** 2
    slopes = [(values[i + 1] - values[i]) / intervals[i] for i in range(len(intervals))]
    lag_one = None
    if variance > 0:
        lag_one = sum((values[i] - center) * (values[i + 1] - center) for i in range(len(values) - 1)) / ((len(values) - 1) * variance)
    return {
        "point_count": len(values), "start_time": timestamps[0], "end_time": timestamps[-1],
        "duration": timestamps[-1] - timestamps[0], "mean": center,
        "median": median(values), "standard_deviation": variance ** 0.5,
        "minimum": min(values), "maximum": max(values),
        "mean_absolute_first_difference": mean(abs(values[i + 1] - values[i]) for i in range(len(values) - 1)),
        "mean_slope_per_second": mean(slopes), "lag_one_autocorrelation": lag_one,
        "median_sample_interval": median(intervals),
        "interval_coefficient_of_variation": (pstdev(intervals) / mean(intervals)) if mean(intervals) else None,
        "interpolation_performed": False,
    }


def segment_time_series(points: list[dict], *, window_points: int, stride_points: int) -> list[dict]:
    if window_points < 3 or stride_points < 1 or window_points > len(points):
        raise ValueError("Invalid window_points or stride_points")
    segments = []
    for start in range(0, len(points) - window_points + 1, stride_points):
        segment = points[start:start + window_points]
        segments.append({"segment_index": len(segments), "start_index": start,
                         "end_index": start + window_points - 1,
                         "descriptors": temporal_descriptors(segment)})
    return segments
