"""Inspectable ridge-regression baseline with standardized features.

This implementation is intended for small tabular baselines and educational replay;
large or safety-critical training workloads should use a reviewed ML framework.
"""
from __future__ import annotations
from dataclasses import dataclass
from math import sqrt
from statistics import mean


def _solve(matrix: list[list[float]], vector: list[float]) -> list[float]:
    """Solve Ax=b with partial-pivot Gaussian elimination."""
    size = len(vector)
    augmented = [list(map(float, row)) + [float(vector[i])] for i, row in enumerate(matrix)]
    for column in range(size):
        pivot = max(range(column, size), key=lambda row: abs(augmented[row][column]))
        if abs(augmented[pivot][column]) < 1e-12:
            raise ValueError("Singular system; increase regularization or inspect the feature matrix")
        augmented[column], augmented[pivot] = augmented[pivot], augmented[column]
        scale = augmented[column][column]
        augmented[column] = [value / scale for value in augmented[column]]
        for row in range(size):
            if row == column:
                continue
            factor = augmented[row][column]
            if factor:
                augmented[row] = [left - factor * right for left, right in zip(augmented[row], augmented[column])]
    return [augmented[row][-1] for row in range(size)]


@dataclass
class RidgeBaseline:
    feature_names: list[str]
    means: list[float]
    scales: list[float]
    coefficients: list[float]
    intercept: float
    residual_std: float
    alpha: float

    @classmethod
    def fit(cls, rows: list[dict[str, float]], targets: list[float], *, alpha: float = 1.0) -> "RidgeBaseline":
        if len(rows) != len(targets) or len(rows) < 3:
            raise ValueError("At least three aligned training rows are required")
        if alpha < 0:
            raise ValueError("alpha must be non-negative")
        names = sorted(rows[0])
        if not names:
            raise ValueError("At least one feature is required")
        if any(sorted(row) != names for row in rows):
            raise ValueError("Every training row must have the identical feature schema")
        x = [[float(row[name]) for name in names] for row in rows]
        y = [float(value) for value in targets]
        means = [mean(row[column] for row in x) for column in range(len(names))]
        scales = []
        for column, center in enumerate(means):
            variance = mean((row[column] - center) ** 2 for row in x)
            scale = sqrt(variance)
            scales.append(scale if scale > 1e-12 else 1.0)
        standardized = [[(value - means[j]) / scales[j] for j, value in enumerate(row)] for row in x]
        y_mean = mean(y)
        gram = [[sum(row[i] * row[j] for row in standardized) for j in range(len(names))] for i in range(len(names))]
        for i in range(len(names)):
            gram[i][i] += alpha
        rhs = [sum(row[i] * (target - y_mean) for row, target in zip(standardized, y)) for i in range(len(names))]
        coefficients = _solve(gram, rhs)
        provisional = cls(names, means, scales, coefficients, y_mean, 0.0, alpha)
        predictions = [provisional.predict(row)["value"] for row in rows]
        residuals = [target - prediction for target, prediction in zip(y, predictions)]
        residual_std = sqrt(sum(value * value for value in residuals) / max(1, len(residuals) - len(names) - 1))
        provisional.residual_std = residual_std
        return provisional

    def predict(self, row: dict[str, float]) -> dict[str, float]:
        missing = sorted(set(self.feature_names) - set(row))
        extra = sorted(set(row) - set(self.feature_names))
        if missing or extra:
            raise ValueError(f"Feature schema mismatch; missing={missing}, extra={extra}")
        standardized = [(float(row[name]) - self.means[index]) / self.scales[index] for index, name in enumerate(self.feature_names)]
        value = self.intercept + sum(coefficient * feature for coefficient, feature in zip(self.coefficients, standardized))
        return {"value": value, "uncertainty_std": self.residual_std, "lower_95": value - 1.96 * self.residual_std, "upper_95": value + 1.96 * self.residual_std}

    def to_dict(self) -> dict:
        return {
            "model_type": "ridge_regression_baseline",
            "feature_names": self.feature_names,
            "means": self.means,
            "scales": self.scales,
            "coefficients": self.coefficients,
            "intercept": self.intercept,
            "residual_std": self.residual_std,
            "alpha": self.alpha,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "RidgeBaseline":
        if data.get("model_type") != "ridge_regression_baseline":
            raise ValueError("Unsupported model type")
        return cls(
            feature_names=list(data["feature_names"]), means=list(data["means"]),
            scales=list(data["scales"]), coefficients=list(data["coefficients"]),
            intercept=float(data["intercept"]), residual_std=float(data["residual_std"]),
            alpha=float(data["alpha"]),
        )
