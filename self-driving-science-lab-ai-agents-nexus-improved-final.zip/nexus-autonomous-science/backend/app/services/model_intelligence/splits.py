"""Deterministic group-aware holdout split to prevent sample leakage."""
from __future__ import annotations
import random


def group_holdout_indices(groups: list[str], *, test_fraction: float = 0.2, seed: int = 17) -> tuple[list[int], list[int]]:
    if len(groups) < 2:
        raise ValueError("At least two records are required for a holdout split")
    if not 0.05 < test_fraction < 0.5:
        raise ValueError("test_fraction must be between 0.05 and 0.5")
    unique_groups = sorted(set(groups))
    if len(unique_groups) < 2:
        raise ValueError("At least two independent sample groups are required")
    rng = random.Random(seed)
    rng.shuffle(unique_groups)
    test_count = max(1, round(len(unique_groups) * test_fraction))
    test_groups = set(unique_groups[:test_count])
    train = [index for index, group in enumerate(groups) if group not in test_groups]
    test = [index for index, group in enumerate(groups) if group in test_groups]
    if not train or not test:
        raise ValueError("Split produced an empty train or test partition")
    if set(groups[i] for i in train) & set(groups[i] for i in test):
        raise RuntimeError("Group leakage detected")
    return train, test


def split_manifest(groups: list[str], train: list[int], test: list[int], seed: int) -> dict:
    return {
        "strategy": "group_holdout",
        "group_key": "sample_id",
        "random_seed": seed,
        "train_indices": train,
        "test_indices": test,
        "train_group_count": len({groups[index] for index in train}),
        "test_group_count": len({groups[index] for index in test}),
        "overlap_groups": sorted({groups[index] for index in train} & {groups[index] for index in test}),
    }
