"""Cross-domain transferability checklist; no automatic weight transfer."""
from __future__ import annotations

REQUIRED_TRANSFER_EVIDENCE = {
    "feature_semantics_review", "target_measurement_equivalence", "unit_compatibility",
    "target_domain_reference_dataset", "held_out_target_validation", "uncertainty_recalibration",
    "out_of_domain_benchmark", "scientist_signoff",
}


def assess_transferability(source_domain: str, target_domain: str,
                           completed_checks: list[str]) -> dict:
    if source_domain == target_domain:
        raise ValueError("Transferability assessment is for distinct source and target domains")
    checks = set(completed_checks)
    unknown = sorted(checks - REQUIRED_TRANSFER_EVIDENCE)
    missing = sorted(REQUIRED_TRANSFER_EVIDENCE - checks)
    return {
        "source_domain": source_domain, "target_domain": target_domain,
        "completed_checks": sorted(checks & REQUIRED_TRANSFER_EVIDENCE),
        "unknown_checks": unknown, "missing_checks": missing,
        "eligible_for_target_validation_review": not missing and not unknown,
        "weights_transferred": False,
        "target_domain_applicability_established": False,
        "notice": "Passing the checklist only permits an expert review of a transfer experiment; it does not establish target-domain validity.",
    }
