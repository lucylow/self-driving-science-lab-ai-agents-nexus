"""Scientific model cards, applicability declarations, and evaluation metadata."""

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any


@dataclass
class ModelCard:
    model_id: str
    name: str
    version: str
    supported_domains: list[str]
    supported_modalities: list[str]
    prediction_targets: list[str]
    training_dataset_refs: list[str] = field(default_factory=list)
    training_data_version: str | None = None
    validation_report_ref: str | None = None
    calibration_status: str = "uncalibrated"
    validated_conditions: dict[str, Any] = field(default_factory=dict)
    known_limitations: list[str] = field(default_factory=list)
    requires_scientist_review: bool = True
    synthetic: bool = True


@dataclass
class ModelEvaluation:
    model_id: str
    dataset_ref: str
    split_name: str
    metrics: dict[str, float]
    calibration_metrics: dict[str, float]
    subgroup_metrics: dict[str, dict[str, float]]
    evaluated_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


class ModelRegistry:
    def __init__(self) -> None:
        self.cards: dict[str, ModelCard] = {}
        self.evaluations: list[ModelEvaluation] = []

    def register(self, card: ModelCard) -> None:
        if card.model_id in self.cards:
            raise ValueError(f"Model '{card.model_id}' is already registered.")
        self.cards[card.model_id] = card

    def get(self, model_id: str) -> ModelCard:
        if model_id not in self.cards:
            raise KeyError(model_id)
        return self.cards[model_id]

    def check_applicability(self, model_id: str, *, domain: str, modality: str, target: str) -> dict:
        card = self.get(model_id)
        checks = {
            "domain_supported": domain in card.supported_domains,
            "modality_supported": modality in card.supported_modalities,
            "target_supported": target in card.prediction_targets,
        }
        return {
            "applicable_for_review": all(checks.values()),
            "checks": checks,
            "limitations": card.known_limitations,
            "calibration_status": card.calibration_status,
            "requires_scientist_review": card.requires_scientist_review,
        }

    def add_evaluation(self, evaluation: ModelEvaluation) -> None:
        if evaluation.model_id not in self.cards:
            raise KeyError(evaluation.model_id)
        self.evaluations.append(evaluation)
