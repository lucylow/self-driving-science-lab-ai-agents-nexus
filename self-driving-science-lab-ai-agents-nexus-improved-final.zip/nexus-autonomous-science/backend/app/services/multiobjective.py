"""Pareto filtering and interpretable scalarization for candidate portfolios."""
from __future__ import annotations
from math import isfinite
from typing import Any


def dominates(left: dict[str, float], right: dict[str, float], directions: dict[str, str]) -> bool:
    objectives = list(directions)
    if not objectives:
        raise ValueError("At least one objective is required")
    no_worse = True
    strictly_better = False
    for key in objectives:
        if key not in left or key not in right:
            raise ValueError(f"Missing objective '{key}'")
        a, b = float(left[key]), float(right[key])
        if not isfinite(a) or not isfinite(b):
            raise ValueError("Objective values must be finite")
        if directions[key] == "maximize":
            no_worse &= a >= b
            strictly_better |= a > b
        elif directions[key] == "minimize":
            no_worse &= a <= b
            strictly_better |= a < b
        else:
            raise ValueError(f"Unsupported optimization direction for '{key}'")
    return no_worse and strictly_better


def pareto_front(candidates: list[dict[str, Any]], directions: dict[str, str]) -> dict:
    ids = [str(item["id"]) for item in candidates]
    if len(ids) != len(set(ids)):
        raise ValueError("Candidate ids must be unique")
    efficient, dominated = [], []
    for candidate in candidates:
        is_dominated = any(other["id"] != candidate["id"] and dominates(other["values"], candidate["values"], directions)
                           for other in candidates)
        (dominated if is_dominated else efficient).append(candidate)
    return {"pareto_front": efficient, "dominated": dominated,
            "objective_directions": directions,
            "note": "Pareto efficiency does not establish scientific validity or feasibility."}


def weighted_score(values: dict[str, float], ranges: dict[str, tuple[float, float]],
                   directions: dict[str, str], weights: dict[str, float]) -> dict:
    if set(weights) != set(directions) or set(ranges) != set(directions):
        raise ValueError("weights, ranges and directions must contain the same objective names")
    if any(float(weight) < 0 or not isfinite(float(weight)) for weight in weights.values()):
        raise ValueError("Weights must be finite and non-negative")
    total_weight = sum(float(value) for value in weights.values())
    if total_weight <= 0:
        raise ValueError("At least one objective weight must be positive")
    components = {}
    for name, direction in directions.items():
        minimum, maximum = map(float, ranges[name])
        if maximum <= minimum:
            raise ValueError(f"Objective '{name}' has an invalid normalization range")
        value = float(values[name])
        score = (value - minimum) / (maximum - minimum)
        if direction == "minimize":
            score = 1 - score
        components[name] = {"normalized_score": max(0.0, min(1.0, score)),
                            "weight": float(weights[name]),
                            "weighted_contribution": max(0.0, min(1.0, score)) * float(weights[name]) / total_weight}
    return {"score": sum(item["weighted_contribution"] for item in components.values()),
            "components": components,
            "explanation": "Weighted normalized utility; review weights and ranges before use."}
