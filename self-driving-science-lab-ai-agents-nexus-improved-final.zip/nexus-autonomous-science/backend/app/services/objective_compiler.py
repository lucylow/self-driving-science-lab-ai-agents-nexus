"""Rule-based objective compiler baseline.

This is intentionally transparent and conservative. Replace or augment it with a
reviewable LLM extraction step, but keep schema validation and scientist approval.
"""

from uuid import uuid4

PROPERTY_HINTS = {
    "ionic conductivity": {"property": "ionic_conductivity", "direction": "maximize", "unit": "S/cm"},
    "stability": {"property": "electrochemical_stability", "direction": "maximize", "unit": "score"},
    "energy density": {"property": "energy_density", "direction": "maximize", "unit": "Wh/kg"},
    "thermal stability": {"property": "thermal_stability", "direction": "maximize", "unit": "score"},
    "mechanical strength": {"property": "mechanical_strength", "direction": "maximize", "unit": "MPa"},
    "solubility": {"property": "solubility", "direction": "maximize", "unit": "domain_specific"},
    "yield": {"property": "yield", "direction": "maximize", "unit": "%"},
}


def compile_objective(prompt: str, laboratory_code: str) -> dict:
    text = " ".join(prompt.strip().split())
    lower = text.lower()
    objectives = [value for phrase, value in PROPERTY_HINTS.items() if phrase in lower]
    if not objectives:
        objectives = [{"property": "primary_research_outcome", "direction": "optimize", "unit": "to_be_defined"}]
    warnings = []
    if "synthesize" in lower or "robot" in lower or "execute" in lower:
        warnings.append("The request mentions physical operations; this compiler only creates a proposal.")
    if len(text) < 30:
        warnings.append("The objective is short. Add constraints, measurement methods, and success criteria.")
    return {
        "objective_id": f"OBJ-{uuid4().hex[:8].upper()}",
        "version": 1,
        "laboratory_code": laboratory_code.upper(),
        "description": text,
        "target_properties": objectives,
        "constraints": {
            "require_sample_identity": True,
            "require_measurement_provenance": True,
            "require_unit_validation": True,
        },
        "evidence_requirements": {
            "require_uncertainty_estimates": True,
            "distinguish_prediction_from_measurement": True,
            "experimental_validation_required": True,
        },
        "governance": {
            "scientist_review_required": True,
            "physical_execution_requires_authorization": True,
        },
        "compiler": "transparent-rule-baseline",
        "warnings": warnings,
        "requires_scientist_review": True,
    }
