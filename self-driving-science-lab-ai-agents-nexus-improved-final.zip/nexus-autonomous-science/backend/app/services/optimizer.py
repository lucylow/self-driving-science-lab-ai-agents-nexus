"""Transparent multi-objective candidate ranking baseline.

Scores are decision-support heuristics. They are not calibrated property predictions.
"""

from typing import Any


def normalize(value: float, low: float, high: float) -> float:
    if high <= low:
        return 0.0
    return max(0.0, min(1.0, (value - low) / (high - low)))


def score_candidate(candidate: dict[str, Any], weights: dict[str, float] | None = None) -> dict[str, Any]:
    weights = weights or {"conductivity": 0.50, "stability": 0.25, "feasibility": 0.25}
    props = candidate.get("predicted_properties", {})
    uncertainty = candidate.get("uncertainty", {})
    conductivity = float(props.get("ionic_conductivity", 0.0))
    stability = float(props.get("stability_score", 0.0))
    feasibility = float(candidate.get("feasibility_score", 0.0))
    # Illustrative score windows; replace with domain-validated ranges before research use.
    c_score = normalize(conductivity, 0.0001, 0.01)
    s_score = normalize(stability, 0.0, 100.0)
    f_score = normalize(feasibility, 0.0, 100.0)
    total_weight = sum(max(0.0, float(value)) for value in weights.values()) or 1.0
    raw = (c_score * weights.get("conductivity", 0.0) + s_score * weights.get("stability", 0.0) + f_score * weights.get("feasibility", 0.0)) / total_weight
    mean_uncertainty = sum(float(v) for v in uncertainty.values() if isinstance(v, (int, float))) / max(1, len(uncertainty))
    uncertainty_penalty = min(0.25, mean_uncertainty * 0.10)
    return {
        "score": round(max(0.0, raw - uncertainty_penalty) * 100, 2),
        "components": {"conductivity": round(c_score, 3), "stability": round(s_score, 3), "feasibility": round(f_score, 3)},
        "uncertainty_penalty": round(uncertainty_penalty, 4),
        "explanation": "Weighted demo heuristic with an uncertainty penalty; not a validated materials model.",
    }


def select_next_batch(candidates: list[dict[str, Any]], batch_size: int = 3) -> list[dict[str, Any]]:
    scored = []
    for candidate in candidates:
        result = score_candidate(candidate)
        scored.append({**candidate, "recommendation": result})
    return sorted(scored, key=lambda item: item["recommendation"]["score"], reverse=True)[: max(1, batch_size)]
