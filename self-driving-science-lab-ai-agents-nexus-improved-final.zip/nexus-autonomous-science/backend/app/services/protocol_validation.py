"""Protocol metadata validation; intentionally does not generate actionable wet-lab SOPs."""
from __future__ import annotations
from app.services.domain_registry import get_domain

ALLOWED_PROTOCOL_STATES = {"draft", "review", "approved", "retired"}


def validate_protocol_manifest(payload: dict) -> dict:
    errors = []
    required = ["protocol_id", "version", "laboratory_code", "domain", "owner", "purpose",
                "required_capabilities", "required_approvals", "expected_outputs"]
    errors.extend([f"Missing required field '{key}'" for key in required if payload.get(key) in (None, "", [])])
    if payload.get("state", "draft") not in ALLOWED_PROTOCOL_STATES:
        errors.append("Invalid protocol lifecycle state")
    lab_code = payload.get("laboratory_code")
    if lab_code:
        try:
            lab = get_domain(lab_code)
            if payload.get("domain") != lab["domain"]:
                errors.append("Protocol domain does not match laboratory registry")
        except KeyError:
            errors.append("Unknown laboratory code")
    if payload.get("physical_execution_enabled") is True:
        errors.append("Cloud protocol manifests cannot enable physical execution")
    return {
        "valid": not errors,
        "errors": errors,
        "protocol_state": payload.get("state", "draft"),
        "requires_human_approval": True,
        "instrument_commands_generated": False,
        "physical_execution_enabled": False,
    }
