"""Helpers for explicit scientific lineage and evidence typing."""

from dataclasses import dataclass
from typing import Literal

EvidenceType = Literal[
    "measured_value", "computational_result", "model_prediction",
    "literature_value", "human_observation", "inferred_value", "synthetic_simulation",
]


@dataclass(frozen=True)
class ProvenanceLink:
    source_type: str
    source_id: str
    relationship: str
    transformation_id: str | None = None


def build_lineage_chain(*links: ProvenanceLink) -> list[dict[str, str | None]]:
    """Return an ordered immutable-style representation of the supplied lineage links."""
    return [
        {
            "source_type": link.source_type,
            "source_id": link.source_id,
            "relationship": link.relationship,
            "transformation_id": link.transformation_id,
        }
        for link in links
    ]


def evidence_label(evidence_type: EvidenceType) -> str:
    return {
        "measured_value": "Experimental measurement",
        "computational_result": "Computational result",
        "model_prediction": "Model prediction",
        "literature_value": "Literature-derived value",
        "human_observation": "Human-entered observation",
        "inferred_value": "Inferred value",
        "synthetic_simulation": "Synthetic simulation output",
    }[evidence_type]
