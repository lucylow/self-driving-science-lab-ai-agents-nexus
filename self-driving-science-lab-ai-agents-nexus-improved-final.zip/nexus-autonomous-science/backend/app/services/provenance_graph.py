"""In-memory validators and graph queries for scientific artifact provenance.

Persist each node and edge in the canonical database in production. These pure
functions are suitable for request validation, tests, and query planning.
"""
from __future__ import annotations
from collections import defaultdict, deque
from typing import Any


def validate_lineage_graph(nodes: list[dict[str, Any]]) -> dict[str, Any]:
    by_id: dict[str, dict[str, Any]] = {}
    issues: list[dict[str, str]] = []
    for node in nodes:
        identifier = str(node.get("id", "")).strip()
        if not identifier:
            issues.append({"code": "missing_id", "node": "", "message": "Each graph node needs an id."})
        elif identifier in by_id:
            issues.append({"code": "duplicate_id", "node": identifier, "message": "Node identifiers must be unique."})
        else:
            by_id[identifier] = node
    parents: dict[str, list[str]] = {}
    children: dict[str, list[str]] = defaultdict(list)
    for identifier, node in by_id.items():
        refs = list(dict.fromkeys(str(ref) for ref in node.get("parents", [])))
        parents[identifier] = refs
        for ref in refs:
            if ref == identifier:
                issues.append({"code": "self_reference", "node": identifier, "message": "A node cannot be its own parent."})
            elif ref not in by_id:
                issues.append({"code": "missing_parent", "node": identifier, "message": f"Parent {ref} is not present in the submitted graph."})
            else:
                children[ref].append(identifier)
    if issues:
        return {"valid": False, "issues": issues, "topological_order": [], "root_ids": []}
    indegree = {identifier: len(refs) for identifier, refs in parents.items()}
    queue = deque(sorted(identifier for identifier, degree in indegree.items() if degree == 0))
    order: list[str] = []
    while queue:
        current = queue.popleft()
        order.append(current)
        for child in sorted(children[current]):
            indegree[child] -= 1
            if indegree[child] == 0:
                queue.append(child)
    if len(order) != len(by_id):
        cycle_nodes = sorted(identifier for identifier, degree in indegree.items() if degree > 0)
        issues.append({"code": "cycle_detected", "node": ",".join(cycle_nodes),
                       "message": "The lineage graph contains a cycle."})
    roots = sorted(identifier for identifier, refs in parents.items() if not refs)
    return {"valid": not issues, "issues": issues, "topological_order": order if not issues else [],
            "root_ids": roots, "node_count": len(by_id),
            "edge_count": sum(len(refs) for refs in parents.values())}


def trace_to_roots(node_id: str, nodes: list[dict[str, Any]]) -> dict[str, Any]:
    by_id = {str(node.get("id")): node for node in nodes if node.get("id") is not None}
    if node_id not in by_id:
        raise KeyError(f"lineage node not found: {node_id}")
    graph_check = validate_lineage_graph(nodes)
    if not graph_check["valid"]:
        raise ValueError("cannot trace an invalid lineage graph")
    visited: set[str] = set()
    frontier = [node_id]
    layers: list[list[str]] = []
    while frontier:
        layer = sorted(set(frontier) - visited)
        if not layer:
            break
        layers.append(layer)
        visited.update(layer)
        frontier = [parent for identifier in layer for parent in by_id[identifier].get("parents", [])]
    root_ids = [identifier for identifier in visited if not by_id[identifier].get("parents", [])]
    return {"node_id": node_id, "visited_ids": sorted(visited), "levels": layers,
            "root_ids": sorted(root_ids), "all_roots_reached": bool(root_ids)}


def downstream_impact(node_id: str, nodes: list[dict[str, Any]]) -> dict[str, Any]:
    by_id = {str(node.get("id")): node for node in nodes if node.get("id") is not None}
    if node_id not in by_id:
        raise KeyError(f"lineage node not found: {node_id}")
    graph_check = validate_lineage_graph(nodes)
    if not graph_check["valid"]:
        raise ValueError("cannot evaluate impact for an invalid lineage graph")
    children: dict[str, list[str]] = defaultdict(list)
    for identifier, node in by_id.items():
        for parent in node.get("parents", []):
            children[str(parent)].append(identifier)
    impacted, frontier = set(), [node_id]
    while frontier:
        current = frontier.pop()
        for child in children[current]:
            if child not in impacted:
                impacted.add(child); frontier.append(child)
    by_kind: dict[str, list[str]] = defaultdict(list)
    for identifier in impacted:
        by_kind[str(by_id[identifier].get("kind", "unknown"))].append(identifier)
    return {"source_id": node_id, "downstream_ids": sorted(impacted),
            "downstream_count": len(impacted),
            "downstream_by_kind": {key: sorted(value) for key, value in sorted(by_kind.items())},
            "impact_scope": "submitted_graph_only"}


def compare_lineage_sources(left: dict[str, Any], right: dict[str, Any]) -> dict[str, Any]:
    """Compare whether two results share source lineage; does not imply independence."""
    left_sources = set(str(item) for item in left.get("root_ids", []))
    right_sources = set(str(item) for item in right.get("root_ids", []))
    shared = left_sources & right_sources
    union = left_sources | right_sources
    return {"shared_roots": sorted(shared), "left_only_roots": sorted(left_sources-right_sources),
            "right_only_roots": sorted(right_sources-left_sources),
            "root_jaccard_similarity": len(shared) / len(union) if union else 1.0,
            "independence_assessed": False,
            "note": "Distinct root IDs do not guarantee independent experimental replication."}


def validate_artifact_transform(*, parent_ids: list[str], declared_transform: str,
                                tool_version: str, parameters: dict[str, Any]) -> dict[str, Any]:
    issues = []
    if not parent_ids:
        issues.append("at least one parent artifact is required")
    if len(parent_ids) != len(set(parent_ids)):
        issues.append("parent artifact IDs must be unique")
    if not declared_transform.strip():
        issues.append("transformation name is required")
    if not tool_version.strip():
        issues.append("tool version is required")
    return {"valid": not issues, "issues": issues,
            "transformation": {"name": declared_transform, "tool_version": tool_version,
                              "parameters": parameters, "parent_artifact_ids": parent_ids},
            "lineage_policy": "append_only; corrections create a new derived artifact"}
