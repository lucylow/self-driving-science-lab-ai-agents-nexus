"""Declarative, versioned scientific data-quality rule evaluation."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Callable
import math

@dataclass(frozen=True)
class QualityRule:
    rule_id: str
    version: str
    severity: str
    description: str
    field: str
    operator: str
    expected: Any = None
    minimum: float | None = None
    maximum: float | None = None
    blocks_training: bool = False


class QualityRuleEngine:
    def __init__(self, rules: list[QualityRule] | None = None):
        self._rules: dict[str, QualityRule] = {}
        for rule in rules or []:
            self.register(rule)

    def register(self, rule: QualityRule) -> None:
        if rule.severity not in {"info", "warning", "error", "critical"}:
            raise ValueError("unsupported rule severity")
        if rule.operator not in {"required", "equals", "in", "finite", "range", "non_empty"}:
            raise ValueError("unsupported rule operator")
        if rule.rule_id in self._rules:
            raise ValueError("rule IDs are immutable and cannot be overwritten")
        self._rules[rule.rule_id] = rule

    def evaluate(self, record: dict[str, Any], *, rule_ids: list[str] | None = None) -> dict[str, Any]:
        selected = [self._rules[item] for item in rule_ids] if rule_ids is not None else list(self._rules.values())
        results = []
        for rule in selected:
            value = record.get(rule.field)
            passed = True
            if rule.operator == "required": passed = rule.field in record and value is not None
            elif rule.operator == "equals": passed = value == rule.expected
            elif rule.operator == "in": passed = value in (rule.expected or [])
            elif rule.operator == "finite":
                try: passed = math.isfinite(float(value))
                except (TypeError, ValueError): passed = False
            elif rule.operator == "range":
                try:
                    numeric = float(value)
                    passed = math.isfinite(numeric) and (rule.minimum is None or numeric >= rule.minimum) and (rule.maximum is None or numeric <= rule.maximum)
                except (TypeError, ValueError): passed = False
            elif rule.operator == "non_empty": passed = value not in (None, "", [], {})
            results.append({"rule_id": rule.rule_id, "version": rule.version,
                            "severity": rule.severity, "passed": passed,
                            "field": rule.field, "blocks_training": rule.blocks_training,
                            "description": rule.description,
                            "observed": value if isinstance(value, (str, int, float, bool, type(None))) else type(value).__name__})
        failures = [item for item in results if not item["passed"]]
        critical = any(item["severity"] == "critical" for item in failures)
        errors = any(item["severity"] == "error" for item in failures)
        training_blocked = any(item["blocks_training"] for item in failures)
        return {"passed": not failures, "record_accepted": not critical and not errors,
                "training_eligible": not training_blocked and not critical and not errors,
                "rule_count": len(results), "failed_rule_count": len(failures),
                "results": results, "failed_rules": failures}

    def catalogue(self) -> list[dict[str, Any]]:
        return [{"rule_id": rule.rule_id, "version": rule.version,
                 "severity": rule.severity, "field": rule.field,
                 "operator": rule.operator, "blocks_training": rule.blocks_training,
                 "description": rule.description}
                for rule in sorted(self._rules.values(), key=lambda item: item.rule_id)]


def default_quality_engine() -> QualityRuleEngine:
    return QualityRuleEngine([
        QualityRule("measurement.sample_id", "1.0.0", "critical", "Measurement must have a sample identity.", "sample_id", "non_empty", blocks_training=True),
        QualityRule("measurement.origin", "1.0.0", "critical", "Measurement origin must be explicit.", "origin", "in", ["measured", "simulation", "prediction", "literature", "human_observation", "computational"], blocks_training=True),
        QualityRule("measurement.synthetic", "1.0.0", "critical", "Synthetic flag must be a boolean.", "synthetic", "in", [True, False], blocks_training=True),
        QualityRule("measurement.value", "1.0.0", "error", "Measurement value must be finite.", "value", "finite", blocks_training=True),
        QualityRule("measurement.unit", "1.0.0", "error", "Measurement unit is required.", "unit", "non_empty", blocks_training=True),
        QualityRule("measurement.quality", "1.0.0", "warning", "Accepted measurements are preferred for training.", "quality_status", "equals", "accepted", blocks_training=False),
    ])
