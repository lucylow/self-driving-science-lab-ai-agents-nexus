"""Replicate summaries that preserve batch and method context."""
from __future__ import annotations
from math import sqrt
from statistics import mean, median, pstdev
from collections import defaultdict


def summarize_replicates(records: list[dict], *, value_key: str = "value",
                          group_key: str = "condition_id") -> dict:
    groups: dict[str, list[dict]] = defaultdict(list)
    for record in records:
        if record.get(group_key) is None or record.get(value_key) is None:
            continue
        groups[str(record[group_key])].append(record)
    summaries = []
    for group, rows in sorted(groups.items()):
        values = [float(row[value_key]) for row in rows]
        center = mean(values)
        standard_deviation = pstdev(values) if len(values) > 1 else 0.0
        cv = abs(standard_deviation / center) if center != 0 else None
        summaries.append({
            "group": group, "replicate_count": len(values), "mean": center,
            "median": median(values), "standard_deviation_population": standard_deviation,
            "coefficient_of_variation": cv,
            "minimum": min(values), "maximum": max(values),
            "sample_ids": sorted({str(row.get("sample_id", "unknown")) for row in rows}),
            "method_ids": sorted({str(row.get("method_id", "unknown")) for row in rows}),
            "batch_ids": sorted({str(row.get("batch_id", "unknown")) for row in rows}),
        })
    return {
        "groups": summaries,
        "group_count": len(summaries),
        "independent_sample_count": len({str(row.get("sample_id")) for row in records if row.get("sample_id")}),
        "warnings": [
            "Replicates are only comparable when sample preparation, method, conditions and controls are compatible.",
            "Technical repeats must not be treated as independent biological or synthesis replicates.",
            "A small coefficient of variation is not proof of accuracy or external reproducibility.",
        ],
    }


def reproducibility_gate(summary: dict, *, minimum_replicates: int = 3,
                         maximum_cv: float | None = None) -> dict:
    failures = []
    for group in summary.get("groups", []):
        if group["replicate_count"] < minimum_replicates:
            failures.append(f"Group {group['group']} has fewer than {minimum_replicates} replicates")
        cv = group.get("coefficient_of_variation")
        if maximum_cv is not None and cv is not None and cv > maximum_cv:
            failures.append(f"Group {group['group']} exceeds the configured CV threshold")
    return {"passed": not failures, "failures": failures,
            "scientist_review_required": True}
