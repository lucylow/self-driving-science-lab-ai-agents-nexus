"""Bibliographic source registry and claim-evidence linkage."""
from __future__ import annotations
import re
from uuid import uuid4
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.models.entities import ResearchSource, ScientificClaim, ScientificArtifact, Measurement, ScientificPrediction
from app.services.audit import record_event
from app.services.domain_registry import get_domain

DOI_PATTERN = re.compile(r"^10\.\d{4,9}/[-._;()/:A-Z0-9]+$", re.IGNORECASE)


def normalize_doi(value: str | None) -> str | None:
    if not value:
        return None
    doi = value.strip()
    for prefix in ("https://doi.org/", "http://doi.org/", "doi:"):
        if doi.lower().startswith(prefix):
            doi = doi[len(prefix):].strip()
            break
    doi = doi.rstrip(".,; ")
    if not DOI_PATTERN.match(doi):
        raise ValueError("DOI does not match the expected DOI syntax")
    return doi.lower()


def register_source(db: Session, payload: dict) -> ResearchSource:
    doi = normalize_doi(payload.get("doi"))
    if doi:
        existing = db.scalar(select(ResearchSource).where(ResearchSource.doi == doi))
        if existing:
            return existing
    source_key = payload.get("source_key") or (f"doi:{doi}" if doi else f"manual:{uuid4()}")
    duplicate = db.scalar(select(ResearchSource).where(ResearchSource.source_key == source_key))
    if duplicate:
        return duplicate
    source = ResearchSource(
        id=str(uuid4()), source_key=source_key, title=payload["title"], doi=doi,
        url=payload.get("url", ""), publication_year=payload.get("publication_year"),
        venue=payload.get("venue", ""), authors=payload.get("authors", []),
        abstract=payload.get("abstract", ""), source_type=payload.get("source_type", "journal_article"),
        metadata_json=payload.get("metadata", {}), verification_status="metadata_unverified",
        synthetic=bool(payload.get("synthetic", False)),
    )
    db.add(source)
    db.flush()
    record_event(db, "RESEARCH_SOURCE_REGISTERED", "research_source", source.id,
                 actor="literature-registry", payload={"source_key": source_key, "doi": doi,
                 "metadata_verified": False})
    return source


def verify_source_metadata(db: Session, source_id: str, *, reviewer: str,
                            verification_refs: list[str], note: str = "") -> ResearchSource:
    source = db.get(ResearchSource, source_id)
    if not source:
        raise KeyError(source_id)
    if not reviewer.strip() or not verification_refs:
        raise ValueError("Source metadata verification requires reviewer and verification references")
    source.verification_status = "metadata_reviewed"
    source.metadata_json = {**(source.metadata_json or {}),
                            "metadata_review": {"reviewer": reviewer,
                                                "verification_refs": verification_refs,
                                                "note": note}}
    record_event(db, "RESEARCH_SOURCE_METADATA_REVIEWED", "research_source", source.id,
                 actor=reviewer, payload={"verification_refs": verification_refs})
    db.flush()
    return source


def _reference_exists(db: Session, ref: str) -> bool:
    return any([
        db.get(ResearchSource, ref) is not None,
        db.get(ScientificArtifact, ref) is not None,
        db.get(Measurement, ref) is not None,
        db.get(ScientificPrediction, ref) is not None,
    ])


def register_claim(db: Session, payload: dict) -> ScientificClaim:
    lab = payload["laboratory_code"].upper()
    domain = get_domain(lab)["domain"]
    if payload["domain"] != domain:
        raise ValueError("Claim domain does not match laboratory domain")
    support = list(payload.get("support_refs", []))
    contradiction = list(payload.get("contradiction_refs", []))
    claim = ScientificClaim(
        id=str(uuid4()), claim_key=payload["claim_key"], statement=payload["statement"],
        domain=domain, laboratory_code=lab, claim_type=payload.get("claim_type", "empirical_observation"),
        support_refs=support, contradiction_refs=contradiction,
        assumptions=payload.get("assumptions", []), limitations=payload.get("limitations", []),
        status="draft", synthetic=bool(payload.get("synthetic", False)),
    )
    db.add(claim)
    db.flush()
    record_event(db, "SCIENTIFIC_CLAIM_DRAFTED", "scientific_claim", claim.id,
                 actor="claim-registry", payload={"support_ref_count": len(support),
                 "contradiction_ref_count": len(contradiction)})
    return claim


def review_claim(db: Session, claim_id: str, *, decision: str, reviewer: str,
                 note: str, checked_refs: list[str]) -> ScientificClaim:
    allowed = {"supported_for_review", "partially_supported", "contradicted", "inconclusive", "rejected"}
    if decision not in allowed:
        raise ValueError("Invalid scientific claim review decision")
    if not reviewer.strip() or len(note.strip()) < 12:
        raise ValueError("Claim review needs a named reviewer and substantive note")
    claim = db.get(ScientificClaim, claim_id)
    if not claim:
        raise KeyError(claim_id)
    required_refs = set(claim.support_refs or []) | set(claim.contradiction_refs or [])
    if not required_refs:
        raise ValueError("A claim cannot be reviewed without explicit evidence references")
    missing = sorted(ref for ref in required_refs if not _reference_exists(db, ref))
    if missing:
        raise ValueError(f"Claim includes unresolved evidence references: {missing}")
    if not required_refs.issubset(set(checked_refs)):
        raise ValueError("Reviewer must explicitly attest to checking every linked evidence reference")
    if decision in {"supported_for_review", "partially_supported"}:
        unverified_sources = []
        nonaccepted_measurements = []
        predictions_supporting_empirical_claim = []
        for ref in claim.support_refs or []:
            source = db.get(ResearchSource, ref)
            measurement = db.get(Measurement, ref)
            prediction = db.get(ScientificPrediction, ref)
            if source and source.verification_status != "metadata_reviewed":
                unverified_sources.append(ref)
            if measurement and measurement.quality_status != "accepted":
                nonaccepted_measurements.append(ref)
            if prediction and claim.claim_type != "computational_result":
                predictions_supporting_empirical_claim.append(ref)
        if unverified_sources:
            raise ValueError(f"Supporting literature metadata is not reviewed: {unverified_sources}")
        if nonaccepted_measurements:
            raise ValueError(f"Supporting measurements are not quality accepted: {nonaccepted_measurements}")
        if predictions_supporting_empirical_claim:
            raise ValueError("Model predictions cannot independently establish an empirical claim; label the claim computational_result or retain an inconclusive status")
    claim.status = decision
    claim.reviewer = reviewer
    claim.review_note = note
    record_event(db, "SCIENTIFIC_CLAIM_REVIEWED", "scientific_claim", claim.id,
                 actor=reviewer, payload={"decision": decision, "checked_refs": sorted(checked_refs)})
    db.flush()
    return claim
