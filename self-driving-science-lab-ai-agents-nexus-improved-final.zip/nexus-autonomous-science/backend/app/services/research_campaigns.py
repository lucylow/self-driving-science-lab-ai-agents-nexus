"""Governed multi-stage research campaigns built on existing workflow runs.

Campaigns coordinate analytical workflows; they never issue physical instrument commands.
Each stage is reviewed by a scientist before the next stage can be launched.
"""
from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from typing import Any
from uuid import uuid4

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.entities import (
    Objective, ResearchCampaignEventRecord, ResearchCampaignRecord,
    WorkflowRunRecord,
)
from app.services.domain_registry import get_domain
from app.services.workflow_supervisor import WORKFLOW_PLANS, start_workflow


CAMPAIGN_STATES = {
    "awaiting_approval", "approved", "running", "awaiting_scientist_review",
    "blocked", "completed", "cancelled",
}
STAGE_STATES = {"planned", "running", "awaiting_scientist_review", "completed", "failed", "needs_revision"}

DEFAULT_STAGE_BY_LAB = {
    "SDL0": "dataset_quality_review",
    "SDL1": "sdl1_candidate_review",
    "SDL2": "cross_lab_evidence_review",
    "SDL3": "cross_lab_evidence_review",
    "SDL4": "cross_lab_evidence_review",
    "SDL5": "dataset_quality_review",
    "SDL6": "dataset_quality_review",
    "SDL7": "dataset_quality_review",
}

STAGE_TITLES = {
    "sdl1_candidate_review": "Inorganic materials candidate review",
    "cross_lab_evidence_review": "Scientific evidence review",
    "dataset_quality_review": "Scientific dataset quality review",
}


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _hash(payload: dict[str, Any]) -> str:
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _event(db: Session, campaign: ResearchCampaignRecord, event_type: str,
           actor: str, payload: dict[str, Any]) -> ResearchCampaignEventRecord:
    last = db.scalar(select(ResearchCampaignEventRecord).where(
        ResearchCampaignEventRecord.campaign_id == campaign.id
    ).order_by(ResearchCampaignEventRecord.sequence.desc()).limit(1))
    sequence = last.sequence + 1 if last else 0
    previous_hash = last.event_hash if last else ""
    body = {
        "campaign_id": campaign.id, "sequence": sequence,
        "event_type": event_type, "actor": actor,
        "payload": payload, "previous_hash": previous_hash,
    }
    event = ResearchCampaignEventRecord(
        id=str(uuid4()), **body, event_hash=_hash(body),
    )
    db.add(event)
    db.flush()
    return event


def list_campaign_events(db: Session, campaign_id: str) -> list[ResearchCampaignEventRecord]:
    return db.scalars(select(ResearchCampaignEventRecord).where(
        ResearchCampaignEventRecord.campaign_id == campaign_id
    ).order_by(ResearchCampaignEventRecord.sequence.asc())).all()


def verify_campaign_events(events: list[ResearchCampaignEventRecord]) -> dict[str, Any]:
    ordered = sorted(events, key=lambda item: item.sequence)
    issues: list[dict[str, Any]] = []
    previous_hash = ""
    for expected, event in enumerate(ordered):
        if event.sequence != expected:
            issues.append({"event_id": event.id, "code": "sequence_gap"})
        if event.previous_hash != previous_hash:
            issues.append({"event_id": event.id, "code": "previous_hash_mismatch"})
        body = {
            "campaign_id": event.campaign_id, "sequence": event.sequence,
            "event_type": event.event_type, "actor": event.actor,
            "payload": event.payload, "previous_hash": event.previous_hash,
        }
        if event.event_hash != _hash(body):
            issues.append({"event_id": event.id, "code": "content_hash_mismatch"})
        previous_hash = event.event_hash
    return {"valid": not issues, "event_count": len(ordered), "issues": issues,
            "head_hash": previous_hash if ordered else None, "append_only": True}


def _campaign_stages(laboratory_code: str, workflow_keys: list[str] | None) -> list[dict[str, Any]]:
    keys = workflow_keys or [DEFAULT_STAGE_BY_LAB[laboratory_code]]
    if not keys or len(keys) > 6:
        raise ValueError("A campaign must contain between one and six stages")
    if len(set(keys)) != len(keys):
        raise ValueError("Campaign stage workflow keys must be unique")
    unknown = [key for key in keys if key not in WORKFLOW_PLANS]
    if unknown:
        raise ValueError(f"Unknown workflow stages: {', '.join(unknown)}")
    if "sdl1_candidate_review" in keys and laboratory_code != "SDL1":
        raise ValueError("The SDL1 candidate review stage is restricted to SDL1")
    return [{
        "index": index,
        "stage_key": f"stage-{index + 1}",
        "workflow_key": key,
        "title": STAGE_TITLES.get(key, key.replace("_", " ").title()),
        "status": "planned",
        "workflow_run_id": None,
        "started_at": None,
        "reviewed_at": None,
        "reviewer": None,
        "review_note": "",
    } for index, key in enumerate(keys)]


def create_campaign(db: Session, *, title: str, description: str,
                    laboratory_code: str, objective_id: str,
                    workflow_keys: list[str] | None = None,
                    constraints: dict | None = None, synthetic: bool = True,
                    actor: str = "campaign-author") -> ResearchCampaignRecord:
    if not title.strip():
        raise ValueError("Campaign title is required")
    laboratory_code = laboratory_code.upper()
    domain = get_domain(laboratory_code)
    objective = db.get(Objective, objective_id)
    if not objective:
        raise ValueError("Research objective does not exist")
    if objective.laboratory_code.upper() != laboratory_code or objective.domain != domain["domain"]:
        raise ValueError("Campaign laboratory and domain must match the referenced objective")
    stages = _campaign_stages(laboratory_code, workflow_keys)
    clean_constraints = constraints or {}
    if clean_constraints.get("physical_execution") is True or clean_constraints.get("execution_mode") == "physical":
        raise ValueError("Research campaigns are analytical and simulation-only; physical execution is disabled")
    campaign = ResearchCampaignRecord(
        id=str(uuid4()), campaign_code=f"CAM-{uuid4().hex[:10].upper()}",
        title=title.strip(), description=description.strip(),
        laboratory_code=laboratory_code, domain=domain["domain"],
        objective_id=objective_id, status="awaiting_approval",
        execution_mode="simulation_only", stages_json=stages, current_stage_index=0,
        constraints_json=clean_constraints, approval_json={}, result_summary={},
        synthetic=synthetic,
    )
    db.add(campaign)
    db.flush()
    _event(db, campaign, "CAMPAIGN_CREATED", actor, {
        "laboratory_code": laboratory_code, "domain": domain["domain"],
        "stage_count": len(stages), "synthetic": synthetic,
        "execution_mode": "simulation_only",
    })
    db.flush()
    return campaign


def approve_campaign(db: Session, campaign: ResearchCampaignRecord, *,
                     reviewer: str, note: str = "") -> ResearchCampaignRecord:
    if campaign.status != "awaiting_approval":
        raise ValueError(f"Campaign cannot be approved from state '{campaign.status}'")
    if not reviewer.strip():
        raise ValueError("A named human reviewer is required")
    campaign.approval_json = {
        "approved": True, "reviewer": reviewer.strip(),
        "note": note.strip(), "approved_at": _now().isoformat(),
        "authority": "human_reviewer",
    }
    campaign.status = "approved"
    _event(db, campaign, "CAMPAIGN_APPROVED", reviewer.strip(), {"note": note.strip()})
    db.flush()
    return campaign


def launch_next_stage(db: Session, campaign: ResearchCampaignRecord, *,
                      subject_id: str | None = None,
                      context: dict[str, Any] | None = None) -> ResearchCampaignRecord:
    if campaign.status != "approved":
        raise ValueError("Campaign must be approved and have no stage awaiting review")
    stages = list(campaign.stages_json or [])
    index = campaign.current_stage_index
    if index >= len(stages):
        campaign.status = "completed"
        campaign.result_summary = {**campaign.result_summary, "completed_stage_count": len(stages)}
        _event(db, campaign, "CAMPAIGN_COMPLETED", "nexus-campaign-manager", {})
        db.flush()
        return campaign
    stage = dict(stages[index])
    if stage["status"] not in {"planned", "failed"}:
        raise ValueError("Current campaign stage is not launchable")
    stage["status"] = "running"
    stage["started_at"] = _now().isoformat()
    stages[index] = stage
    campaign.stages_json = stages
    campaign.status = "running"
    _event(db, campaign, "CAMPAIGN_STAGE_STARTED", "nexus-campaign-manager", {
        "stage_key": stage["stage_key"], "workflow_key": stage["workflow_key"],
    })
    db.commit()
    try:
        workflow_context = {
            "campaign_id": campaign.id,
            "campaign_code": campaign.campaign_code,
            "campaign_stage": stage["stage_key"],
            "research_context": context or {},
            "constraints": campaign.constraints_json,
            "execution_mode": "simulation_only",
        }
        workflow = start_workflow(
            db, workflow_key=stage["workflow_key"],
            laboratory_code=campaign.laboratory_code,
            objective_id=campaign.objective_id, subject_id=subject_id or campaign.id,
            context=workflow_context, synthetic=campaign.synthetic,
        )
        stages = list(campaign.stages_json or [])
        stage = dict(stages[index])
        stage["workflow_run_id"] = workflow.id
        stage["status"] = "awaiting_scientist_review" if workflow.status == "awaiting_scientist_review" else "failed"
        stages[index] = stage
        campaign.stages_json = stages
        campaign.status = "awaiting_scientist_review" if workflow.status == "awaiting_scientist_review" else "blocked"
        if workflow.status != "awaiting_scientist_review":
            campaign.result_summary = {**campaign.result_summary, "last_error": workflow.error_summary}
        _event(db, campaign, "CAMPAIGN_STAGE_WORKFLOW_LINKED", "nexus-campaign-manager", {
            "stage_key": stage["stage_key"], "workflow_run_id": workflow.id,
            "workflow_status": workflow.status,
        })
        db.commit()
        return campaign
    except Exception as exc:
        db.rollback()
        campaign = db.get(ResearchCampaignRecord, campaign.id)
        if not campaign:
            raise
        stages = list(campaign.stages_json or [])
        stage = dict(stages[index])
        stage["status"] = "failed"
        stage["failure_reason"] = str(exc)[:1000]
        stages[index] = stage
        campaign.stages_json = stages
        campaign.status = "blocked"
        campaign.result_summary = {**campaign.result_summary, "last_error": str(exc)[:1000]}
        _event(db, campaign, "CAMPAIGN_STAGE_FAILED", "nexus-campaign-manager", {
            "stage_key": stage["stage_key"], "error": str(exc)[:1000],
        })
        db.commit()
        return campaign


def review_campaign_stage(db: Session, campaign: ResearchCampaignRecord, *,
                          decision: str, reviewer: str, note: str = "") -> ResearchCampaignRecord:
    if campaign.status != "awaiting_scientist_review":
        raise ValueError("Campaign has no stage awaiting scientist review")
    if decision not in {"accepted", "rejected"}:
        raise ValueError("decision must be accepted or rejected")
    if not reviewer.strip():
        raise ValueError("A named human reviewer is required")
    stages = list(campaign.stages_json or [])
    index = campaign.current_stage_index
    stage = dict(stages[index])
    if stage["status"] != "awaiting_scientist_review":
        raise ValueError("Current stage is not awaiting review")
    stage["reviewer"] = reviewer.strip()
    stage["review_note"] = note.strip()
    stage["reviewed_at"] = _now().isoformat()
    stage["status"] = "completed" if decision == "accepted" else "needs_revision"
    stages[index] = stage
    campaign.stages_json = stages
    if decision == "accepted":
        campaign.current_stage_index = index + 1
        if campaign.current_stage_index >= len(stages):
            campaign.status = "completed"
            campaign.result_summary = {
                **campaign.result_summary, "completed_stage_count": len(stages),
                "scientist_reviewed": True,
            }
            event_type = "CAMPAIGN_COMPLETED"
        else:
            campaign.status = "approved"
            event_type = "CAMPAIGN_STAGE_ACCEPTED"
    else:
        campaign.status = "blocked"
        campaign.result_summary = {**campaign.result_summary, "review_block": note.strip() or "Scientific review rejected this stage."}
        event_type = "CAMPAIGN_STAGE_REJECTED"
    _event(db, campaign, event_type, reviewer.strip(), {
        "stage_key": stage["stage_key"], "decision": decision, "note": note.strip(),
    })
    db.flush()
    return campaign


def cancel_campaign(db: Session, campaign: ResearchCampaignRecord, *,
                    actor: str, reason: str) -> ResearchCampaignRecord:
    if campaign.status in {"completed", "cancelled"}:
        raise ValueError(f"Campaign cannot be cancelled from state '{campaign.status}'")
    if not actor.strip() or not reason.strip():
        raise ValueError("Cancellation actor and reason are required")
    campaign.status = "cancelled"
    campaign.result_summary = {**campaign.result_summary, "cancellation_reason": reason.strip()}
    _event(db, campaign, "CAMPAIGN_CANCELLED", actor.strip(), {"reason": reason.strip()})
    db.flush()
    return campaign


def serialize_campaign(campaign: ResearchCampaignRecord, *, include_events: bool = False,
                       events: list[ResearchCampaignEventRecord] | None = None) -> dict[str, Any]:
    output = {
        "id": campaign.id, "campaign_code": campaign.campaign_code,
        "title": campaign.title, "description": campaign.description,
        "laboratory_code": campaign.laboratory_code, "domain": campaign.domain,
        "objective_id": campaign.objective_id, "status": campaign.status,
        "execution_mode": campaign.execution_mode, "stages": campaign.stages_json,
        "current_stage_index": campaign.current_stage_index,
        "constraints": campaign.constraints_json, "approval": campaign.approval_json,
        "result_summary": campaign.result_summary, "synthetic": campaign.synthetic,
        "created_at": campaign.created_at.isoformat() if campaign.created_at else None,
        "updated_at": campaign.updated_at.isoformat() if campaign.updated_at else None,
    }
    if include_events:
        event_rows = events or []
        output["event_integrity"] = verify_campaign_events(event_rows)
        output["events"] = [{
            "sequence": event.sequence, "type": event.event_type,
            "actor": event.actor, "payload": event.payload,
            "hash": event.event_hash,
            "created_at": event.created_at.isoformat() if event.created_at else None,
        } for event in event_rows]
    return output


def get_campaign_or_raise(db: Session, campaign_id: str) -> ResearchCampaignRecord:
    campaign = db.get(ResearchCampaignRecord, campaign_id)
    if not campaign:
        raise KeyError(campaign_id)
    return campaign
