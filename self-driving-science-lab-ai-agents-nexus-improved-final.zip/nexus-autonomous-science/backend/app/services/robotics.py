"""Robotics planning interface for simulation evaluation only."""

from dataclasses import dataclass
from typing import Any


@dataclass
class RobotPlanReview:
    plan_id: str
    status: str
    checks: dict[str, bool]
    blockers: list[str]
    warnings: list[str]
    physical_execution_allowed: bool = False


def review_robot_plan(plan: dict[str, Any], workspace: dict[str, Any]) -> RobotPlanReview:
    blockers = []
    warnings = []
    checks = {
        "has_plan_id": bool(plan.get("plan_id")),
        "has_named_target": bool(plan.get("target_id")),
        "workspace_declared": bool(workspace.get("workspace_id")),
        "collision_check_reported": bool(plan.get("collision_check_report_ref")),
        "simulation_reference_present": bool(plan.get("simulation_run_ref")),
    }
    for key, passed in checks.items():
        if not passed:
            blockers.append(f"Missing prerequisite: {key}")
    if plan.get("simulation_result") == "success":
        warnings.append("Simulation success is not physical robot acceptance.")
    if not plan.get("operator_review_ref"):
        warnings.append("Operator review record is missing.")
    return RobotPlanReview(
        plan_id=str(plan.get("plan_id", "unidentified")),
        status="reviewable" if not blockers else "blocked",
        checks=checks, blockers=blockers, warnings=warnings,
    )


def simulation_acceptance_metrics(runs: list[dict[str, Any]]) -> dict[str, Any]:
    if not runs:
        return {"runs": 0, "success_rate": None, "collision_rate": None, "physical_validation": "not_performed"}
    success = sum(run.get("status") == "success" for run in runs)
    collisions = sum(bool(run.get("collision_detected")) for run in runs)
    return {
        "runs": len(runs),
        "success_rate": success / len(runs),
        "collision_rate": collisions / len(runs),
        "physical_validation": "not_performed",
        "note": "Metrics describe simulation fixtures only.",
    }
