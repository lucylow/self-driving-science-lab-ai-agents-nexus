"""Sample registration and lineage integrity services."""
from __future__ import annotations
from uuid import uuid4
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.models.entities import ScientificSample
from app.services.domain_registry import get_domain
from app.services.audit import record_event


def register_sample(db: Session, payload: dict) -> ScientificSample:
    if payload.get("identity_status", "unverified") != "unverified":
        raise ValueError("Sample identity can only be changed through the evidence-backed verification workflow")
    existing = db.scalar(select(ScientificSample).where(ScientificSample.code == payload["code"].upper()))
    if existing:
        raise ValueError(f"Sample code '{payload['code']}' already exists")
    lab = payload["laboratory_code"].upper()
    domain = get_domain(lab)["domain"]
    if payload["domain"] != domain:
        raise ValueError(f"Domain '{payload['domain']}' does not match {lab} domain '{domain}'")
    parent_id = payload.get("parent_sample_id")
    if parent_id:
        parent = db.get(ScientificSample, parent_id)
        if not parent:
            raise ValueError("Parent sample does not exist")
        if parent.domain != domain:
            raise ValueError("Parent sample must be in the same scientific domain; use a transfer package across labs")
    sample = ScientificSample(
        id=str(uuid4()), code=payload["code"].upper(), name=payload["name"],
        laboratory_code=lab, domain=domain, sample_type=payload.get("sample_type", "material"),
        parent_sample_id=parent_id, composition=payload.get("composition", {}),
        preparation_metadata=payload.get("preparation_metadata", {}),
        identity_status="unverified",
        lifecycle_status="registered", provenance=payload.get("provenance", {}),
        synthetic=bool(payload.get("synthetic", True)),
    )
    db.add(sample)
    db.flush()
    record_event(db, "SAMPLE_REGISTERED", "sample", sample.id,
                 actor="sample-registry", payload={"code": sample.code, "domain": domain, "synthetic": sample.synthetic})
    return sample


def verify_sample_identity(db: Session, sample_id: str, *, reviewer: str, evidence_refs: list[str], note: str = "") -> ScientificSample:
    sample = db.get(ScientificSample, sample_id)
    if not sample:
        raise KeyError(sample_id)
    if sample.identity_status == "rejected":
        raise ValueError("Rejected sample identity cannot be verified; register a corrected identity record")
    if not reviewer.strip() or not evidence_refs:
        raise ValueError("Identity verification requires a reviewer and at least one evidence reference")
    sample.identity_status = "verified"
    sample.provenance = {
        **(sample.provenance or {}),
        "identity_review": {"reviewer": reviewer, "evidence_refs": evidence_refs, "note": note},
    }
    record_event(db, "SAMPLE_IDENTITY_VERIFIED", "sample", sample.id, actor=reviewer,
                 payload={"evidence_refs": evidence_refs, "synthetic": sample.synthetic})
    db.flush()
    return sample


def list_sample_ancestry(db: Session, sample_id: str, *, max_depth: int = 50) -> list[dict]:
    ancestry = []
    seen: set[str] = set()
    current_id: str | None = sample_id
    while current_id:
        if current_id in seen:
            raise ValueError("Sample lineage cycle detected")
        if len(ancestry) >= max_depth:
            raise ValueError("Sample lineage exceeds the configured depth limit")
        seen.add(current_id)
        item = db.get(ScientificSample, current_id)
        if not item:
            raise KeyError(current_id)
        ancestry.append({"id": item.id, "code": item.code, "domain": item.domain,
                         "lifecycle_status": item.lifecycle_status, "synthetic": item.synthetic})
        current_id = item.parent_sample_id
    return ancestry
