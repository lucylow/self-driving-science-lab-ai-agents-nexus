"""Explainable resource-aware experiment scheduling baseline."""

from dataclasses import dataclass
from typing import Any


@dataclass
class ScheduleDecision:
    experiment_id: str
    slot: str
    score: float
    reasons: list[str]
    conflicts: list[str]


def schedule_experiments(experiments: list[dict[str, Any]], instruments: list[dict[str, Any]]) -> list[ScheduleDecision]:
    available = {item["id"] for item in instruments if item.get("status") in {"idle", "simulated", "available"}}
    ordered = sorted(experiments, key=lambda item: (item.get("priority", 0), -item.get("duration_minutes", 60)), reverse=True)
    decisions: list[ScheduleDecision] = []
    for index, experiment in enumerate(ordered):
        required = set(experiment.get("instrument_ids", []))
        conflicts = sorted(required - available)
        score = max(0.0, float(experiment.get("priority", 0)) * 10 - len(conflicts) * 20)
        reasons = [f"Priority contribution: {experiment.get('priority', 0)}"]
        reasons.append("All requested resources are listed as available." if not conflicts else f"Unavailable resources: {', '.join(conflicts)}")
        reasons.append("Demo scheduler is advisory and does not reserve laboratory equipment.")
        decisions.append(ScheduleDecision(
            experiment_id=str(experiment.get("id", f"unidentified-{index}")),
            slot=f"DEMO-SLOT-{index + 1:02d}", score=score, reasons=reasons, conflicts=conflicts,
        ))
        if not conflicts:
            available -= required
    return decisions
