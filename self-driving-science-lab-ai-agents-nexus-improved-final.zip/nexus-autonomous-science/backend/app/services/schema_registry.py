"""A small, in-process schema registry with explicit versions and compatibility checks."""
from __future__ import annotations
from copy import deepcopy
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any
import re

_SEMVER = re.compile(r"^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$")


def parse_version(version: str) -> tuple[int, int, int]:
    match = _SEMVER.fullmatch(version)
    if not match:
        raise ValueError("schema version must use semantic versioning MAJOR.MINOR.PATCH")
    return tuple(int(part) for part in match.groups())


@dataclass(frozen=True)
class FieldDefinition:
    name: str
    value_type: str
    required: bool = False
    nullable: bool = False
    unit: str | None = None
    description: str = ""


@dataclass(frozen=True)
class SchemaDefinition:
    schema_key: str
    version: str
    domain: str
    fields: tuple[FieldDefinition, ...]
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        parse_version(self.version)
        if not self.schema_key.strip() or not self.domain.strip():
            raise ValueError("schema key and domain are required")
        field_names = [item.name for item in self.fields]
        if len(field_names) != len(set(field_names)):
            raise ValueError("schema field names must be unique")


class SchemaRegistry:
    def __init__(self):
        self._schemas: dict[tuple[str, str], SchemaDefinition] = {}
        self._latest: dict[str, str] = {}

    def register(self, schema: SchemaDefinition) -> dict[str, Any]:
        key = (schema.schema_key, schema.version)
        if key in self._schemas:
            raise ValueError("schema version is immutable and already registered")
        latest = self._latest.get(schema.schema_key)
        if latest is not None and parse_version(schema.version) <= parse_version(latest):
            raise ValueError("new schema version must be greater than the latest version")
        self._schemas[key] = schema
        self._latest[schema.schema_key] = schema.version
        return {"schema_key": schema.schema_key, "version": schema.version,
                "registered": True, "latest": True}

    def get(self, schema_key: str, version: str | None = None) -> SchemaDefinition:
        resolved = version or self._latest.get(schema_key)
        if resolved is None or (schema_key, resolved) not in self._schemas:
            raise KeyError(f"schema not found: {schema_key}@{resolved or 'latest'}")
        return self._schemas[(schema_key, resolved)]

    def list(self, domain: str | None = None) -> list[dict[str, Any]]:
        items = []
        for (key, version), schema in sorted(self._schemas.items()):
            if domain and schema.domain != domain:
                continue
            items.append({"schema_key": key, "version": version, "domain": schema.domain,
                          "field_count": len(schema.fields), "latest": self._latest[key] == version})
        return items

    def validate(self, schema_key: str, payload: dict[str, Any], version: str | None = None) -> dict[str, Any]:
        schema = self.get(schema_key, version)
        definitions = {field.name: field for field in schema.fields}
        issues: list[dict[str, str]] = []
        for name, definition in definitions.items():
            if definition.required and name not in payload:
                issues.append({"field": name, "code": "required", "message": "Required field is absent."})
                continue
            if name not in payload:
                continue
            value = payload[name]
            if value is None:
                if not definition.nullable:
                    issues.append({"field": name, "code": "null_not_allowed", "message": "Field cannot be null."})
                continue
            expected = definition.value_type
            valid = {
                "string": lambda v: isinstance(v, str),
                "number": lambda v: isinstance(v, (int, float)) and not isinstance(v, bool),
                "integer": lambda v: isinstance(v, int) and not isinstance(v, bool),
                "boolean": lambda v: isinstance(v, bool),
                "object": lambda v: isinstance(v, dict),
                "array": lambda v: isinstance(v, list),
            }.get(expected)
            if valid is None:
                issues.append({"field": name, "code": "unknown_schema_type", "message": f"Unsupported field type {expected}."})
            elif not valid(value):
                issues.append({"field": name, "code": "type_mismatch", "message": f"Expected {expected}."})
        unknown = sorted(set(payload) - set(definitions))
        return {"valid": not issues, "schema_key": schema_key, "schema_version": schema.version,
                "domain": schema.domain, "issues": issues,
                "unknown_fields": unknown, "unknown_fields_policy": "warn_only"}

    def compare(self, schema_key: str, from_version: str, to_version: str) -> dict[str, Any]:
        before, after = self.get(schema_key, from_version), self.get(schema_key, to_version)
        old = {f.name: f for f in before.fields}; new = {f.name: f for f in after.fields}
        added = sorted(set(new) - set(old)); removed = sorted(set(old) - set(new))
        changed = sorted(name for name in set(old) & set(new) if old[name] != new[name])
        breaking = bool(removed or any(new[name].required and not old[name].required for name in added)
                        or any(new[name].value_type != old[name].value_type or (old[name].nullable and not new[name].nullable)
                               for name in changed))
        return {"schema_key": schema_key, "from_version": from_version, "to_version": to_version,
                "added_fields": added, "removed_fields": removed, "changed_fields": changed,
                "potentially_breaking": breaking,
                "note": "Compatibility is structural; downstream scientific meaning requires domain review."}


def default_registry() -> SchemaRegistry:
    registry = SchemaRegistry()
    registry.register(SchemaDefinition("scientific_measurement", "1.0.0", "shared", (
        FieldDefinition("measurement_id", "string", True),
        FieldDefinition("sample_id", "string", True),
        FieldDefinition("property_name", "string", True),
        FieldDefinition("value", "number", True),
        FieldDefinition("unit", "string", True),
        FieldDefinition("origin", "string", True),
        FieldDefinition("synthetic", "boolean", True),
        FieldDefinition("context", "object", True),
    )))
    registry.register(SchemaDefinition("scientific_sample", "1.0.0", "shared", (
        FieldDefinition("sample_id", "string", True),
        FieldDefinition("laboratory_code", "string", True),
        FieldDefinition("domain", "string", True),
        FieldDefinition("identity_status", "string", True),
        FieldDefinition("composition", "object", False),
    )))
    for domain, schema_fields in {
        "inorganic_materials": (FieldDefinition("formula", "string", True), FieldDefinition("phase_method", "string", False)),
        "polymers": (FieldDefinition("polymer_family", "string", True), FieldDefinition("molecular_weight_method", "string", False)),
        "biological_systems": (FieldDefinition("biological_model_id", "string", True), FieldDefinition("passage_or_batch", "string", True)),
    }.items():
        registry.register(SchemaDefinition(f"{domain}_sample", "1.0.0", domain, schema_fields))
    return registry
