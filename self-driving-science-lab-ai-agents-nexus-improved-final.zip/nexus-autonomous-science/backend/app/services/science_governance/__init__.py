"""Governance primitives for model releases and agent capacity."""
