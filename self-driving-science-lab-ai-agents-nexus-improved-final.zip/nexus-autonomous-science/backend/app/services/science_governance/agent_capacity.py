"""Local single-process agent quotas, circuit breakers and budget accounting.

This implementation is for local/demo deployments. Multi-worker production systems
must back these atomic operations with Redis or another transactional coordinator.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from threading import RLock
from typing import Any


@dataclass
class AgentBudget:
    agent_id: str
    max_concurrent: int = 1
    max_runs_per_window: int = 20
    window_seconds: int = 3600
    max_tokens_per_run: int = 12000
    max_tool_calls_per_run: int = 30
    active_runs: int = 0
    run_timestamps: list[datetime] = field(default_factory=list)


class LocalCapacityManager:
    def __init__(self):
        self._budgets: dict[str, AgentBudget] = {}
        self._lock = RLock()

    def register(self, budget: AgentBudget) -> None:
        if budget.max_concurrent < 1 or budget.max_runs_per_window < 1 or budget.window_seconds < 1:
            raise ValueError("agent capacity limits must be positive")
        with self._lock:
            if budget.agent_id in self._budgets:
                raise ValueError("agent budget already registered")
            self._budgets[budget.agent_id] = budget

    def acquire(self, agent_id: str, *, now: datetime | None = None) -> dict[str, Any]:
        current = now or datetime.now(timezone.utc)
        with self._lock:
            budget = self._budgets.get(agent_id)
            if budget is None:
                raise KeyError(f"agent budget not registered: {agent_id}")
            cutoff = current - timedelta(seconds=budget.window_seconds)
            budget.run_timestamps = [stamp for stamp in budget.run_timestamps if stamp >= cutoff]
            if budget.active_runs >= budget.max_concurrent:
                return {"granted": False, "reason": "concurrency_limit", "retry_after_seconds": 5}
            if len(budget.run_timestamps) >= budget.max_runs_per_window:
                next_allowed = budget.run_timestamps[0] + timedelta(seconds=budget.window_seconds)
                return {"granted": False, "reason": "rate_limit",
                        "retry_after_seconds": max(0, int((next_allowed-current).total_seconds()))}
            budget.active_runs += 1
            budget.run_timestamps.append(current)
            return {"granted": True, "agent_id": agent_id,
                    "remaining_window_runs": budget.max_runs_per_window-len(budget.run_timestamps),
                    "active_runs": budget.active_runs}

    def release(self, agent_id: str) -> None:
        with self._lock:
            budget = self._budgets.get(agent_id)
            if budget is None:
                raise KeyError(f"agent budget not registered: {agent_id}")
            budget.active_runs = max(0, budget.active_runs - 1)

    def enforce_run_budget(self, agent_id: str, *, token_count: int, tool_call_count: int) -> dict[str, Any]:
        budget = self._budgets.get(agent_id)
        if budget is None:
            raise KeyError(f"agent budget not registered: {agent_id}")
        violations = []
        if token_count < 0 or token_count > budget.max_tokens_per_run:
            violations.append("token_budget_exceeded_or_invalid")
        if tool_call_count < 0 or tool_call_count > budget.max_tool_calls_per_run:
            violations.append("tool_call_budget_exceeded_or_invalid")
        return {"allowed": not violations, "violations": violations,
                "limits": {"max_tokens": budget.max_tokens_per_run,
                           "max_tool_calls": budget.max_tool_calls_per_run}}


@dataclass
class CircuitState:
    failure_threshold: int = 4
    reset_after_seconds: int = 60
    failures: int = 0
    opened_at: datetime | None = None
    half_open_probe_active: bool = False


class CircuitBreaker:
    def __init__(self, state: CircuitState | None = None):
        self.state = state or CircuitState()

    def permit(self, *, now: datetime | None = None) -> dict[str, Any]:
        current = now or datetime.now(timezone.utc)
        state = self.state
        if state.opened_at is None:
            return {"allowed": True, "state": "closed"}
        elapsed = (current - state.opened_at).total_seconds()
        if elapsed < state.reset_after_seconds:
            return {"allowed": False, "state": "open",
                    "retry_after_seconds": max(0, int(state.reset_after_seconds-elapsed))}
        if state.half_open_probe_active:
            return {"allowed": False, "state": "half_open", "retry_after_seconds": 1}
        state.half_open_probe_active = True
        return {"allowed": True, "state": "half_open", "probe_required": True}

    def record_success(self) -> None:
        self.state.failures = 0
        self.state.opened_at = None
        self.state.half_open_probe_active = False

    def record_failure(self, *, now: datetime | None = None) -> dict[str, Any]:
        current = now or datetime.now(timezone.utc)
        self.state.failures += 1
        self.state.half_open_probe_active = False
        if self.state.failures >= self.state.failure_threshold:
            self.state.opened_at = current
        return {"failures": self.state.failures,
                "state": "open" if self.state.opened_at else "closed"}


def aggregate_agent_capacity(statuses: list[dict[str, Any]]) -> dict[str, Any]:
    total = len(statuses)
    running = sum(item.get("status") == "running" for item in statuses)
    blocked = sum(item.get("status") in {"blocked", "circuit_open", "rate_limited"} for item in statuses)
    failed = sum(item.get("status") == "failed" for item in statuses)
    return {"agent_count": total, "running": running, "blocked": blocked,
            "failed": failed, "idle_or_complete": total-running-blocked-failed,
            "availability_fraction": (total-blocked-failed)/total if total else None}
