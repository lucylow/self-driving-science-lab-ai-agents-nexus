"""Scientific model release gates and champion/challenger comparisons."""
from __future__ import annotations
from typing import Any

RELEASE_STATES = ("registered", "research_only", "shadow", "candidate", "production", "retired")
_ALLOWED_TRANSITIONS = {
    "registered": {"research_only", "retired"},
    "research_only": {"shadow", "retired"},
    "shadow": {"candidate", "research_only", "retired"},
    "candidate": {"production", "shadow", "retired"},
    "production": {"retired", "candidate"},
    "retired": set(),
}


def evaluate_release_gate(*, model: dict[str, Any], evaluation: dict[str, Any],
                          approvals: list[dict[str, Any]], required_domains: list[str],
                          minimum_holdout_rows: int = 20, require_uncertainty_calibration: bool = True) -> dict[str, Any]:
    blockers: list[str] = []; warnings: list[str] = []
    if model.get("synthetic"):
        blockers.append("model is marked synthetic")
    if model.get("status") == "retired":
        blockers.append("retired models cannot be promoted")
    if not set(required_domains).issubset(set(model.get("supported_domains", []))):
        blockers.append("model does not declare all requested deployment domains")
    if evaluation.get("status") != "passed":
        blockers.append("latest evaluation is not passed")
    row_count = int(evaluation.get("holdout_rows", 0) or 0)
    if row_count < minimum_holdout_rows:
        blockers.append(f"holdout rows below required minimum ({row_count} < {minimum_holdout_rows})")
    if require_uncertainty_calibration and evaluation.get("uncertainty_calibrated") is not True:
        blockers.append("uncertainty calibration has not been independently reviewed")
    if evaluation.get("group_leakage_detected"):
        blockers.append("sample-group leakage detected in evaluation split")
    if evaluation.get("out_of_domain_fraction", 1.0) > 0.05:
        blockers.append("out-of-domain evaluation fraction exceeds 5 percent")
    approved = [item for item in approvals if item.get("decision") == "approved" and item.get("role") == "model_release_reviewer"]
    if not approved:
        blockers.append("independent model-release approval is missing")
    if not evaluation.get("benchmark_ids"):
        warnings.append("no benchmark identifiers are attached")
    if not evaluation.get("subgroup_metrics"):
        warnings.append("subgroup performance has not been reported")
    return {"eligible_for_review": not blockers, "blockers": blockers,
            "warnings": warnings, "release_state": "candidate" if not blockers else "research_only",
            "human_decision_required": True,
            "note": "This is a release-readiness check, not autonomous deployment authorization."}


def validate_release_transition(current_state: str, next_state: str, *,
                                gate_passed: bool = False, authorized_by: str | None = None) -> dict[str, Any]:
    if current_state not in RELEASE_STATES or next_state not in RELEASE_STATES:
        raise ValueError("unknown model release state")
    if next_state not in _ALLOWED_TRANSITIONS[current_state]:
        raise ValueError(f"transition {current_state} -> {next_state} is not allowed")
    if next_state in {"shadow", "candidate", "production"} and not gate_passed:
        raise ValueError("promotion transition requires a passed release gate")
    if next_state in {"candidate", "production"} and not (authorized_by or "").strip():
        raise ValueError("promotion to candidate or production requires a named human authorizer")
    return {"valid": True, "from": current_state, "to": next_state,
            "authorized_by": authorized_by, "promotion_gate_passed": gate_passed}


def compare_champion_challenger(champion: dict[str, Any], challenger: dict[str, Any], *,
                                metric: str, direction: str = "minimize",
                                minimum_relative_improvement: float = 0.02) -> dict[str, Any]:
    if direction not in ("minimize", "maximize") or not 0 <= minimum_relative_improvement < 1:
        raise ValueError("invalid comparison direction or improvement threshold")
    if champion.get("domain") != challenger.get("domain") or champion.get("target") != challenger.get("target"):
        raise ValueError("champion and challenger must use the same domain and target")
    a, b = float(champion.get(metric, float("nan"))), float(challenger.get(metric, float("nan")))
    if not all(map(lambda v: v == v and abs(v) != float("inf"), (a, b))):
        raise ValueError("comparison metric must be finite in both evaluations")
    delta = b - a
    improvement = (a - b) / abs(a) if direction == "minimize" and abs(a) > 1e-12 else ((b-a) / abs(a) if abs(a) > 1e-12 else 0.0)
    beats = b < a if direction == "minimize" else b > a
    material = beats and improvement >= minimum_relative_improvement
    return {"metric": metric, "champion_value": a, "challenger_value": b,
            "absolute_delta": delta, "relative_improvement": improvement,
            "challenger_better": beats, "minimum_improvement_met": material,
            "recommendation": "send_to_human_review" if material else "retain_champion_pending_review",
            "caveat": "Metric comparison is insufficient without uncertainty, subgroup, robustness, and applicability review."}


def model_rollback_plan(*, current_model_id: str, previous_model_id: str | None,
                        incident_id: str, reason: str, affected_domains: list[str]) -> dict[str, Any]:
    if not current_model_id.strip() or not incident_id.strip() or not reason.strip():
        raise ValueError("current model, incident and rollback reason are required")
    return {"incident_id": incident_id, "current_model_id": current_model_id,
            "previous_model_id": previous_model_id, "affected_domains": sorted(set(affected_domains)),
            "reason": reason, "rollback_ready": previous_model_id is not None,
            "actions": ["freeze promotion", "preserve current model and evaluation artifacts",
                        "route predictions to reviewed fallback if available", "notify model owners",
                        "re-evaluate affected predictions", "create incident postmortem"],
            "requires_human_authorization": True}
