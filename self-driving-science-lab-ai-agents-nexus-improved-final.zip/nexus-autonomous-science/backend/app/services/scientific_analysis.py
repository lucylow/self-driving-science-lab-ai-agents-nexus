"""Transparent descriptive statistics and data-quality checks for demo observations."""
from __future__ import annotations

from math import isfinite, sqrt
from statistics import mean, median, stdev
from typing import Any, Mapping, Sequence

# Two-sided 95% Student-t critical values for df 1..30; larger samples use the
# normal limit. This avoids presenting a normal interval as reliable for tiny n.
_T95 = (0.0, 12.706, 4.303, 3.182, 2.776, 2.571, 2.447, 2.365, 2.306,
        2.262, 2.228, 2.201, 2.179, 2.160, 2.145, 2.131, 2.120, 2.110,
        2.101, 2.093, 2.086, 2.080, 2.074, 2.069, 2.064, 2.060, 2.056,
        2.052, 2.048, 2.045, 2.042)


def _quantile(values: list[float], probability: float) -> float:
    ordered = sorted(values)
    position = (len(ordered) - 1) * probability
    lower = int(position)
    upper = min(lower + 1, len(ordered) - 1)
    fraction = position - lower
    return ordered[lower] * (1 - fraction) + ordered[upper] * fraction


def analyze_observations(observations: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    """Summarize finite numeric observations; explicitly report any exclusions.

    Outliers are identified with the 1.5-IQR rule and remain included in every
    statistic. Duplicate/missing/invalid observations are visible in the result.
    The confidence interval describes the sample mean under an independent,
    approximately normal sampling assumption; it is not a causal estimate.
    """
    seen: set[str] = set()
    valid: list[tuple[str, float, float | None]] = []
    missing_ids: list[str] = []
    missing_uncertainty_ids: list[str] = []
    invalid_ids: list[str] = []
    duplicate_ids: list[str] = []
    for index, row in enumerate(observations):
        raw_id = row.get("id")
        row_id = str(raw_id) if raw_id is not None else f"<missing-id:{index}>"
        if raw_id is None:
            invalid_ids.append(row_id)
            continue
        if row_id in seen:
            duplicate_ids.append(row_id)
            continue
        seen.add(row_id)
        raw_value = row.get("value")
        if raw_value is None:
            missing_ids.append(row_id)
            continue
        if isinstance(raw_value, bool) or not isinstance(raw_value, (int, float)) or not isfinite(raw_value):
            invalid_ids.append(row_id)
            continue
        value = float(raw_value)
        if row.get("metric") == "synthetic_quality_score" and (not 0 <= value <= 1 or row.get("unit") != "fraction_0_to_1"):
            invalid_ids.append(row_id)
            continue
        raw_uncertainty = row.get("uncertainty")
        uncertainty = None
        if raw_uncertainty is None:
            missing_uncertainty_ids.append(row_id)
        else:
            if isinstance(raw_uncertainty, bool) or not isinstance(raw_uncertainty, (int, float)) or not isfinite(raw_uncertainty) or raw_uncertainty < 0:
                invalid_ids.append(row_id)
                continue
            uncertainty = float(raw_uncertainty)
            if row.get("metric") == "synthetic_quality_score" and uncertainty > 1:
                invalid_ids.append(row_id)
                continue
        valid.append((row_id, value, uncertainty))

    values = [entry[1] for entry in valid]
    outlier_ids: list[str] = []
    if len(values) >= 4:
        q1, q3 = _quantile(values, 0.25), _quantile(values, 0.75)
        spread = q3 - q1
        low, high = q1 - 1.5 * spread, q3 + 1.5 * spread
        outlier_ids = [row_id for row_id, value, _ in valid if value < low or value > high]

    n = len(values)
    sample_sd = stdev(values) if n >= 2 else None
    standard_error = sample_sd / sqrt(n) if sample_sd is not None else None
    interval = None
    if standard_error is not None:
        df = n - 1
        critical = _T95[df] if df <= 30 else 1.96
        half_width = critical * standard_error
        interval = [mean(values) - half_width, mean(values) + half_width]

    high_uncertainty_ids = [row_id for row_id, _, uncertainty in valid if uncertainty is not None and uncertainty > 0.08]
    if invalid_ids or duplicate_ids:
        quality_status = "invalid"
    elif n == 0:
        quality_status = "needs_review"
    elif missing_ids or missing_uncertainty_ids or outlier_ids or high_uncertainty_ids:
        quality_status = "warning"
    else:
        quality_status = "valid"
    return {
        "records_received": len(observations), "n": n,
        "missing_count": len(missing_ids), "missing_ids": missing_ids,
        "missing_uncertainty_count": len(missing_uncertainty_ids), "missing_uncertainty_ids": missing_uncertainty_ids,
        "invalid_count": len(invalid_ids), "invalid_ids": invalid_ids,
        "duplicate_count": len(duplicate_ids), "duplicate_ids": duplicate_ids,
        "mean": round(mean(values), 6) if values else None,
        "median": round(median(values), 6) if values else None,
        "sample_standard_deviation": round(sample_sd, 6) if sample_sd is not None else None,
        "standard_error": round(standard_error, 6) if standard_error is not None else None,
        "confidence_level": 0.95 if interval is not None else None,
        "mean_confidence_interval_95": [round(value, 6) for value in interval] if interval else None,
        "minimum": round(min(values), 6) if values else None,
        "maximum": round(max(values), 6) if values else None,
        "outlier_ids": outlier_ids,
        "outliers_included_in_summary": True,
        "high_uncertainty_ids": high_uncertainty_ids,
        "high_uncertainty_threshold": 0.08,
        "quality_status": quality_status,
        "included_observation_ids": [entry[0] for entry in valid],
        "analysis_method": "Descriptive mean/median/sample SD; t-based two-sided 95% interval for df <= 30, normal-limit 1.96 thereafter; no causal interpretation.",
        "assumptions": ["observations are independent sampling units", "mean sampling distribution is approximately normal", "units and measurement protocol are comparable"],
        "limitations": "Synthetic observations are demonstration fixtures. Small or clustered samples may make the interval unreliable; flagged outliers are retained, not automatically removed.",
    }
