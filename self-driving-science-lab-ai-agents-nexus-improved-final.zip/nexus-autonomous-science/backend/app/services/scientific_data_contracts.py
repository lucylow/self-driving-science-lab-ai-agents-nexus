"""Versioned scientific measurement contracts and conservative unit normalization.

The contract catalogue is deliberately explicit. A unit is only convertible when a
known dimensional relationship is registered; unknown units are preserved as raw
strings and never silently treated as dimensionless.
"""
from __future__ import annotations
from copy import deepcopy
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any
import math


@dataclass(frozen=True)
class UnitDefinition:
    symbol: str
    dimension: str
    factor_to_base: float
    offset_to_base: float = 0.0


UNIT_DEFINITIONS: dict[str, UnitDefinition] = {
    "S/cm": UnitDefinition("S/cm", "conductivity", 100.0),
    "S/m": UnitDefinition("S/m", "conductivity", 1.0),
    "mS/cm": UnitDefinition("mS/cm", "conductivity", 0.1),
    "uS/cm": UnitDefinition("uS/cm", "conductivity", 1e-4),
    "K": UnitDefinition("K", "temperature", 1.0),
    "degC": UnitDefinition("degC", "temperature", 1.0, 273.15),
    "Pa": UnitDefinition("Pa", "pressure", 1.0),
    "kPa": UnitDefinition("kPa", "pressure", 1000.0),
    "MPa": UnitDefinition("MPa", "pressure", 1e6),
    "GPa": UnitDefinition("GPa", "pressure", 1e9),
    "ohm": UnitDefinition("ohm", "resistance", 1.0),
    "kohm": UnitDefinition("kohm", "resistance", 1000.0),
    "Hz": UnitDefinition("Hz", "frequency", 1.0),
    "kHz": UnitDefinition("kHz", "frequency", 1000.0),
    "MHz": UnitDefinition("MHz", "frequency", 1e6),
    "V": UnitDefinition("V", "voltage", 1.0),
    "mV": UnitDefinition("mV", "voltage", 1e-3),
    "A": UnitDefinition("A", "current", 1.0),
    "mA": UnitDefinition("mA", "current", 1e-3),
    "g": UnitDefinition("g", "mass", 1.0),
    "mg": UnitDefinition("mg", "mass", 1e-3),
    "kg": UnitDefinition("kg", "mass", 1000.0),
    "cm": UnitDefinition("cm", "length", 1.0),
    "mm": UnitDefinition("mm", "length", 0.1),
    "um": UnitDefinition("um", "length", 1e-4),
    "cm2": UnitDefinition("cm2", "area", 1.0),
    "mm2": UnitDefinition("mm2", "area", 0.01),
    "s": UnitDefinition("s", "time", 1.0),
    "min": UnitDefinition("min", "time", 60.0),
    "h": UnitDefinition("h", "time", 3600.0),
}


MEASUREMENT_CONTRACTS: dict[str, dict[str, Any]] = {
    "ionic_conductivity": {
        "version": "1.0.0", "domain": "inorganic_materials", "units": ["S/cm", "S/m", "mS/cm", "uS/cm"],
        "required_context": ["temperature", "measurement_method", "sample_id", "instrument_id"],
        "positive": True, "replicates_recommended": True,
    },
    "temperature": {"version": "1.0.0", "domain": "all", "units": ["K", "degC"],
                      "required_context": ["sensor_id", "timestamp"], "positive": False},
    "pressure": {"version": "1.0.0", "domain": "all", "units": ["Pa", "kPa", "MPa", "GPa"],
                  "required_context": ["sensor_id", "timestamp"], "positive": True},
    "young_modulus": {"version": "1.0.0", "domain": "polymers", "units": ["MPa", "GPa"],
                       "required_context": ["test_method", "sample_id", "strain_rate"], "positive": True},
    "specific_capacity": {"version": "1.0.0", "domain": "inorganic_materials", "units": ["mAh/g"],
                           "required_context": ["cycle_index", "voltage_window", "sample_id"], "positive": True},
}


def convert_unit(value: float, source_unit: str, target_unit: str) -> dict:
    """Convert between registered units with the same dimension."""
    numeric = float(value)
    if not math.isfinite(numeric):
        raise ValueError("measurement value must be finite")
    source = UNIT_DEFINITIONS.get(source_unit)
    target = UNIT_DEFINITIONS.get(target_unit)
    if source is None or target is None:
        raise ValueError("unit is not registered; preserve raw value rather than guessing")
    if source.dimension != target.dimension:
        raise ValueError(f"incompatible dimensions: {source.dimension} and {target.dimension}")
    base = numeric * source.factor_to_base + source.offset_to_base
    converted = (base - target.offset_to_base) / target.factor_to_base
    return {"original_value": numeric, "original_unit": source_unit,
            "normalized_value": converted, "normalized_unit": target_unit,
            "dimension": source.dimension,
            "conversion": {"source_factor": source.factor_to_base,
                           "source_offset": source.offset_to_base,
                           "target_factor": target.factor_to_base,
                           "target_offset": target.offset_to_base},
            "origin": "unit_conversion"}


def validate_measurement_contract(*, property_name: str, value: float, unit: str,
                                  domain: str, context: dict[str, Any],
                                  origin: str, synthetic: bool) -> dict:
    contract = MEASUREMENT_CONTRACTS.get(property_name)
    issues: list[dict[str, str]] = []
    if contract is None:
        return {"valid": False, "contract_found": False,
                "issues": [{"code": "unknown_property", "message": "No measurement contract is registered."}],
                "normalization": None}
    if contract["domain"] not in ("all", domain):
        issues.append({"code": "domain_mismatch", "message": f"Contract expects {contract['domain']}, received {domain}."})
    if unit not in contract["units"]:
        issues.append({"code": "unit_not_allowed", "message": f"Unit {unit} is not allowed by contract {contract['version']}."})
    missing = [key for key in contract["required_context"] if context.get(key) in (None, "", [])]
    for key in missing:
        issues.append({"code": "missing_context", "message": f"Required context field '{key}' is missing."})
    try:
        numeric = float(value)
        if not math.isfinite(numeric):
            raise ValueError
        if contract.get("positive") and numeric <= 0:
            issues.append({"code": "non_positive_measurement", "message": "This property must be positive under the contract."})
    except (TypeError, ValueError):
        issues.append({"code": "invalid_numeric_value", "message": "Measurement value must be finite numeric data."})
    if origin == "simulation" and not synthetic:
        issues.append({"code": "simulation_origin_mismatch", "message": "Simulation-origin records must remain explicitly synthetic or simulated."})
    if synthetic and origin == "measured":
        issues.append({"code": "synthetic_measured_conflict", "message": "Synthetic records cannot be asserted as measured observations."})
    return {"valid": len(issues) == 0, "contract_found": True,
            "contract_version": contract["version"], "domain": contract["domain"],
            "required_context": list(contract["required_context"]),
            "issues": issues, "normalization": {"value": numeric, "unit": unit} if not any(i["code"] == "invalid_numeric_value" for i in issues) else None,
            "origin": origin, "synthetic": synthetic}


def normalize_measurement(value: float, unit: str, *, canonical_unit: str) -> dict:
    return convert_unit(value, unit, canonical_unit)


def get_measurement_contract(property_name: str) -> dict[str, Any] | None:
    value = MEASUREMENT_CONTRACTS.get(property_name)
    return deepcopy(value) if value is not None else None


def contract_catalogue() -> list[dict[str, Any]]:
    return [{"property_name": key, **deepcopy(value)} for key, value in sorted(MEASUREMENT_CONTRACTS.items())]
