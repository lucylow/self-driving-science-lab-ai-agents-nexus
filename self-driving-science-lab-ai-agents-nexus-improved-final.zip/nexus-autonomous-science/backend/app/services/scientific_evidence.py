"""Evidence typing, conservative grading, and contradiction reporting.

Evidence grades in NEXUS are traceability labels rather than universal scientific
rankings. Domain-specific quality gates must still be defined by qualified scientists.
"""

from dataclasses import dataclass, asdict
from typing import Any, Literal

EvidenceOrigin = Literal[
    "model_hypothesis",
    "computational_prediction",
    "validated_computational_prediction",
    "preliminary_measurement",
    "quality_controlled_measurement",
    "independent_replication",
    "independent_validation",
]

GRADE_BY_ORIGIN: dict[str, str] = {
    "model_hypothesis": "E0",
    "computational_prediction": "E1",
    "validated_computational_prediction": "E2",
    "preliminary_measurement": "E3",
    "quality_controlled_measurement": "E4",
    "independent_replication": "E5",
    "independent_validation": "E6",
}

GRADE_DESCRIPTIONS = {
    "E0": "Unverified model-generated hypothesis",
    "E1": "Computational prediction",
    "E2": "Prediction with calibration and validation evidence",
    "E3": "Preliminary experimental measurement",
    "E4": "Quality-controlled experimental result",
    "E5": "Result reproduced across independent runs",
    "E6": "Independently validated result",
}


@dataclass(frozen=True)
class EvidenceAssessment:
    evidence_id: str
    origin: str
    grade: str
    description: str
    eligible_for_model_training: bool
    synthetic: bool
    limitations: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def assess_evidence(
    *, evidence_id: str, origin: EvidenceOrigin, synthetic: bool = False,
    quality_checks: dict[str, bool] | None = None,
    independent_replicates: int = 0,
    independent_validation_reference: str | None = None,
) -> EvidenceAssessment:
    """Assign a conservative label from declared origin and explicit quality gates."""
    checks = quality_checks or {}
    limitations: list[str] = []
    grade = GRADE_BY_ORIGIN[origin]

    if synthetic:
        limitations.append("Synthetic records are not experimental evidence.")
        return EvidenceAssessment(
            evidence_id=evidence_id, origin=origin, grade="E0",
            description="Synthetic demonstration record", eligible_for_model_training=False,
            synthetic=True, limitations=tuple(limitations),
        )

    if origin in {"quality_controlled_measurement", "independent_replication", "independent_validation"}:
        required = {"sample_identity", "method_metadata", "calibration", "unit_validation", "protocol_adherence"}
        missing = sorted(key for key in required if checks.get(key) is not True)
        if missing:
            limitations.append("Quality-control requirements are incomplete: " + ", ".join(missing))
            grade = "E3" if origin != "independent_validation" else "E4"
    if origin == "independent_replication" and independent_replicates < 2:
        limitations.append("At least two independent runs are required for this replication label.")
        grade = "E4"
    if origin == "independent_validation" and not independent_validation_reference:
        limitations.append("Independent validation reference is missing.")
        grade = "E4"
    if origin in {"model_hypothesis", "computational_prediction", "validated_computational_prediction"}:
        limitations.append("Computational evidence is not an experimental measurement.")
    if origin == "validated_computational_prediction" and checks.get("calibration") is not True:
        limitations.append("Calibration evidence is missing; the prediction remains E1.")
        grade = "E1"

    eligible = (
        grade in {"E3", "E4", "E5", "E6"}
        and checks.get("sample_identity") is True
        and checks.get("unit_validation") is True
        and checks.get("method_metadata") is True
        and not synthetic
    )
    return EvidenceAssessment(
        evidence_id=evidence_id, origin=origin, grade=grade,
        description=GRADE_DESCRIPTIONS[grade], eligible_for_model_training=eligible,
        synthetic=False, limitations=tuple(limitations),
    )


@dataclass(frozen=True)
class Contradiction:
    subject_id: str
    observation_a_id: str
    observation_b_id: str
    property_name: str
    explanation_candidates: tuple[str, ...]
    resolution_status: str = "unresolved"


def detect_numeric_contradiction(
    *, subject_id: str, observation_a_id: str, observation_b_id: str,
    property_name: str, value_a: float, value_b: float,
    relative_tolerance: float = 0.25,
) -> Contradiction | None:
    """Flag materially divergent values; do not decide which observation is correct."""
    scale = max(abs(value_a), abs(value_b), 1e-12)
    relative_difference = abs(value_a - value_b) / scale
    if relative_difference <= relative_tolerance:
        return None
    return Contradiction(
        subject_id=subject_id,
        observation_a_id=observation_a_id,
        observation_b_id=observation_b_id,
        property_name=property_name,
        explanation_candidates=(
            "Measurement conditions differ.",
            "Sample identity, phase, or batch differs.",
            "Instrument calibration or method differs.",
            "A model or measurement may be outside its validated domain.",
            "The difference may be scientifically real and requires investigation.",
        ),
    )
