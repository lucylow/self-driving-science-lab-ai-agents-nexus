"""Evidence graph primitives for traceable scientific claims and impact queries."""
from __future__ import annotations
from collections import defaultdict, deque
from dataclasses import dataclass, asdict
from typing import Iterable

ALLOWED_NODE_TYPES = {
    "objective", "hypothesis", "candidate", "sample", "experiment", "measurement",
    "artifact", "dataset", "model", "prediction", "conclusion", "publication", "instrument",
}
ALLOWED_EDGE_TYPES = {
    "motivates", "tests", "produces", "measured_by", "derived_from", "supports",
    "contradicts", "trained_on", "predicts", "characterizes", "references", "uses",
}


@dataclass(frozen=True)
class EvidenceNode:
    node_id: str
    node_type: str
    label: str
    evidence_origin: str
    synthetic: bool
    metadata: dict


@dataclass(frozen=True)
class EvidenceEdge:
    source_id: str
    target_id: str
    relationship: str
    provenance_refs: tuple[str, ...] = ()


class EvidenceGraph:
    def __init__(self) -> None:
        self.nodes: dict[str, EvidenceNode] = {}
        self.edges: list[EvidenceEdge] = []
        self.outgoing: dict[str, list[EvidenceEdge]] = defaultdict(list)
        self.incoming: dict[str, list[EvidenceEdge]] = defaultdict(list)

    def add_node(self, node: EvidenceNode) -> None:
        if node.node_type not in ALLOWED_NODE_TYPES:
            raise ValueError(f"Unsupported evidence node type '{node.node_type}'")
        if not node.node_id:
            raise ValueError("Evidence nodes require a stable identifier")
        if node.node_id in self.nodes:
            raise ValueError(f"Evidence node '{node.node_id}' already exists")
        if node.evidence_origin == "simulation" and not node.synthetic:
            raise ValueError("Simulation evidence must be labelled synthetic")
        self.nodes[node.node_id] = node

    def add_edge(self, edge: EvidenceEdge) -> None:
        if edge.relationship not in ALLOWED_EDGE_TYPES:
            raise ValueError(f"Unsupported evidence relationship '{edge.relationship}'")
        if edge.source_id not in self.nodes or edge.target_id not in self.nodes:
            raise ValueError("Both endpoints must exist before an edge is created")
        if edge.source_id == edge.target_id:
            raise ValueError("Self-referential evidence edges are not allowed")
        if edge.relationship in {"derived_from", "trained_on", "produces"} and not edge.provenance_refs:
            raise ValueError("Data lineage edges require provenance references")
        self.edges.append(edge)
        self.outgoing[edge.source_id].append(edge)
        self.incoming[edge.target_id].append(edge)

    def ancestors(self, node_id: str, *, max_depth: int = 100) -> list[str]:
        if node_id not in self.nodes:
            raise KeyError(node_id)
        visited: set[str] = set()
        queue = deque([(node_id, 0)])
        while queue:
            current, depth = queue.popleft()
            if depth >= max_depth:
                continue
            for edge in self.incoming[current]:
                if edge.source_id not in visited:
                    visited.add(edge.source_id)
                    queue.append((edge.source_id, depth + 1))
        return sorted(visited)

    def descendants(self, node_id: str, *, max_depth: int = 100) -> list[str]:
        if node_id not in self.nodes:
            raise KeyError(node_id)
        visited: set[str] = set()
        queue = deque([(node_id, 0)])
        while queue:
            current, depth = queue.popleft()
            if depth >= max_depth:
                continue
            for edge in self.outgoing[current]:
                if edge.target_id not in visited:
                    visited.add(edge.target_id)
                    queue.append((edge.target_id, depth + 1))
        return sorted(visited)

    def impact_report(self, node_id: str) -> dict:
        descendants = self.descendants(node_id)
        affected = [self.nodes[item] for item in descendants]
        return {
            "source_node": node_id,
            "affected_node_count": len(affected),
            "affected_nodes": [asdict(item) for item in affected],
            "affected_conclusions": [item.node_id for item in affected if item.node_type == "conclusion"],
            "affected_models": [item.node_id for item in affected if item.node_type == "model"],
            "warning": "Impact traversal identifies graph connectivity, not proven causal dependence.",
        }

    def validate(self) -> dict:
        dangling = [edge for edge in self.edges if edge.source_id not in self.nodes or edge.target_id not in self.nodes]
        missing_provenance = [edge for edge in self.edges if edge.relationship in {"derived_from", "trained_on", "produces"} and not edge.provenance_refs]
        return {"valid": not dangling and not missing_provenance,
                "node_count": len(self.nodes), "edge_count": len(self.edges),
                "dangling_edges": [asdict(item) for item in dangling],
                "missing_provenance_edges": [asdict(item) for item in missing_provenance]}
