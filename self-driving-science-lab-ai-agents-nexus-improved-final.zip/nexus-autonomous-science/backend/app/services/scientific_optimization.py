"""Explainable two-objective Pareto ranking for synthetic experiment candidates."""
from __future__ import annotations

from math import isfinite
from typing import Any, Mapping, Sequence

VALID_QUALITY_STATUSES = {"successful", "partial_improvement", "negative_result"}


def rank_experiments_by_quality_and_cost(
    experiments: Sequence[Mapping[str, Any]],
    executions: Sequence[Mapping[str, Any]],
    *,
    max_compute_hours: float | None = None,
) -> dict[str, Any]:
    """Maximize mean quality while minimizing consumed/planned compute hours.

    Technical failures and inconclusive outcomes are excluded from the quality
    mean, but their consumed compute is included in cost. Candidates violating
    a supplied hard cost ceiling are returned as infeasible and never enter the
    Pareto frontier. Duplicate configurations are not collapsed: replication is
    allowed and remains inspectable.
    """
    if max_compute_hours is not None and (not isfinite(max_compute_hours) or max_compute_hours <= 0):
        raise ValueError("max_compute_hours must be a finite positive number")
    by_experiment: dict[str, list[Mapping[str, Any]]] = {}
    for execution in executions:
        experiment_id = execution.get("experiment_id")
        if experiment_id is not None:
            by_experiment.setdefault(str(experiment_id), []).append(execution)

    candidates: list[dict[str, Any]] = []
    for experiment in experiments:
        experiment_id = str(experiment.get("id", ""))
        runs = by_experiment.get(experiment_id, [])
        costs = [run.get("compute_hours") for run in runs]
        valid_costs = [float(value) for value in costs if isinstance(value, (int, float)) and not isinstance(value, bool) and isfinite(value) and value >= 0]
        if runs:
            cost = sum(valid_costs) if len(valid_costs) == len(costs) else None
        else:
            estimate = experiment.get("estimated_compute_hours")
            cost = float(estimate) if isinstance(estimate, (int, float)) and not isinstance(estimate, bool) and isfinite(estimate) and estimate >= 0 else None
        quality_values = [
            float(run["quality_score"]) for run in runs
            if run.get("status") in VALID_QUALITY_STATUSES
            and isinstance(run.get("quality_score"), (int, float))
            and not isinstance(run.get("quality_score"), bool)
            and isfinite(run["quality_score"])
            and 0 <= run["quality_score"] <= 1
        ]
        feasible = cost is not None and (max_compute_hours is None or cost <= max_compute_hours)
        quality = sum(quality_values) / len(quality_values) if quality_values else None
        if cost is None:
            status = "invalid_cost"
        elif not feasible:
            status = "infeasible"
        elif quality is None:
            status = "unscored"
        else:
            status = "candidate"
        candidates.append({
            "experiment_id": experiment_id,
            "name": experiment.get("name", experiment_id),
            "mean_quality": round(quality, 6) if quality is not None else None,
            "compute_hours": round(cost, 6) if cost is not None else None,
            "quality_run_count": len(quality_values),
            "execution_count": len(runs),
            "technical_failure_count": sum(run.get("status") == "technical_failure" for run in runs),
            "inconclusive_count": sum(run.get("status") == "inconclusive" for run in runs),
            "invalid_quality_count": sum(run.get("status") in VALID_QUALITY_STATUSES and (not isinstance(run.get("quality_score"), (int, float)) or isinstance(run.get("quality_score"), bool) or not isfinite(run.get("quality_score")) or not 0 <= run.get("quality_score") <= 1) for run in runs),
            "feasible": feasible,
            "on_pareto_front": False,
            "status": status,
            "rationale": "Quality is the mean of successful, partially improved, and negative-result runs; technical failures and inconclusive runs do not score. All valid run compute, including failed attempts, contributes to cost.",
        })

    scored_feasible = [row for row in candidates if row["feasible"] and row["mean_quality"] is not None]
    frontier_ids: list[str] = []
    for candidate in scored_feasible:
        dominated = any(
            other["experiment_id"] != candidate["experiment_id"]
            and other["mean_quality"] >= candidate["mean_quality"]
            and other["compute_hours"] <= candidate["compute_hours"]
            and (other["mean_quality"] > candidate["mean_quality"] or other["compute_hours"] < candidate["compute_hours"])
            for other in scored_feasible
        )
        candidate["on_pareto_front"] = not dominated
        candidate["status"] = "pareto_front" if not dominated else "dominated"
        if not dominated:
            frontier_ids.append(candidate["experiment_id"])
    candidates.sort(key=lambda row: (not row["on_pareto_front"], row["compute_hours"] if row["compute_hours"] is not None else float("inf"), row["experiment_id"]))
    return {
        "objectives": {"mean_quality": "maximize", "compute_hours": "minimize"},
        "hard_constraint": {"max_compute_hours": max_compute_hours},
        "frontier_experiment_ids": frontier_ids,
        "candidates": candidates,
        "quality_excluded_statuses": ["technical_failure", "inconclusive"],
        "cost_includes_failed_attempts": True,
        "method": "pareto_quality_vs_compute_v1",
        "limitations": "Synthetic demonstration ranking only. Mean run quality is descriptive, not a causal treatment effect or validated scientific optimum.",
    }
