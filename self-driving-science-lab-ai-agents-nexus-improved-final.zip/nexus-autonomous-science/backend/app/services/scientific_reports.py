"""Evidence-linked, non-generative objective reports assembled from persisted records."""
from __future__ import annotations
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.models.entities import Objective, Hypothesis, Experiment, Measurement, ScientificPrediction, ScientificSample


def build_objective_report(db: Session, objective_id: str, *, include_synthetic: bool = True,
                           include_predictions: bool = True) -> dict:
    objective = db.get(Objective, objective_id)
    if not objective:
        raise KeyError(objective_id)
    hypotheses = db.scalars(select(Hypothesis).where(Hypothesis.objective_id == objective_id)).all()
    experiments = db.scalars(select(Experiment).where(Experiment.objective_id == objective_id)).all()
    experiment_ids = [item.id for item in experiments]
    measurements = db.scalars(select(Measurement).where(Measurement.experiment_id.in_(experiment_ids))).all() if experiment_ids else []
    measurements = [item for item in measurements if include_synthetic or not item.synthetic]
    predictions = []
    if include_predictions and experiment_ids:
        predictions = db.scalars(select(ScientificPrediction).where(ScientificPrediction.subject_id.in_(experiment_ids))).all()
    evidence = []
    for item in measurements:
        evidence.append({"id": item.id, "type": "measurement", "origin": item.origin,
                         "property": item.property_name, "value": item.value, "unit": item.unit,
                         "uncertainty": item.uncertainty, "quality_status": item.quality_status,
                         "synthetic": item.synthetic, "experiment_id": item.experiment_id,
                         "sample_id": item.sample_id})
    for item in predictions:
        evidence.append({"id": item.id, "type": "prediction", "origin": item.evidence_origin,
                         "property": item.target_property, "value": item.predicted_value,
                         "unit": item.unit, "uncertainty": item.uncertainty,
                         "synthetic": item.synthetic, "model_id": item.model_id,
                         "subject_id": item.subject_id})
    return {
        "report_type": "objective_evidence_summary",
        "objective": {"id": objective.id, "code": objective.code, "title": objective.title,
                      "domain": objective.domain, "laboratory_code": objective.laboratory_code,
                      "version": objective.version, "description": objective.description,
                      "target_properties": objective.target_properties,
                      "constraints": objective.constraints_json},
        "hypotheses": [{"id": row.id, "code": row.code, "statement": row.statement,
                         "status": row.status, "evidence_grade": row.evidence_grade,
                         "confidence": row.confidence,
                         "supporting_observations": row.supporting_observations,
                         "contradictory_observations": row.contradictory_observations} for row in hypotheses],
        "experiments": [{"id": row.id, "code": row.code, "title": row.title,
                         "status": row.status, "execution_mode": row.execution_mode,
                         "result_summary": row.result_summary, "synthetic": row.synthetic} for row in experiments],
        "evidence": evidence,
        "evidence_counts": {
            "measurements": sum(item["type"] == "measurement" for item in evidence),
            "predictions": sum(item["type"] == "prediction" for item in evidence),
            "synthetic": sum(bool(item["synthetic"]) for item in evidence),
            "measured": sum(item["origin"] == "measured" for item in evidence),
        },
        "limitations": [
            "This is an index of persisted records, not an AI-generated scientific conclusion.",
            "Predictions and measured observations are listed as separate evidence classes.",
            "A missing record is not evidence that a property is absent.",
        ],
        "requires_scientist_interpretation": True,
    }
