"""Deterministic demonstration records. Every generated observation is explicitly synthetic."""

from uuid import uuid4
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.models.entities import (
    Agent, Approval, AuditEvent, Candidate, Dataset, Experiment, Hypothesis,
    Instrument, Laboratory, Measurement, Objective,
)
from app.services.audit import record_event

LABS = [
    ("SDL0", "AI & Robotics", "Autonomous systems research", "Develop and validate the agents, robotics, simulation, instrument interfaces, and reliability controls used across NEXUS.", "critical"),
    ("SDL1", "Inorganic Materials", "Advanced inorganic materials and energy", "Explore crystal structures, defects, ionic transport, electrochemistry, semiconductors, catalysts, and battery materials.", "highest"),
    ("SDL2", "Organic Chemistry", "Molecular discovery and reaction science", "Study molecular generation, reaction mechanisms, synthesis feasibility, purification, and analytical confirmation.", "high"),
    ("SDL3", "Medicinal Chemistry", "Structure–activity research", "Connect molecular structure with binding, assay behavior, selectivity, ADME-related measurements, and evidence quality.", "high"),
    ("SDL4", "Polymers", "Polymer structure and performance", "Connect molecular architecture, crystallization, phase behavior, rheology, mechanics, and degradation.", "high"),
    ("SDL5", "Formulations", "Formulation and product systems", "Investigate composition, stability, interfaces, particle attributes, processability, and formulation performance.", "standard"),
    ("SDL6", "Organoids & Organ-on-Chip", "Biological structure–function research", "Coordinate biological model provenance, imaging, cellular function, mechanobiology, and independent replication.", "standard"),
    ("SDL7", "Scale-up & Process Engineering", "Multiscale process science", "Connect reaction kinetics, mixing, heat and mass transfer, process telemetry, scale-up, and manufacturing feasibility.", "high"),
]

# Each department has ten measurable specialist responsibilities. Profiles are capability
# registrations, not ten independent LLM sessions or autonomous hardware controllers.
DEPARTMENTS = [
    ("Scientific Research", "SDL0", [
        ("Research Intelligence", "Retrieve and structure literature evidence", ["literature_retrieval", "evidence_extraction"]),
        ("Hypothesis Generation", "Draft falsifiable, evidence-linked hypotheses", ["hypothesis_drafting", "uncertainty"]),
        ("Scientific Debate", "Compare competing mechanisms and expose disagreement", ["critique", "evidence_comparison"]),
        ("Objective Compiler", "Translate natural-language goals into versioned objective contracts", ["objective_parsing", "schema_validation"]),
        ("Research Gap Mapper", "Locate underexplored questions and contradictory results", ["gap_analysis", "knowledge_graph"]),
        ("Evidence Grader", "Assign field-specific evidence review labels", ["evidence_grading", "provenance"]),
        ("Mechanism Reasoner", "Connect structures, mechanisms, observables, and performance", ["mechanism_mapping", "causal_hypotheses"]),
        ("Scientific Reviewer", "Check whether claims are supported by records", ["claim_review", "citation_checks"]),
        ("Discovery Radar", "Rank research opportunities for scientist review", ["opportunity_ranking", "trend_detection"]),
        ("Report Synthesizer", "Prepare traceable experiment and discovery reports", ["reporting", "lineage"]),
    ]),
    ("Materials Discovery", "SDL1", [
        ("Crystal Structure Parser", "Validate and normalize crystal structure records", ["crystal_structures", "pymatgen_adapter"]),
        ("Composition Validator", "Check formula syntax and composition constraints", ["composition_validation", "chemistry_rules"]),
        ("Defect Chemistry Analyst", "Organize defect hypotheses and charge-compensation evidence", ["defect_chemistry", "evidence_mapping"]),
        ("Ionic Transport Modeler", "Manage ionic transport predictions and uncertainty", ["property_prediction", "uncertainty"]),
        ("Phase Stability Analyst", "Compare phase stability evidence and model outputs", ["phase_analysis", "model_comparison"]),
        ("Battery Interface Analyst", "Track interface compatibility hypotheses", ["interface_science", "materials_comparison"]),
        ("Catalysis Surface Analyst", "Structure adsorption and surface-reaction evidence", ["surface_science", "reaction_mechanisms"]),
        ("Materials Candidate Ranker", "Rank candidates under explicit multi-objective weights", ["multiobjective_optimization", "explainability"]),
        ("Synthesis Feasibility Reviewer", "Flag missing synthesis and processing evidence", ["feasibility_review", "constraint_checks"]),
        ("Materials Evidence Curator", "Maintain material-to-measurement traceability", ["materials_registry", "provenance"]),
    ]),
    ("Organic Chemistry", "SDL2", [
        ("Molecular Structure Validator", "Validate molecular graph representations", ["molecular_validation", "rdkit_adapter"]),
        ("Reaction Classifier", "Classify reaction records and mechanism families", ["reaction_classification", "taxonomy"]),
        ("Retrosynthesis Planner", "Propose routes for chemist review", ["route_proposal", "feasibility"]),
        ("Reaction Condition Analyst", "Compare condition and outcome metadata", ["reaction_conditions", "data_analysis"]),
        ("Molecular Property Estimator", "Manage molecular property prediction outputs", ["property_prediction", "uncertainty"]),
        ("Reaction Outcome Analyst", "Analyze reported reaction outcomes and controls", ["yield_analysis", "reproducibility"]),
        ("Purification Intelligence", "Track purification stages and recovery evidence", ["purification", "process_records"]),
        ("Spectral Assignment Assistant", "Link spectral features to reviewed assignments", ["spectroscopy", "annotation"]),
        ("Synthesis Failure Analyst", "Classify failed and incomplete synthesis records", ["failure_analysis", "anomaly_detection"]),
        ("Molecule Registry Curator", "Maintain compound identity and batch lineage", ["compound_registry", "provenance"]),
    ]),
    ("Medicinal Chemistry", "SDL3", [
        ("Target Evidence Curator", "Organize target biology and assay provenance", ["target_biology", "evidence_review"]),
        ("Binding Model Analyst", "Keep docking predictions distinct from measured affinity", ["binding_models", "uncertainty"]),
        ("SAR Analyst", "Compare matched molecular pairs and structure–activity data", ["sar", "matched_pairs"]),
        ("Activity Cliff Detector", "Flag abrupt activity changes among similar molecules", ["activity_cliffs", "outlier_detection"]),
        ("Assay Quality Reviewer", "Check assay variability and control records", ["assay_quality", "reproducibility"]),
        ("Selectivity Analyst", "Compare selectivity panels with uncertainty", ["selectivity", "multiassay"]),
        ("ADME Evidence Analyst", "Organize absorption, distribution, metabolism, and excretion data", ["adme_data", "evidence_quality"]),
        ("Cellular Response Analyst", "Track cellular response measurements and caveats", ["cell_assay", "data_validation"]),
        ("Medicinal Candidate Reviewer", "Summarize scientific evidence without clinical claims", ["candidate_review", "claim_guardrails"]),
        ("Bioactivity Dataset Curator", "Version bioactivity datasets and provenance", ["dataset_versioning", "lineage"]),
    ]),
    ("Polymer Science", "SDL4", [
        ("Polymer Representation Parser", "Validate polymer composition and architecture records", ["polymer_representation", "schema_validation"]),
        ("Molecular Weight Analyst", "Track molecular-weight distributions and measurement methods", ["molecular_weight", "measurement_context"]),
        ("Rheology Analyst", "Interpret rheology datasets with method metadata", ["rheology", "time_series"]),
        ("Thermal Characterization Analyst", "Organize thermal transitions and stability evidence", ["thermal_analysis", "uncertainty"]),
        ("Crystallization Analyst", "Link crystallization behavior to process conditions", ["crystallization", "process_context"]),
        ("Phase Separation Analyst", "Track morphology and phase-behavior observations", ["phase_behavior", "image_metadata"]),
        ("Mechanical Property Analyst", "Compare mechanical response by test conditions", ["mechanics", "unit_validation"]),
        ("Polymer Degradation Analyst", "Track degradation mechanisms and aging experiments", ["degradation", "longitudinal_data"]),
        ("Polymer Formulation Reviewer", "Assess polymer blend and additive evidence", ["formulation", "candidate_review"]),
        ("Polymer Data Curator", "Maintain structure–processing–property lineage", ["polymer_registry", "provenance"]),
    ]),
    ("Formulation Science", "SDL5", [
        ("Composition Design Analyst", "Structure formulation composition spaces", ["composition_space", "candidate_design"]),
        ("Stability Study Planner", "Track stability study design and conditions", ["stability_studies", "experiment_design"]),
        ("Particle Attribute Analyst", "Organize particle size and morphology measurements", ["particle_analysis", "measurement_metadata"]),
        ("Dispersion Analyst", "Evaluate dispersion records and variability", ["dispersion", "quality_control"]),
        ("Interface Compatibility Analyst", "Track compatibility and interfacial hypotheses", ["interfaces", "hypothesis_testing"]),
        ("Rheology Formulation Analyst", "Compare flow properties across formulations", ["formulation_rheology", "unit_validation"]),
        ("Batch Consistency Monitor", "Detect drift across formulation batches", ["batch_monitoring", "drift_detection"]),
        ("Packaging Interaction Reviewer", "Organize packaging interaction evidence", ["packaging", "provenance"]),
        ("Formulation Optimizer", "Rank formulation proposals under constraints", ["optimization", "explainability"]),
        ("Formulation Dataset Curator", "Version formulation datasets and derived features", ["dataset_management", "lineage"]),
    ]),
    ("Biological Systems", "SDL6", [
        ("Biological Model Registrar", "Track model identity, passage, and provenance", ["model_registry", "provenance"]),
        ("Culture Metadata Reviewer", "Validate culture conditions and reagent-lot metadata", ["culture_metadata", "schema_validation"]),
        ("Organoid Morphology Analyst", "Analyze morphology outputs with confidence and unknown states", ["image_analysis", "morphology"]),
        ("Imaging Quality Monitor", "Check imaging quality and acquisition context", ["microscopy", "quality_control"]),
        ("Cellular Metabolism Analyst", "Organize metabolic readouts and assay context", ["metabolism", "assay_metadata"]),
        ("Mechanobiology Analyst", "Connect mechanical environment and biological observations", ["mechanobiology", "multimodal_data"]),
        ("Functional Assay Reviewer", "Separate morphology, gene expression, and functional evidence", ["functional_assays", "evidence_separation"]),
        ("Replication Monitor", "Track independent biological replication", ["replication", "statistics"]),
        ("Biosafety Workflow Reviewer", "Route biological workflows through expert review", ["biosafety_routing", "governance"]),
        ("Biological Data Curator", "Maintain model-to-observation lineage", ["biological_registry", "provenance"]),
    ]),
    ("Process Engineering", "SDL7", [
        ("Process Objective Analyst", "Compile process optimization objectives", ["process_objectives", "constraints"]),
        ("Reaction Kinetics Analyst", "Organize kinetic model inputs and outputs", ["kinetics", "model_review"]),
        ("Heat Transfer Analyst", "Track heat-transfer models and sensor context", ["heat_transfer", "physical_models"]),
        ("Mass Transfer Analyst", "Track mass-transfer phenomena and limitations", ["mass_transfer", "physical_models"]),
        ("Mixing Intelligence Analyst", "Compare mixing states and scale dependencies", ["mixing", "scale_up"]),
        ("Process Sensor Monitor", "Monitor process telemetry and timestamp quality", ["sensor_streams", "time_sync"]),
        ("Scale-up Feasibility Reviewer", "Compare laboratory and larger-scale assumptions", ["scale_up", "feasibility"]),
        ("Process Anomaly Analyst", "Flag process deviations and candidate explanations", ["anomaly_detection", "root_cause"]),
        ("Batch Scheduler", "Schedule compatible workflows under resource constraints", ["scheduling", "resource_planning"]),
        ("Process Provenance Curator", "Preserve batch and process-history traceability", ["process_registry", "provenance"]),
    ]),
    ("Data & Evidence", "SDL0", [
        ("Scientific Schema Validator", "Validate domain contracts and schema versions", ["schema_validation", "contracts"]),
        ("Unit Semantics Service", "Check unit presence and compatible conversion metadata", ["units", "dimensional_validation"]),
        ("Data Quality Assessor", "Score completeness and flag disqualifying defects", ["data_quality", "quarantine"]),
        ("Anomaly Detection Analyst", "Identify anomalies without deleting unusual observations", ["anomaly_detection", "human_review"]),
        ("Time-series Alignment Agent", "Reconcile clocks and timestamp provenance", ["time_series", "clock_alignment"]),
        ("Multimodal Fusion Planner", "Design scientifically defensible sensor-fusion workflows", ["sensor_fusion", "multimodal"]),
        ("Dataset Version Manager", "Version curated datasets and transformations", ["dataset_versioning", "reproducibility"]),
        ("Knowledge Graph Curator", "Maintain objective-to-evidence relationships", ["knowledge_graph", "entity_resolution"]),
        ("Model Data Steward", "Manage training eligibility and split integrity", ["ml_data_governance", "model_lineage"]),
        ("Provenance Auditor", "Trace conclusions to original artifacts and transformations", ["provenance_audit", "lineage"]),
    ]),
    ("Governance & Reliability", "SDL0", [
        ("Permission Policy Agent", "Check role and agent permission boundaries", ["permissions", "policy_checks"]),
        ("Safety Review Router", "Route high-impact workflows to qualified reviewers", ["safety_review", "escalation"]),
        ("Experiment State Auditor", "Detect invalid lifecycle state transitions", ["state_machine", "audit"]),
        ("Instrument Capability Registrar", "Track instrument capabilities and local approval requirements", ["instrument_registry", "capability_manifests"]),
        ("Equipment Health Analyst", "Summarize calibration, downtime, and equipment alerts", ["equipment_health", "maintenance"]),
        ("Workflow Recovery Planner", "Recommend checkpoint review and recovery paths", ["recovery", "checkpointing"]),
        ("Agent Evaluation Engineer", "Evaluate agents against benchmark tasks", ["benchmarking", "model_evaluation"]),
        ("Reliability Monitor", "Track retries, timeouts, and tool-call failures", ["observability", "reliability"]),
        ("Cross-Lab Transfer Reviewer", "Check transferability across instruments and domains", ["transfer_learning", "domain_shift"]),
        ("Audit Trail Custodian", "Preserve append-only event history", ["audit_trail", "retention"]),
    ]),
]

CANDIDATES = [
    ("MAT-00128", "Argyrodite-like candidate A", "Li6PS5Cl", "Thio-phosphate solid electrolyte", 0.0042, 81.0, 84.0, 0.17),
    ("MAT-00129", "Garnet-like candidate B", "Li7La3Zr2O12", "Oxide solid electrolyte", 0.0018, 91.0, 68.0, 0.11),
    ("MAT-00130", "NASICON-like candidate C", "Li1.3Al0.3Ti1.7(PO4)3", "Phosphate solid electrolyte", 0.0026, 76.0, 78.0, 0.14),
    ("MAT-00131", "Halide candidate D", "Li3YCl6", "Halide solid electrolyte", 0.0033, 73.0, 72.0, 0.21),
    ("MAT-00132", "Oxide candidate E", "Li5La3Ta2O12", "Oxide solid electrolyte", 0.0012, 88.0, 61.0, 0.10),
    ("MAT-00133", "Phosphate candidate F", "Li1.5Al0.5Ge1.5(PO4)3", "NASICON-family candidate", 0.0022, 79.0, 75.0, 0.16),
]


def seed_database(db: Session) -> None:
    if db.scalar(select(Laboratory).limit(1)):
        return
    for code, name, focus, description, priority in LABS:
        db.add(Laboratory(id=code.lower(), code=code, name=name, focus=focus, description=description, priority=priority, status="online" if code in {"SDL0", "SDL1"} else "standby", metadata_json={"synthetic_demo": True}))

    agent_count = 0
    for department, lab_code, roles in DEPARTMENTS:
        for index, (name, purpose, capabilities) in enumerate(roles, start=1):
            agent_count += 1
            key = f"{lab_code.lower()}-{department.lower().replace(' ', '-')}-{index:02d}"
            db.add(Agent(
                id=f"AG-{agent_count:03d}", agent_key=key, name=name, department=department,
                laboratory_code=lab_code, purpose=purpose, status="idle",
                permission_level="analyze" if "review" in name.lower() or "auditor" in name.lower() else "propose_only",
                capabilities=capabilities, synthetic=True,
            ))

    objective = Objective(
        id="OBJ-0001", code="NEXUS-SDL1-OBJ-0001", title="Discover inorganic solid-state electrolyte candidates",
        domain="inorganic_materials", laboratory_code="SDL1",
        description="Identify candidate solid-state electrolytes with promising ionic transport, electrochemical stability, and practical synthesis feasibility.",
        target_properties=[
            {"property": "ionic_conductivity", "direction": "maximize", "unit": "S/cm"},
            {"property": "electrochemical_stability", "direction": "maximize", "unit": "score/100"},
            {"property": "synthesis_feasibility", "direction": "maximize", "unit": "score/100"},
        ],
        constraints_json={"require_valid_chemical_formula": True, "require_phase_identification": True, "require_measurement_provenance": True},
        evidence_requirements={"require_uncertainty_estimates": True, "require_experimental_validation": True, "distinguish_prediction_from_measurement": True},
        governance={"scientist_review_required": True, "physical_execution_requires_authorization": True},
        synthetic=True,
    )
    db.add(objective)
    db.add(Hypothesis(
        id="HYP-0001", code="HYP-SDL1-0001", objective_id=objective.id,
        statement="Changes to the anion sublattice and local structural disorder may influence ionic transport while changing stability and processability trade-offs.",
        status="proposed", evidence_grade="E0", confidence=0.43,
        predictions=[{"property": "ionic_conductivity", "direction": "increase"}, {"property": "stability", "direction": "trade_off_possible"}],
        supporting_observations=[], contradictory_observations=[], synthetic=True,
    ))

    for code, name, formula, family, conductivity, stability, feasibility, uncertainty in CANDIDATES:
        score = conductivity * 10000 * 0.5 + stability * 0.25 + feasibility * 0.25
        db.add(Candidate(
            id=code, code=code, name=name, formula=formula, family=family,
            domain="inorganic_materials", laboratory_code="SDL1",
            predicted_properties={"ionic_conductivity": conductivity, "stability_score": stability},
            uncertainty={"ionic_conductivity_relative": uncertainty, "stability_score": 0.08},
            feasibility_score=feasibility, recommendation_score=round(score, 2),
            lifecycle_stage="model_candidate", evidence_type="synthetic_model_prediction", synthetic=True,
        ))

    experiments = [
        ("EXP-2401", "Candidate A · computational screening", "executing", "MAT-00128", "simulation", 45),
        ("EXP-2398", "Candidate B · phase-stability comparison", "data_validation", "MAT-00129", "computational", 75),
        ("EXP-2395", "Candidate C · uncertainty review", "awaiting_approval", "MAT-00130", "simulation", 60),
        ("EXP-2389", "Reference dataset · metadata audit", "completed", "MAT-00131", "computational", 30),
        ("EXP-2381", "Candidate D · twin feasibility run", "failed", "MAT-00132", "simulation", 50),
    ]
    for code, title, status, candidate_id, mode, duration in experiments:
        db.add(Experiment(
            id=code, code=code, title=title, laboratory_code="SDL1", objective_id=objective.id,
            hypothesis_id="HYP-0001", candidate_id=candidate_id, status=status, execution_mode=mode,
            protocol_id="sdl1-screening-demo", protocol_version="0.1.0", owner="Dr. Demo Scientist",
            estimated_duration_minutes=duration,
            resource_requirements={"instrument_ids": ["SDL1-XRD-001"], "required_capabilities": ["computational_screening"]},
            governance={"approval_required": True, "safety_review_required": True, "physical_execution": False},
            result_summary={"evidence_type": "synthetic_demo_record"}, synthetic=True,
        ))

    for idx, (lab, name, kind, caps) in enumerate([
        ("SDL1", "XRD Twin 01", "x_ray_diffraction", ["powder_diffraction", "phase_identification"]),
        ("SDL1", "EIS Twin 02", "electrochemical_impedance", ["impedance_sweep", "conductivity_estimation"]),
        ("SDL1", "Thermal Twin 03", "thermal_analyzer", ["thermal_profile", "temperature_telemetry"]),
        ("SDL0", "Robot Cell Twin 01", "robotic_cell", ["workspace_state", "simulated_motion"]),
        ("SDL4", "Rheometer Twin 01", "rheometer", ["viscosity_profile", "oscillatory_sweep"]),
        ("SDL6", "Microscopy Twin 01", "microscope", ["image_acquisition", "morphology_stream"]),
    ], start=1):
        db.add(Instrument(
            id=f"INST-{idx:03d}", laboratory_code=lab, name=name, instrument_type=kind,
            status="simulated", capabilities=caps, telemetry={"temperature": None, "connection": "simulated"},
            requires_local_approval=True, synthetic=True,
        ))

    for name, domain, layer, count, status in [
        ("SDL1 materials candidate register", "inorganic_materials", "validated", 6, "preliminary"),
        ("NEXUS agent evaluation fixtures", "cross_domain", "ai", 120, "synthetic"),
        ("Instrument capability manifests", "cross_domain", "knowledge", 6, "preliminary"),
        ("Objective and hypothesis registry", "cross_domain", "scientific", 2, "preliminary"),
    ]:
        db.add(Dataset(id=str(uuid4()), name=name, domain=domain, data_layer=layer, version="0.1.0", record_count=count, quality_status=status, lineage=["seed://nexus-demo"], synthetic=True))

    # One pending approval keeps the governance screen immediately demonstrable.
    db.add(Approval(
        id="APR-0001", experiment_id="EXP-2395", requested_by="Dr. Demo Scientist",
        reason="Review the proposed computational follow-up and verify resource assumptions.", status="pending",
    ))
    record_event(db, "DEMO_DATABASE_SEEDED", "system", "NEXUS", actor="seed", payload={"synthetic": True, "agent_profiles": agent_count, "laboratories": 8})
    db.commit()
