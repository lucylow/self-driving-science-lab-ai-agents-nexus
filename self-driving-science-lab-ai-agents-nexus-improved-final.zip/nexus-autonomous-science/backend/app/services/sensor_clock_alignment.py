"""Estimate sensor clock offset/drift from explicit synchronization beacons."""
from __future__ import annotations
from statistics import mean, pstdev


def estimate_clock_transform(beacons: list[dict]) -> dict:
    if len(beacons) < 3:
        raise ValueError("At least three synchronization beacons are required")
    sensor_ids = {str(row.get("sensor_id", "")) for row in beacons}
    if len(sensor_ids) != 1 or "" in sensor_ids:
        raise ValueError("All beacons must belong to one identified sensor")
    x = [float(row["sensor_time"]) for row in beacons]
    y = [float(row["reference_time"]) for row in beacons]
    if len(set(x)) < 2:
        raise ValueError("Sensor clock beacon times must vary")
    x_mean, y_mean = mean(x), mean(y)
    denominator = sum((value - x_mean) ** 2 for value in x)
    slope = sum((a - x_mean) * (b - y_mean) for a, b in zip(x, y)) / denominator
    intercept = y_mean - slope * x_mean
    residuals = [b - (slope * a + intercept) for a, b in zip(x, y)]
    return {
        "sensor_id": next(iter(sensor_ids)), "affine_clock_transform": {"scale": slope, "offset_seconds": intercept},
        "beacon_count": len(beacons), "residual_mean_seconds": mean(residuals),
        "residual_standard_deviation_seconds": pstdev(residuals),
        "maximum_absolute_residual_seconds": max(abs(value) for value in residuals),
        "raw_timestamps_modified": False,
        "notice": "Store this transform as derived metadata; do not overwrite original instrument timestamps.",
    }
