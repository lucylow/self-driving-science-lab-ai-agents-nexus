"""Offline sensor stream validation, temporal quality, and drift indicators.

This module is diagnostic only. It never changes equipment setpoints or safety controls.
"""
from __future__ import annotations
from math import isfinite
from statistics import median, mean, pstdev


def review_timeseries(points: list[dict], *, expected_interval_seconds: float | None = None,
                      drift_window: int = 20) -> dict:
    if len(points) < 3:
        raise ValueError("At least three points are required")
    normalized = sorted(points, key=lambda item: float(item["timestamp"]))
    errors: list[str] = []
    for index, point in enumerate(normalized):
        if not isfinite(float(point["timestamp"])) or not isfinite(float(point["value"])):
            errors.append(f"Point {index} contains a non-finite value")
    sensors = {str(point["sensor_id"]) for point in normalized}
    units = {str(point["unit"]) for point in normalized}
    if len(sensors) != 1:
        errors.append("A stream review must contain exactly one sensor_id")
    if len(units) != 1:
        errors.append("A stream review must contain exactly one unit")
    timestamps = [float(point["timestamp"]) for point in normalized]
    values = [float(point["value"]) for point in normalized]
    intervals = [right - left for left, right in zip(timestamps, timestamps[1:])]
    duplicate_timestamps = sum(interval == 0 for interval in intervals)
    backward_timestamps = sum(interval < 0 for interval in intervals)
    positive = [interval for interval in intervals if interval > 0]
    median_interval = median(positive) if positive else None
    gap_indices = []
    if expected_interval_seconds:
        gap_indices = [index for index, interval in enumerate(intervals) if interval > 1.5 * expected_interval_seconds]
    robust_center = median(values)
    deviations = [abs(value - robust_center) for value in values]
    mad = median(deviations)
    robust_scale = 1.4826 * mad if mad > 1e-12 else (pstdev(values) or 1.0)
    anomalies = [index for index, value in enumerate(values) if abs(value - robust_center) / robust_scale > 4.5]
    window = min(max(3, drift_window), max(3, len(values) // 2))
    drift = None
    if len(values) >= 2 * window:
        baseline = mean(values[:window])
        recent = mean(values[-window:])
        baseline_scale = pstdev(values[:window]) or 1.0
        drift = {"baseline_mean": baseline, "recent_mean": recent,
                 "delta": recent - baseline, "standardized_delta": (recent - baseline) / baseline_scale,
                 "flagged": abs(recent - baseline) / baseline_scale > 3.0}
    return {
        "valid": not errors,
        "errors": errors,
        "sensor_id": next(iter(sensors)) if len(sensors) == 1 else None,
        "unit": next(iter(units)) if len(units) == 1 else None,
        "point_count": len(points),
        "time_range": {"start": timestamps[0], "end": timestamps[-1]},
        "median_interval_seconds": median_interval,
        "duplicate_timestamps": duplicate_timestamps,
        "backward_timestamps": backward_timestamps,
        "gap_after_indices": gap_indices,
        "robust_center": robust_center,
        "robust_scale": robust_scale,
        "anomaly_indices": anomalies,
        "drift_review": drift,
        "action": "review_only_no_equipment_control",
    }
