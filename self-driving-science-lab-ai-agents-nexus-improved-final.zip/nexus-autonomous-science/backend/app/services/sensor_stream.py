"""Timestamp-aware sensor stream processing and conservative sensor fusion."""

from dataclasses import dataclass
from datetime import datetime, timezone
from math import isfinite
from statistics import median
from typing import Any


@dataclass
class SensorReading:
    sensor_id: str
    value: float
    unit: str
    timestamp: datetime
    sequence_id: int | None = None
    quality: str = "unreviewed"
    metadata: dict[str, Any] | None = None


def validate_reading(reading: SensorReading) -> dict[str, Any]:
    issues = []
    if not isfinite(reading.value):
        issues.append("non_finite_value")
    if not reading.unit:
        issues.append("missing_unit")
    if reading.timestamp.tzinfo is None:
        issues.append("naive_timestamp")
    return {"valid_structure": not issues, "issues": issues}


def estimate_clock_offset(reference_times: list[datetime], sensor_times: list[datetime]) -> dict[str, float | int | None]:
    if len(reference_times) != len(sensor_times) or not reference_times:
        return {"median_offset_seconds": None, "sample_count": 0}
    offsets = [(ref - sensor).total_seconds() for ref, sensor in zip(reference_times, sensor_times)]
    return {"median_offset_seconds": median(offsets), "sample_count": len(offsets)}


def normalize_timestamp(timestamp: datetime) -> datetime:
    if timestamp.tzinfo is None:
        raise ValueError("A timezone-aware timestamp is required.")
    return timestamp.astimezone(timezone.utc)


def align_streams(streams: dict[str, list[SensorReading]]) -> dict[str, Any]:
    normalized = {}
    for sensor_id, readings in streams.items():
        normalized[sensor_id] = sorted(readings, key=lambda record: normalize_timestamp(record.timestamp))
    all_times = [normalize_timestamp(item.timestamp) for rows in normalized.values() for item in rows]
    return {
        "sensor_count": len(streams),
        "reading_count": len(all_times),
        "start": min(all_times).isoformat() if all_times else None,
        "end": max(all_times).isoformat() if all_times else None,
        "streams": normalized,
        "alignment_uncertainty": "not estimated by this baseline",
    }


def inverse_variance_fusion(values: list[tuple[float, float]]) -> dict[str, float]:
    """Fuse compatible readings with known variances; callers must establish compatibility."""
    if not values or any(variance <= 0 for _, variance in values):
        raise ValueError("Provide at least one reading with strictly positive variance.")
    weights = [1.0 / variance for _, variance in values]
    fused = sum(value * weight for (value, _), weight in zip(values, weights)) / sum(weights)
    variance = 1.0 / sum(weights)
    return {"value": fused, "variance": variance, "standard_uncertainty": variance ** 0.5, "source_count": len(values)}
