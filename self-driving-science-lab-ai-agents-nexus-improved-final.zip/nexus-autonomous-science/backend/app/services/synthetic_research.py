"""Deterministic, explicitly fictional research-network data for product demonstrations.

Records generated here are not measurements, publications, or results from Discovery Loop.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from functools import lru_cache
import random
from math import isfinite
from typing import Any, Mapping

SYNTHETIC_NOTICE = "SYNTHETIC DEMONSTRATION DATA — fictional records; not real scientific results."
PROGRAM_NAMES = [
    "Foundation Model Optimization", "Neural Architecture Discovery", "Reasoning and Evaluation",
    "Efficient Inference", "Distributed Machine Learning", "Model Compression and Distillation",
    "Automated Benchmark Discovery", "AI Research Agent Optimization", "Computational Materials Discovery",
    "Energy Storage Materials", "Solar Materials Research", "Computational Drug Discovery",
    "Protein and Enzyme Research", "Synthetic Biology and Bioprocess Optimization", "Water and Environmental Engineering",
]
DOMAINS = ["machine_learning"] * 8 + ["materials_science", "energy_storage", "solar_energy", "computational_drug_discovery", "protein_science", "synthetic_biology", "environmental_engineering"]
PROJECT_TEMPLATES = [
    ("Adaptive training schedules", "Compare training schedules under a fixed synthetic compute budget."),
    ("Compute-aware architecture search", "Test constrained architecture candidates against a reproducible baseline."),
    ("Evaluation-set robustness", "Measure how evaluation design affects estimated model quality."),
    ("Inference throughput controls", "Explore batching and precision choices while tracking quality trade-offs."),
    ("Evidence-linked iteration", "Evaluate whether explicit evidence links improve research-loop traceability."),
    ("Resource-allocation policies", "Compare deterministic resource-allocation policies in a simulated workload."),
]
STATUSES = ["active", "completed", "paused", "awaiting_review", "experimental", "failed", "archived"]
OUTCOMES = ["successful", "successful", "successful", "successful", "successful", "successful", "partial_improvement", "partial_improvement", "partial_improvement", "partial_improvement", "partial_improvement", "inconclusive", "inconclusive", "inconclusive", "inconclusive", "technical_failure", "technical_failure", "technical_failure", "negative_result", "negative_result"]
BASE_TIME = datetime(2026, 1, 1, tzinfo=timezone.utc)
DEFAULT_COUNTS = {
    "programs": 15, "projects": 60, "objectives": 180, "hypotheses": 400,
    "experiments": 800, "executions": 1500, "observations": 2000, "models": 150, "benchmarks": 40,
    "evaluations": 1000, "agents": 30, "agent_activities": 1500,
    "compute_jobs": 1200, "compute_resources": 300, "findings": 300,
    "insights": 250, "references": 150, "datasets": 80, "dataset_versions": 160,
    "iterations": 400, "decisions": 500, "failures": 150, "reports": 100,
}


def _id(prefix: str, index: int) -> str:
    return f"{prefix}_{index + 1:04d}"


def _time(index: int, *, minutes_per_step: int = 90) -> str:
    return (BASE_TIME + timedelta(minutes=index * minutes_per_step)).isoformat().replace("+00:00", "Z")


def generate_research_universe(seed: int = 42, counts: Mapping[str, int] | None = None) -> dict[str, Any]:
    """Build an interconnected demo dataset. Same seed and counts always yield identical output."""
    rng = random.Random(seed)
    sizes = dict(DEFAULT_COUNTS)
    if counts:
        unknown = set(counts) - set(sizes)
        if unknown:
            raise ValueError(f"Unknown record categories: {', '.join(sorted(unknown))}")
        for name, count in counts.items():
            if not isinstance(count, int) or isinstance(count, bool) or count < 0 or count > 100_000:
                raise ValueError(f"Count for {name!r} must be an integer between 0 and 100000")
            sizes[name] = count
    if sizes["programs"] != len(PROGRAM_NAMES):
        raise ValueError("The program count is fixed at 15 so every named demonstration program is present")
    records: dict[str, list[dict[str, Any]]] = {name: [] for name in sizes}

    for i, name in enumerate(PROGRAM_NAMES):
        records["programs"].append({"id": _id("program", i), "name": name, "domain": DOMAINS[i],
            "mission": f"Explore {name.lower()} through bounded, measurable computational experiments.",
            "status": "active" if i < 6 else "planned", "project_ids": [], "synthetic": True, "notice": SYNTHETIC_NOTICE})

    for i in range(sizes["projects"]):
        program = records["programs"][i % len(records["programs"])]
        template, objective_text = PROJECT_TEMPLATES[i % len(PROJECT_TEMPLATES)]
        status = STATUSES[i % len(STATUSES)]
        project = {"id": _id("project", i), "program_id": program["id"], "name": f"{template} · study {i + 1:02d}",
            "domain": program["domain"], "objective": objective_text, "status": status,
            "priority": ["high", "medium", "standard"][i % 3], "owner_agent_id": _id("agent", i % sizes["agents"]) if sizes["agents"] else None,
            "pause_reason": "Awaiting resource review in this simulated scenario." if status == "paused" else None,
            "created_at": _time(i), "synthetic": True, "notice": SYNTHETIC_NOTICE}
        records["projects"].append(project)
        program["project_ids"].append(project["id"])

    for i in range(sizes["objectives"]):
        project = records["projects"][i % len(records["projects"])] if records["projects"] else None
        records["objectives"].append({"id": _id("objective", i), "project_id": project["id"] if project else None,
            "question": f"Can {PROJECT_TEMPLATES[i % len(PROJECT_TEMPLATES)][0].lower()} improve the stated objective under controlled conditions?",
            "success_metric": ["quality_score", "throughput", "latency_ms", "compute_hours"][i % 4],
            "target_direction": "maximize" if i % 4 < 2 else "minimize", "synthetic": True, "notice": SYNTHETIC_NOTICE})

    project_objectives: dict[str, list[dict[str, Any]]] = {}
    for obj in records["objectives"]:
        if obj["project_id"]:
            project_objectives.setdefault(obj["project_id"], []).append(obj)
    for i in range(sizes["hypotheses"]):
        project = records["projects"][i % len(records["projects"])] if records["projects"] else None
        objectives = project_objectives.get(project["id"], []) if project else []
        objective = objectives[i % len(objectives)] if objectives else None
        prior = round(rng.uniform(0.25, 0.85), 3)
        hypothesis = {"id": _id("hypothesis", i), "project_id": project["id"] if project else None,
            "objective_id": objective["id"] if objective else None,
            "statement": f"A controlled change to {PROJECT_TEMPLATES[i % len(PROJECT_TEMPLATES)][0].lower()} may improve the selected metric without exceeding its resource constraint.",
            "status": ["open", "under_investigation", "supported", "rejected", "inconclusive"][i % 5],
            "prior_probability": prior, "posterior_probability": prior, "confidence": prior, "evidence_count": 0,
            "belief_update_method": "Illustrative Beta-Bernoulli update; technical failures and inconclusive runs are excluded.",
            "falsification_criterion": "Reject if repeated, comparable runs fail the prespecified threshold.",
            "created_at": _time(i), "synthetic": True, "notice": SYNTHETIC_NOTICE}
        records["hypotheses"].append(hypothesis)

    project_hypotheses: dict[str, list[dict[str, Any]]] = {}
    for hyp in records["hypotheses"]:
        if hyp["project_id"]:
            project_hypotheses.setdefault(hyp["project_id"], []).append(hyp)
    for i in range(sizes["experiments"]):
        project = records["projects"][i % len(records["projects"])] if records["projects"] else None
        hypotheses = project_hypotheses.get(project["id"], []) if project else []
        hyp = hypotheses[i % len(hypotheses)] if hypotheses else None
        obj = next((x for x in records["objectives"] if hyp and x["id"] == hyp["objective_id"]), None)
        estimated_hours = round(rng.uniform(0.5, 24), 2)
        information_gain = round(rng.uniform(0.01, 0.8), 4)
        records["experiments"].append({"id": _id("experiment", i), "project_id": project["id"] if project else None,
            "hypothesis_id": hyp["id"] if hyp else None, "objective_id": obj["id"] if obj else None,
            "name": f"{PROJECT_TEMPLATES[i % len(PROJECT_TEMPLATES)][0]} · configuration {i + 1:03d}",
            "baseline": "fixed_seed_reference", "status": ["completed", "approved", "awaiting_review", "draft"][i % 4],
            "estimated_compute_hours": estimated_hours, "expected_information_gain": information_gain,
            "acquisition_score": round(information_gain / max(estimated_hours, 0.1), 5),
            "recommendation_rationale": "Illustrative expected information gain divided by estimated compute hours; review before acting.",
            "synthetic": True, "notice": SYNTHETIC_NOTICE})

    for i in range(sizes["executions"]):
        experiment = records["experiments"][i % len(records["experiments"])] if records["experiments"] else None
        start = BASE_TIME + timedelta(minutes=i * 120)
        end = start + timedelta(minutes=rng.randint(1, 480))
        outcome = OUTCOMES[i % len(OUTCOMES)]
        score = round(max(0.0, min(1.0, rng.gauss(0.72 if outcome in {"successful", "partial_improvement"} else 0.48, 0.12))), 4)
        records["executions"].append({"id": _id("execution", i), "experiment_id": experiment["id"] if experiment else None,
            "project_id": experiment["project_id"] if experiment else None, "attempt": i // max(sizes["experiments"], 1) + 1,
            "status": outcome, "started_at": start.isoformat().replace("+00:00", "Z"),
            "ended_at": end.isoformat().replace("+00:00", "Z"), "duration_seconds": int((end - start).total_seconds()),
            "quality_score": score, "compute_hours": round(rng.uniform(0.1, 20), 2),
            "error_category": "simulated_infrastructure_error" if outcome == "technical_failure" else None,
            "synthetic": True, "notice": SYNTHETIC_NOTICE})

    experiment_by_id = {row["id"]: row for row in records["experiments"]}
    for i in range(sizes["observations"]):
        execution = records["executions"][i % len(records["executions"])] if records["executions"] else None
        experiment = experiment_by_id.get(execution["experiment_id"]) if execution else None
        value = round(max(0.0, min(1.0, rng.gauss(execution["quality_score"], 0.06))) if execution else 0.0, 4)
        records["observations"].append({"id": _id("observation", i), "project_id": execution["project_id"] if execution else None,
            "experiment_id": execution["experiment_id"] if execution else None, "execution_id": execution["id"] if execution else None,
            "hypothesis_id": experiment["hypothesis_id"] if experiment else None,
            "metric": "synthetic_quality_score", "value": value, "unit": "fraction_0_to_1", "uncertainty": round(rng.uniform(0.01, 0.12), 4),
            "result_class": execution["status"] if execution else "unavailable", "observed_at": execution["ended_at"] if execution else _time(i),
            "origin": "simulated_observation", "synthetic": True, "notice": SYNTHETIC_NOTICE})

    hypothesis_by_id = {row["id"]: row for row in records["hypotheses"]}
    evidence_counts: dict[str, list[int]] = {}
    for observation in records["observations"]:
        hyp_id = observation["hypothesis_id"]
        if hyp_id not in hypothesis_by_id or observation["result_class"] in {"technical_failure", "inconclusive", "unavailable"}:
            continue
        counts_for_hypothesis = evidence_counts.setdefault(hyp_id, [0, 0])
        counts_for_hypothesis[0 if observation["result_class"] in {"successful", "partial_improvement"} else 1] += 1
    for hypothesis in records["hypotheses"]:
        positive, negative = evidence_counts.get(hypothesis["id"], [0, 0])
        n = positive + negative
        posterior = (2 * hypothesis["prior_probability"] + positive) / (2 + n)
        hypothesis["posterior_probability"] = round(posterior, 4)
        hypothesis["confidence"] = round(posterior, 4)
        hypothesis["evidence_count"] = n
    for project in records["projects"]:
        project_id = project["id"]
        project_experiments = [row for row in records["experiments"] if row["project_id"] == project_id]
        project_hypotheses = [row for row in records["hypotheses"] if row["project_id"] == project_id]
        project_executions = [row for row in records["executions"] if row["project_id"] == project_id]
        project["hypothesis_ids"] = [row["id"] for row in project_hypotheses]
        project["experiment_ids"] = [row["id"] for row in project_experiments]
        project["execution_count"] = len(project_executions)
        project["completed_execution_count"] = sum(row["status"] in {"successful", "partial_improvement", "inconclusive", "negative_result"} for row in project_executions)
        project["current_confidence"] = round(sum(row["posterior_probability"] for row in project_hypotheses) / len(project_hypotheses), 4) if project_hypotheses else None
        eligible_experiments = [row for row in project_experiments if row["status"] != "completed"]
        next_experiment = max(eligible_experiments, key=lambda row: row["acquisition_score"], default=None)
        project["recommended_next_experiment_id"] = next_experiment["id"] if next_experiment else None
        project["recommendation_rationale"] = next_experiment["recommendation_rationale"] if next_experiment else None

    for i in range(sizes["models"]):
        records["models"].append({"id": _id("model", i), "project_id": _id("project", i % sizes["projects"]) if sizes["projects"] else None,
            "family": ["decoder_transformer", "encoder_decoder", "mixture_of_experts", "vision_transformer", "small_language_model"][i % 5],
            "parameters_millions": [125, 350, 760, 1300, 2800][i % 5], "layers": [12, 24, 32, 40][i % 4],
            "precision": ["bf16", "fp16", "int8"][i % 3], "version": f"0.{i // 10}.{i % 10}", "synthetic": True, "notice": SYNTHETIC_NOTICE})
    for i in range(sizes["benchmarks"]):
        records["benchmarks"].append({"id": _id("benchmark", i), "name": ["reasoning_consistency", "code_task_success", "inference_latency", "training_efficiency"][i % 4] + f" · suite {i + 1:02d}",
            "metric": ["score", "success_rate", "milliseconds", "tokens_per_second"][i % 4], "synthetic": True, "notice": SYNTHETIC_NOTICE})
    for i in range(sizes["evaluations"]):
        execution = records["executions"][i % len(records["executions"])] if records["executions"] else None
        records["evaluations"].append({"id": _id("evaluation", i), "execution_id": execution["id"] if execution else None,
            "benchmark_id": _id("benchmark", i % max(sizes["benchmarks"], 1)), "model_id": _id("model", i % max(sizes["models"], 1)),
            "score": round(rng.uniform(0.35, 0.98), 4), "split": ["validation", "holdout"][i % 2], "synthetic": True, "notice": SYNTHETIC_NOTICE})
    for i in range(sizes["agents"]):
        records["agents"].append({"id": _id("agent", i), "name": ["Hypothesis Analyst", "Experiment Designer", "Evidence Reviewer", "Evaluation Specialist", "Resource Planner"][i % 5] + f" {i + 1:02d}",
            "role": ["hypothesis_generation", "experiment_design", "evidence_review", "evaluation", "compute_planning"][i % 5], "permission_level": "propose_only", "synthetic": True, "notice": SYNTHETIC_NOTICE})
    for i in range(sizes["agent_activities"]):
        records["agent_activities"].append({"id": _id("activity", i), "agent_id": _id("agent", i % max(sizes["agents"], 1)),
            "project_id": _id("project", i % sizes["projects"]) if sizes["projects"] else None, "event": ["hypothesis_drafted", "experiment_reviewed", "evidence_summarized", "result_ranked"][i % 4],
            "created_at": _time(i), "synthetic": True, "notice": SYNTHETIC_NOTICE})
    for i in range(sizes["compute_jobs"]):
        execution = records["executions"][i % len(records["executions"])] if records["executions"] else None
        records["compute_jobs"].append({"id": _id("compute_job", i), "execution_id": execution["id"] if execution else None,
            "status": execution["status"] if execution else "unassigned", "gpu_type": ["synthetic_A100_class", "synthetic_H100_class", "cpu_simulation"][i % 3],
            "gpu_count": 1 + i % 8, "cost_usd": round(rng.uniform(0.1, 250), 2), "synthetic": True, "notice": SYNTHETIC_NOTICE})
    for i in range(sizes["compute_resources"]):
        records["compute_resources"].append({"id": _id("resource", i), "pool": ["accelerator_demo", "cpu_demo", "simulation_demo"][i % 3],
            "capacity_units": 8 + i % 120, "allocated_units": (i * 7) % (8 + i % 120), "synthetic": True, "notice": SYNTHETIC_NOTICE})
    for i in range(sizes["findings"]):
        execution = records["executions"][i % len(records["executions"])] if records["executions"] else None
        records["findings"].append({"id": _id("finding", i), "project_id": execution["project_id"] if execution else None,
            "execution_id": execution["id"] if execution else None, "claim": f"Synthetic run {i + 1} yielded a {execution['status'] if execution else 'unavailable'} outcome under its recorded configuration.",
            "evidence_refs": [execution["id"]] if execution else [], "synthetic": True, "notice": SYNTHETIC_NOTICE})
    for i in range(sizes["insights"]):
        finding = records["findings"][i % len(records["findings"])] if records["findings"] else None
        records["insights"].append({"id": _id("insight", i), "finding_id": finding["id"] if finding else None,
            "summary": f"Review finding {finding['id'] if finding else 'unavailable'} alongside independent replications before updating a hypothesis.",
            "synthetic": True, "notice": SYNTHETIC_NOTICE})
    for i in range(sizes["references"]):
        hyp = records["hypotheses"][i % len(records["hypotheses"])] if records["hypotheses"] else None
        records["references"].append({"id": _id("reference", i), "hypothesis_id": hyp["id"] if hyp else None,
            "title": f"Synthetic methods note {i + 1:03d}: controlled evaluation protocol", "source_uri": f"synthetic://reference/{i + 1:04d}",
            "record_type": "fictional_demo_reference", "synthetic": True, "notice": SYNTHETIC_NOTICE})
    for i in range(sizes["datasets"]):
        records["datasets"].append({"id": _id("dataset", i), "project_id": _id("project", i % sizes["projects"]) if sizes["projects"] else None,
            "name": f"Synthetic benchmark snapshot {i + 1:03d}", "version_count": 2, "synthetic": True, "notice": SYNTHETIC_NOTICE})
    for i in range(sizes["dataset_versions"]):
        dataset = records["datasets"][i % len(records["datasets"])] if records["datasets"] else None
        records["dataset_versions"].append({"id": _id("dataset_version", i), "dataset_id": dataset["id"] if dataset else None,
            "version": f"0.{i // 10}.{i % 10}", "row_count": 100 + i * 17, "synthetic": True, "notice": SYNTHETIC_NOTICE})
    for i in range(sizes["iterations"]):
        project = records["projects"][i % len(records["projects"])] if records["projects"] else None
        records["iterations"].append({"id": _id("iteration", i), "project_id": project["id"] if project else None,
            "iteration_number": i // max(sizes["projects"], 1) + 1, "stage": ["hypothesis", "design", "execution", "evaluation", "selection"][i % 5],
            "created_at": _time(i), "synthetic": True, "notice": SYNTHETIC_NOTICE})
    for i in range(sizes["decisions"]):
        hyp = records["hypotheses"][i % len(records["hypotheses"])] if records["hypotheses"] else None
        exp = records["experiments"][i % len(records["experiments"])] if records["experiments"] else None
        records["decisions"].append({"id": _id("decision", i), "hypothesis_id": hyp["id"] if hyp else None,
            "experiment_id": exp["id"] if exp else None, "decision": ["continue", "revise", "pause", "reject"][i % 4],
            "rationale": "Synthetic evidence review decision; human review is required for consequential use.", "synthetic": True, "notice": SYNTHETIC_NOTICE})
    technical = [x for x in records["executions"] if x["status"] == "technical_failure"]
    for i in range(sizes["failures"]):
        execution = technical[i % len(technical)] if technical else None
        records["failures"].append({"id": _id("failure", i), "execution_id": execution["id"] if execution else None,
            "failure_type": "simulated_infrastructure_error", "recovered": i % 3 == 0, "synthetic": True, "notice": SYNTHETIC_NOTICE})
    for i in range(sizes["reports"]):
        project = records["projects"][i % len(records["projects"])] if records["projects"] else None
        findings = [f for f in records["findings"] if project and f["project_id"] == project["id"]]
        records["reports"].append({"id": _id("report", i), "project_id": project["id"] if project else None,
            "title": f"Synthetic research summary · {project['name'] if project else 'unassigned'}",
            "source_record_ids": [f["id"] for f in findings[:5]], "limitations": ["Synthetic demonstration data only", "No physical experiment or external measurement is represented"],
            "created_at": _time(i), "synthetic": True, "notice": SYNTHETIC_NOTICE})

    dataset = {"metadata": {"seed": seed, "record_counts": {key: len(value) for key, value in records.items()},
        "total_records": sum(map(len, records.values())), "synthetic": True, "notice": SYNTHETIC_NOTICE}, **records}
    errors = validate_research_universe(dataset)
    if errors:
        raise ValueError("Generated dataset failed validation: " + "; ".join(errors[:5]))
    return dataset


def validate_research_universe(dataset: Mapping[str, Any]) -> list[str]:
    """Return actionable referential-integrity and timestamp errors for a generated bundle."""
    errors: list[str] = []
    ids = {category: {item.get("id") for item in dataset.get(category, [])} for category in DEFAULT_COUNTS}
    for category, items in dataset.items():
        if category == "metadata" or not isinstance(items, list):
            continue
        record_ids = [item.get("id") for item in items]
        if None in record_ids:
            errors.append(f"{category} contains a record without an id")
        if len(record_ids) != len(set(record_ids)):
            errors.append(f"{category} contains duplicate record ids")
    checks = {
        "projects": [("program_id", "programs"), ("owner_agent_id", "agents")], "objectives": [("project_id", "projects")],
        "hypotheses": [("project_id", "projects"), ("objective_id", "objectives")],
        "experiments": [("project_id", "projects"), ("hypothesis_id", "hypotheses"), ("objective_id", "objectives")],
        "executions": [("experiment_id", "experiments"), ("project_id", "projects")],
        "observations": [("execution_id", "executions"), ("experiment_id", "experiments"), ("project_id", "projects"), ("hypothesis_id", "hypotheses")],
        "models": [("project_id", "projects")], "evaluations": [("execution_id", "executions"), ("benchmark_id", "benchmarks"), ("model_id", "models")],
        "agent_activities": [("agent_id", "agents"), ("project_id", "projects")], "compute_jobs": [("execution_id", "executions")],
        "findings": [("project_id", "projects"), ("execution_id", "executions")], "insights": [("finding_id", "findings")],
        "references": [("hypothesis_id", "hypotheses")], "datasets": [("project_id", "projects")],
        "dataset_versions": [("dataset_id", "datasets")], "iterations": [("project_id", "projects")],
        "decisions": [("hypothesis_id", "hypotheses"), ("experiment_id", "experiments")],
        "failures": [("execution_id", "executions")], "reports": [("project_id", "projects")],
    }
    for category, foreign_keys in checks.items():
        for record in dataset.get(category, []):
            for field, parent_category in foreign_keys:
                value = record.get(field)
                if value is not None and value not in ids[parent_category]:
                    errors.append(f"{category}.{record.get('id')} references missing {parent_category} id {value}")
    for record in dataset.get("executions", []):
        try:
            if datetime.fromisoformat(record["ended_at"].replace("Z", "+00:00")) < datetime.fromisoformat(record["started_at"].replace("Z", "+00:00")):
                errors.append(f"execution {record.get('id')} ends before it starts")
        except (KeyError, ValueError, TypeError):
            errors.append(f"execution {record.get('id')} has invalid timestamps")
        score = record.get("quality_score")
        if not isinstance(score, (int, float)) or not isfinite(score) or not 0 <= score <= 1:
            errors.append(f"execution {record.get('id')} has a quality score outside [0, 1]")
        if not isinstance(record.get("compute_hours"), (int, float)) or record["compute_hours"] < 0:
            errors.append(f"execution {record.get('id')} has invalid compute usage")
    for record in dataset.get("findings", []):
        if any(ref not in ids["executions"] for ref in record.get("evidence_refs", [])):
            errors.append(f"finding {record.get('id')} references missing execution evidence")
    for record in dataset.get("reports", []):
        if any(ref not in ids["findings"] for ref in record.get("source_record_ids", [])):
            errors.append(f"report {record.get('id')} references missing source findings")
    for category, items in dataset.items():
        if category == "metadata" or not isinstance(items, list):
            continue
        for item in items:
            if item.get("synthetic") is not True or not item.get("notice"):
                errors.append(f"{category}.{item.get('id')} lacks synthetic provenance")
    return errors


@lru_cache(maxsize=4)
def get_default_research_universe(seed: int = 42) -> dict[str, Any]:
    """Cache the standard dataset for read-only API exploration."""
    return generate_research_universe(seed)
