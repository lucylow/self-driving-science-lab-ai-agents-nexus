"""Minimal uncertainty utilities; calibration must be learned from held-out validation data."""

from math import sqrt
from statistics import mean


def ensemble_summary(predictions: list[float]) -> dict:
    if not predictions:
        return {"mean": None, "standard_deviation": None, "count": 0}
    center = mean(predictions)
    variance = sum((value - center) ** 2 for value in predictions) / max(1, len(predictions) - 1)
    return {
        "mean": center,
        "standard_deviation": sqrt(variance),
        "count": len(predictions),
        "interpretation": "Uncalibrated ensemble dispersion; not a confidence interval.",
    }


def flag_out_of_domain(*, training_min: float, training_max: float, query_value: float) -> dict:
    is_ood = query_value < training_min or query_value > training_max
    return {
        "out_of_domain": is_ood,
        "training_range": [training_min, training_max],
        "query_value": query_value,
        "recommendation": "Route to scientist review" if is_ood else "Within the declared numeric training range",
    }
