"""Computer-vision result contract and image-ingestion quality checks.

This module accepts metadata and model outputs; a trained image model is intentionally not
fabricated. Integrate PyTorch/OpenCV behind this interface after domain-labelled benchmarks.
"""

from typing import Any

ALLOWED_IMAGE_MODALITIES = {"microscopy", "xrd_map", "macro_sample", "robot_workspace", "spectroscopy_image"}


def validate_image_artifact(metadata: dict[str, Any]) -> dict[str, Any]:
    errors = []
    if metadata.get("modality") not in ALLOWED_IMAGE_MODALITIES:
        errors.append("Unsupported or missing image modality.")
    if not metadata.get("artifact_uri"):
        errors.append("Missing source artifact reference.")
    if not metadata.get("sample_id"):
        errors.append("Sample identity is required for scientific image analysis.")
    if not metadata.get("acquisition_timestamp"):
        errors.append("Acquisition timestamp is required.")
    if not metadata.get("instrument_id"):
        errors.append("Instrument identity is required.")
    return {
        "valid_for_review": not errors,
        "errors": errors,
        "requires_image_model": True,
        "unknown_state_supported": True,
    }


def package_vision_prediction(*, artifact_uri: str, sample_id: str, task: str,
                               labels: list[dict[str, Any]], model_id: str,
                               confidence_threshold: float = 0.75) -> dict[str, Any]:
    reviewed = []
    for label in labels:
        confidence = float(label.get("confidence", 0.0))
        reviewed.append({
            "label": label.get("label", "unknown") if confidence >= confidence_threshold else "unknown",
            "confidence": confidence,
            "accepted_at_threshold": confidence >= confidence_threshold,
        })
    return {
        "artifact_uri": artifact_uri,
        "sample_id": sample_id,
        "task": task,
        "model_id": model_id,
        "predictions": reviewed,
        "origin": "model_prediction",
        "requires_scientist_annotation": True,
    }
