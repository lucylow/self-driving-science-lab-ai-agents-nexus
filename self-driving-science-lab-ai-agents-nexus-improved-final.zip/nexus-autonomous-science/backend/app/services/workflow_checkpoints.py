"""Hash-linked workflow checkpoints and conservative recovery planning."""
from __future__ import annotations
import hashlib
import json
from uuid import uuid4
from typing import Any
from sqlalchemy import select, func
from sqlalchemy.orm import Session
from app.models.entities import WorkflowCheckpointRecord, WorkflowRunRecord


def _canonical_hash(payload: dict[str, Any]) -> str:
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def append_checkpoint(db: Session, *, workflow: WorkflowRunRecord, checkpoint_key: str,
                      node_id: str, node_status: str, state_snapshot: dict,
                      output_snapshot: dict | None = None, idempotency_key: str,
                      physical_side_effects: bool = False) -> WorkflowCheckpointRecord:
    """Append one checkpoint, returning the existing row on identical idempotent retry."""
    if not idempotency_key.strip() or not checkpoint_key.strip() or not node_id.strip():
        raise ValueError("checkpoint identity fields are required")
    existing = db.scalar(select(WorkflowCheckpointRecord).where(
        WorkflowCheckpointRecord.idempotency_key == idempotency_key))
    if existing:
        candidate = {"workflow_run_id": workflow.id, "checkpoint_key": checkpoint_key,
                     "node_id": node_id, "node_status": node_status,
                     "state_snapshot": state_snapshot, "output_snapshot": output_snapshot or {},
                     "physical_side_effects": physical_side_effects}
        existing_projection = {"workflow_run_id": existing.workflow_run_id,
                     "checkpoint_key": existing.checkpoint_key, "node_id": existing.node_id,
                     "node_status": existing.node_status, "state_snapshot": existing.state_snapshot,
                     "output_snapshot": existing.output_snapshot,
                     "physical_side_effects": existing.physical_side_effects}
        if _canonical_hash(candidate) != _canonical_hash(existing_projection):
            raise ValueError("checkpoint idempotency key was reused with different content")
        return existing
    last = db.scalar(select(WorkflowCheckpointRecord).where(
        WorkflowCheckpointRecord.workflow_run_id == workflow.id).order_by(
        WorkflowCheckpointRecord.checkpoint_index.desc()).limit(1))
    index = (last.checkpoint_index + 1) if last else 0
    previous_hash = last.checkpoint_hash if last else ""
    body = {"workflow_run_id": workflow.id, "checkpoint_index": index,
            "checkpoint_key": checkpoint_key, "node_id": node_id,
            "node_status": node_status, "state_snapshot": state_snapshot,
            "output_snapshot": output_snapshot or {},
            "idempotency_key": idempotency_key, "previous_hash": previous_hash,
            "physical_side_effects": physical_side_effects}
    record = WorkflowCheckpointRecord(id=str(uuid4()), **body,
                                      checkpoint_hash=_canonical_hash(body))
    db.add(record)
    db.flush()
    return record


def list_checkpoints(db: Session, workflow_run_id: str) -> list[WorkflowCheckpointRecord]:
    return db.scalars(select(WorkflowCheckpointRecord).where(
        WorkflowCheckpointRecord.workflow_run_id == workflow_run_id).order_by(
        WorkflowCheckpointRecord.checkpoint_index.asc())).all()


def verify_checkpoint_chain(records: list[WorkflowCheckpointRecord]) -> dict[str, Any]:
    issues = []; previous_hash = ""
    ordered = sorted(records, key=lambda item: item.checkpoint_index)
    for expected_index, row in enumerate(ordered):
        if row.checkpoint_index != expected_index:
            issues.append({"checkpoint_id": row.id, "code": "index_gap"})
        if row.previous_hash != previous_hash:
            issues.append({"checkpoint_id": row.id, "code": "previous_hash_mismatch"})
        body = {"workflow_run_id": row.workflow_run_id, "checkpoint_index": row.checkpoint_index,
                "checkpoint_key": row.checkpoint_key, "node_id": row.node_id,
                "node_status": row.node_status, "state_snapshot": row.state_snapshot,
                "output_snapshot": row.output_snapshot, "idempotency_key": row.idempotency_key,
                "previous_hash": row.previous_hash, "physical_side_effects": row.physical_side_effects}
        expected_hash = _canonical_hash(body)
        if row.checkpoint_hash != expected_hash:
            issues.append({"checkpoint_id": row.id, "code": "content_hash_mismatch"})
        previous_hash = row.checkpoint_hash
    return {"valid": not issues, "checkpoint_count": len(ordered), "issues": issues,
            "head_hash": previous_hash if ordered else None,
            "append_only": True}


def recovery_plan(workflow: WorkflowRunRecord, records: list[WorkflowCheckpointRecord], *,
                  operator_requested: bool = False) -> dict[str, Any]:
    integrity = verify_checkpoint_chain(records)
    if not integrity["valid"]:
        return {"eligible": False, "reason": "checkpoint_chain_integrity_failed",
                "integrity": integrity, "requires_operator": True}
    if not records:
        return {"eligible": False, "reason": "no_checkpoint_available",
                "integrity": integrity, "requires_operator": True}
    latest = max(records, key=lambda item: item.checkpoint_index)
    if any(item.physical_side_effects for item in records):
        return {"eligible": False, "reason": "physical_side_effect_recovery_not_supported",
                "integrity": integrity, "latest_checkpoint_id": latest.id,
                "requires_operator": True}
    if workflow.status not in {"failed", "interrupted", "paused"}:
        return {"eligible": False, "reason": "workflow_not_in_recoverable_state",
                "workflow_status": workflow.status, "integrity": integrity,
                "requires_operator": True}
    completed = [item for item in records if item.node_status == "completed"]
    if not completed:
        return {"eligible": False, "reason": "no_completed_checkpoint",
                "integrity": integrity, "latest_checkpoint_id": latest.id,
                "failed_node": latest.node_id if latest.node_status == "failed" else None,
                "requires_operator": True, "automatic_resume": False}
    resume_boundary = max(completed, key=lambda item: item.checkpoint_index)
    failure = latest if latest.node_status == "failed" else None
    if not operator_requested:
        return {"eligible": True, "resume_recommendation": "await_operator_request",
                "latest_checkpoint_id": resume_boundary.id,
                "completed_node": resume_boundary.node_id,
                "failed_checkpoint_id": failure.id if failure else None,
                "failed_node": failure.node_id if failure else None,
                "requires_operator": True, "automatic_resume": False,
                "integrity": integrity}
    return {"eligible": True, "resume_recommendation": "resume_after_latest_checkpoint",
            "latest_checkpoint_id": resume_boundary.id,
            "completed_node": resume_boundary.node_id,
            "failed_checkpoint_id": failure.id if failure else None,
            "failed_node": failure.node_id if failure else None,
            "state_snapshot": resume_boundary.state_snapshot, "requires_operator": True,
            "automatic_resume": False, "integrity": integrity,
            "note": "This is an advisory computational recovery boundary only; no workflow is resumed and no physical procedure can be replayed."}


def checkpoint_summary(records: list[WorkflowCheckpointRecord]) -> dict[str, Any]:
    chain = verify_checkpoint_chain(records)
    return {**chain, "nodes": [{"index": row.checkpoint_index, "node_id": row.node_id,
            "status": row.node_status, "checkpoint_key": row.checkpoint_key,
            "physical_side_effects": row.physical_side_effects,
            "created_at": row.created_at.isoformat() if row.created_at else None}
            for row in sorted(records, key=lambda item: item.checkpoint_index)]}
