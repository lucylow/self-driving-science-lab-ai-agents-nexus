"""Compile research requests into reviewed computational workflow DAGs.

Compilation describes scientific work and dependencies. It never emits robot motion,
liquid-handling operations, chemical synthesis parameters, or physical commands.
"""
from __future__ import annotations
from typing import Any
from app.services.agent_intelligence.task_graph import compile_task_graph

LAB_DOMAIN = {
    "SDL0": "autonomous_systems", "SDL1": "inorganic_materials",
    "SDL2": "organic_chemistry", "SDL3": "medicinal_chemistry",
    "SDL4": "polymers", "SDL5": "formulations",
    "SDL6": "biological_systems", "SDL7": "process_engineering",
}

WORKFLOW_TEMPLATES: dict[str, dict[str, Any]] = {
    "sdl1_material_screening": {
        "laboratory_code": "SDL1", "nodes": [
            ("objective_check", "objective_validation", []),
            ("formula_check", "composition_validation", ["objective_check"]),
            ("data_retrieval", "evidence_retrieval", ["objective_check"]),
            ("candidate_scoring", "multiobjective_ranking", ["formula_check", "data_retrieval"]),
            ("uncertainty_review", "uncertainty_assessment", ["candidate_scoring"]),
            ("scientist_review", "human_review", ["uncertainty_review"]),
        ]},
    "sdl2_molecular_review": {
        "laboratory_code": "SDL2", "nodes": [
            ("objective_check", "objective_validation", []),
            ("structure_check", "molecular_structure_validation", ["objective_check"]),
            ("descriptor_generation", "molecular_descriptor_analysis", ["structure_check"]),
            ("property_estimation", "property_prediction", ["descriptor_generation"]),
            ("applicability_review", "model_applicability", ["property_estimation"]),
            ("scientist_review", "human_review", ["applicability_review"]),
        ]},
    "sdl4_polymer_characterization": {
        "laboratory_code": "SDL4", "nodes": [
            ("objective_check", "objective_validation", []),
            ("metadata_check", "sample_metadata_validation", ["objective_check"]),
            ("measurement_review", "measurement_quality_review", ["metadata_check"]),
            ("structure_property_review", "polymer_structure_property_analysis", ["measurement_review"]),
            ("reproducibility_review", "replicate_analysis", ["structure_property_review"]),
            ("scientist_review", "human_review", ["reproducibility_review"]),
        ]},
    "sdl6_biological_evidence_review": {
        "laboratory_code": "SDL6", "nodes": [
            ("objective_check", "objective_validation", []),
            ("model_identity", "biological_model_provenance", ["objective_check"]),
            ("culture_context", "culture_context_validation", ["model_identity"]),
            ("image_quality", "image_quality_review", ["culture_context"]),
            ("replicate_review", "biological_replicate_analysis", ["image_quality"]),
            ("biosafety_review", "human_biosafety_review", ["replicate_review"]),
        ]},
}


def compile_workflow(*, workflow_key: str, laboratory_code: str, domain: str,
                     objective: dict[str, Any], context: dict[str, Any] | None = None,
                     synthetic: bool = True) -> dict[str, Any]:
    template = WORKFLOW_TEMPLATES.get(workflow_key)
    if template is None:
        raise KeyError(f"unknown workflow template: {workflow_key}")
    expected_lab = template["laboratory_code"]
    if expected_lab != laboratory_code:
        raise ValueError(f"workflow {workflow_key} is registered for {expected_lab}, not {laboratory_code}")
    if LAB_DOMAIN.get(laboratory_code) != domain:
        raise ValueError("laboratory code and scientific domain are inconsistent")
    required = ["objective_id", "description", "target_properties"]
    missing = [key for key in required if objective.get(key) in (None, "", [])]
    if missing:
        raise ValueError(f"objective is missing required fields: {', '.join(missing)}")
    if objective.get("domain") and objective["domain"] != domain:
        raise ValueError("objective domain does not match workflow domain")
    nodes = [{"node_id": node_id, "capability": capability, "depends_on": deps,
              "execution_class": "analysis_only" if capability != "human_review" and capability != "human_biosafety_review" else "human_review",
              "status": "pending"}
             for node_id, capability, deps in template["nodes"]]
    graph = compile_task_graph(nodes)
    if not graph.get("valid"):
        raise RuntimeError(f"registered workflow template is invalid: {graph.get('issues')}")
    return {"workflow_key": workflow_key, "laboratory_code": laboratory_code,
            "domain": domain, "objective_id": objective["objective_id"],
            "compiled_nodes": nodes, "topological_order": graph.get("topological_order", []),
            "context": context or {}, "synthetic": synthetic,
            "compiled_status": "awaiting_scientist_review",
            "physical_execution": False,
            "requires_scientist_review": True,
            "guardrails": ["AI-generated plan is not an approved protocol.",
                           "No physical command is generated by this compiler.",
                           "Scientific evidence retains origin, uncertainty, and provenance."]}


def compare_workflow_templates(left_key: str, right_key: str) -> dict[str, Any]:
    left, right = WORKFLOW_TEMPLATES[left_key], WORKFLOW_TEMPLATES[right_key]
    left_caps = {cap for _, cap, _ in left["nodes"]}
    right_caps = {cap for _, cap, _ in right["nodes"]}
    return {"left": left_key, "right": right_key,
            "shared_capabilities": sorted(left_caps & right_caps),
            "left_specific_capabilities": sorted(left_caps-right_caps),
            "right_specific_capabilities": sorted(right_caps-left_caps),
            "same_laboratory": left["laboratory_code"] == right["laboratory_code"],
            "note": "Shared capability labels do not imply scientifically interchangeable procedures."}
