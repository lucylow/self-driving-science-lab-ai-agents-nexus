"""Small deterministic workflow graph used before optional LangGraph integration.

Each node is a pure transformation over workflow state. The graph has no equipment
commands and returns an explicit human-review checkpoint before experiment execution.
"""

from dataclasses import dataclass, field
from typing import Any, Callable


@dataclass
class WorkflowState:
    objective: dict[str, Any]
    candidate_records: list[dict[str, Any]] = field(default_factory=list)
    hypothesis: dict[str, Any] | None = None
    ranking: list[dict[str, Any]] = field(default_factory=list)
    feasibility: dict[str, Any] = field(default_factory=dict)
    approval_checkpoint: dict[str, Any] = field(default_factory=dict)
    messages: list[dict[str, Any]] = field(default_factory=list)
    synthetic: bool = True


def objective_review(state: WorkflowState) -> WorkflowState:
    text = state.objective.get("description", "").strip()
    state.messages.append({"node": "objective_review", "status": "passed" if text else "needs_input"})
    state.feasibility["objective_text_present"] = bool(text)
    return state


def candidate_screen(state: WorkflowState) -> WorkflowState:
    from app.services.optimizer import select_next_batch
    state.ranking = select_next_batch(state.candidate_records, batch_size=3)
    state.messages.append({"node": "candidate_screen", "ranked_candidates": len(state.ranking)})
    return state


def feasibility_review(state: WorkflowState) -> WorkflowState:
    missing = []
    if not state.objective.get("target_properties"):
        missing.append("target_properties")
    if not state.objective.get("constraints"):
        missing.append("constraints")
    state.feasibility["missing_fields"] = missing
    state.feasibility["status"] = "review_required" if missing else "preliminary_pass"
    state.messages.append({"node": "feasibility_review", "status": state.feasibility["status"]})
    return state


def approval_checkpoint(state: WorkflowState) -> WorkflowState:
    state.approval_checkpoint = {
        "required": True,
        "approved": False,
        "physical_execution_enabled": False,
        "reason": "Scientist review is mandatory before any consequential execution.",
    }
    state.messages.append({"node": "approval_checkpoint", "status": "awaiting_human"})
    return state


NODES: dict[str, Callable[[WorkflowState], WorkflowState]] = {
    "objective_review": objective_review,
    "candidate_screen": candidate_screen,
    "feasibility_review": feasibility_review,
    "approval_checkpoint": approval_checkpoint,
}


def run_discovery_workflow(state: WorkflowState) -> WorkflowState:
    for name in ("objective_review", "candidate_screen", "feasibility_review", "approval_checkpoint"):
        state = NODES[name](state)
    return state
