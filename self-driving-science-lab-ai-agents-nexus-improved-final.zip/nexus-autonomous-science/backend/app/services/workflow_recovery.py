"""Checkpoint recovery assessment for interrupted computational and simulated workflows."""
from __future__ import annotations


def assess_recovery(checkpoint: dict) -> dict:
    errors = []
    execution_mode = checkpoint.get("execution_mode", "simulation")
    if execution_mode == "physical":
        errors.append("Physical workflow recovery is not supported by the cloud starter")
    if checkpoint.get("sample_identity_status") not in {"verified", "provisional"}:
        errors.append("Sample identity requires review before recovery")
    if checkpoint.get("quarantined"):
        errors.append("Quarantined sample or dataset cannot be resumed")
    if checkpoint.get("safety_interlock_state") not in {"not_applicable_simulation", "verified_local"}:
        errors.append("Safety interlock state is unknown or not verified")
    if not checkpoint.get("last_acknowledged_command_id") and checkpoint.get("completed_operations"):
        errors.append("Last acknowledged operation is missing from checkpoint")
    if checkpoint.get("protocol_version") is None:
        errors.append("Protocol version is missing")
    if errors:
        recommendation = "operator_intervention_required"
    elif execution_mode == "simulation":
        recommendation = "eligible_to_resume_simulation_after_review"
    else:
        recommendation = "eligible_for_computational_replay"
    return {
        "recoverable": not errors,
        "recommendation": recommendation,
        "blocking_reasons": errors,
        "checkpoint_fields_reviewed": sorted(checkpoint.keys()),
        "resume_authorized": False,
        "physical_execution_authorized": False,
    }
