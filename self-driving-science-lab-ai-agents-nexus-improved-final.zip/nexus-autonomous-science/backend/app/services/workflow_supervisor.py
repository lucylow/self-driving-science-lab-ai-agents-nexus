"""Persisted supervisor graphs with capability checks and explicit human gates."""
from __future__ import annotations
from uuid import uuid4
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.models.entities import Agent, Objective, WorkflowRunRecord
from app.services.agent_runtime import dispatch_task
from app.services.audit import record_event
from app.services.domain_registry import get_domain
from app.services.workflow_checkpoints import append_checkpoint

WORKFLOW_PLANS = {
    "sdl1_candidate_review": [
        {"node": "objective_context", "agent_name": "Objective Compiler", "task_type": "compile_objective", "capability": "objective_parsing"},
        {"node": "composition_review", "agent_name": "Composition Validator", "task_type": "validate_composition", "capability": "composition_validation"},
        {"node": "candidate_ranking", "agent_name": "Materials Candidate Ranker", "task_type": "rank_candidates", "capability": "multiobjective_optimization"},
        {"node": "evidence_review", "agent_name": "Research Intelligence", "task_type": "inspect_evidence", "capability": "evidence_extraction"},
        {"node": "governance_summary", "agent_name": "Scientific Reviewer", "task_type": "review_claims", "capability": "claim_review"},
    ],
    "cross_lab_evidence_review": [
        {"node": "source_evidence", "agent_name": "Research Intelligence", "task_type": "inspect_evidence", "capability": "evidence_extraction"},
        {"node": "data_quality", "agent_name": "Data Quality Assessor", "task_type": "review_data_quality", "capability": "data_quality"},
    ],
    "dataset_quality_review": [
        {"node": "dataset_validation", "agent_name": "Data Quality Assessor", "task_type": "review_data_quality", "capability": "data_quality"},
        {"node": "provenance_review", "agent_name": "Research Intelligence", "task_type": "inspect_evidence", "capability": "evidence_extraction"},
    ],
}


def start_workflow(db: Session, *, workflow_key: str, laboratory_code: str,
                   objective_id: str | None, subject_id: str | None,
                   context: dict, synthetic: bool = True) -> WorkflowRunRecord:
    plan = WORKFLOW_PLANS.get(workflow_key)
    if not plan:
        raise ValueError("Unknown workflow key")
    domain = get_domain(laboratory_code)
    if objective_id and not db.get(Objective, objective_id):
        raise ValueError("Objective does not exist")
    if workflow_key == "sdl1_candidate_review" and laboratory_code != "SDL1":
        raise ValueError("sdl1_candidate_review can only run within SDL1")
    run = WorkflowRunRecord(
        id=str(uuid4()), workflow_key=workflow_key, laboratory_code=laboratory_code,
        objective_id=objective_id, status="running", current_node="starting",
        state_json={"domain": domain["domain"], "subject_id": subject_id, "context": context,
                    "physical_execution": False, "synthetic": synthetic},
        node_history=[], error_summary="", correlation_id=str(uuid4()), synthetic=synthetic,
    )
    db.add(run)
    db.flush()
    history: list[dict] = []
    append_checkpoint(
        db, workflow=run, checkpoint_key="workflow_started", node_id="starting",
        node_status="created", state_snapshot=run.state_json,
        output_snapshot={"workflow_key": workflow_key, "laboratory_code": laboratory_code},
        idempotency_key=f"{run.id}:workflow:started", physical_side_effects=False,
    )
    # Commit the run and its initial checkpoint before invoking any agent. A crashed
    # worker can therefore be diagnosed without relying on process-local memory.
    db.commit()
    try:
        for spec in plan:
            run.current_node = spec["node"]
            agent = db.scalar(select(Agent).where(
                Agent.laboratory_code == laboratory_code,
                Agent.name == spec["agent_name"],
            ))
            if agent is None:
                # Shared SDL0 capabilities may be used as an analytical service, never as authority.
                agent = db.scalar(select(Agent).where(Agent.laboratory_code == "SDL0", Agent.name == spec["agent_name"]))
            if not agent:
                raise ValueError(f"Required specialist '{spec['agent_name']}' is not registered")
            if spec["capability"] not in agent.capabilities:
                raise ValueError(f"Agent '{agent.name}' does not advertise required capability '{spec['capability']}'")
            run_record = dispatch_task(
                db, agent=agent, task_type=spec["task_type"],
                input_contract={"objective_id": objective_id, "subject_id": subject_id,
                                "laboratory_code": laboratory_code, "domain": domain["domain"],
                                "context_keys": sorted(context.keys())},
                correlation_id=run.correlation_id,
            )
            history.append({"node": spec["node"], "agent_id": agent.id,
                            "agent_run_id": run_record.id, "status": run_record.status,
                            "output": run_record.output_contract})
            run.node_history = history
            run.state_json = {**run.state_json, "last_completed_node": spec["node"],
                              "completed_node_count": len(history)}
            append_checkpoint(
                db, workflow=run, checkpoint_key=f"node_completed:{spec['node']}",
                node_id=spec["node"], node_status="completed",
                state_snapshot={**run.state_json, "node_history": history},
                output_snapshot=run_record.output_contract,
                idempotency_key=f"{run.id}:node:{spec['node']}:completed",
                physical_side_effects=False,
            )
            # Each completed analytical node is a durable recovery boundary.
            db.commit()
        run.current_node = "awaiting_scientist_review"
        run.status = "awaiting_scientist_review"
        run.state_json = {**run.state_json,
                          "summary": "Analytical workflow nodes completed; this workflow has not authorized or executed an experiment.",
                          "human_review_required": True,
                          "physical_execution_authorized": False}
        append_checkpoint(
            db, workflow=run, checkpoint_key="workflow_review_ready",
            node_id="awaiting_scientist_review", node_status="awaiting_scientist_review",
            state_snapshot={**run.state_json, "node_history": history},
            output_snapshot={"node_count": len(history), "human_review_required": True},
            idempotency_key=f"{run.id}:workflow:review-ready", physical_side_effects=False,
        )
        record_event(db, "WORKFLOW_REVIEW_READY", "workflow", run.id, actor="nexus-supervisor",
                     payload={"workflow_key": workflow_key, "node_count": len(history), "synthetic": synthetic},
                     correlation_id=run.correlation_id)
    except Exception as exc:
        run.status = "failed"
        run.error_summary = str(exc)[:2000]
        run.node_history = history
        append_checkpoint(
            db, workflow=run, checkpoint_key="workflow_failed", node_id=run.current_node,
            node_status="failed", state_snapshot={**run.state_json, "node_history": history},
            output_snapshot={"error": run.error_summary},
            idempotency_key=f"{run.id}:workflow:failed:{len(history)}",
            physical_side_effects=False,
        )
        record_event(db, "WORKFLOW_FAILED", "workflow", run.id, actor="nexus-supervisor",
                     payload={"error": run.error_summary}, correlation_id=run.correlation_id)
    db.flush()
    return run


def serialize_workflow(run: WorkflowRunRecord) -> dict:
    return {"id": run.id, "workflow_key": run.workflow_key,
            "laboratory_code": run.laboratory_code, "objective_id": run.objective_id,
            "status": run.status, "current_node": run.current_node,
            "state": run.state_json, "node_history": run.node_history,
            "error_summary": run.error_summary, "correlation_id": run.correlation_id,
            "synthetic": run.synthetic, "created_at": run.created_at,
            "updated_at": run.updated_at}
