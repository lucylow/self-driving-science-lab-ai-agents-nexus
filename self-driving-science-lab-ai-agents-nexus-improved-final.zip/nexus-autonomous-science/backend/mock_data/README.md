# Generated mock data

Run `python scripts/generate_mock_data.py --seed 42 --scale large` from the backend directory to create one JSON file per category here. Run `python scripts/validate_mock_data.py` to verify required exports, references, timestamps, and synthetic provenance. These are fictional test/demo records, not scientific evidence.
