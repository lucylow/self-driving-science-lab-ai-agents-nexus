#!/usr/bin/env python3
"""Generate independently stored, reproducible synthetic research records."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

BACKEND = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND))
from app.services.synthetic_research import DEFAULT_COUNTS, generate_research_universe

SCALES = {
    "demo": {"projects": 15, "objectives": 45, "hypotheses": 75, "experiments": 150, "executions": 300, "observations": 400, "models": 30, "benchmarks": 12, "evaluations": 200, "agents": 15, "agent_activities": 200, "compute_jobs": 200, "compute_resources": 40, "findings": 75, "insights": 60, "references": 30, "datasets": 20, "dataset_versions": 40, "iterations": 80, "decisions": 100, "failures": 30, "reports": 15},
    "small": None,
    "medium": None,
    "large": DEFAULT_COUNTS,
}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--scale", choices=tuple(SCALES), default="large")
    parser.add_argument("--output", type=Path, default=BACKEND / "mock_data" / "generated")
    args = parser.parse_args()
    if args.scale in {"small", "medium"}:
        factor = 0.15 if args.scale == "small" else 0.5
        counts = {key: max(1, round(value * factor)) for key, value in DEFAULT_COUNTS.items()}
        counts["programs"] = 15
    else:
        counts = SCALES[args.scale]
    dataset = generate_research_universe(args.seed, counts)
    args.output.mkdir(parents=True, exist_ok=True)
    for category, records in dataset.items():
        path = args.output / f"{category}.json"
        path.write_text(json.dumps(records, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"Generated {dataset['metadata']['total_records']:,} synthetic records ({args.scale}, seed={args.seed}) at {args.output}")


if __name__ == "__main__":
    main()
