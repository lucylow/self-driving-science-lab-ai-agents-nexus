#!/usr/bin/env python3
"""Remove generated demo fixtures only; never deletes outside backend/mock_data."""
from __future__ import annotations

import argparse
from pathlib import Path
import shutil

BACKEND = Path(__file__).resolve().parents[1]
MOCK_ROOT = (BACKEND / "mock_data").resolve()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=MOCK_ROOT / "generated")
    parser.add_argument("--confirm", action="store_true", help="confirm deletion of the selected generated-data directory")
    args = parser.parse_args()
    target = args.output.resolve()
    if target == MOCK_ROOT or MOCK_ROOT not in target.parents:
        parser.error(f"Output must be a child of {MOCK_ROOT}")
    if not args.confirm:
        parser.error("Refusing to delete files without --confirm")
    if target.exists():
        shutil.rmtree(target)
    target.mkdir(parents=True)
    print(f"Cleared generated synthetic files at {target}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
