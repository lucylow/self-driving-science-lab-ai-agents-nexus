#!/usr/bin/env python3
"""Validate a directory of JSON files produced by generate_mock_data.py."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

BACKEND = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND))
from app.services.synthetic_research import DEFAULT_COUNTS, validate_research_universe


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("path", type=Path, nargs="?", default=BACKEND / "mock_data" / "generated")
    args = parser.parse_args()
    data = {}
    for category in (*DEFAULT_COUNTS.keys(), "metadata"):
        path = args.path / f"{category}.json"
        if not path.is_file():
            print(f"Missing required file: {path}", file=sys.stderr)
            return 1
        try:
            data[category] = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            print(f"Could not read {path}: {exc}", file=sys.stderr)
            return 1
    errors = validate_research_universe(data)
    if errors:
        print("Synthetic dataset validation failed:")
        for error in errors[:50]:
            print(f"- {error}")
        return 1
    print(f"Validated {data['metadata'].get('total_records', 0):,} synthetic records; all checked relationships are valid.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
