import pytest
from app.services.advanced_research.value_of_information import expected_value_of_sample_information, stopping_decision
from app.services.advanced_research.multi_fidelity import fit_fidelity_bridge, correct_low_fidelity, rank_multi_fidelity
from app.services.advanced_research.bayesian_evidence import update_hypothesis_probability
from app.services.advanced_research.replication_planning import estimate_replicates_for_mean_precision, replicate_summary
from app.services.advanced_research.sensitivity_analysis import finite_difference_sensitivity, one_at_a_time_scenarios
from app.services.advanced_research.protocol_diff import compare_protocol_versions, protocol_compatibility
from app.services.advanced_research.lab_capacity import capacity_preview


def test_value_of_information_accounts_for_cost():
    result = expected_value_of_sample_information(current_best_utility=1,
        posterior_best_utilities=[2, 3, 2.5], experiment_cost=.2)
    assert result["net_expected_value"] > 0
    expensive = expected_value_of_sample_information(current_best_utility=1,
        posterior_best_utilities=[2, 3, 2.5], experiment_cost=10)
    assert expensive["recommendation"] == "defer_or_reformulate"


def test_stopping_policy_does_not_claim_automatic_termination():
    result = stopping_decision(remaining_budget=0, minimum_budget=1,
        best_recent_improvement=0, improvement_tolerance=.01,
        uncertainty_reduction_possible=False, unresolved_hard_constraints=["toxicity"],
        minimum_evidence_grade_met=False)
    assert result["is_automatic_terminal_decision"] is False
    assert len(result["reasons"]) >= 3


def test_multi_fidelity_bridge():
    paired = [{"low_fidelity": i, "high_fidelity": 2 + 1.5 * i, "group_id": str(i)} for i in range(10)]
    bridge = fit_fidelity_bridge(paired)
    assert abs(bridge["slope"] - 1.5) < 1e-9
    inside = correct_low_fidelity(5, bridge)
    outside = correct_low_fidelity(50, bridge)
    assert inside["extrapolation"] is False
    assert outside["extrapolation"] is True


def test_multi_fidelity_budget_flag():
    result = rank_multi_fidelity([{"candidate_id": "A", "corrected_mean": 3, "corrected_sd": .3}],
                                 best_observed=2, high_fidelity_budget=1)
    assert result["ranked_candidates"][0]["recommend_high_fidelity_check"] is True


def test_bayesian_update_preserves_evidence_refs_and_warning():
    result = update_hypothesis_probability(.3, [{"evidence_ref": "MEAS-1", "likelihood_ratio": 4}])
    assert result["posterior_probability"] > .3
    assert "dependent evidence" in result["warning"]


def test_bayesian_update_rejects_bad_likelihood_ratio():
    with pytest.raises(ValueError):
        update_hypothesis_probability(.5, [{"evidence_ref": "X", "likelihood_ratio": 0}])


def test_replication_estimation_and_summary():
    estimate = estimate_replicates_for_mean_precision(pilot_standard_deviation=2, desired_half_width=1)
    summary = replicate_summary([1, 2, 3, 4])
    assert estimate["estimated_replicates"] >= 16
    assert summary["replicate_count"] == 4


def test_sensitivity_finite_difference_for_linear_model():
    result = finite_difference_sensitivity(parameters={"a": 2, "b": 3},
        evaluator=lambda x: 5 * x["a"] + 2 * x["b"])
    assert abs(result["local_derivatives"]["a"] - 5) < 1e-6
    assert result["sensitivity_order"][0] == "a"


def test_one_at_a_time_requires_full_ranges():
    with pytest.raises(ValueError):
        one_at_a_time_scenarios(parameters={"a": 1}, ranges={}, evaluator=lambda x: x["a"])


def test_protocol_diff_marks_revalidation():
    previous = {"protocol_id": "P", "version": "1.0", "steps": [{"step_id": "a", "duration": 2}]}
    current = {"protocol_id": "P", "version": "1.1", "steps": [{"step_id": "a", "duration": 3}, {"step_id": "b"}]}
    result = compare_protocol_versions(previous, current)
    assert result["requires_scientific_revalidation"] is True
    assert result["added_steps"] == ["b"]


def test_protocol_compatibility_checks_capabilities():
    result = protocol_compatibility({"domain": "materials", "supported_sample_types": ["powder"],
        "required_capabilities": ["xrd"]}, domain="materials", sample_types=["powder"], instrument_capabilities=[])
    assert result["compatible"] is False
    assert result["missing_instrument_capabilities"] == ["xrd"]


def test_capacity_preview_reports_unscheduled_tasks():
    result = capacity_preview(resources=[{"resource_id": "R1", "capabilities": ["xrd"]}],
        tasks=[{"task_id": "T1", "duration_minutes": 30, "required_capabilities": ["xrd"]},
               {"task_id": "T2", "duration_minutes": 20, "required_capabilities": ["microscopy"]}])
    assert len(result["schedule"]) == 1
    assert result["unscheduled"][0]["task_id"] == "T2"
    assert result["reservations_created"] is False
