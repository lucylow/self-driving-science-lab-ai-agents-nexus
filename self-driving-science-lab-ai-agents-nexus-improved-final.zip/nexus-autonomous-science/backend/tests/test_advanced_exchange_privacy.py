import pytest
from app.services.advanced_research.multi_lab_exchange import create_exchange_envelope, verify_exchange_envelope
from app.services.advanced_research.federated_aggregation import PrivacyBudget, aggregate_lab_statistics


def envelope():
    return create_exchange_envelope(source_laboratory="SDL1", target_laboratory="SDL7",
        subject_type="dataset", subject_id="DATA-1", domain="inorganic_materials",
        schema_version="1.0.0", payload={"provenance_refs": ["EXP-1"], "mean": 1.5,
        "operator_email": "remove@example.invalid", "features": [1, 2]},
        evidence_origin="computational_result", synthetic=False,
        shared_secret="test-secret", allowed_fields=["provenance_refs", "mean", "features"])


def test_envelope_redaction_signature_and_digest():
    result = envelope()
    assert "operator_email" not in result["payload"]
    assert verify_exchange_envelope(result, shared_secret="test-secret")["status"] == "integrity_verified_review_required"


def test_envelope_detects_tampering():
    result = envelope()
    result["payload"]["mean"] = 99
    verified = verify_exchange_envelope(result, shared_secret="test-secret")
    assert verified["digest_valid"] is False


def test_envelope_blocks_wrong_signature():
    assert verify_exchange_envelope(envelope(), shared_secret="wrong")["status"] == "blocked_signature_missing_or_invalid"


def test_exchange_requires_distinct_labs_and_synthetic_label():
    with pytest.raises(ValueError):
        create_exchange_envelope(source_laboratory="SDL1", target_laboratory="SDL1",
            subject_type="sample", subject_id="S-1", domain="x", schema_version="1",
            payload={}, evidence_origin="measured_value", synthetic=False)
    with pytest.raises(ValueError):
        create_exchange_envelope(source_laboratory="SDL1", target_laboratory="SDL2",
            subject_type="sample", subject_id="S-1", domain="x", schema_version="1",
            payload={}, evidence_origin="synthetic_simulation", synthetic=False)


def contributions():
    return [{"laboratory_code": f"SDL{i}", "record_count": 20,
             "means": {"x": float(i), "y": float(2 * i)}} for i in range(1, 4)]


def test_federated_aggregate_suppresses_small_cohort():
    result = aggregate_lab_statistics(contributions()[:2], feature_names=["x", "y"], minimum_labs=3)
    assert result["status"] == "suppressed_small_cohort"


def test_federated_aggregate_clips_and_does_not_send_raw_rows():
    result = aggregate_lab_statistics(contributions(), feature_names=["x", "y"], clip_norm=5)
    assert result["status"] == "aggregate_created"
    assert result["raw_records_transmitted"] is False


def test_gaussian_release_spends_budget():
    budget = PrivacyBudget(3, .01)
    result = aggregate_lab_statistics(contributions(), feature_names=["x", "y"],
        add_gaussian_noise=True, epsilon=1, delta=.001, budget=budget, random_seed=2)
    assert result["noise_added"] is True
    assert budget.release_count == 1


def test_privacy_budget_rejects_overrun():
    budget = PrivacyBudget(1, .001)
    with pytest.raises(ValueError):
        aggregate_lab_statistics(contributions(), feature_names=["x", "y"],
            add_gaussian_noise=True, epsilon=2, delta=.001, budget=budget)


def test_exchange_redacts_sensitive_keys_recursively_before_signing():
    result = create_exchange_envelope(
        source_laboratory="SDL1", target_laboratory="SDL7", subject_type="dataset",
        subject_id="DATA-2", domain="inorganic_materials", schema_version="1.0.0",
        payload={
            "summary": {"mean": 2.4, "patient_id": "hidden-patient", "contact": {"operator_email": "hidden@example.invalid", "safe_label": "kept"}},
            "observations": [{"value": 2.1, "accession_number": "hidden-accession"}, {"value": 2.7, "api_key": "hidden-token"}],
            "private_secret": "hidden-secret",
        }, evidence_origin="measured_value", synthetic=False, shared_secret="test-secret",
        allowed_fields=["summary", "observations", "private_secret"],
    )
    payload = result["payload"]
    assert payload["summary"] == {"mean": 2.4, "contact": {"safe_label": "kept"}}
    assert payload["observations"] == [{"value": 2.1}, {"value": 2.7}]
    assert "private_secret" not in payload
    assert verify_exchange_envelope(result, shared_secret="test-secret")["status"] == "integrity_verified_review_required"

def test_federated_aggregation_requires_integral_positive_record_counts():
    from app.services.advanced_research.federated_aggregation import aggregate_lab_statistics

    rows = contributions()
    for malformed in (20.9, True, "20", float("nan"), float("inf")):
        invalid = [dict(row) for row in rows]
        invalid[0]["record_count"] = malformed
        with pytest.raises(ValueError, match="positive integer record_count"):
            aggregate_lab_statistics(invalid, feature_names=["x", "y"], minimum_labs=3)

    valid = [dict(row) for row in contributions()]
    for row, count in zip(valid, [10, 20.0, 30]):
        row["record_count"] = count
    result = aggregate_lab_statistics(valid, feature_names=["x", "y"], minimum_labs=3)
    assert result["record_count"] == 60
    assert result["aggregate_means"]["x"] == pytest.approx((1 * 10 + 2 * 20 + 3 * 30) / 60)


def test_malformed_counts_are_rejected_even_when_cohort_would_be_suppressed():
    from app.services.advanced_research.federated_aggregation import aggregate_lab_statistics

    rows = contributions()[:2]
    rows[0]["record_count"] = 3.5
    with pytest.raises(ValueError, match="positive integer record_count"):
        aggregate_lab_statistics(rows, feature_names=["x", "y"], minimum_labs=3)
