from uuid import uuid4
from fastapi.testclient import TestClient
from app.main import app


def _calibration_rows(n=24):
    rows = []
    for i in range(n):
        x = i / 3
        z = 250 + (i * i) / 7
        rows.append({"features": {"x": x, "temperature": z},
                     "observed": 1.2 + 2.3 * x - .002 * z,
                     "measurement_sigma": .05, "group_id": f"sample-{i // 2}"})
    return rows


def test_twin_calibration_persists_and_validates():
    with TestClient(app) as client:
        created = client.post("/api/advanced-research/digital-twins/calibrations", json={
            "model_id": f"twin-{uuid4().hex[:6]}", "domain": "inorganic_materials",
            "feature_names": ["x", "temperature"], "records": _calibration_rows()})
        assert created.status_code == 201, created.text
        row = created.json()
        validation = client.post(f"/api/advanced-research/digital-twins/calibrations/{row['id']}/validate", json={
            "validation_domain": "inorganic_materials", "records": _calibration_rows(10)})
        assert validation.status_code == 200, validation.text
        assert validation.json()["validation"]["valid_for_domain"] is True
        prediction = client.post(f"/api/advanced-research/digital-twins/calibrations/{row['id']}/predict", json={
            "features": {"x": 1.2, "temperature": 280}})
        assert prediction.status_code == 200
        assert prediction.json()["evidence_type"] == "model_prediction"


def test_sequential_design_and_uncertainty_api():
    with TestClient(app) as client:
        design = client.post("/api/advanced-research/sequential-design/propose", json={
            "candidates": [
                {"candidate_id": "C1", "parameters": {"temperature": 300}, "prediction_mean": 2.0, "prediction_std": .3, "family": "A"},
                {"candidate_id": "C2", "parameters": {"temperature": 320}, "prediction_mean": 2.3, "prediction_std": .2, "family": "B"}],
            "feature_names": ["temperature"], "best_observed": 1.7,
            "batch_size": 2, "feature_ranges": {"temperature": [280, 350]}})
        assert design.status_code == 200, design.text
        assert len(design.json()["proposal"]["selected"]) == 2
        uncertainty = client.post("/api/advanced-research/uncertainty/linear-propagation", json={
            "means": {"a": 2, "b": 4}, "standard_deviations": {"a": .2, "b": .4},
            "coefficients": {"a": 2, "b": .5}, "samples": 1000})
        assert uncertainty.status_code == 200, uncertainty.text
        assert uncertainty.json()["method"] == "monte_carlo"


def test_privacy_ledger_and_private_aggregate_budget_are_persistent():
    with TestClient(app) as client:
        key = f"ledger-{uuid4().hex[:8]}"
        create = client.post("/api/advanced-research/privacy-ledgers", json={
            "ledger_key": key, "epsilon_limit": 1.0, "delta_limit": .001})
        assert create.status_code == 201, create.text
        preflight = client.post(f"/api/advanced-research/privacy-ledgers/{key}/preflight", json={
            "epsilon": .4, "delta": .0001})
        assert preflight.status_code == 200 and preflight.json()["allowed"]
        contributions = [{"laboratory_code": f"SDL{i}", "record_count": 20,
                          "means": {"x": float(i), "y": float(i * 2)}} for i in range(3)]
        body = {"contributions": contributions, "feature_names": ["x", "y"],
                "minimum_labs": 3, "minimum_total_records": 30, "clip_norm": 10,
                "ledger_key": key, "epsilon": .4, "delta": .0001,
                "release_key": f"release-{uuid4().hex[:8]}"}
        release = client.post("/api/advanced-research/federated/aggregate-private", json=body)
        assert release.status_code == 200, release.text
        assert release.json()["aggregate"]["noise_added"] is True
        ledger = client.get(f"/api/advanced-research/privacy-ledgers/{key}")
        assert ledger.json()["epsilon_spent"] == .4
        duplicate = client.post("/api/advanced-research/federated/aggregate-private", json=body)
        assert duplicate.status_code == 409


def test_exchange_envelope_endpoint_redacts_and_logs():
    with TestClient(app) as client:
        response = client.post("/api/advanced-research/cross-lab/exchange-envelope", json={
            "source_laboratory": "SDL1", "target_laboratory": "SDL7",
            "subject_type": "dataset", "subject_id": "DATA-TEST-1",
            "domain": "inorganic_materials", "payload": {
                "provenance_refs": ["EXP-1"], "operator_email": "private@example.invalid", "mean": 1.4},
            "evidence_origin": "computational_result", "synthetic": False,
            "shared_secret": "integration-secret"})
        assert response.status_code == 201, response.text
        envelope = response.json()["envelope"]
        assert "operator_email" not in envelope["payload"]
        verification = client.post("/api/advanced-research/cross-lab/verify-envelope", json={
            "envelope": envelope, "shared_secret": "integration-secret"})
        assert verification.status_code == 200
        assert verification.json()["status"] == "integrity_verified_review_required"


def test_simulation_endpoint_is_explicitly_synthetic():
    with TestClient(app) as client:
        response = client.post("/api/advanced-research/simulation/battery", json={
            "parameters": {"capacity_ah": 3, "initial_soc": .95, "current_a": 1,
                           "internal_resistance_ohm": .04, "nominal_voltage_v": 3.7,
                           "duration_seconds": 3600, "time_step_seconds": 60}})
        assert response.status_code == 200, response.text
        assert response.json()["synthetic"] is True
        assert response.json()["physical_control_authorized"] is False
