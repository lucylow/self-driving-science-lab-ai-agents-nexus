import pytest
from app.services.advanced_research.sequential_design import (
    acquisition_score, propose_sequential_batch, pareto_front,
)


def sample_candidates():
    return [
        {"candidate_id": "A", "parameters": {"temperature": 300, "dopant": .1}, "prediction_mean": 2.1, "prediction_std": .3, "estimated_cost": 2, "family": "argyrodite"},
        {"candidate_id": "B", "parameters": {"temperature": 320, "dopant": .2}, "prediction_mean": 2.4, "prediction_std": .2, "estimated_cost": 1, "family": "garnet"},
        {"candidate_id": "C", "parameters": {"temperature": 340, "dopant": .3}, "prediction_mean": 2.6, "prediction_std": .4, "estimated_cost": 3, "family": "argyrodite"},
        {"candidate_id": "D", "parameters": {"temperature": 360, "dopant": .4}, "prediction_mean": 1.8, "prediction_std": .7, "estimated_cost": 1, "family": "nasicon"},
    ]


def test_ei_direction_and_cost_are_applied():
    high = acquisition_score(2, .3, 1, direction="maximize", strategy="expected_improvement", cost=1)
    low = acquisition_score(2, .3, 1, direction="minimize", strategy="expected_improvement", cost=1)
    assert high > low


def test_batch_respects_constraints_and_family_cap():
    result = propose_sequential_batch(sample_candidates(), feature_names=["temperature", "dopant"],
        best_observed=2.0, batch_size=3, constraints=[{"parameter": "temperature", "maximum": 350}],
        max_per_family=1)
    ids = [row["candidate_id"] for row in result["selected"]]
    families = [row["family"] for row in result["selected"]]
    assert "D" not in ids
    assert len(families) == len(set(families))
    assert result["execution_authorized"] is False


def test_batch_diversity_is_visible():
    result = propose_sequential_batch(sample_candidates(), feature_names=["temperature", "dopant"],
        best_observed=1.5, batch_size=3, diversity_weight=.2)
    assert all("diversity_bonus" in row for row in result["selected"])


def test_duplicate_candidate_ids_rejected():
    rows = sample_candidates()
    rows[1]["candidate_id"] = "A"
    with pytest.raises(ValueError):
        propose_sequential_batch(rows, feature_names=["temperature", "dopant"], best_observed=1, batch_size=2)


def test_pareto_front_preserves_tradeoffs():
    front = pareto_front([{"id": "a", "conductivity": 2, "cost": 5},
                          {"id": "b", "conductivity": 3, "cost": 7},
                          {"id": "c", "conductivity": 1, "cost": 8}],
                         [{"property": "conductivity", "direction": "maximize"},
                          {"property": "cost", "direction": "minimize"}])
    assert {row["id"] for row in front} == {"a", "b"}


def test_invalid_acquisition_rejected():
    with pytest.raises(ValueError):
        acquisition_score(1, 1, 0, direction="sideways")
