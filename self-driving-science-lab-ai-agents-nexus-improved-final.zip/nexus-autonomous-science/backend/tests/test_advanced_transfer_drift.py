import pytest
from app.services.advanced_research.model_transfer import evaluate_model_transfer, transfer_learning_plan
from app.services.advanced_research.drift_monitoring import ewma, cusum, residual_monitor, compare_feature_windows
from app.services.advanced_research.digital_twin_ensemble import combine_twin_predictions


def test_transfer_requires_domain_and_holdout_validation():
    card = {"model_id": "M1", "supported_domains": ["inorganic_materials"]}
    source = {"domain": "inorganic_materials", "measurement_method": "EIS", "unit_system": "SI",
              "feature_distributions": {"temperature": [290, 295, 300, 305]}}
    target = {"domain": "inorganic_materials", "measurement_method": "EIS", "unit_system": "SI",
              "feature_distributions": {"temperature": [291, 296, 299, 304]}}
    result = evaluate_model_transfer(model_card=card, source_context=source, target_context=target,
        source_validation={"valid_for_domain": True},
        target_holdout_metrics={"n": 20, "scientist_reviewed": True, "status": "accepted_for_research"})
    assert result["recommendation"] == "eligible_for_target_lab_review"
    assert result["model_training_authorized"] is False


def test_transfer_flags_feature_shift_and_method_mismatch():
    card = {"model_id": "M1", "supported_domains": ["polymers"]}
    source = {"domain": "polymers", "measurement_method": "DMA", "unit_system": "SI",
              "feature_distributions": {"temperature": [20, 21, 19, 20]}}
    target = {"domain": "polymers", "measurement_method": "DSC", "unit_system": "SI",
              "feature_distributions": {"temperature": [80, 82, 84, 79]}}
    result = evaluate_model_transfer(model_card=card, source_context=source, target_context=target)
    assert result["checks"]["method_compatible"] is False
    assert result["large_shift_features"] == ["temperature"]


def test_transfer_plan_requests_target_data():
    result = transfer_learning_plan(source_model_id="M1", target_domain="organoids", target_rows=4, target_labs=1)
    assert result["recommended_route"] == "collect_target_domain_validation_data"


def test_ewma_and_cusum_detect_shift():
    path = ewma([0, 0, 0, 5, 5, 5], smoothing=.5)
    signal = cusum([0, 0, 5, 5, 5], allowance=.2, decision_interval=1)
    assert path["path"][-1] > 3
    assert signal["drift_detected"] is True


def test_residual_monitor_requires_minimum_and_flags_signal():
    result = residual_monitor([0, .1, 0, -.1, .1, 5, 5, 5], baseline_sd=1, cusum_threshold=2)
    assert result["drift_status"] == "signal_detected_review_required"
    with pytest.raises(ValueError):
        residual_monitor([1, 2])


def test_feature_shift_comparison():
    result = compare_feature_windows({"x": [0, 0, .1, -.1]}, {"x": [5, 5.2, 4.8, 5.1]})
    assert result["flagged_features"] == ["x"]


def test_twin_ensemble_preserves_disagreement():
    result = combine_twin_predictions([
        {"model_id": "A", "domain": "battery", "mean": 1, "standard_deviation": .1},
        {"model_id": "B", "domain": "battery", "mean": 3, "standard_deviation": .1}], disagreement_threshold=2)
    assert result["status"] == "model_disagreement_review"


def test_twin_ensemble_blocks_domain_mismatch():
    result = combine_twin_predictions([
        {"model_id": "A", "domain": "battery", "mean": 1, "standard_deviation": .1},
        {"model_id": "B", "domain": "polymer", "mean": 3, "standard_deviation": .1}])
    assert result["status"] == "blocked_domain_mismatch"
