import pytest
from app.services.advanced_research.twin_calibration import (
    fit_affine_calibrator, predict_calibrated, validate_calibrator, group_holdout_split,
)


def records(n=24):
    return [{"features": {"raw": i / 2, "temperature": 280 + (i * i) / 10},
             "observed": 2.5 + 1.8 * (i / 2) - .01 * (280 + (i * i) / 10),
             "measurement_sigma": .1, "group_id": f"sample-{i // 2}"} for i in range(n)]


def test_weighted_calibration_recovers_linear_mapping():
    fit = fit_affine_calibrator(records(), feature_names=["raw", "temperature"], domain="inorganic_materials")
    assert abs(fit["coefficients"]["raw"] - 1.8) < 1e-8
    assert abs(fit["coefficients"]["temperature"] + .01) < 1e-8
    assert fit["training_group_count"] == 12
    assert fit["physical_control_authorized"] is False


def test_calibrated_prediction_flags_extrapolation():
    fit = fit_affine_calibrator(records(), feature_names=["raw", "temperature"])
    result = predict_calibrated(fit, {"raw": 999, "temperature": 280})
    assert "raw" in result["outside_calibration_feature_ranges"]
    assert result["evidence_type"] == "model_prediction"


def test_validation_is_domain_scoped():
    fit = fit_affine_calibrator(records(), feature_names=["raw", "temperature"], domain="inorganic_materials")
    result = validate_calibrator(fit, records(10), validation_domain="polymers")
    assert result["status"] == "blocked_domain_mismatch"


def test_group_holdout_never_splits_group():
    split = group_holdout_split(records(), holdout_fraction=.25)
    assert split["group_overlap"] is False
    train_groups = {row["group_id"] for row in split["train"]}
    test_groups = {row["group_id"] for row in split["test"]}
    assert train_groups.isdisjoint(test_groups)


def test_calibration_rejects_underdetermined_and_bad_values():
    with pytest.raises(ValueError):
        fit_affine_calibrator(records(3), feature_names=["raw", "temperature"])
    bad = records()
    bad[0]["observed"] = float("nan")
    with pytest.raises(ValueError):
        fit_affine_calibrator(bad, feature_names=["raw", "temperature"])


def test_calibration_requires_features():
    fit = fit_affine_calibrator(records(), feature_names=["raw", "temperature"])
    with pytest.raises(ValueError):
        predict_calibrated(fit, {"raw": .2})
