import pytest
from app.services.advanced_research.uncertainty_propagation import (
    cholesky, propagate_monte_carlo, split_conformal_radius, apply_conformal_interval,
    decompose_uncertainty,
)


def test_cholesky_rejects_non_psd():
    with pytest.raises(ValueError):
        cholesky([[1, 2], [2, 1]])


def test_monte_carlo_linear_mean_is_stable():
    result = propagate_monte_carlo(means={"x": 2, "y": 3}, standard_deviations={"x": .2, "y": .3},
        evaluator=lambda d: 2 * d["x"] + d["y"], samples=10000, seed=7)
    assert abs(result["mean"] - 7) < .03
    assert result["lower_quantile"] < result["upper_quantile"]


def test_monte_carlo_uses_correlation():
    result = propagate_monte_carlo(means={"x": 0, "y": 0}, standard_deviations={"x": 1, "y": 1},
        evaluator=lambda d: d["x"] + d["y"], correlation=[[1, .9], [.9, 1]], samples=10000, seed=3)
    independent = propagate_monte_carlo(means={"x": 0, "y": 0}, standard_deviations={"x": 1, "y": 1},
        evaluator=lambda d: d["x"] + d["y"], samples=10000, seed=3)
    assert result["standard_deviation"] > independent["standard_deviation"]


def test_conformal_radius_and_intervals():
    actual = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    predicted = [x + .2 for x in actual]
    calibration = split_conformal_radius(actual, predicted, alpha=.1)
    intervals = apply_conformal_interval([12, 13], calibration)
    assert intervals[0]["lower"] <= 12 <= intervals[0]["upper"]


def test_conformal_requires_groups_when_supplied():
    with pytest.raises(ValueError):
        split_conformal_radius([1, 2, 3, 4, 5], [1, 2, 3, 4, 5], group_ids=["a"] * 5)


def test_uncertainty_decomposition_validates_and_ranks():
    result = decompose_uncertainty(aleatoric=1, epistemic=2, calibration=.5, distribution_shift=3)
    assert result["dominant_component"] == "distribution_shift"
    with pytest.raises(ValueError):
        decompose_uncertainty(aleatoric=-1, epistemic=0)


def test_monte_carlo_rejects_mismatched_inputs():
    with pytest.raises(ValueError):
        propagate_monte_carlo(means={"x": 1}, standard_deviations={"y": 1}, evaluator=lambda x: 0)
