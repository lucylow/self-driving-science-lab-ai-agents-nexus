import pytest
from app.services.agent_evaluation import evaluate_agent, validate_metric_vector


def test_agent_evaluation_holds_for_low_sample_count():
    metrics = {
        "scientific_correctness": 0.93,
        "constraint_compliance": 0.94,
        "schema_compliance": 1.0,
        "evidence_attribution": 0.91,
        "out_of_domain_detection": 0.9,
    }
    result = evaluate_agent(agent_id="AG-001", benchmark_id="SDL0-BENCH-01", sample_count=10, metrics=metrics)
    assert result.promotion_recommendation == "hold_for_review"
    assert any("below the minimum" in note for note in result.limitations)


def test_agent_evaluation_only_recommends_shadow_review():
    metrics = {
        "scientific_correctness": 0.93,
        "constraint_compliance": 0.94,
        "schema_compliance": 1.0,
        "evidence_attribution": 0.91,
        "out_of_domain_detection": 0.9,
    }
    result = evaluate_agent(agent_id="AG-001", benchmark_id="SDL0-BENCH-01", sample_count=100, metrics=metrics)
    assert result.promotion_recommendation == "eligible_for_shadow_deployment_review"
    assert result.promotion_recommendation != "production"


def test_metric_values_are_bounded():
    assert validate_metric_vector({"scientific_correctness": 1.2})
    assert not validate_metric_vector({"scientific_correctness": 0.8})


def test_unknown_metrics_fail_evaluation():
    with pytest.raises(ValueError):
        evaluate_agent(agent_id="AG-1", benchmark_id="B-1", sample_count=50, metrics={"accuracy": 0.9})
