"""API-level contracts for the governed synthetic SDL1 discovery demonstration."""

from uuid import uuid4
from fastapi.testclient import TestClient
from app.main import app


def test_closed_loop_proposal_approval_and_simulated_measurements():
    with TestClient(app) as client:
        title = f"API integration proposal {uuid4().hex[:8]}"
        created = client.post("/api/experiments", json={
            "title": title,
            "laboratory_code": "SDL1",
            "objective_id": "OBJ-0001",
            "candidate_id": "MAT-00128",
            "protocol_id": "sdl1-screening-demo",
            "protocol_version": "0.1.0",
            "owner": "test-scientist",
            "estimated_duration_minutes": 30,
            "execution_mode": "simulation",
            "resource_requirements": {"instrument_ids": ["SDL1-XRD-001"]},
            "governance": {"approval_required": True, "physical_execution": False},
        })
        assert created.status_code == 200, created.text
        experiment_id = created.json()["id"]
        assert created.json()["status"] == "draft"

        requested = client.post(
            f"/api/governance/experiments/{experiment_id}/request-approval",
            json={"requested_by": "test-scientist", "reason": "Verify API workflow contract."},
        )
        assert requested.status_code == 200, requested.text
        approval_id = requested.json()["id"]
        assert requested.json()["status"] == "pending"

        decided = client.post(
            f"/api/governance/approvals/{approval_id}/decision",
            json={"decision": "approved", "reviewer": "test-reviewer", "note": "Approved for synthetic test only."},
        )
        assert decided.status_code == 200, decided.text
        assert decided.json()["experiment_status"] == "approved"

        simulated = client.post(f"/api/experiments/{experiment_id}/simulate")
        assert simulated.status_code == 200, simulated.text
        payload = simulated.json()
        assert payload["experiment"]["status"] == "completed"
        assert payload["result"]["evidence_type"] == "synthetic_simulation_output"
        assert payload["result"]["synthetic"] is True
        assert len(payload["result"]["measurements"]) >= 1


def test_physical_execution_mode_is_rejected_at_contract_boundary():
    with TestClient(app) as client:
        response = client.post("/api/experiments", json={
            "title": "Physical operation must not be accepted",
            "laboratory_code": "SDL1",
            "execution_mode": "physical",
        })
        assert response.status_code == 422


def test_cross_laboratory_candidate_link_is_rejected():
    with TestClient(app) as client:
        response = client.post("/api/experiments", json={
            "title": "Cross-lab candidate mismatch",
            "laboratory_code": "SDL4",
            "candidate_id": "MAT-00128",
            "execution_mode": "simulation",
        })
        assert response.status_code == 409


def test_new_science_routes_keep_evidence_and_evaluation_review_only():
    with TestClient(app) as client:
        domains = client.get("/api/science/domains")
        assert domains.status_code == 200
        assert len(domains.json()) == 8

        assessment = client.post("/api/science/evidence/assess", json={
            "evidence_id": "SYNTHETIC-API-RECORD",
            "origin": "independent_validation",
            "synthetic": True,
            "independent_validation_reference": "demo-ref",
        })
        assert assessment.status_code == 200
        assert assessment.json()["grade"] == "E0"
        assert assessment.json()["eligible_for_model_training"] is False

        evaluation = client.post("/api/agents/evaluations/preview", json={
            "agent_id": "AG-001",
            "benchmark_id": "SDL0-BASELINE",
            "sample_count": 100,
            "metrics": {
                "scientific_correctness": 0.92,
                "constraint_compliance": 0.91,
                "schema_compliance": 1.0,
                "evidence_attribution": 0.94,
                "out_of_domain_detection": 0.9,
            },
        })
        assert evaluation.status_code == 200
        assert evaluation.json()["production_promotion"] is False
