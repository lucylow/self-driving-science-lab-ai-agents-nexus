from datetime import datetime, timedelta, timezone
import pytest
from app.services.command_protocol import CommandEnvelope, check_idempotency, validate_command_envelope


def _envelope():
    return CommandEnvelope(
        command_id="CMD-1", idempotency_key="IDEM-1", experiment_id="EXP-1",
        instrument_id="INST-1", operation="status_check", protocol_version="1.0.0",
        authorization_ref="APPROVAL-1", expires_at=datetime.now(timezone.utc) + timedelta(minutes=5),
    )


def test_command_acknowledgement_transitions_are_ordered():
    item = _envelope()
    for state in ["received", "validated", "accepted", "completed"]:
        item.transition(state)
    assert item.acknowledgement == "completed"
    with pytest.raises(ValueError):
        item.transition("received")


def test_idempotency_detects_existing_command():
    item = _envelope()
    result = check_idempotency([item], "IDEM-1")
    assert result["duplicate"] is True
    assert result["existing_command_id"] == "CMD-1"


def test_command_requires_explicit_authorization_and_valid_expiry():
    item = _envelope()
    assert validate_command_envelope(item) == []
    item.authorization_ref = None
    assert any("authorization" in error.lower() for error in validate_command_envelope(item))
