from app.services.data_quality import assess_measurement


def test_synthetic_measurement_is_not_mislabeled_as_measured():
    result = assess_measurement({"value": 0.002, "unit": "S/cm", "sample_id": "SYN-01", "origin": "simulation"})
    assert result.status == "synthetic_or_derived"


def test_missing_sample_is_quarantined():
    result = assess_measurement({"value": 0.002, "unit": "S/cm", "origin": "measured"})
    assert result.status == "quarantined"
    assert result.checks["sample_identity"] == "failed"


def test_non_finite_value_is_quarantined():
    result = assess_measurement({"value": float("nan"), "unit": "S/cm", "sample_id": "S-1", "origin": "measured"})
    assert result.status == "quarantined"
