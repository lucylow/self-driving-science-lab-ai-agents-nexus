import pytest
from app.services.dataset_lineage import create_transformation_record, validate_lineage, canonical_hash


def _record(**overrides):
    values = dict(
        transformation_id="TR-1", operation="unit-normalization", software_name="nexus-core",
        software_version="0.1.0", input_artifact_ids=["RAW-1"], output_artifact_id="DERIVED-1",
        parameters={"from": "mS/cm", "to": "S/cm"}, actor="scientist",
    )
    values.update(overrides)
    return create_transformation_record(**values)


def test_transformation_preserves_source_and_hashes_parameters():
    item = _record()
    assert item.input_artifact_ids == ("RAW-1",)
    assert item.output_artifact_id == "DERIVED-1"
    assert len(item.parameters_hash) == 64


def test_lineage_requires_input_and_new_output():
    with pytest.raises(ValueError):
        _record(input_artifact_ids=[])
    with pytest.raises(ValueError):
        _record(output_artifact_id="RAW-1")


def test_lineage_detects_duplicate_transformation_writers():
    first = _record()
    second = _record(transformation_id="TR-2", input_artifact_ids=["RAW-2"])
    result = validate_lineage([first, second])
    assert not result["valid"]
    assert result["raw_artifacts_overwritten"] is False


def test_canonical_hash_is_order_independent_for_mapping_keys():
    assert canonical_hash({"a": 1, "b": 2}) == canonical_hash({"b": 2, "a": 1})
