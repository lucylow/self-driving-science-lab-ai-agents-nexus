from datetime import datetime, timedelta, timezone

import pytest
from sqlalchemy import create_engine, inspect, text
from sqlalchemy.orm import Session
from pydantic import ValidationError

from app.core.database import Base, ensure_outbox_event_key_unique_index
from app.models.entities import OutboxEvent
from app.schemas.extension import OutboxDrainRequest
from app.services.event_outbox import (
    acknowledge_delivery,
    enqueue_event,
    prepare_event_for_delivery,
)


def test_enqueue_event_is_idempotent_for_same_key_and_payload(tmp_path):
    engine = create_engine(f"sqlite:///{tmp_path / 'idempotency.db'}")
    Base.metadata.create_all(engine)
    with Session(engine) as db:
        first = enqueue_event(
            db, event_key="same-key", aggregate_type="sample", aggregate_id="S-1",
            event_type="sample.created", payload={"value": 1},
        )
        db.commit()
        duplicate = enqueue_event(
            db, event_key="same-key", aggregate_type="sample", aggregate_id="S-1",
            event_type="sample.created", payload={"value": 1},
        )
        assert duplicate.id == first.id
        with pytest.raises(ValueError, match="different event content"):
            enqueue_event(
                db, event_key="same-key", aggregate_type="sample", aggregate_id="S-1",
                event_type="sample.created", payload={"value": 2},
            )


def test_fresh_schema_has_database_unique_event_key_index(tmp_path):
    engine = create_engine(f"sqlite:///{tmp_path / 'fresh.db'}")
    Base.metadata.create_all(engine)
    indexes = {item["name"]: item for item in inspect(engine).get_indexes("outbox_events")}
    assert bool(indexes["uq_outbox_events_event_key"]["unique"])


def test_legacy_schema_gets_unique_index_without_rewriting_rows(tmp_path):
    engine = create_engine(f"sqlite:///{tmp_path / 'legacy.db'}")
    with engine.begin() as connection:
        connection.execute(text("CREATE TABLE outbox_events (id TEXT PRIMARY KEY, event_key TEXT NOT NULL)"))
        connection.execute(text("CREATE INDEX ix_outbox_events_event_key ON outbox_events(event_key)"))
        connection.execute(text("INSERT INTO outbox_events VALUES ('e1', 'k1')"))
        connection.execute(text("INSERT INTO outbox_events VALUES ('e2', 'k2')"))

    ensure_outbox_event_key_unique_index(engine)

    indexes = {item["name"]: item for item in inspect(engine).get_indexes("outbox_events")}
    assert bool(indexes["uq_outbox_events_event_key"]["unique"])
    with engine.connect() as connection:
        assert connection.execute(text("SELECT COUNT(*) FROM outbox_events")).scalar_one() == 2


def test_legacy_duplicate_keys_block_upgrade_without_deleting_history(tmp_path):
    engine = create_engine(f"sqlite:///{tmp_path / 'duplicates.db'}")
    with engine.begin() as connection:
        connection.execute(text("CREATE TABLE outbox_events (id TEXT PRIMARY KEY, event_key TEXT NOT NULL)"))
        connection.execute(text("INSERT INTO outbox_events VALUES ('e1', 'collision')"))
        connection.execute(text("INSERT INTO outbox_events VALUES ('e2', 'collision')"))

    with pytest.raises(RuntimeError, match="duplicate keys exist"):
        ensure_outbox_event_key_unique_index(engine)

    with engine.connect() as connection:
        assert connection.execute(text("SELECT COUNT(*) FROM outbox_events")).scalar_one() == 2
    indexes = {item["name"]: item for item in inspect(engine).get_indexes("outbox_events")}
    assert "uq_outbox_events_event_key" not in indexes


def test_outbox_batch_request_rejects_service_unsupported_values():
    assert OutboxDrainRequest(batch_size=500).batch_size == 500
    with pytest.raises(ValidationError):
        OutboxDrainRequest(batch_size=501)


def test_expired_delivery_lease_cannot_be_acknowledged(tmp_path):
    engine = create_engine(f"sqlite:///{tmp_path / 'lease.db'}")
    Base.metadata.create_all(engine)
    with Session(engine) as db:
        event = enqueue_event(
            db, event_key="lease-key", aggregate_type="workflow", aggregate_id="W-1",
            event_type="workflow.ready", payload={"step": 1},
        )
        db.commit()
        event_id = event.id
        envelope = prepare_event_for_delivery(db, event_id, lease_seconds=10)
        db.commit()
        row = db.get(OutboxEvent, event_id)
        payload = dict(row.payload)
        metadata = dict(payload["_nexus_delivery"])
        metadata["lease_expires_at"] = (
            datetime.now(timezone.utc) - timedelta(seconds=1)
        ).isoformat()
        payload["_nexus_delivery"] = metadata
        row.payload = payload
        db.commit()

        with pytest.raises(ValueError, match="lease has expired"):
            acknowledge_delivery(
                db, event_id, success=True, claim_token=envelope["claim_token"]
            )
        db.rollback()
        assert db.get(OutboxEvent, event_id).status == "ready_for_delivery"


def _checkpoint(checkpoint_id, index, node_id, status, previous_hash="", physical=False):
    from types import SimpleNamespace
    from app.services.workflow_checkpoints import _canonical_hash

    row = SimpleNamespace(
        id=checkpoint_id, workflow_run_id="wf-test", checkpoint_index=index,
        checkpoint_key=f"{node_id}:{status}", node_id=node_id, node_status=status,
        state_snapshot={"node": node_id}, output_snapshot={},
        idempotency_key=f"key-{index}", previous_hash=previous_hash,
        physical_side_effects=physical,
    )
    body = {
        "workflow_run_id": row.workflow_run_id,
        "checkpoint_index": row.checkpoint_index,
        "checkpoint_key": row.checkpoint_key,
        "node_id": row.node_id,
        "node_status": row.node_status,
        "state_snapshot": row.state_snapshot,
        "output_snapshot": row.output_snapshot,
        "idempotency_key": row.idempotency_key,
        "previous_hash": row.previous_hash,
        "physical_side_effects": row.physical_side_effects,
    }
    row.checkpoint_hash = _canonical_hash(body)
    return row


def test_workflow_recovery_uses_last_completed_checkpoint_not_failure_checkpoint():
    from types import SimpleNamespace
    from app.services.workflow_checkpoints import recovery_plan

    completed = _checkpoint("cp-1", 0, "node-a", "completed")
    failed = _checkpoint("cp-2", 1, "node-b", "failed", completed.checkpoint_hash)
    plan = recovery_plan(SimpleNamespace(status="failed"), [completed, failed], operator_requested=True)

    assert plan["eligible"] is True
    assert plan["latest_checkpoint_id"] == "cp-1"
    assert plan["completed_node"] == "node-a"
    assert plan["failed_checkpoint_id"] == "cp-2"
    assert plan["failed_node"] == "node-b"
    assert plan["state_snapshot"] == {"node": "node-a"}
    assert plan["automatic_resume"] is False


def test_workflow_recovery_rejects_a_run_without_completed_checkpoint():
    from types import SimpleNamespace
    from app.services.workflow_checkpoints import recovery_plan

    failed = _checkpoint("cp-failed", 0, "node-a", "failed")
    plan = recovery_plan(SimpleNamespace(status="failed"), [failed], operator_requested=True)

    assert plan["eligible"] is False
    assert plan["reason"] == "no_completed_checkpoint"
    assert plan["failed_node"] == "node-a"


def test_workflow_recovery_rejects_physical_side_effects_in_any_checkpoint():
    from types import SimpleNamespace
    from app.services.workflow_checkpoints import recovery_plan

    physical = _checkpoint("cp-physical", 0, "node-a", "completed", physical=True)
    failed = _checkpoint("cp-failed", 1, "node-b", "failed", physical.checkpoint_hash)
    plan = recovery_plan(SimpleNamespace(status="failed"), [physical, failed], operator_requested=True)

    assert plan["eligible"] is False
    assert plan["reason"] == "physical_side_effect_recovery_not_supported"


def test_liveness_readiness_and_request_id_propagation():
    import re
    from fastapi.testclient import TestClient
    from app.main import app

    with TestClient(app) as client:
        live = client.get("/health", headers={"X-Request-ID": "study_run.42"})
        assert live.status_code == 200
        assert live.json()["status"] == "ok"
        assert live.headers["x-request-id"] == "study_run.42"

        ready = client.get("/ready")
        assert ready.status_code == 200
        assert ready.json() == {
            "status": "ready", "dependencies": {"database": "available"}
        }
        assert re.fullmatch(r"[A-Za-z0-9._-]{1,128}", ready.headers["x-request-id"])

        invalid = client.get("/health", headers={"X-Request-ID": "unsafe id"})
        assert invalid.status_code == 200
        assert invalid.headers["x-request-id"] != "unsafe id"
        assert re.fullmatch(r"[A-Za-z0-9._-]{1,128}", invalid.headers["x-request-id"])


def test_readiness_returns_503_when_database_is_unavailable(monkeypatch):
    from fastapi.testclient import TestClient
    import app.main as main

    class UnavailableDatabase:
        def connect(self):
            raise OSError("connection refused")

    monkeypatch.setattr(main, "engine", UnavailableDatabase())
    with TestClient(main.app) as client:
        response = client.get("/ready")
    assert response.status_code == 503
    assert response.json() == {
        "status": "not_ready", "dependencies": {"database": "unavailable"}
    }
    assert response.headers.get("x-request-id")


def test_sample_identity_cannot_be_self_declared_during_registration(tmp_path):
    from app.services.domain_registry import get_domain
    from app.services.sample_registry import register_sample, verify_sample_identity

    engine = create_engine(f"sqlite:///{tmp_path / 'sample-identity.db'}")
    Base.metadata.create_all(engine)
    domain = get_domain("SDL1")["domain"]
    with Session(engine) as db:
        payload = {
            "code": "TRUST-001", "name": "Unverified reference sample",
            "laboratory_code": "SDL1", "domain": domain,
            "composition": {"Li": 1}, "identity_status": "verified",
        }
        with pytest.raises(ValueError, match="evidence-backed verification workflow"):
            register_sample(db, payload)

        payload["identity_status"] = "unverified"
        sample = register_sample(db, payload)
        assert sample.identity_status == "unverified"
        verify_sample_identity(
            db, sample.id, reviewer="reviewer-1", evidence_refs=["artifact://identity-proof"]
        )
        assert sample.identity_status == "verified"

    with pytest.raises(ValidationError):
        from app.schemas.extension import SampleCreate
        SampleCreate(
            code="TRUST-002", name="Attempted preverified sample", laboratory_code="SDL1",
            domain=domain, identity_status="verified",
        )


def test_synthetic_dataset_snapshot_is_rejected_at_model_training_boundary():
    from types import SimpleNamespace
    from app.services.model_training import train_baseline

    synthetic_dataset = SimpleNamespace(
        id="synthetic-dataset", synthetic=True, status="ready_for_research_training",
        records_json=[], split_manifest={},
    )
    with pytest.raises(ValueError, match="Synthetic dataset snapshots"):
        train_baseline(
            None, dataset=synthetic_dataset, model_key="model-demo", model_name="Demo model",
            version="0.1.0",
        )


def _artifact_payload(laboratory_code="SDL1", artifact_code="ART-001", sha256="a" * 64, **overrides):
    from app.services.domain_registry import get_domain

    payload = {
        "artifact_code": artifact_code,
        "sha256": sha256,
        "storage_uri": f"memory://{artifact_code.lower()}",
        "media_type": "application/octet-stream",
        "artifact_type": "raw_data",
        "byte_size": 4,
        "domain": get_domain(laboratory_code)["domain"],
        "laboratory_code": laboratory_code,
        "origin": "measured",
        "metadata": {},
        "parent_artifact_ids": [],
        "synthetic": False,
    }
    payload.update(overrides)
    return payload


def test_artifact_identity_is_scoped_to_artifact_code_not_global_digest(tmp_path):
    from app.services.artifact_registry import register_artifact, validate_artifact_parents

    engine = create_engine(f"sqlite:///{tmp_path / 'artifact-identity.db'}")
    Base.metadata.create_all(engine)
    with Session(engine) as db:
        first = register_artifact(db, _artifact_payload("SDL1", "ART-ONE"))
        db.commit()
        second = register_artifact(db, _artifact_payload("SDL2", "ART-TWO"))
        db.commit()
        assert first.sha256 == second.sha256
        assert first.id != second.id
        assert first.laboratory_code == "SDL1"
        assert second.laboratory_code == "SDL2"
        validation = validate_artifact_parents(db, first.id)
        assert validation["immutable"] is False
        assert validation["immutability_enforced"] is False

        retry = register_artifact(db, _artifact_payload("SDL1", "ART-ONE"))
        assert retry.id == first.id
        with pytest.raises(ValueError, match="different metadata"):
            register_artifact(db, _artifact_payload("SDL1", "ART-ONE", sha256="b" * 64))


def test_artifact_registration_rejects_missing_cross_lab_and_cyclic_parents(tmp_path):
    from app.services.artifact_registry import register_artifact

    engine = create_engine(f"sqlite:///{tmp_path / 'artifact-lineage.db'}")
    Base.metadata.create_all(engine)
    with Session(engine) as db:
        parent = register_artifact(db, _artifact_payload("SDL1", "ART-PARENT"))
        db.flush()
        with pytest.raises(ValueError, match="Unknown parent artifact IDs"):
            register_artifact(db, _artifact_payload(
                "SDL1", "ART-MISSING-PARENT", sha256="c" * 64,
                parent_artifact_ids=["missing-parent"],
            ))
        with pytest.raises(ValueError, match="must belong to laboratory SDL2"):
            register_artifact(db, _artifact_payload(
                "SDL2", "ART-CROSS-LAB-PARENT", sha256="d" * 64,
                parent_artifact_ids=[parent.id],
            ))

        other = register_artifact(db, _artifact_payload("SDL1", "ART-OTHER", sha256="e" * 64))
        db.flush()
        parent.parent_artifact_ids = [other.id]
        other.parent_artifact_ids = [parent.id]
        db.flush()
        with pytest.raises(ValueError, match="contains a cycle"):
            register_artifact(db, _artifact_payload(
                "SDL1", "ART-CYCLE-CHILD", sha256="f" * 64,
                parent_artifact_ids=[parent.id],
            ))
