import pytest
from app.services.domain_registry import get_domain, list_domains, validate_domain_payload


def test_eight_labs_have_distinct_domain_descriptors():
    labs = list_domains()
    assert len(labs) == 8
    assert {item["laboratory_code"] for item in labs} == {f"SDL{i}" for i in range(8)}
    assert len({item["domain"] for item in labs}) == 8


def test_unknown_lab_does_not_fall_back_to_sdl1():
    with pytest.raises(KeyError):
        get_domain("SDL99")


def test_domain_validation_flags_unsupported_modality_and_missing_gates():
    result = validate_domain_payload("SDL1", {"modality": "microscopy", "quality_gates": {}})
    assert result["modality_supported"] is False
    assert result["review_required"] is True
    assert result["accepted_for_scientific_conclusion"] is False
