import asyncio
import json

from fastapi import Request

from app.core.errors import InvalidTransitionError, NotFoundError, ValidationDomainError
from app.main import handle_domain_error, handle_unexpected_error


def test_unexpected_api_error_returns_safe_json_with_correlation_id():
    request = Request({
        "type": "http", "method": "GET", "path": "/api/private/value",
        "raw_path": b"/api/private/value", "query_string": b"", "headers": [],
        "scheme": "http", "server": ("test", 80), "client": ("test", 1234),
        "http_version": "1.1", "app": None,
    })
    response = asyncio.run(handle_unexpected_error(request, RuntimeError("sensitive internal detail")))
    body = json.loads(response.body)
    assert response.status_code == 500
    assert body["detail"] == "An unexpected server error occurred."
    assert len(body["request_id"]) == 12
    assert "sensitive internal detail" not in response.body.decode()


def test_domain_errors_use_semantic_http_statuses():
    request = Request({"type": "http"})
    assert asyncio.run(handle_domain_error(request, NotFoundError("missing"))).status_code == 404
    assert asyncio.run(handle_domain_error(request, ValidationDomainError("invalid"))).status_code == 422
    assert asyncio.run(handle_domain_error(request, InvalidTransitionError("blocked"))).status_code == 409
