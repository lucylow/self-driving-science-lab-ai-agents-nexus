import pytest
from app.services.integrations.instrument_adapter import SimulatedInstrumentAdapter


def test_adapter_deduplicates_command_ids():
    adapter = SimulatedInstrumentAdapter("INST-01")
    adapter.connect()
    first = adapter.submit_command({"command_id": "cmd-1", "operation": "read_status"})
    second = adapter.submit_command({"command_id": "cmd-1", "operation": "read_status"})
    assert first["acknowledgement"] == "received"
    assert second["idempotent_replay"] is True


def test_adapter_blocks_physical_operations():
    adapter = SimulatedInstrumentAdapter("INST-01")
    adapter.connect()
    with pytest.raises(PermissionError):
        adapter.submit_command({"command_id": "cmd-2", "operation": "dispense"})
