import pytest
from app.core.errors import InvalidTransitionError
from app.services.lifecycle import ensure_transition


def test_valid_transition_is_accepted():
    ensure_transition("draft", "validated")


def test_invalid_transition_is_rejected():
    with pytest.raises(InvalidTransitionError):
        ensure_transition("draft", "executing")


def test_completed_is_terminal():
    with pytest.raises(InvalidTransitionError):
        ensure_transition("completed", "executing")
