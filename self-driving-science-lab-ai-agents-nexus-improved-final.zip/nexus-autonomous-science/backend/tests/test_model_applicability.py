from app.services.model_applicability import check_model_applicability

MODEL = {
    "supported_domains": ["inorganic_materials"],
    "supported_modalities": ["tabular"],
    "prediction_targets": ["ionic_conductivity"],
    "numeric_training_ranges": {"temperature_k": [250, 400]},
}


def test_model_query_inside_capability_contract_is_applicable():
    result = check_model_applicability(MODEL, {
        "domain": "inorganic_materials", "modality": "tabular",
        "prediction_target": "ionic_conductivity", "numeric_features": {"temperature_k": 300},
    })
    assert result["applicable"] is True
    assert result["prediction_allowed"] is True


def test_model_query_outside_domain_is_rejected():
    result = check_model_applicability(MODEL, {
        "domain": "polymers", "modality": "image",
        "prediction_target": "tensile_strength", "numeric_features": {"temperature_k": 500},
    })
    assert result["applicable"] is False
    assert result["prediction_allowed"] is False
    assert "out_of_domain:temperature_k" in result["reasons"]
