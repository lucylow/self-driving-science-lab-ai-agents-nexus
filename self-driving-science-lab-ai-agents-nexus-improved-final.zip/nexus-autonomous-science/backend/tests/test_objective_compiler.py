from app.services.objective_compiler import compile_objective


def test_compiler_extracts_known_objective_target():
    result = compile_objective("Find solid electrolytes with high ionic conductivity and stability", "SDL1")
    properties = {item["property"] for item in result["target_properties"]}
    assert "ionic_conductivity" in properties
    assert result["requires_scientist_review"] is True
