from app.services.optimizer import score_candidate, select_next_batch


def test_ranker_returns_explainable_score():
    result = score_candidate({
        "predicted_properties": {"ionic_conductivity": 0.004, "stability_score": 80},
        "uncertainty": {"ionic_conductivity_relative": 0.1},
        "feasibility_score": 85,
    })
    assert 0 <= result["score"] <= 100
    assert "components" in result
    assert "not a validated" in result["explanation"]


def test_batch_respects_requested_size():
    candidates = [{"id": str(i), "predicted_properties": {"ionic_conductivity": i / 1000, "stability_score": 70}, "uncertainty": {}, "feasibility_score": 70} for i in range(1, 6)]
    assert len(select_next_batch(candidates, 2)) == 2
