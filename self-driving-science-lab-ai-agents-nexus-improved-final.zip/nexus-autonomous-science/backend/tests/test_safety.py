import pytest
from types import SimpleNamespace
from app.core.errors import GovernanceError
from app.services.safety import validate_agent_permission, validate_execution_request


def test_unapproved_experiment_cannot_run():
    experiment = SimpleNamespace(status="awaiting_approval", governance={"physical_execution": False})
    with pytest.raises(GovernanceError):
        validate_execution_request(experiment, requested_mode="simulation")


def test_physical_mode_is_blocked_even_when_approved():
    experiment = SimpleNamespace(status="approved", governance={"physical_execution": False})
    with pytest.raises(GovernanceError):
        validate_execution_request(experiment, requested_mode="physical")


@pytest.mark.parametrize("experiment", [None, SimpleNamespace(status="approved"), SimpleNamespace(status="approved", governance=None), SimpleNamespace(status="approved", governance=[])])
def test_missing_or_malformed_experiment_governance_is_denied(experiment):
    with pytest.raises(GovernanceError):
        validate_execution_request(experiment, requested_mode="simulation")


@pytest.mark.parametrize("mode", [None, [], "unknown"])
def test_invalid_execution_modes_are_denied(mode):
    with pytest.raises(GovernanceError):
        validate_execution_request(SimpleNamespace(status="approved", governance={}), requested_mode=mode)


def test_non_string_agent_action_is_denied():
    with pytest.raises(GovernanceError, match="action must be a string"):
        validate_agent_permission("analyze", [])


def test_non_string_agent_permission_is_denied():
    with pytest.raises(GovernanceError, match="permission level must be a string"):
        validate_agent_permission([], "analyze")
