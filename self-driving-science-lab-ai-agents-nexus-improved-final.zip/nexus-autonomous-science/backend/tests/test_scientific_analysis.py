import math

from fastapi.testclient import TestClient

from app.main import app
from app.services.scientific_analysis import analyze_observations


def observation(row_id: str, value, *, unit: str = "score", uncertainty: float = 0.01):
    return {"id": row_id, "metric": "demo_metric", "value": value, "unit": unit, "uncertainty": uncertainty}


def test_descriptive_statistics_and_small_sample_t_interval():
    result = analyze_observations([observation(str(i), value) for i, value in enumerate([1, 2, 3, 4, 5])])
    assert result["n"] == 5
    assert result["mean"] == 3
    assert result["median"] == 3
    assert math.isclose(result["sample_standard_deviation"], math.sqrt(2.5), abs_tol=1e-6)
    assert result["mean_confidence_interval_95"][0] < 3 < result["mean_confidence_interval_95"][1]
    assert math.isclose(result["mean_confidence_interval_95"][0], 1.037, abs_tol=0.002)
    assert result["quality_status"] == "valid"


def test_outlier_is_reported_but_not_silently_removed():
    rows = [observation(str(i), value) for i, value in enumerate([1, 2, 3, 4, 100])]
    result = analyze_observations(rows)
    assert result["outlier_ids"] == ["4"]
    assert result["outliers_included_in_summary"] is True
    assert result["n"] == 5
    assert result["mean"] == 22
    assert result["quality_status"] == "warning"


def test_missing_invalid_duplicate_and_wrong_unit_records_are_reported():
    rows = [
        observation("a", 0.5, unit="fraction_0_to_1"),
        observation("missing", None),
        observation("bad", float("inf")),
        observation("a", 0.9),
        {**observation("unit", 0.4), "metric": "synthetic_quality_score", "unit": "milliseconds"},
    ]
    result = analyze_observations(rows)
    assert result["n"] == 1
    assert result["missing_ids"] == ["missing"]
    assert result["invalid_ids"] == ["bad", "unit"]
    assert result["duplicate_ids"] == ["a"]
    assert result["quality_status"] == "invalid"
    assert result["mean_confidence_interval_95"] is None


def test_empty_data_requires_review_instead_of_reporting_valid():
    result = analyze_observations([])
    assert result["n"] == 0
    assert result["quality_status"] == "needs_review"
    assert result["mean"] is None


def test_missing_measurement_uncertainty_is_reported_without_dropping_value():
    result = analyze_observations([{"id": "u1", "metric": "demo_metric", "value": 0.7, "unit": "score", "uncertainty": None}])
    assert result["n"] == 1
    assert result["missing_uncertainty_ids"] == ["u1"]
    assert result["quality_status"] == "warning"


def test_project_analysis_api_records_hash_method_and_observation_count():
    client = TestClient(app)
    project = client.get("/api/synthetic-research/records/projects", params={"program_id": "program_0001", "limit": 1}).json()["items"][0]
    project_id = project["id"]
    observations = client.get("/api/synthetic-research/records/observations", params={"project_id": project_id, "limit": 100}).json()
    response = client.get(f"/api/synthetic-research/analysis/projects/{project_id}")
    assert response.status_code == 200
    analysis = response.json()
    assert analysis["synthetic"] is True
    assert analysis["input_dataset_version"].startswith("sha256:")
    assert analysis["analysis_method"] == "descriptive_mean_t_interval_95_v1"
    assert analysis["analysis"]["n"] == observations["total"]
    assert analysis["analysis"]["mean_confidence_interval_95"] is not None
    assert client.get("/api/synthetic-research/analysis/projects/not_a_project").status_code == 404
