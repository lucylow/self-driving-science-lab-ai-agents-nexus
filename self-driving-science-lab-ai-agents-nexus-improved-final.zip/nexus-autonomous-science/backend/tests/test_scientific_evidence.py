from app.services.scientific_evidence import assess_evidence, detect_numeric_contradiction


def test_synthetic_measurement_cannot_be_promoted_to_experimental_evidence():
    result = assess_evidence(
        evidence_id="SYN-1", origin="independent_validation", synthetic=True,
        quality_checks={"sample_identity": True}, independent_validation_reference="external-review-1",
    )
    assert result.grade == "E0"
    assert result.eligible_for_model_training is False


def test_quality_controlled_measurement_requires_all_domain_gates():
    result = assess_evidence(
        evidence_id="MEAS-1", origin="quality_controlled_measurement",
        quality_checks={"sample_identity": True, "unit_validation": True},
    )
    assert result.grade == "E3"
    assert result.eligible_for_model_training is False
    assert result.limitations


def test_complete_qc_record_can_be_training_eligible():
    checks = {key: True for key in ["sample_identity", "method_metadata", "calibration", "unit_validation", "protocol_adherence"]}
    result = assess_evidence(evidence_id="MEAS-2", origin="quality_controlled_measurement", quality_checks=checks)
    assert result.grade == "E4"
    assert result.eligible_for_model_training is True


def test_contradiction_report_does_not_choose_a_winner():
    result = detect_numeric_contradiction(
        subject_id="MAT-1", observation_a_id="A", observation_b_id="B",
        property_name="ionic_conductivity", value_a=0.004, value_b=0.0008,
    )
    assert result is not None
    assert result.resolution_status == "unresolved"
    assert any("calibration" in item.lower() for item in result.explanation_candidates)


def test_values_within_tolerance_do_not_create_contradiction():
    result = detect_numeric_contradiction(
        subject_id="MAT-1", observation_a_id="A", observation_b_id="B",
        property_name="density", value_a=1.0, value_b=1.05,
    )
    assert result is None
