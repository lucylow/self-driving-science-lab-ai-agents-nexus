import pytest
from fastapi.testclient import TestClient

from app.main import app
from app.services.scientific_optimization import rank_experiments_by_quality_and_cost


def test_pareto_front_preserves_tradeoffs_and_marks_dominated_candidates():
    experiments = [{"id": name, "name": name, "estimated_compute_hours": cost} for name, cost in [("quality", 2), ("cheap", 1), ("dominated", 3)]]
    executions = [
        {"experiment_id": "quality", "status": "successful", "quality_score": 0.9, "compute_hours": 2},
        {"experiment_id": "cheap", "status": "partial_improvement", "quality_score": 0.7, "compute_hours": 1},
        {"experiment_id": "dominated", "status": "negative_result", "quality_score": 0.6, "compute_hours": 3},
    ]
    result = rank_experiments_by_quality_and_cost(experiments, executions)
    by_id = {candidate["experiment_id"]: candidate for candidate in result["candidates"]}
    assert by_id["quality"]["on_pareto_front"] is True
    assert by_id["cheap"]["on_pareto_front"] is True
    assert by_id["dominated"]["status"] == "dominated"
    assert set(result["frontier_experiment_ids"]) == {"quality", "cheap"}


def test_hard_cost_limit_excludes_infeasible_high_quality_candidate():
    experiments = [{"id": "within"}, {"id": "over"}]
    executions = [
        {"experiment_id": "within", "status": "successful", "quality_score": 0.6, "compute_hours": 1},
        {"experiment_id": "over", "status": "successful", "quality_score": 1.0, "compute_hours": 5},
    ]
    result = rank_experiments_by_quality_and_cost(experiments, executions, max_compute_hours=2)
    by_id = {candidate["experiment_id"]: candidate for candidate in result["candidates"]}
    assert by_id["over"]["status"] == "infeasible"
    assert by_id["within"]["on_pareto_front"] is True
    assert result["frontier_experiment_ids"] == ["within"]


def test_failures_cost_compute_but_do_not_enter_quality_mean():
    result = rank_experiments_by_quality_and_cost(
        [{"id": "replicate"}],
        [
            {"experiment_id": "replicate", "status": "successful", "quality_score": 0.8, "compute_hours": 2},
            {"experiment_id": "replicate", "status": "technical_failure", "quality_score": 0.9, "compute_hours": 7},
            {"experiment_id": "replicate", "status": "inconclusive", "quality_score": 0.95, "compute_hours": 1},
        ],
    )
    candidate = result["candidates"][0]
    assert candidate["mean_quality"] == 0.8
    assert candidate["compute_hours"] == 10
    assert candidate["quality_run_count"] == 1
    assert candidate["technical_failure_count"] == 1


def test_invalid_compute_limit_is_rejected():
    with pytest.raises(ValueError, match="finite positive"):
        rank_experiments_by_quality_and_cost([], [], max_compute_hours=0)


def test_invalid_execution_cost_and_quality_are_not_ranked_as_feasible():
    result = rank_experiments_by_quality_and_cost(
        [{"id": "bad-cost"}, {"id": "bad-score"}],
        [
            {"experiment_id": "bad-cost", "status": "successful", "quality_score": 0.8},
            {"experiment_id": "bad-score", "status": "successful", "quality_score": 1.2, "compute_hours": 1},
        ],
    )
    by_id = {candidate["experiment_id"]: candidate for candidate in result["candidates"]}
    assert by_id["bad-cost"]["status"] == "invalid_cost"
    assert by_id["bad-score"]["status"] == "unscored"
    assert by_id["bad-score"]["invalid_quality_count"] == 1


def test_project_pareto_api_returns_traceable_frontier_and_constraints():
    client = TestClient(app)
    response = client.get("/api/synthetic-research/optimization/projects/project_0001", params={"max_compute_hours": 0.0001})
    assert response.status_code == 200
    body = response.json()
    assert body["synthetic"] is True
    assert body["input_dataset_version"].startswith("sha256:")
    assert body["hard_constraint"]["max_compute_hours"] == 0.0001
    assert body["objectives"] == {"mean_quality": "maximize", "compute_hours": "minimize"}
    assert any(candidate["status"] == "infeasible" for candidate in body["candidates"])
    assert body["frontier_experiment_ids"] == []
    assert client.get("/api/synthetic-research/optimization/projects/unknown").status_code == 404
