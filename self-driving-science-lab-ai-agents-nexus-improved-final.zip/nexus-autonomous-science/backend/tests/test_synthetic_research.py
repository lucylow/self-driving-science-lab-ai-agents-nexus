import copy
from collections import Counter

from fastapi.testclient import TestClient

from app.main import app
from app.services.synthetic_research import DEFAULT_COUNTS, generate_research_universe, validate_research_universe


def test_default_dataset_has_documented_counts_and_is_repeatable():
    first = generate_research_universe(seed=23)
    second = generate_research_universe(seed=23)
    assert first == second
    assert first["metadata"]["record_counts"] == DEFAULT_COUNTS
    assert first["metadata"]["total_records"] == sum(DEFAULT_COUNTS.values())
    assert validate_research_universe(first) == []


def test_seed_changes_values_but_preserves_referential_integrity():
    first = generate_research_universe(seed=23)
    second = generate_research_universe(seed=24)
    assert first["hypotheses"] != second["hypotheses"]
    assert validate_research_universe(second) == []


def test_next_experiment_recommendations_never_select_completed_proposals():
    data = generate_research_universe()
    experiments = {row["id"]: row for row in data["experiments"]}
    for project in data["projects"]:
        recommendation = project["recommended_next_experiment_id"]
        if recommendation is not None:
            assert recommendation in project["experiment_ids"]
            assert experiments[recommendation]["status"] != "completed"
            assert project["recommendation_rationale"]


def test_every_exported_entity_is_marked_as_synthetic():
    data = generate_research_universe()
    for category, records in data.items():
        if category == "metadata":
            continue
        assert records
        assert all(row.get("synthetic") is True and row.get("notice") for row in records)


def test_relationship_validator_detects_broken_execution_link():
    broken = copy.deepcopy(generate_research_universe())
    broken["executions"][0]["experiment_id"] = "experiment_missing"
    assert any("references missing experiments" in error for error in validate_research_universe(broken))


def test_outcome_distribution_separates_negative_results_from_technical_failures():
    outcomes = Counter(row["status"] for row in generate_research_universe()["executions"])
    assert (outcomes["successful"] + outcomes["partial_improvement"]) / 1500 == 0.55
    assert outcomes["inconclusive"] / 1500 == 0.20
    assert outcomes["technical_failure"] / 1500 == 0.15
    assert outcomes["negative_result"] / 1500 == 0.10


def test_zero_sized_categories_are_supported_when_programs_remain_present():
    counts = {category: 0 for category in DEFAULT_COUNTS}
    counts["programs"] = 15
    data = generate_research_universe(counts=counts)
    assert data["metadata"]["total_records"] == 15
    assert validate_research_universe(data) == []


def test_observations_link_to_executions_and_hypotheses_update_from_evidence():
    data = generate_research_universe()
    executions = {row["id"] for row in data["executions"]}
    hypotheses = {row["id"] for row in data["hypotheses"]}
    assert len(data["programs"]) == 15
    assert len(data["observations"]) == 2000
    assert all(row["execution_id"] in executions and row["hypothesis_id"] in hypotheses for row in data["observations"])
    assert all(0 <= row["posterior_probability"] <= 1 for row in data["hypotheses"])
    assert any(row["evidence_count"] > 0 for row in data["hypotheses"])


def test_api_supports_pagination_search_and_program_filtering():
    client = TestClient(app)
    summary = client.get("/api/synthetic-research")
    assert summary.status_code == 200
    assert summary.json()["total_records"] == sum(DEFAULT_COUNTS.values())
    page = client.get("/api/synthetic-research/records/projects", params={"limit": 3, "offset": 2, "q": "adaptive"})
    assert page.status_code == 200
    assert len(page.json()["items"]) == 3
    assert page.json()["total"] >= len(page.json()["items"])
    program = client.get("/api/synthetic-research/records/projects", params={"program_id": "program_0001", "limit": 100})
    assert program.status_code == 200
    assert program.json()["items"]
    assert all(row["program_id"] == "program_0001" for row in program.json()["items"])
    project_id = program.json()["items"][0]["id"]
    detail = client.get("/api/synthetic-research/records/observations", params={"project_id": project_id, "limit": 100})
    assert detail.status_code == 200
    assert all(row["project_id"] == project_id for row in detail.json()["items"])


def test_unknown_category_is_not_served():
    response = TestClient(app).get("/api/synthetic-research/records/not_a_category")
    assert response.status_code == 404
