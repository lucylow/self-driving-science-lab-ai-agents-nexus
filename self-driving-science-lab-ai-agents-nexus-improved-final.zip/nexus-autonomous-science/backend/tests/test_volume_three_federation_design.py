from uuid import uuid4

from fastapi.testclient import TestClient

from app.main import app
from app.services.advanced_research.federated_model_updates import (
    aggregate_model_deltas,
    compare_federated_rounds,
)
from app.services.advanced_research.lab_effects import summarize_lab_effects
from app.services.advanced_research.blocked_assignment import (
    create_blocked_assignment,
    audit_assignment,
)
from app.services.advanced_research.repeatability import (
    repeatability_summary,
    bland_altman_summary,
)


def _updates():
    return [
        {
            "laboratory_code": f"SDL{i}",
            "base_model_id": "shared-property-model",
            "base_model_version": "0.4.0",
            "consent_scope": "approved_parameter_update",
            "local_validation_status": "accepted_for_research",
            "training_record_count": 50 + i * 10,
            "parameter_delta": {"w1": 0.1 * (i + 1), "b": -0.02 * i},
        }
        for i in range(3)
    ]


def test_federated_model_updates_are_clipped_and_not_released():
    result = aggregate_model_deltas(
        _updates(), expected_model_id="shared-property-model",
        expected_version="0.4.0", parameter_names=["w1", "b"],
        minimum_labs=3, clip_norm=0.5,
    )
    assert result["status"] == "aggregate_ready_for_review"
    assert result["model_update_created"] is False
    assert result["model_release_authorized"] is False
    assert result["training_examples_transmitted"] is False
    assert all(scale <= 1 for scale in result["client_clip_scales"].values())
    assert set(result["aggregate_parameter_delta"]) == {"w1", "b"}


def test_federated_model_updates_block_duplicate_lab_and_bad_consent():
    updates = _updates()
    updates[1]["laboratory_code"] = "SDL0"
    try:
        aggregate_model_deltas(updates, expected_model_id="shared-property-model",
            expected_version="0.4.0", parameter_names=["w1", "b"], minimum_labs=2)
    except ValueError as exc:
        assert "one update per laboratory" in str(exc)
    else:
        raise AssertionError("duplicate lab should be rejected")
    updates = _updates()
    updates[0]["consent_scope"] = "not-approved"
    result = aggregate_model_deltas(updates, expected_model_id="shared-property-model",
        expected_version="0.4.0", parameter_names=["w1", "b"], minimum_labs=3)
    assert result["status"] == "blocked_insufficient_eligible_labs"
    assert result["model_update_created"] is False


def test_federated_round_comparison_is_descriptive_only():
    result = compare_federated_rounds([
        {"round_id": "r1", "base_model_version": "0.1", "eligible_lab_count": 3,
         "aggregate_parameter_delta": {"w": 0.3}},
        {"round_id": "r2", "base_model_version": "0.2", "eligible_lab_count": 4,
         "aggregate_parameter_delta": {"w": 0.4, "b": 0.1}},
    ])
    assert len(result["rounds"]) == 2
    assert "does not measure model improvement" in result["interpretation"]


def test_lab_effects_shrinkage_preserves_observed_means():
    rows = [
        {"laboratory_code": "SDL1", "value": v} for v in [1.0, 1.1, 0.9, 1.05]
    ] + [
        {"laboratory_code": "SDL2", "value": v} for v in [2.0, 2.1, 1.9, 2.05]
    ]
    result = summarize_lab_effects(rows)
    assert result["laboratory_count"] == 2
    assert result["record_count"] == 8
    assert result["laboratory_effects"]["SDL1"]["observed_mean"] < result["grand_mean"]
    assert result["laboratory_effects"]["SDL1"]["partially_pooled_mean"] < result["grand_mean"]
    assert any("causal" in item for item in result["limitations"])


def test_blocked_assignment_is_reproducible_and_auditable():
    units = [
        {"unit_id": f"U{i:02d}", "block_id": f"B{i // 4}"}
        for i in range(12)
    ]
    a = create_blocked_assignment(units=units, arms=["control", "candidate"], seed=91)
    b = create_blocked_assignment(units=units, arms=["control", "candidate"], seed=91)
    assert a["assignment_plan"] == b["assignment_plan"]
    audit = audit_assignment(a, expected_unit_ids=[x["unit_id"] for x in units],
                              arms=["control", "candidate"])
    assert audit["valid"] is True
    assert a["physical_assignment_executed"] is False


def test_blocked_assignment_rejects_duplicate_units_and_unknown_arm_in_audit():
    try:
        create_blocked_assignment(units=[{"unit_id": "U1"}, {"unit_id": "U1"}],
                                  arms=["A", "B"])
    except ValueError:
        pass
    else:
        raise AssertionError("duplicate computational unit IDs should fail")
    audit = audit_assignment({"assignment_plan": [{"unit_id": "U1", "assigned_arm": "X"}]},
                              expected_unit_ids=["U1"], arms=["A", "B"])
    assert audit["valid"] is False
    assert audit["unknown_arms"] == ["X"]


def test_repeatability_reports_within_and_between_group_components():
    rows = []
    for sample, center in [("S1", 10), ("S2", 11), ("S3", 13)]:
        rows.extend([{"sample_id": sample, "value": center + offset}
                     for offset in [-0.1, 0, 0.1]])
    result = repeatability_summary(rows)
    assert result["group_count"] == 3
    assert result["replicate_count"] == 9
    assert result["estimated_within_group_sd"] > 0
    assert 0 <= result["icc_one_way_random_intercept_approximation"] <= 1


def test_bland_altman_summary_keeps_paired_method_information():
    a = [1, 2, 3, 4, 5, 6]
    b = [0.9, 2.1, 2.8, 4.2, 4.9, 6.1]
    result = bland_altman_summary(a, b)
    assert result["paired_count"] == 6
    assert abs(result["mean_bias_a_minus_b"]) < 1e-12
    assert result["lower_approximate_95_limit"] < 0 < result["upper_approximate_95_limit"]


def test_volume_three_api_routes_persist_analyses_and_keep_physical_actions_disabled():
    with TestClient(app) as client:
        updates = client.post("/api/advanced-research/federated/model-updates/aggregate", json={
            "expected_model_id": "test-model", "expected_version": "1.0",
            "parameter_names": ["weight", "bias"], "minimum_labs": 3,
            "updates": [
                {"laboratory_code": f"SDL{i}", "base_model_id": "test-model",
                 "base_model_version": "1.0", "consent_scope": "approved_parameter_update",
                 "local_validation_status": "accepted_for_research", "training_record_count": 40,
                 "parameter_delta": {"weight": i * .01, "bias": -.001 * i}}
                for i in range(3)
            ]})
        assert updates.status_code == 200, updates.text
        assert updates.json()["aggregation"]["model_update_created"] is False

        effects = client.post("/api/advanced-research/labs/effects/summarize", json={
            "observations": ([{"laboratory_code": "SDL1", "value": x} for x in [1, 1.1, .9]] +
                             [{"laboratory_code": "SDL2", "value": x} for x in [2, 2.1, 1.9]])})
        assert effects.status_code == 200, effects.text
        assert effects.json()["diagnostics"]["laboratory_count"] == 2

        assignment = client.post("/api/advanced-research/design/blocked-assignment", json={
            "units": [{"unit_id": f"U{i}", "block_id": f"B{i // 3}"} for i in range(9)],
            "arms": ["reference", "variant"], "seed": 7})
        assert assignment.status_code == 201, assignment.text
        plan = assignment.json()["assignment"]["assignment_plan"]
        audit = client.post("/api/advanced-research/design/blocked-assignment/audit", json={
            "plan": assignment.json()["assignment"],
            "expected_unit_ids": [f"U{i}" for i in range(9)],
            "arms": ["reference", "variant"]})
        assert audit.status_code == 200 and audit.json()["valid"] is True

        repeat = client.post("/api/advanced-research/repeatability/summarize", json={
            "replicates": [{"sample_id": f"S{i}", "value": value}
                           for i, pair in enumerate([[1, 1.1], [2, 2.1], [3, 3.1]])
                           for value in pair], "synthetic": True})
        assert repeat.status_code == 200, repeat.text
        assert repeat.json()["analysis"]["synthetic"] is True

        agreement = client.post("/api/advanced-research/repeatability/bland-altman", json={
            "method_a": [1, 2, 3, 4, 5], "method_b": [.9, 2.1, 2.9, 4.1, 5]})
        assert agreement.status_code == 200, agreement.text
