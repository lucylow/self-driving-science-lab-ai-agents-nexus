"""Domain science, data-contract, governance and lineage regression tests."""
from datetime import datetime, timezone
import pytest
from fastapi.testclient import TestClient

from app.main import app
from app.services.domain_science.electrochemistry import calculate_conductivity, fit_arrhenius_conductivity, summarize_eis_spectrum
from app.services.domain_science.diffraction import bragg_d_spacing, estimate_lattice_cubic, compare_xrd_peaks
from app.services.domain_science.battery import summarize_galvanostatic_cycle, calculate_energy_density, summarize_cycle_life
from app.services.domain_science.polymer import calculate_polydispersity, calculate_crystallinity, analyze_tensile_curve
from app.services.domain_science.spectroscopy import baseline_correct, normalize_spectrum, detect_peaks, integrate_spectrum
from app.services.domain_science.kinetics import fit_first_order_decay, calculate_mass_balance
from app.services.domain_science.formulation import validate_mixture, calculate_blend_property
from app.services.domain_science.morphology import analyze_binary_mask, summarize_morphology_batch
from app.services.domain_science.replicates import summarize_replicates, compare_replicate_groups
from app.services.scientific_data_contracts import convert_unit, validate_measurement_contract, get_measurement_contract
from app.services.schema_registry import SchemaRegistry, SchemaDefinition, FieldDefinition, default_registry
from app.services.provenance_graph import validate_lineage_graph, trace_to_roots, downstream_impact, compare_lineage_sources
from app.services.quality_rules import default_quality_engine
from app.services.science_governance.model_release import evaluate_release_gate, validate_release_transition, compare_champion_challenger
from app.services.science_governance.agent_capacity import LocalCapacityManager, AgentBudget, CircuitBreaker, CircuitState
from app.services.workflow_compiler import compile_workflow
from app.services.experiment_scheduler_advanced import propose_schedule


def test_conductivity_and_uncertainty_propagation():
    result = calculate_conductivity(resistance_ohm=100, thickness_cm=0.1, area_cm2=1,
                                    resistance_uncertainty_ohm=1, thickness_uncertainty_cm=0.001)
    assert result["value"] == pytest.approx(0.001)
    assert result["standard_uncertainty"] > 0
    assert result["origin"] == "derived_computational_result"


def test_conductivity_rejects_bad_geometry():
    with pytest.raises(ValueError):
        calculate_conductivity(resistance_ohm=0, thickness_cm=0.1, area_cm2=1)


def test_arrhenius_estimate_from_synthetic_linear_series():
    temperatures = [300, 320, 340, 360, 380]
    # ln(sigma*T) = intercept - Ea/kB/T, with Ea=0.25 eV.
    import math
    kb = 8.617333262145e-5
    sigma = [math.exp(5 - 0.25/(kb*t))/t for t in temperatures]
    fit = fit_arrhenius_conductivity(temperatures, sigma)
    assert fit["activation_energy_ev"] == pytest.approx(0.25, rel=1e-4)
    assert fit["r_squared"] > .9999


def test_arrhenius_rejects_nonpositive_conductivity():
    with pytest.raises(ValueError):
        fit_arrhenius_conductivity([300, 310, 320], [1, 0, 2])


def test_eis_summary_preserves_frequency_range_and_flags():
    result = summarize_eis_spectrum([1, 10, 100, 1000], [4, 3, 2, 1], [-1, -2, -1, 0], expected_frequency_range=(5, 900))
    assert result["point_count"] == 4
    assert "frequency_outside_declared_range" in result["quality_flags"]


def test_eis_rejects_duplicate_frequency():
    with pytest.raises(ValueError):
        summarize_eis_spectrum([1, 10, 10, 100], [1, 2, 3, 4], [0, -1, -2, 0])


def test_bragg_spacing_known_geometry():
    result = bragg_d_spacing(30, 1.5406)
    assert result["d_spacing_angstrom"] == pytest.approx(2.9762106559618773, rel=1e-9)


def test_cubic_lattice_average():
    a = 5.4
    hkls = [(1, 0, 0), (1, 1, 0), (1, 1, 1)]
    ds = [a / (sum(v*v for v in hkl) ** 0.5) for hkl in hkls]
    assert estimate_lattice_cubic(ds, hkls)["cubic_lattice_parameter_angstrom"] == pytest.approx(a)


def test_xrd_reference_peak_coverage_is_not_phase_proof():
    result = compare_xrd_peaks([(20, 100), (30.1, 70), (42, 40)], [(20, 1), (30, 1), (50, 1)])
    assert result["reference_coverage"] == pytest.approx(2/3)
    assert "not phase identification" in result["interpretation"]


def test_battery_coulombic_efficiency_and_curve_energy():
    result = summarize_galvanostatic_cycle(charge_capacity_mah_g=120, discharge_capacity_mah_g=114,
        cycle_index=1, discharge_voltage_v=[4, 3, 2], discharge_capacity_axis_mah_g=[0, 50, 100])
    assert result["coulombic_efficiency_percent"] == pytest.approx(95)
    assert result["discharge_energy_wh_kg"] == pytest.approx(300)


def test_battery_energy_density_rejects_nonmonotonic_axis():
    with pytest.raises(ValueError):
        calculate_energy_density([4, 3, 2], [0, 50, 40])


def test_battery_cycle_life_tracks_retention():
    result = summarize_cycle_life([1, 10, 20], [100, 95, 90])
    assert result["last_cycle_retention_percent"] == pytest.approx(90)


def test_polymer_dispersity_and_crystallinity():
    assert calculate_polydispersity(10000, 18000)["dispersity"] == pytest.approx(1.8)
    assert calculate_crystallinity(melting_enthalpy_j_g=40, reference_enthalpy_j_g=100, polymer_mass_fraction=.8)["crystallinity_percent"] == pytest.approx(50)


def test_polymer_tensile_curve_calculates_modulus():
    result = analyze_tensile_curve(extension_mm=[0, .01, .02, .03], force_n=[0, 1, 2, 3],
                                  initial_length_mm=10, cross_section_mm2=2, elastic_strain_limit=.004)
    assert result["young_modulus_mpa"] == pytest.approx(500)


def test_spectrum_baseline_correction():
    result = baseline_correct([0, 1, 2, 3], [1, 3, 4, 2])
    assert result["corrected_intensity"][0] == pytest.approx(0)
    assert result["corrected_intensity"][-1] == pytest.approx(0)


def test_spectrum_normalization_and_peak_detection():
    norm = normalize_spectrum([0, 1, 5, 1, 0])
    peaks = detect_peaks([0, 1, 2, 3, 4], norm["normalized_intensity"], minimum_prominence=.5)
    assert max(norm["normalized_intensity"]) == pytest.approx(1)
    assert peaks["peak_count"] == 1


def test_spectrum_integral_with_interpolated_bounds():
    result = integrate_spectrum([0, 1, 2, 3], [0, 1, 2, 3], lower=.5, upper=2.5)
    assert result["area"] == pytest.approx(3)


def test_first_order_kinetics_retrieves_rate_constant():
    import math
    times = [0, 1, 2, 3, 4]
    concentrations = [math.exp(-.3*t) for t in times]
    result = fit_first_order_decay(times, concentrations)
    assert result["rate_constant_s_inv"] == pytest.approx(.3)
    assert result["half_life_s"] == pytest.approx(math.log(2)/.3)


def test_mass_balance_closure_is_explicit():
    result = calculate_mass_balance(inlet_mass_g=100, outlet_mass_g=96, accumulated_mass_g=4)
    assert result["mass_balance_closure_fraction"] == pytest.approx(1)


def test_formulation_fractions_are_not_silently_normalized():
    result = validate_mixture([{"name": "A", "fraction": .4}, {"name": "B", "fraction": .5}])
    assert result["valid"] is False
    assert result["normalization_applied"] is False


def test_ideal_blend_property_with_valid_mixture():
    result = calculate_blend_property([{"name": "A", "fraction": .25, "viscosity": 2},
                                       {"name": "B", "fraction": .75, "viscosity": 6}], property_key="viscosity")
    assert result["ideal_linear_blend_value"] == pytest.approx(5)


def test_morphology_empty_and_solid_masks():
    empty = analyze_binary_mask([[0, 0], [0, 0]])
    solid = analyze_binary_mask([[1, 1], [1, 1]], pixel_size=.5)
    assert empty["area_pixels"] == 0
    assert solid["area"] == pytest.approx(1)
    assert solid["circularity"] > 0


def test_morphology_batch_summarizes_multiple_objects():
    result = summarize_morphology_batch([[[1, 0], [0, 0]], [[1, 1], [1, 0]]])
    assert result["object_count"] == 2
    assert result["area_range"] == [1.0, 3.0]


def test_replicate_summary_does_not_delete_outliers():
    result = summarize_replicates([1, 1, 1, 100], expected_unit="mS/cm", observed_units=["mS/cm"]*4)
    assert result["n"] == 4
    assert result["maximum"] == 100


def test_replicate_group_compare_is_descriptive_only():
    result = compare_replicate_groups({"batch_a": [1, 2, 3], "batch_b": [3, 4, 5]})
    assert "no inferential test" in result["interpretation"]


def test_unit_conversion_is_dimension_safe():
    assert convert_unit(1, "S/cm", "S/m")["normalized_value"] == pytest.approx(100)
    with pytest.raises(ValueError):
        convert_unit(1, "S/cm", "K")


def test_temperature_conversion_uses_offset():
    assert convert_unit(25, "degC", "K")["normalized_value"] == pytest.approx(298.15)


def test_measurement_contract_requires_context_and_origin_consistency():
    result = validate_measurement_contract(property_name="ionic_conductivity", value=.001,
        unit="S/cm", domain="inorganic_materials", context={}, origin="measured", synthetic=True)
    assert result["valid"] is False
    assert any(issue["code"] == "synthetic_measured_conflict" for issue in result["issues"])


def test_contract_catalogue_returns_copies():
    first = get_measurement_contract("ionic_conductivity")
    first["units"].append("fake")
    assert "fake" not in get_measurement_contract("ionic_conductivity")["units"]


def test_schema_registry_rejects_duplicate_and_nonmonotonic_versions():
    registry = SchemaRegistry()
    registry.register(SchemaDefinition("record", "1.0.0", "SDL1", (FieldDefinition("id", "string", True),)))
    with pytest.raises(ValueError):
        registry.register(SchemaDefinition("record", "1.0.0", "SDL1", (FieldDefinition("id", "string", True),)))
    with pytest.raises(ValueError):
        registry.register(SchemaDefinition("record", "0.9.0", "SDL1", (FieldDefinition("id", "string", True),)))


def test_default_schema_registry_checks_required_fields_and_types():
    registry = default_registry()
    good = registry.validate("scientific_measurement", {"measurement_id": "M1", "sample_id": "S1",
       "property_name": "conductivity", "value": .01, "unit": "S/cm", "origin": "measured",
       "synthetic": False, "context": {}})
    assert good["valid"] is True
    bad = registry.validate("scientific_measurement", {"measurement_id": 1})
    assert bad["valid"] is False


def test_schema_compatibility_reports_breaking_field_removal():
    registry = SchemaRegistry()
    registry.register(SchemaDefinition("sample", "1.0.0", "SDL1", (FieldDefinition("id", "string", True), FieldDefinition("note", "string"))))
    registry.register(SchemaDefinition("sample", "1.1.0", "SDL1", (FieldDefinition("id", "string", True),)))
    comparison = registry.compare("sample", "1.0.0", "1.1.0")
    assert comparison["removed_fields"] == ["note"]
    assert comparison["potentially_breaking"] is True


def test_lineage_graph_detects_cycle_and_missing_parent():
    cycle = validate_lineage_graph([{"id": "a", "parents": ["b"]}, {"id": "b", "parents": ["a"]}])
    assert cycle["valid"] is False
    missing = validate_lineage_graph([{"id": "a", "parents": ["missing"]}])
    assert missing["issues"][0]["code"] == "missing_parent"


def test_lineage_trace_and_downstream_impact():
    nodes = [{"id": "raw", "kind": "raw"}, {"id": "clean", "kind": "dataset", "parents": ["raw"]},
             {"id": "model", "kind": "model", "parents": ["clean"]}, {"id": "report", "kind": "report", "parents": ["model"]}]
    trace = trace_to_roots("report", nodes)
    impact = downstream_impact("raw", nodes)
    assert trace["root_ids"] == ["raw"]
    assert impact["downstream_count"] == 3
    assert impact["downstream_by_kind"]["model"] == ["model"]


def test_lineage_source_comparison_does_not_claim_independence():
    result = compare_lineage_sources({"root_ids": ["a", "b"]}, {"root_ids": ["b", "c"]})
    assert result["shared_roots"] == ["b"]
    assert result["independence_assessed"] is False


def test_default_quality_engine_blocks_missing_sample_id():
    result = default_quality_engine().evaluate({"value": 1, "unit": "S/cm", "origin": "measured",
                                                "synthetic": False, "quality_status": "accepted"})
    assert result["training_eligible"] is False


def test_default_quality_engine_keeps_low_quality_as_warning_not_erasure():
    result = default_quality_engine().evaluate({"sample_id": "S1", "value": 1, "unit": "S/cm",
       "origin": "measured", "synthetic": False, "quality_status": "pending"})
    assert result["record_accepted"] is True
    assert result["training_eligible"] is True
    assert result["passed"] is False


def test_model_release_gate_requires_independent_reviewer_and_calibration():
    result = evaluate_release_gate(model={"synthetic": False, "status": "research_only", "supported_domains": ["inorganic_materials"]},
        evaluation={"status": "passed", "holdout_rows": 100, "uncertainty_calibrated": False,
                    "group_leakage_detected": False, "out_of_domain_fraction": 0, "benchmark_ids": ["B1"]},
        approvals=[], required_domains=["inorganic_materials"])
    assert result["eligible_for_review"] is False
    assert any("calibration" in blocker for blocker in result["blockers"])


def test_model_release_transition_requires_named_human_authorizer():
    with pytest.raises(ValueError):
        validate_release_transition("candidate", "production", gate_passed=True)
    good = validate_release_transition("candidate", "production", gate_passed=True, authorized_by="reviewer")
    assert good["valid"] is True


def test_challenger_comparison_checks_matching_scientific_task():
    result = compare_champion_challenger({"domain": "SDL1", "target": "sigma", "rmse": .2},
       {"domain": "SDL1", "target": "sigma", "rmse": .15}, metric="rmse")
    assert result["challenger_better"] is True
    with pytest.raises(ValueError):
        compare_champion_challenger({"domain": "SDL1", "target": "sigma", "rmse": .2},
           {"domain": "SDL4", "target": "sigma", "rmse": .15}, metric="rmse")


def test_agent_capacity_enforces_concurrency_rate_and_run_budgets():
    manager = LocalCapacityManager(); manager.register(AgentBudget("agent-a", max_concurrent=1, max_runs_per_window=2))
    first = manager.acquire("agent-a", now=datetime(2026, 1, 1, tzinfo=timezone.utc))
    second = manager.acquire("agent-a", now=datetime(2026, 1, 1, tzinfo=timezone.utc))
    assert first["granted"] is True and second["reason"] == "concurrency_limit"
    assert manager.enforce_run_budget("agent-a", token_count=1, tool_call_count=1)["allowed"] is True
    manager.release("agent-a")


def test_circuit_breaker_opens_and_half_open_probe_recovers():
    breaker = CircuitBreaker(CircuitState(failure_threshold=2, reset_after_seconds=10))
    now = datetime(2026, 1, 1, tzinfo=timezone.utc)
    breaker.record_failure(now=now); breaker.record_failure(now=now)
    assert breaker.permit(now=now)["allowed"] is False
    assert breaker.permit(now=now.replace(second=15))["state"] == "half_open"
    breaker.record_success()
    assert breaker.permit(now=now.replace(second=16))["state"] == "closed"


def test_workflow_compiler_enforces_lab_objective_consistency_and_review_gate():
    objective = {"objective_id": "OBJ1", "description": "screen materials", "target_properties": ["sigma"], "domain": "inorganic_materials"}
    result = compile_workflow(workflow_key="sdl1_material_screening", laboratory_code="SDL1",
                              domain="inorganic_materials", objective=objective)
    assert result["compiled_status"] == "awaiting_scientist_review"
    assert result["physical_execution"] is False
    with pytest.raises(ValueError):
        compile_workflow(workflow_key="sdl1_material_screening", laboratory_code="SDL4",
                         domain="polymers", objective=objective)


def test_advanced_scheduler_respects_dependencies_and_explains_assignments():
    jobs = [{"job_id": "child", "depends_on": ["parent"], "required_capabilities": ["xrd"], "duration_minutes": 20},
            {"job_id": "parent", "depends_on": [], "required_capabilities": ["prepare"], "duration_minutes": 10}]
    instruments = [{"instrument_id": "station-a", "capabilities": ["prepare", "xrd"]}]
    result = propose_schedule(jobs, instruments, start_at=datetime(2026,1,1,tzinfo=timezone.utc), buffer_minutes=0)
    indexed = {item["job_id"]: item for item in result["schedule"]}
    assert result["valid"] is True
    assert indexed["child"]["start_at"] >= indexed["parent"]["finish_at"]
    assert result["resource_reservations_created"] is False


def test_advanced_scheduler_rejects_cycles_and_missing_capabilities():
    cyc = propose_schedule([{ "job_id": "a", "depends_on": ["b"], "required_capabilities": ["x"], "duration_minutes": 2},
                            { "job_id": "b", "depends_on": ["a"], "required_capabilities": ["x"], "duration_minutes": 2}], [])
    assert cyc["valid"] is False
    blocked = propose_schedule([{ "job_id": "a", "depends_on": [], "required_capabilities": ["x"], "duration_minutes": 2}], [])
    assert blocked["valid"] is False
    dependency_blocked = propose_schedule([
        {"job_id": "root", "depends_on": [], "required_capabilities": ["missing"], "duration_minutes": 2},
        {"job_id": "child", "depends_on": ["root"], "required_capabilities": ["x"], "duration_minutes": 2},
    ], [{"instrument_id": "inst", "capabilities": ["x"]}])
    assert dependency_blocked["statuses"]["child"] == "blocked_by_dependency"


def test_science_calculator_and_schema_apis():
    with TestClient(app) as client:
        response = client.post("/api/science-calculators/electrochemistry/conductivity", json={"values": {"resistance_ohm": 100, "thickness_cm": .1, "area_cm2": 1}})
        assert response.status_code == 200
        assert response.json()["origin"] == "derived_computational_result"
        bragg = client.post("/api/science-calculators/diffraction/bragg", json={"values": {"two_theta_degrees": 30, "wavelength_angstrom": 1.5406}})
        assert bragg.status_code == 200
        assert bragg.json()["d_spacing_angstrom"] == pytest.approx(2.9762106559618773)
        invalid = client.post("/api/science-calculators/diffraction/bragg", json={"values": {"two_theta_degrees": 180, "wavelength_angstrom": 1.54}})
        assert invalid.status_code == 422
        contract = client.get("/api/science-foundations/measurement-contracts")
        assert contract.status_code == 200
        conversion = client.post("/api/science-foundations/units/convert", json={"value": 1, "source_unit": "S/cm", "target_unit": "S/m"})
        assert conversion.status_code == 200 and conversion.json()["normalized_value"] == pytest.approx(100)


def test_science_lineage_and_compiler_apis():
    with TestClient(app) as client:
        payload = {"nodes": [{"id": "a", "parents": []}, {"id": "b", "parents": ["a"]}]}
        assert client.post("/api/science-foundations/lineage/validate", json=payload).json()["valid"] is True
        compile_response = client.post("/api/science-foundations/workflow-compiler/compile", json={
            "workflow_key": "sdl1_material_screening", "laboratory_code": "SDL1", "domain": "inorganic_materials",
            "objective": {"objective_id": "OBJ-X", "description": "screen", "target_properties": ["ionic_conductivity"], "domain": "inorganic_materials"}
        })
        assert compile_response.status_code == 200
        assert compile_response.json()["physical_execution"] is False


def test_message_protocol_hashes_and_expiration():
    from app.services.agent_intelligence.message_protocol import create_message, validate_message
    now = datetime(2026, 1, 1, tzinfo=timezone.utc)
    message = create_message(message_id="M1", correlation_id="C1", sender_agent_id="A1",
        recipient_agent_id="A2", message_type="analysis_result", payload={"summary": "ok"}, now=now)
    result = validate_message(message, known_agents={"A1", "A2"}, now=now)
    assert result["valid"] is True
    expired = validate_message(message, known_agents={"A1", "A2"}, now=now.replace(day=2))
    assert "message_expired" in expired["issues"]


def test_message_protocol_rejects_self_message_and_oversize_payload():
    from app.services.agent_intelligence.message_protocol import create_message
    with pytest.raises(ValueError):
        create_message(message_id="M1", correlation_id="C1", sender_agent_id="A1",
                       recipient_agent_id="A1", message_type="challenge", payload={})
    with pytest.raises(ValueError):
        create_message(message_id="M2", correlation_id="C2", sender_agent_id="A1",
                       recipient_agent_id="A2", message_type="challenge", payload={"blob": "x" * 140000})


def test_message_loop_checker_reports_cycle_and_missing_parent():
    from app.services.agent_intelligence.message_protocol import create_message, detect_message_loop
    now = datetime(2026, 1, 1, tzinfo=timezone.utc)
    first = create_message(message_id="M1", correlation_id="C1", sender_agent_id="A", recipient_agent_id="B",
                           message_type="handoff", payload={}, parent_message_id="M2", now=now)
    second = create_message(message_id="M2", correlation_id="C1", sender_agent_id="B", recipient_agent_id="A",
                            message_type="handoff", payload={}, parent_message_id="M1", now=now)
    result = detect_message_loop([first, second])
    assert result["valid"] is False
    assert any(issue["code"] == "message_cycle" for issue in result["issues"])


def test_agent_dispatch_respects_capabilities_and_human_only_steps():
    from app.services.agent_intelligence.dispatch import rank_agent_candidates, compile_dispatch_plan
    agents = [{"id": "A1", "capabilities": ["formula_validation"], "domains": ["inorganic_materials"],
               "laboratory_code": "SDL1", "status": "idle", "permission_level": "propose_only"},
              {"id": "A2", "capabilities": ["formula_validation", "approve_physical_execution"],
               "domains": ["inorganic_materials"], "laboratory_code": "SDL1", "status": "idle"}]
    ranked = rank_agent_candidates({"required_capabilities": ["formula_validation"], "domain": "inorganic_materials", "laboratory_code": "SDL1"}, agents)
    assert [item["agent_id"] for item in ranked["ranked_agents"]] == ["A1"]
    plan = compile_dispatch_plan(tasks=[
        {"node_id": "check", "depends_on": [], "required_capabilities": ["formula_validation"]},
        {"node_id": "review", "depends_on": ["check"], "required_capabilities": ["human_review"], "execution_class": "human_review"},
    ], agents=agents, domain="inorganic_materials", laboratory_code="SDL1")
    assert plan["assignments"][1]["assignment_type"] == "human_review"
    assert plan["physical_execution_authorized"] is False


def test_scientific_review_aggregator_preserves_dissent():
    from app.services.agent_intelligence.consensus import aggregate_scientific_reviews, build_evidence_disagreement_matrix
    reviews = [
        {"reviewer_id": "R1", "decision": "support", "domain_expert": True, "evidence_refs": ["E1"], "rationale": "supports"},
        {"reviewer_id": "R2", "decision": "challenge", "domain_expert": False, "evidence_refs": ["E2"], "rationale": "conflict"},
    ]
    result = aggregate_scientific_reviews(reviews)
    assert result["outcome"] == "contested"
    assert result["dissent_preserved"] is True
    assert result["scientific_claim_status_changed"] is False
    assert build_evidence_disagreement_matrix(reviews)["dissent_visible"] is True


def test_scientific_review_aggregator_requires_distinct_expert_reviews():
    from app.services.agent_intelligence.consensus import aggregate_scientific_reviews
    result = aggregate_scientific_reviews([{"reviewer_id": "R1", "decision": "support", "domain_expert": True}])
    assert result["outcome"] == "insufficient_review"


def test_csv_preview_splits_reviewable_and_quarantined_rows():
    import csv
    import io
    from app.services.csv_ingestion import preview_measurement_csv
    stream = io.StringIO()
    writer = csv.writer(stream)
    writer.writerow(["sample_id", "property_name", "value", "unit", "origin", "synthetic", "context_json"])
    context = '{"temperature":300,"measurement_method":"EIS","instrument_id":"XRD-1"}'
    writer.writerow(["S1", "ionic_conductivity", "0.001", "S/cm", "measured", "false", context])
    writer.writerow(["S2", "ionic_conductivity", "0.002", "S/cm", "measured", "true", context])
    result = preview_measurement_csv(stream.getvalue(), domain="inorganic_materials", laboratory_code="SDL1")
    assert result["row_count"] == 2
    assert result["ready_for_review_count"] == 1
    assert result["quarantine_count"] == 1
    assert result["accepted_into_database"] is False


def test_csv_preview_rejects_missing_columns_and_bad_encoding():
    from app.services.csv_ingestion import preview_measurement_csv
    with pytest.raises(ValueError):
        preview_measurement_csv("sample_id,value\nS1,1", domain="inorganic_materials", laboratory_code="SDL1")
    with pytest.raises(ValueError):
        preview_measurement_csv(b"\xff", domain="inorganic_materials", laboratory_code="SDL1")


def test_dataset_audit_detects_duplicate_and_missing_sample_groups():
    from app.services.dataset_auditor import audit_training_records, audit_train_test_split
    records = [{"sample_id": "S1", "x": 1, "target": 2, "origin": "measured", "unit": "S/cm", "synthetic": False},
               {"sample_id": "S1", "x": 1, "target": 2, "origin": "measured", "unit": "S/cm", "synthetic": False},
               {"sample_id": "", "x": 3, "target": 4, "origin": "measured", "unit": "S/cm", "synthetic": False}]
    result = audit_training_records(records, feature_names=["x"], target_name="target")
    assert result["duplicate_record_count"] == 1
    assert result["training_ready"] is False
    split = audit_train_test_split([{"sample_id": "S1"}], [{"sample_id": "S1"}])
    assert split["leakage_detected"] is True


def test_dataset_audit_feature_drift_reports_recommendation():
    from app.services.dataset_auditor import compare_feature_distributions
    result = compare_feature_distributions([float(i) for i in range(20)], [float(i+50) for i in range(20)])
    assert result["drift_level"] == "high"
    assert result["automatic_model_update"] is False


def test_network_intelligence_apis():
    with TestClient(app) as client:
        ranked = client.post("/api/network-intelligence/agents/rank", json={
            "task": {"required_capabilities": ["formula_validation"], "domain": "inorganic_materials", "laboratory_code": "SDL1"},
            "agents": [{"id": "A1", "capabilities": ["formula_validation"], "domains": ["inorganic_materials"],
                        "laboratory_code": "SDL1", "status": "idle", "permission_level": "propose_only"}]
        })
        assert ranked.status_code == 200
        assert ranked.json()["ranked_agents"][0]["agent_id"] == "A1"
        csv_preview = client.post("/api/network-intelligence/data/csv-preview", json={
            "csv_text": 'sample_id,property_name,value,unit,origin,synthetic,context_json\nS1,ionic_conductivity,.001,S/cm,measured,false,""{""""temperature"""":300,""""measurement_method"""":""""EIS"""",""""instrument_id"""":""""I1""""}""',
            "domain": "inorganic_materials", "laboratory_code": "SDL1"
        })
        assert csv_preview.status_code == 200
        assert csv_preview.json()["accepted_into_database"] is False


def test_workflow_run_persists_hash_linked_checkpoints_and_recovery_plan():
    with TestClient(app) as client:
        created = client.post("/api/orchestration/runs", json={
            "workflow_key": "sdl1_candidate_review", "laboratory_code": "SDL1",
            "objective_id": "OBJ-0001", "subject_id": "MAT-00128",
            "context": {"intent": "checkpoint integration"}, "synthetic": True,
        })
        assert created.status_code == 201, created.text
        run_id = created.json()["id"]
        checkpoints = client.get(f"/api/orchestration/runs/{run_id}/checkpoints")
        assert checkpoints.status_code == 200, checkpoints.text
        payload = checkpoints.json()
        assert payload["valid"] is True
        assert payload["checkpoint_count"] == 7
        assert payload["nodes"][0]["node_id"] == "starting"
        assert payload["nodes"][-1]["status"] == "awaiting_scientist_review"
        assert all(node["physical_side_effects"] is False for node in payload["nodes"])
        recovery = client.post(f"/api/orchestration/runs/{run_id}/recovery-plan", json={
            "operator_requested": True,
        })
        assert recovery.status_code == 200
        assert recovery.json()["eligible"] is False
        assert recovery.json()["reason"] == "workflow_not_in_recoverable_state"


def test_checkpoint_hash_verification_detects_tampering():
    from types import SimpleNamespace
    from app.services.workflow_checkpoints import _canonical_hash, verify_checkpoint_chain
    row = SimpleNamespace(
        id="CP-1", workflow_run_id="WF-1", checkpoint_index=0,
        checkpoint_key="started", node_id="start", node_status="created",
        state_snapshot={"x": 1}, output_snapshot={}, idempotency_key="WF-1:0",
        previous_hash="", physical_side_effects=False,
    )
    body = {
        "workflow_run_id": row.workflow_run_id, "checkpoint_index": row.checkpoint_index,
        "checkpoint_key": row.checkpoint_key, "node_id": row.node_id,
        "node_status": row.node_status, "state_snapshot": row.state_snapshot,
        "output_snapshot": row.output_snapshot, "idempotency_key": row.idempotency_key,
        "previous_hash": row.previous_hash, "physical_side_effects": row.physical_side_effects,
    }
    row.checkpoint_hash = _canonical_hash(body)
    assert verify_checkpoint_chain([row])["valid"] is True
    row.state_snapshot = {"x": 2}
    result = verify_checkpoint_chain([row])
    assert result["valid"] is False
    assert result["issues"][0]["code"] == "content_hash_mismatch"


def test_campaign_requires_explicit_human_approval_before_launch():
    with TestClient(app) as client:
        created = client.post("/api/research-campaigns", json={
            "title": "SDL1 solid electrolyte programme", "laboratory_code": "SDL1",
            "objective_id": "OBJ-0001", "workflow_keys": ["sdl1_candidate_review"],
            "synthetic": True,
        })
        assert created.status_code == 201, created.text
        campaign_id = created.json()["id"]
        denied = client.post(f"/api/research-campaigns/{campaign_id}/launch-next-stage", json={})
        assert denied.status_code == 409
        approved = client.post(f"/api/research-campaigns/{campaign_id}/approve", json={
            "reviewer": "Dr. Reviewer", "note": "Approved for computational analysis only.",
        })
        assert approved.status_code == 200
        assert approved.json()["approval"]["authority"] == "human_reviewer"
        launched = client.post(f"/api/research-campaigns/{campaign_id}/launch-next-stage", json={
            "context": {"test_run": True},
        })
        assert launched.status_code == 200, launched.text
        payload = launched.json()
        assert payload["status"] == "awaiting_scientist_review"
        assert payload["execution_mode"] == "simulation_only"
        workflow_run_id = payload["stages"][0]["workflow_run_id"]
        assert workflow_run_id
        checkpoints = client.get(f"/api/orchestration/runs/{workflow_run_id}/checkpoints")
        assert checkpoints.status_code == 200
        assert checkpoints.json()["valid"] is True
        assert checkpoints.json()["checkpoint_count"] == 7


def test_campaign_stage_review_controls_the_next_stage():
    with TestClient(app) as client:
        create = client.post("/api/research-campaigns", json={
            "title": "Two-stage SDL1 study", "laboratory_code": "SDL1",
            "objective_id": "OBJ-0001",
            "workflow_keys": ["sdl1_candidate_review", "dataset_quality_review"],
        })
        assert create.status_code == 201, create.text
        cid = create.json()["id"]
        assert client.post(f"/api/research-campaigns/{cid}/approve", json={"reviewer": "Scientist"}).status_code == 200
        first = client.post(f"/api/research-campaigns/{cid}/launch-next-stage", json={})
        assert first.status_code == 200, first.text
        blocked = client.post(f"/api/research-campaigns/{cid}/launch-next-stage", json={})
        assert blocked.status_code == 409
        reviewed = client.post(f"/api/research-campaigns/{cid}/review-stage", json={
            "decision": "accepted", "reviewer": "Scientist", "note": "Evidence review acceptable.",
        })
        assert reviewed.status_code == 200, reviewed.text
        assert reviewed.json()["status"] == "approved"
        assert reviewed.json()["current_stage_index"] == 1
        second = client.post(f"/api/research-campaigns/{cid}/launch-next-stage", json={})
        assert second.status_code == 200, second.text
        assert second.json()["stages"][1]["status"] == "awaiting_scientist_review"
        final_review = client.post(f"/api/research-campaigns/{cid}/review-stage", json={
            "decision": "accepted", "reviewer": "Scientist", "note": "Dataset quality reviewed.",
        })
        assert final_review.status_code == 200
        assert final_review.json()["status"] == "completed"


def test_campaign_rejection_blocks_and_event_chain_is_verifiable():
    with TestClient(app) as client:
        create = client.post("/api/research-campaigns", json={
            "title": "Review rejection test", "laboratory_code": "SDL1", "objective_id": "OBJ-0001",
        })
        assert create.status_code == 201
        cid = create.json()["id"]
        client.post(f"/api/research-campaigns/{cid}/approve", json={"reviewer": "Reviewer"})
        client.post(f"/api/research-campaigns/{cid}/launch-next-stage", json={})
        rejected = client.post(f"/api/research-campaigns/{cid}/review-stage", json={
            "decision": "rejected", "reviewer": "Reviewer", "note": "Insufficient evidence.",
        })
        assert rejected.status_code == 200
        assert rejected.json()["status"] == "blocked"
        events = client.get(f"/api/research-campaigns/{cid}/events")
        assert events.status_code == 200
        assert events.json()["valid"] is True
        assert events.json()["event_count"] >= 4


def test_campaign_rejects_physical_execution_and_objective_domain_mismatch():
    with TestClient(app) as client:
        physical = client.post("/api/research-campaigns", json={
            "title": "Unsafe physical execution request", "laboratory_code": "SDL1",
            "objective_id": "OBJ-0001", "constraints": {"physical_execution": True},
        })
        assert physical.status_code == 422
        mismatch = client.post("/api/research-campaigns", json={
            "title": "Wrong lab objective", "laboratory_code": "SDL2",
            "objective_id": "OBJ-0001", "workflow_keys": ["cross_lab_evidence_review"],
        })
        assert mismatch.status_code == 422


def test_campaign_event_integrity_detects_tampering():
    from types import SimpleNamespace
    from app.services.research_campaigns import _hash, verify_campaign_events
    event = SimpleNamespace(
        id="EV-1", campaign_id="CAM-1", sequence=0,
        event_type="CAMPAIGN_CREATED", actor="test", payload={"synthetic": True},
        previous_hash="",
    )
    event.event_hash = _hash({
        "campaign_id": event.campaign_id, "sequence": event.sequence,
        "event_type": event.event_type, "actor": event.actor,
        "payload": event.payload, "previous_hash": event.previous_hash,
    })
    assert verify_campaign_events([event])["valid"] is True
    event.payload = {"synthetic": False}
    assert verify_campaign_events([event])["valid"] is False


def test_benchmark_catalogue_covers_all_eight_laboratories():
    from app.services.agent_benchmark_suites import list_benchmark_suites
    suites = list_benchmark_suites()
    assert [row["laboratory_code"] for row in suites] == [f"SDL{i}" for i in range(8)]
    assert all(row["case_count"] == 3 for row in suites)
    assert all(row["scientific_correctness_requires_human_adjudication"] for row in suites)


def test_domain_benchmark_scores_schema_and_evidence_without_fabricating_accuracy():
    from app.services.agent_benchmark_suites import score_benchmark_case
    output = {
        "formula_valid": True, "element_counts": {"Li": 7, "La": 3, "Zr": 2, "O": 12},
        "parser_limitations": ["Formal charge omitted"],
        "formula_source_ref": "artifact://raw-formula-1",
        "physical_execution_authorized": False,
    }
    result = score_benchmark_case(case_id="SDL1-COMP-001", output=output)
    assert result["passed_automated_checks"] is True
    assert result["scientific_correctness"] is None
    assert result["scientific_correctness_claimed_by_automation"] is False
    assert result["automated_metrics"]["evidence_attribution"] == 1.0


def test_benchmark_human_adjudication_requires_named_reviewer():
    from app.services.agent_benchmark_suites import score_benchmark_case
    with pytest.raises(ValueError):
        score_benchmark_case(case_id="SDL1-COMP-001", output={
            "formula_valid": True, "element_counts": {"Li": 1},
            "parser_limitations": ["none"], "formula_source_ref": "ref",
            "physical_execution_authorized": False,
        }, scientific_adjudication="correct")


def test_benchmark_aggregation_never_grants_production_promotion():
    from app.services.agent_benchmark_suites import score_benchmark_case, aggregate_benchmark_results
    cases = [
        ("SDL1-COMP-001", {"formula_valid": True, "element_counts": {"Li": 1},
          "parser_limitations": ["none"], "formula_source_ref": "ref", "physical_execution_authorized": False}),
        ("SDL1-XRD-002", {"peak_matches": [{"observed": 20.0, "reference": 20.0}], "reference_coverage": 0.5,
          "phase_claim_limitations": ["screening only"], "pattern_artifact_ref": "p", "reference_pattern_ref": "r",
          "phase_identification_confirmed": False}),
        ("SDL1-EIS-003", {"conductivity_value": 0.001, "conductivity_unit": "S/cm",
          "temperature_k": 300, "uncertainty": 0.0001, "sample_id": "S1",
          "instrument_id": "I1", "raw_artifact_ref": "A1", "origin": "derived_computational_result"}),
    ]
    results = [score_benchmark_case(case_id=case_id, output=output,
               scientific_adjudication="correct", reviewer="Materials scientist")
               for case_id, output in cases]
    aggregate = aggregate_benchmark_results(agent_id="AG-TEST", benchmark_id="SDL1-TEST",
                                            case_results=results, minimum_cases=3)
    assert aggregate["promotion_recommendation"] == "eligible_for_shadow_deployment_review"
    assert aggregate["production_promotion"] is False


def test_benchmark_aggregate_blocks_missing_human_scientific_review():
    from app.services.agent_benchmark_suites import score_benchmark_case, aggregate_benchmark_results
    result = score_benchmark_case(case_id="SDL1-COMP-001", output={
        "formula_valid": True, "element_counts": {"Li": 1},
        "parser_limitations": ["none"], "formula_source_ref": "ref",
        "physical_execution_authorized": False,
    })
    aggregate = aggregate_benchmark_results(agent_id="AG-TEST", benchmark_id="SDL1-TEST",
                                            case_results=[result], minimum_cases=1)
    assert aggregate["promotion_recommendation"] == "hold_for_review"
    assert aggregate["human_adjudicated_case_count"] == 0


def test_benchmark_api_exposes_case_validation_and_review_aggregation():
    with TestClient(app) as client:
        suites = client.get("/api/benchmark-intelligence/suites")
        assert suites.status_code == 200
        assert len(suites.json()) == 8
        score = client.post("/api/benchmark-intelligence/score-case", json={
            "case_id": "SDL1-COMP-001", "output": {
                "formula_valid": True, "element_counts": {"Li": 1},
                "parser_limitations": ["formal charge omitted"],
                "formula_source_ref": "artifact://formula-1",
                "physical_execution_authorized": False,
            },
        })
        assert score.status_code == 200, score.text
        assert score.json()["scientific_correctness"] is None


def test_outbox_requires_claim_token_and_dead_letters_after_retry_limit():
    from uuid import uuid4
    from app.core.database import SessionLocal
    from app.services.event_outbox import enqueue_event
    with TestClient(app) as client:
        db = SessionLocal()
        try:
            event = enqueue_event(db, event_key=f"TEST-{uuid4().hex}",
                aggregate_type="test", aggregate_id="A1", event_type="TEST_EVENT",
                payload={"value": 1})
            event_id = event.id
            db.commit()
        finally:
            db.close()
        batch = client.post(f"/api/outbox/{event_id}/prepare", json={"max_attempts": 1})
        assert batch.status_code == 200, batch.text
        item = batch.json()
        no_token = client.post(f"/api/outbox/{event_id}/acknowledge", json={"success": True})
        assert no_token.status_code == 409
        failed = client.post(f"/api/outbox/{event_id}/acknowledge", json={
            "success": False, "error": "synthetic transport failure",
            "claim_token": item["claim_token"],
        })
        assert failed.status_code == 200, failed.text
        assert failed.json()["status"] == "dead_letter"
        metrics = client.get("/api/outbox/metrics")
        assert metrics.status_code == 200
        assert metrics.json()["dead_letter_count"] >= 1


def test_outbox_rejects_invalid_delivery_parameters_and_parses_false_correctly():
    from uuid import uuid4
    from app.core.database import SessionLocal
    from app.services.event_outbox import enqueue_event
    with TestClient(app) as client:
        db = SessionLocal()
        try:
            event = enqueue_event(db, event_key=f"VALIDATION-{uuid4().hex}",
                aggregate_type="test", aggregate_id="A1", event_type="VALIDATION_TEST",
                payload={"value": 1})
            event_id = event.id
            db.commit()
        finally:
            db.close()
        invalid_prepare = client.post(f"/api/outbox/{event_id}/prepare", json={"lease_seconds": 1})
        assert invalid_prepare.status_code == 422
        invalid_ack = client.post(f"/api/outbox/{event_id}/acknowledge", json={"success": "not-a-bool"})
        assert invalid_ack.status_code == 422
        missing_success = client.post(f"/api/outbox/{event_id}/acknowledge", json={})
        assert missing_success.status_code == 422


def test_outbox_expired_lease_is_requeued_without_claiming_delivery_success():
    from uuid import uuid4
    from datetime import datetime, timedelta, timezone
    from app.core.database import SessionLocal
    from app.services.event_outbox import enqueue_event
    from app.models.entities import OutboxEvent
    with TestClient(app) as client:
        db = SessionLocal()
        try:
            event = enqueue_event(db, event_key=f"LEASE-{uuid4().hex}",
                aggregate_type="test", aggregate_id="A2", event_type="LEASE_TEST",
                payload={"value": 2})
            event_id = event.id
            db.commit()
        finally:
            db.close()
        batch = client.post(f"/api/outbox/{event_id}/prepare", json={"max_attempts": 5})
        assert batch.status_code == 200, batch.text
        item = batch.json()
        db = SessionLocal()
        try:
            row = db.get(OutboxEvent, event_id)
            payload = dict(row.payload)
            meta = dict(payload.get("_nexus_delivery") or {})
            meta["lease_expires_at"] = (datetime.now(timezone.utc) - timedelta(minutes=2)).isoformat()
            payload["_nexus_delivery"] = meta
            row.payload = payload
            db.commit()
        finally:
            db.close()
        recovered = client.post("/api/outbox/recover-expired-leases", json={"max_attempts": 5})
        assert recovered.status_code == 200
        assert recovered.json()["requeued"] >= 1
        db = SessionLocal()
        try:
            row = db.get(OutboxEvent, event_id)
            assert row.status == "delivery_failed"
            assert row.published_at is None
        finally:
            db.close()


def test_outbox_exponential_backoff_policy_persists_across_reclaims():
    from uuid import uuid4
    from datetime import datetime, timedelta, timezone
    from app.core.database import SessionLocal
    from app.models.entities import OutboxEvent
    from app.services.event_outbox import enqueue_event
    with TestClient(app) as client:
        db = SessionLocal()
        try:
            event = enqueue_event(db, event_key=f"BACKOFF-{uuid4().hex}",
                aggregate_type="test", aggregate_id="A3", event_type="BACKOFF_TEST",
                payload={"value": 3})
            event_id = event.id
            db.commit()
        finally:
            db.close()
        first = client.post(f"/api/outbox/{event_id}/prepare", json={
            "max_attempts": 3, "base_backoff_seconds": 2,
        })
        assert first.status_code == 200, first.text
        failed_once = client.post(f"/api/outbox/{event_id}/acknowledge", json={
            "success": False, "error": "first transient failure",
            "claim_token": first.json()["claim_token"],
        })
        assert failed_once.status_code == 200
        assert failed_once.json()["status"] == "delivery_failed"
        assert failed_once.json()["payload"]["_nexus_delivery"]["next_retry_delay_seconds"] == 2
        db = SessionLocal()
        try:
            row = db.get(OutboxEvent, event_id)
            payload = dict(row.payload)
            meta = dict(payload["_nexus_delivery"])
            meta["retry_at"] = (datetime.now(timezone.utc) - timedelta(seconds=1)).isoformat()
            payload["_nexus_delivery"] = meta
            row.payload = payload
            db.commit()
        finally:
            db.close()
        second = client.post(f"/api/outbox/{event_id}/prepare", json={
            "max_attempts": 5, "base_backoff_seconds": 30,
        })
        assert second.status_code == 200, second.text
        assert second.json()["attempt"] == 2
        failed_twice = client.post(f"/api/outbox/{event_id}/acknowledge", json={
            "success": False, "error": "second transient failure",
            "claim_token": second.json()["claim_token"],
        })
        assert failed_twice.status_code == 200
        metadata = failed_twice.json()["payload"]["_nexus_delivery"]
        assert metadata["next_retry_delay_seconds"] == 4
        assert metadata["max_attempts"] == 3
