"""Regression and integration tests for the NEXUS science-engine extension."""
from uuid import uuid4
import pytest
from fastapi.testclient import TestClient

from app.main import app
from app.services.model_intelligence.composition import parse_formula, composition_descriptors, FormulaError
from app.services.model_intelligence.metrics import regression_metrics, interval_metrics
from app.services.model_intelligence.splits import group_holdout_indices
from app.services.model_intelligence.ridge import RidgeBaseline
from app.services.model_intelligence.evaluation.conformal import fit_absolute_residual_calibrator, apply_conformal_interval
from app.services.model_intelligence.evaluation.ood import fit_applicability_reference, score_applicability
from app.services.model_intelligence.evaluation.ensemble import aggregate_ensemble
from app.services.model_intelligence.modalities.spectral import detect_peak_candidates, integrate_spectrum
from app.services.model_intelligence.modalities.timeseries import temporal_descriptors
from app.services.model_intelligence.modalities.imaging import measure_binary_mask
from app.services.model_intelligence.modalities.fusion import fuse_modalities
from app.services.agent_intelligence.task_graph import compile_task_graph, ready_nodes
from app.services.agent_intelligence.retry_policy import plan_retry, idempotency_key
from app.services.agent_intelligence.output_validation import validate_agent_output
from app.services.agent_intelligence.debate import compose_scientific_debate
from app.services.agent_intelligence.permissions import authorize_agent_action
from app.services.experimental_design import full_factorial_design
from app.services.multiobjective import pareto_front, weighted_score
from app.services.sensor_intelligence import review_timeseries
from app.services.sensor_clock_alignment import estimate_clock_transform
from app.services.data_drift import population_stability_index
from app.services.reproducibility import summarize_replicates, reproducibility_gate
from app.services.digital_twin_validation import validate_twin_predictions
from app.services.workflow_recovery import assess_recovery
from app.services.failure_intelligence import triage_failure
from app.services.protocol_validation import validate_protocol_manifest
from app.services.cross_lab_transfer import assess_transfer


def test_fractional_and_nested_composition_formula_parsing():
    parsed = parse_formula("Li1.3Al0.3Ti1.7(PO4)3")
    assert parsed["Li"] == pytest.approx(1.3)
    assert parsed["O"] == pytest.approx(12.0)
    assert parsed["P"] == pytest.approx(3.0)
    descriptor = composition_descriptors("Li7La3Zr2O12")
    assert descriptor["element_count"] == 4
    assert descriptor["fraction_Li"] > 0


def test_formula_parser_rejects_charge_and_unknown_elements():
    with pytest.raises(FormulaError):
        parse_formula("Li7La3Zr2O12+")
    with pytest.raises(FormulaError):
        parse_formula("Xx2O3")
    with pytest.raises(FormulaError, match="Parenthesized groups"):
        parse_formula("Al()3")


def test_group_split_prevents_sample_leakage():
    groups = ["A", "A", "B", "B", "C", "C", "D", "D", "E", "E"]
    train, test = group_holdout_indices(groups, test_fraction=0.2, seed=4)
    assert {groups[i] for i in train}.isdisjoint({groups[i] for i in test})
    assert train and test


def test_ridge_baseline_fit_and_roundtrip():
    rows = [{"x": float(i), "z": float(i % 2)} for i in range(12)]
    targets = [2 * row["x"] + 3 * row["z"] + 1 for row in rows]
    model = RidgeBaseline.fit(rows, targets, alpha=0.01)
    result = model.predict({"x": 13.0, "z": 1.0})
    assert result["value"] == pytest.approx(30.0, abs=0.2)
    restored = RidgeBaseline.from_dict(model.to_dict())
    assert restored.predict({"x": 13.0, "z": 1.0})["value"] == pytest.approx(result["value"])


def test_ridge_rejects_feature_schema_mismatch():
    model = RidgeBaseline.fit([{"x": i, "y": i * 2} for i in range(5)], [i * 3 for i in range(5)])
    with pytest.raises(ValueError):
        model.predict({"x": 1.0})


def test_regression_metrics_known_values():
    result = regression_metrics([1, 2, 3], [1, 2, 4])
    assert result["mae"] == pytest.approx(1 / 3)
    assert result["rmse"] == pytest.approx((1 / 3) ** 0.5)
    assert result["r2"] < 1


def test_conformal_interval_and_coverage():
    calibrator = fit_absolute_residual_calibrator([1, 2, 3, 4, 5, 6, 7, 8], [1, 1, 3, 3, 5, 5, 7, 7], alpha=0.2)
    interval = apply_conformal_interval(4, calibrator)
    assert interval["lower"] < 4 < interval["upper"]
    assert interval_metrics([1, 2], [1, 4], [0.1, 0.1])["undercoverage_count"] == 1


def test_ood_reference_and_flag():
    rows = [{"a": float(i), "b": float(i * 2)} for i in range(10)]
    reference = fit_applicability_reference(rows, ["a", "b"])
    within = score_applicability({"a": 4.5, "b": 9.0}, reference)
    outside = score_applicability({"a": 100, "b": 200}, reference)
    assert within["applicable"] is True
    assert outside["applicable"] is False


def test_ensemble_exposes_disagreement():
    result = aggregate_ensemble([
        {"target": "conductivity", "unit": "S/cm", "value": 0.1, "uncertainty": 0.01},
        {"target": "conductivity", "unit": "S/cm", "value": 0.2, "uncertainty": 0.02},
    ])
    assert result["between_model_standard_deviation"] > 0
    assert result["member_count"] == 2


def test_spectral_peak_candidates_and_integral():
    x = list(range(11))
    y = [0, 0, 0, 1, 4, 1, 0, 0, 3, 0, 0]
    result = detect_peak_candidates(x, y, threshold=0.5)
    assert result["count"] >= 1
    assert integrate_spectrum(x, y) > 0


def test_timeseries_temporal_descriptors():
    result = temporal_descriptors([{"timestamp": float(i), "value": float(i * 2)} for i in range(5)])
    assert result["point_count"] == 5
    assert result["mean_slope_per_second"] == pytest.approx(2.0)


def test_mask_morphometry():
    result = measure_binary_mask([[0, 1, 1], [0, 1, 0]], pixel_size=0.5)
    assert result["foreground_pixel_count"] == 3
    assert result["area"] == pytest.approx(0.75)
    assert result["centroid"] is not None


def test_multimodal_fusion_requires_same_sample_identity():
    with pytest.raises(ValueError):
        fuse_modalities({"spectral": {"sample_id": "A", "features": {"peak": 2}},
                         "image": {"sample_id": "B", "features": {"area": 3}}},
                        required_modalities=["spectral", "image"])
    result = fuse_modalities({"spectral": {"sample_id": "A", "features": {"peak": 2}, "artifact_refs": ["ART-1"]}},
                             required_modalities=["spectral", "image"], allow_missing=True)
    assert result["modalities_missing"] == ["image"]


def test_task_graph_topological_order_and_cycle_rejection():
    graph = compile_task_graph([
        {"node_id": "a", "depends_on": []},
        {"node_id": "b", "depends_on": ["a"]},
        {"node_id": "c", "depends_on": ["a"]},
    ])
    assert graph["topological_order"][0] == "a"
    assert ready_nodes([{"node_id": "a", "depends_on": []}, {"node_id": "b", "depends_on": ["a"]}], set()) == ["a"]
    with pytest.raises(ValueError):
        compile_task_graph([{"node_id": "a", "depends_on": ["b"]}, {"node_id": "b", "depends_on": ["a"]}])


def test_retry_policy_forbids_physical_retry():
    assert plan_retry(failure_code="timeout", attempt=1)["retry_allowed"] is True
    assert plan_retry(failure_code="timeout", attempt=1, task_kind="instrument_command")["retry_allowed"] is False
    assert plan_retry(failure_code="safety_interlock_open", attempt=1)["retry_allowed"] is False


def test_idempotency_key_is_stable_and_context_sensitive():
    first = idempotency_key(workflow_id="W1", node_id="N1", input_contract={"x": 1})
    second = idempotency_key(workflow_id="W1", node_id="N1", input_contract={"x": 1})
    third = idempotency_key(workflow_id="W1", node_id="N1", input_contract={"x": 2})
    assert first == second and first != third


def test_agent_output_must_cite_known_evidence_and_limitations():
    good = {"handler": "deterministic_demo_adapter", "synthetic": True, "findings": []}
    assert validate_agent_output(good, allowed_evidence_refs=set())["valid"]
    bad = {"physical_execution_authorized": True, "findings": [{
        "finding_type": "observation", "summary": "x", "confidence": 1.2,
        "evidence_refs": ["unknown"], "limitations": [],
    }]}
    assert not validate_agent_output(bad, allowed_evidence_refs=set())["valid"]


def test_scientific_debate_preserves_disagreement():
    result = compose_scientific_debate(
        proposition="A testable proposition",
        positions=[{"agent_id": "A", "stance": "supports", "argument": "Some evidence", "evidence_refs": ["E1"], "limitations": ["limited"]},
                   {"agent_id": "B", "stance": "opposes", "argument": "Alternative explanation", "evidence_refs": ["E1"], "limitations": ["limited"]}],
        allowed_evidence_refs={"E1"})
    assert result["consensus_detected"] is False
    assert result["winner_selected"] is False


def test_agent_permission_policy_blocks_human_authority():
    assert authorize_agent_action(permission_level="simulate", action="simulate")["authorized"]
    assert not authorize_agent_action(permission_level="simulate", action="approve_experiment")["authorized"]


def test_full_factorial_design_respects_run_limit():
    result = full_factorial_design([{"name": "a", "levels": [0, 1]}, {"name": "b", "levels": [10, 20]}], center_points=1)
    assert result["run_count"] == 5
    with pytest.raises(ValueError):
        full_factorial_design([{"name": "a", "levels": [0, 1]}] * 9, maximum_runs=1000, center_points=0)


def test_pareto_front_and_weighted_score():
    result = pareto_front([
        {"id": "A", "values": {"quality": 9, "cost": 5}},
        {"id": "B", "values": {"quality": 8, "cost": 7}},
        {"id": "C", "values": {"quality": 6, "cost": 10}},
    ], {"quality": "maximize", "cost": "minimize"})
    assert {item["id"] for item in result["pareto_front"]} == {"A"}
    score = weighted_score({"quality": 8, "cost": 4}, {"quality": (0, 10), "cost": (0, 10)},
                           {"quality": "maximize", "cost": "minimize"}, {"quality": 0.7, "cost": 0.3})
    assert score["score"] == pytest.approx(0.74)


def test_sensor_intelligence_detects_gap_and_returns_review_only():
    points = [{"timestamp": float(i * 10), "value": 1.0, "sensor_id": "S1", "unit": "C"} for i in range(20)]
    points[10]["timestamp"] = 300.0
    result = review_timeseries(points, expected_interval_seconds=10)
    assert result["gap_after_indices"]
    assert result["action"] == "review_only_no_equipment_control"


def test_clock_alignment_estimates_affine_transform():
    beacons = [{"sensor_id": "S1", "sensor_time": float(i), "reference_time": 2 * i + 5} for i in range(5)]
    result = estimate_clock_transform(beacons)
    assert result["affine_clock_transform"]["scale"] == pytest.approx(2)
    assert result["affine_clock_transform"]["offset_seconds"] == pytest.approx(5)
    assert result["raw_timestamps_modified"] is False


def test_psi_increases_with_distribution_shift():
    reference = [float(i) for i in range(30)]
    current = [float(i + 100) for i in range(30)]
    result = population_stability_index(reference, current)
    assert result["psi"] > 0.25


def test_reproducibility_summary_exposes_independent_sample_counts():
    rows = [{"condition_id": "C1", "value": value, "sample_id": f"S{index}", "method_id": "M1"}
            for index, value in enumerate([1.0, 1.1, 0.9])]
    result = summarize_replicates(rows)
    assert result["independent_sample_count"] == 3
    assert reproducibility_gate(result, minimum_replicates=3)["passed"]


def test_digital_twin_validation_blocks_domain_mismatch():
    result = validate_twin_predictions([1, 2, 3], [1, 2, 3], validation_domain="SDL4", declared_domain="SDL1")
    assert result["valid_for_domain"] is False
    assert result["deployment_recommendation"] == "block"


def test_workflow_recovery_never_authorizes_physical_resume():
    physical = assess_recovery({"execution_mode": "physical", "sample_identity_status": "verified",
                               "safety_interlock_state": "verified_local", "protocol_version": "1.0"})
    assert physical["recoverable"] is False
    assert physical["physical_execution_authorized"] is False


def test_failure_triage_keeps_root_cause_unverified():
    result = triage_failure(experiment_id="E1", observed_signals=["calibration_expired"], evidence_refs=["A1"])
    assert result["candidate_explanations"][0]["status"] == "plausible_explanation_not_verified"
    assert result["automatic_retry"] is False


def test_protocol_manifest_cannot_enable_hardware():
    result = validate_protocol_manifest({"protocol_id": "P1", "version": "1", "laboratory_code": "SDL1",
                                         "domain": "inorganic_materials", "owner": "Scientist", "purpose": "Test",
                                         "required_capabilities": ["x"], "required_approvals": ["human"],
                                         "expected_outputs": ["data"], "physical_execution_enabled": True})
    assert result["valid"] is False
    assert result["physical_execution_enabled"] is False


def test_cross_lab_transfer_requires_provenance_context():
    incomplete = assess_transfer("SDL1", "SDL7", "inorganic_materials", {"evidence_origin": "measured"})
    assert incomplete["compatible_for_review"] is False
    complete = assess_transfer("SDL1", "SDL7", "inorganic_materials", {
        "evidence_origin": "measured", "provenance_refs": ["M1"],
        "uncertainty": {"value": 0.1}, "measurement_context": {"temperature": 300},
    })
    assert complete["compatible_for_review"] is True
    assert complete["scientific_reuse_allowed"] is False


def test_workflow_supervisor_runs_review_graph_without_physical_execution():
    with TestClient(app) as client:
        response = client.post("/api/orchestration/runs", json={
            "workflow_key": "sdl1_candidate_review", "laboratory_code": "SDL1",
            "objective_id": "OBJ-0001", "subject_id": "MAT-00128",
            "context": {"intent": "review candidate"}, "synthetic": True,
        })
        assert response.status_code == 201, response.text
        payload = response.json()
        assert payload["status"] == "awaiting_scientist_review"
        assert len(payload["node_history"]) == 5
        assert payload["state"]["physical_execution_authorized"] is False


def test_new_research_intelligence_api_routes_are_wired():
    with TestClient(app) as client:
        design = client.post("/api/research-intelligence/design/full-factorial", json={
            "factors": [{"name": "factor_a", "levels": [0, 1]}, {"name": "factor_b", "levels": [10, 20]}],
            "maximum_runs": 10, "center_points": 1,
        })
        assert design.status_code == 200, design.text
        assert design.json()["design"]["run_count"] == 5
        domains = client.post("/api/research-intelligence/domains/SDL1/validate", json={
            "payload": {"formula": "Li7La3Zr2O12", "sample_id": "S1"}
        })
        assert domains.status_code == 200
        assert domains.json()["domain_validation"]["valid"] is True


def test_scientific_source_and_claim_review_is_evidence_linked():
    with TestClient(app) as client:
        doi = f"10.1234/nexus.test.{uuid4().hex[:8]}"
        source = client.post("/api/research-sources", json={"title": "A synthetic test citation record", "doi": doi,
            "publication_year": 2024, "synthetic": True})
        assert source.status_code == 201, source.text
        source_id = source.json()["id"]
        claim = client.post("/api/research-sources/claims", json={
            "claim_key": f"CLAIM-{uuid4().hex[:8]}", "statement": "The registered synthetic source contains this reviewable statement.",
            "domain": "inorganic_materials", "laboratory_code": "SDL1", "claim_type": "literature_claim",
            "support_refs": [source_id], "limitations": ["Synthetic test record"], "synthetic": True,
        })
        assert claim.status_code == 201, claim.text
        reviewed = client.post(f"/api/research-sources/claims/{claim.json()['id']}/review", json={
            "decision": "supported_for_review", "reviewer": "Test reviewer", "note": "Review completed for API test.",
            "checked_refs": [source_id],
        })
        assert reviewed.status_code == 409
        verified_source = client.post(f"/api/research-sources/{source_id}/verify", json={
            "reviewer": "Metadata reviewer", "verification_refs": ["external-metadata-check-001"],
            "note": "Bibliographic metadata checked against the registered publisher record.",
        })
        assert verified_source.status_code == 200
        accepted = client.post(f"/api/research-sources/claims/{claim.json()['id']}/review", json={
            "decision": "supported_for_review", "reviewer": "Test reviewer", "note": "Review completed for API test.",
            "checked_refs": [source_id],
        })
        assert accepted.status_code == 200, accepted.text


def test_agent_run_history_endpoint_records_deterministic_task():
    with TestClient(app) as client:
        agent = client.get("/api/agents").json()
        target = next(item for item in agent if item["name"] == "Composition Validator")
        result = client.post("/api/agent-runtime/tasks", json={
            "agent_id": target["id"], "task_type": "validate_composition",
            "input_contract": {"formula": "Li7La3Zr2O12"}, "correlation_id": "TEST-CORR-1",
        })
        assert result.status_code == 201, result.text
        assert result.json()["status"] == "completed"
        history = client.get("/api/agent-runtime/runs?agent_id=" + target["id"]).json()
        assert any(item["correlation_id"] == "TEST-CORR-1" for item in history)
