# NEXUS Specialist Agent Registry

The starter seeds 100 specialist **capability profiles** across ten departments. Each profile has a bounded responsibility, domain association, and declared capability tags. They are not 100 separately deployed foundation models or concurrently running agents.

A profile can be bound to a validated model/tool implementation later. Agent execution in the current starter is deterministic demo behavior and must not be interpreted as completed scientific analysis.

| # | Agent | Department | Lab | Responsibility |
|---:|---|---|---|---|
| 001 | Research Intelligence | Scientific Research | SDL0 | Retrieve and structure literature evidence |
| 002 | Hypothesis Generation | Scientific Research | SDL0 | Draft falsifiable, evidence-linked hypotheses |
| 003 | Scientific Debate | Scientific Research | SDL0 | Compare competing mechanisms and expose disagreement |
| 004 | Objective Compiler | Scientific Research | SDL0 | Translate natural-language goals into versioned objective contracts |
| 005 | Research Gap Mapper | Scientific Research | SDL0 | Locate underexplored questions and contradictory results |
| 006 | Evidence Grader | Scientific Research | SDL0 | Assign field-specific evidence review labels |
| 007 | Mechanism Reasoner | Scientific Research | SDL0 | Connect structures, mechanisms, observables, and performance |
| 008 | Scientific Reviewer | Scientific Research | SDL0 | Check whether claims are supported by records |
| 009 | Discovery Radar | Scientific Research | SDL0 | Rank research opportunities for scientist review |
| 010 | Report Synthesizer | Scientific Research | SDL0 | Prepare traceable experiment and discovery reports |
| 011 | Crystal Structure Parser | Materials Discovery | SDL1 | Validate and normalize crystal structure records |
| 012 | Composition Validator | Materials Discovery | SDL1 | Check formula syntax and composition constraints |
| 013 | Defect Chemistry Analyst | Materials Discovery | SDL1 | Organize defect hypotheses and charge-compensation evidence |
| 014 | Ionic Transport Modeler | Materials Discovery | SDL1 | Manage ionic transport predictions and uncertainty |
| 015 | Phase Stability Analyst | Materials Discovery | SDL1 | Compare phase stability evidence and model outputs |
| 016 | Battery Interface Analyst | Materials Discovery | SDL1 | Track interface compatibility hypotheses |
| 017 | Catalysis Surface Analyst | Materials Discovery | SDL1 | Structure adsorption and surface-reaction evidence |
| 018 | Materials Candidate Ranker | Materials Discovery | SDL1 | Rank candidates under explicit multi-objective weights |
| 019 | Synthesis Feasibility Reviewer | Materials Discovery | SDL1 | Flag missing synthesis and processing evidence |
| 020 | Materials Evidence Curator | Materials Discovery | SDL1 | Maintain material-to-measurement traceability |
| 021 | Molecular Structure Validator | Organic Chemistry | SDL2 | Validate molecular graph representations |
| 022 | Reaction Classifier | Organic Chemistry | SDL2 | Classify reaction records and mechanism families |
| 023 | Retrosynthesis Planner | Organic Chemistry | SDL2 | Propose routes for chemist review |
| 024 | Reaction Condition Analyst | Organic Chemistry | SDL2 | Compare condition and outcome metadata |
| 025 | Molecular Property Estimator | Organic Chemistry | SDL2 | Manage molecular property prediction outputs |
| 026 | Reaction Outcome Analyst | Organic Chemistry | SDL2 | Analyze reported reaction outcomes and controls |
| 027 | Purification Intelligence | Organic Chemistry | SDL2 | Track purification stages and recovery evidence |
| 028 | Spectral Assignment Assistant | Organic Chemistry | SDL2 | Link spectral features to reviewed assignments |
| 029 | Synthesis Failure Analyst | Organic Chemistry | SDL2 | Classify failed and incomplete synthesis records |
| 030 | Molecule Registry Curator | Organic Chemistry | SDL2 | Maintain compound identity and batch lineage |
| 031 | Target Evidence Curator | Medicinal Chemistry | SDL3 | Organize target biology and assay provenance |
| 032 | Binding Model Analyst | Medicinal Chemistry | SDL3 | Keep docking predictions distinct from measured affinity |
| 033 | SAR Analyst | Medicinal Chemistry | SDL3 | Compare matched molecular pairs and structure–activity data |
| 034 | Activity Cliff Detector | Medicinal Chemistry | SDL3 | Flag abrupt activity changes among similar molecules |
| 035 | Assay Quality Reviewer | Medicinal Chemistry | SDL3 | Check assay variability and control records |
| 036 | Selectivity Analyst | Medicinal Chemistry | SDL3 | Compare selectivity panels with uncertainty |
| 037 | ADME Evidence Analyst | Medicinal Chemistry | SDL3 | Organize absorption, distribution, metabolism, and excretion data |
| 038 | Cellular Response Analyst | Medicinal Chemistry | SDL3 | Track cellular response measurements and caveats |
| 039 | Medicinal Candidate Reviewer | Medicinal Chemistry | SDL3 | Summarize scientific evidence without clinical claims |
| 040 | Bioactivity Dataset Curator | Medicinal Chemistry | SDL3 | Version bioactivity datasets and provenance |
| 041 | Polymer Representation Parser | Polymer Science | SDL4 | Validate polymer composition and architecture records |
| 042 | Molecular Weight Analyst | Polymer Science | SDL4 | Track molecular-weight distributions and measurement methods |
| 043 | Rheology Analyst | Polymer Science | SDL4 | Interpret rheology datasets with method metadata |
| 044 | Thermal Characterization Analyst | Polymer Science | SDL4 | Organize thermal transitions and stability evidence |
| 045 | Crystallization Analyst | Polymer Science | SDL4 | Link crystallization behavior to process conditions |
| 046 | Phase Separation Analyst | Polymer Science | SDL4 | Track morphology and phase-behavior observations |
| 047 | Mechanical Property Analyst | Polymer Science | SDL4 | Compare mechanical response by test conditions |
| 048 | Polymer Degradation Analyst | Polymer Science | SDL4 | Track degradation mechanisms and aging experiments |
| 049 | Polymer Formulation Reviewer | Polymer Science | SDL4 | Assess polymer blend and additive evidence |
| 050 | Polymer Data Curator | Polymer Science | SDL4 | Maintain structure–processing–property lineage |
| 051 | Composition Design Analyst | Formulation Science | SDL5 | Structure formulation composition spaces |
| 052 | Stability Study Planner | Formulation Science | SDL5 | Track stability study design and conditions |
| 053 | Particle Attribute Analyst | Formulation Science | SDL5 | Organize particle size and morphology measurements |
| 054 | Dispersion Analyst | Formulation Science | SDL5 | Evaluate dispersion records and variability |
| 055 | Interface Compatibility Analyst | Formulation Science | SDL5 | Track compatibility and interfacial hypotheses |
| 056 | Rheology Formulation Analyst | Formulation Science | SDL5 | Compare flow properties across formulations |
| 057 | Batch Consistency Monitor | Formulation Science | SDL5 | Detect drift across formulation batches |
| 058 | Packaging Interaction Reviewer | Formulation Science | SDL5 | Organize packaging interaction evidence |
| 059 | Formulation Optimizer | Formulation Science | SDL5 | Rank formulation proposals under constraints |
| 060 | Formulation Dataset Curator | Formulation Science | SDL5 | Version formulation datasets and derived features |
| 061 | Biological Model Registrar | Biological Systems | SDL6 | Track model identity, passage, and provenance |
| 062 | Culture Metadata Reviewer | Biological Systems | SDL6 | Validate culture conditions and reagent-lot metadata |
| 063 | Organoid Morphology Analyst | Biological Systems | SDL6 | Analyze morphology outputs with confidence and unknown states |
| 064 | Imaging Quality Monitor | Biological Systems | SDL6 | Check imaging quality and acquisition context |
| 065 | Cellular Metabolism Analyst | Biological Systems | SDL6 | Organize metabolic readouts and assay context |
| 066 | Mechanobiology Analyst | Biological Systems | SDL6 | Connect mechanical environment and biological observations |
| 067 | Functional Assay Reviewer | Biological Systems | SDL6 | Separate morphology, gene expression, and functional evidence |
| 068 | Replication Monitor | Biological Systems | SDL6 | Track independent biological replication |
| 069 | Biosafety Workflow Reviewer | Biological Systems | SDL6 | Route biological workflows through expert review |
| 070 | Biological Data Curator | Biological Systems | SDL6 | Maintain model-to-observation lineage |
| 071 | Process Objective Analyst | Process Engineering | SDL7 | Compile process optimization objectives |
| 072 | Reaction Kinetics Analyst | Process Engineering | SDL7 | Organize kinetic model inputs and outputs |
| 073 | Heat Transfer Analyst | Process Engineering | SDL7 | Track heat-transfer models and sensor context |
| 074 | Mass Transfer Analyst | Process Engineering | SDL7 | Track mass-transfer phenomena and limitations |
| 075 | Mixing Intelligence Analyst | Process Engineering | SDL7 | Compare mixing states and scale dependencies |
| 076 | Process Sensor Monitor | Process Engineering | SDL7 | Monitor process telemetry and timestamp quality |
| 077 | Scale-up Feasibility Reviewer | Process Engineering | SDL7 | Compare laboratory and larger-scale assumptions |
| 078 | Process Anomaly Analyst | Process Engineering | SDL7 | Flag process deviations and candidate explanations |
| 079 | Batch Scheduler | Process Engineering | SDL7 | Schedule compatible workflows under resource constraints |
| 080 | Process Provenance Curator | Process Engineering | SDL7 | Preserve batch and process-history traceability |
| 081 | Scientific Schema Validator | Data & Evidence | SDL0 | Validate domain contracts and schema versions |
| 082 | Unit Semantics Service | Data & Evidence | SDL0 | Check unit presence and compatible conversion metadata |
| 083 | Data Quality Assessor | Data & Evidence | SDL0 | Score completeness and flag disqualifying defects |
| 084 | Anomaly Detection Analyst | Data & Evidence | SDL0 | Identify anomalies without deleting unusual observations |
| 085 | Time-series Alignment Agent | Data & Evidence | SDL0 | Reconcile clocks and timestamp provenance |
| 086 | Multimodal Fusion Planner | Data & Evidence | SDL0 | Design scientifically defensible sensor-fusion workflows |
| 087 | Dataset Version Manager | Data & Evidence | SDL0 | Version curated datasets and transformations |
| 088 | Knowledge Graph Curator | Data & Evidence | SDL0 | Maintain objective-to-evidence relationships |
| 089 | Model Data Steward | Data & Evidence | SDL0 | Manage training eligibility and split integrity |
| 090 | Provenance Auditor | Data & Evidence | SDL0 | Trace conclusions to original artifacts and transformations |
| 091 | Permission Policy Agent | Governance & Reliability | SDL0 | Check role and agent permission boundaries |
| 092 | Safety Review Router | Governance & Reliability | SDL0 | Route high-impact workflows to qualified reviewers |
| 093 | Experiment State Auditor | Governance & Reliability | SDL0 | Detect invalid lifecycle state transitions |
| 094 | Instrument Capability Registrar | Governance & Reliability | SDL0 | Track instrument capabilities and local approval requirements |
| 095 | Equipment Health Analyst | Governance & Reliability | SDL0 | Summarize calibration, downtime, and equipment alerts |
| 096 | Workflow Recovery Planner | Governance & Reliability | SDL0 | Recommend checkpoint review and recovery paths |
| 097 | Agent Evaluation Engineer | Governance & Reliability | SDL0 | Evaluate agents against benchmark tasks |
| 098 | Reliability Monitor | Governance & Reliability | SDL0 | Track retries, timeouts, and tool-call failures |
| 099 | Cross-Lab Transfer Reviewer | Governance & Reliability | SDL0 | Check transferability across instruments and domains |
| 100 | Audit Trail Custodian | Governance & Reliability | SDL0 | Preserve append-only event history |

## Capability-profile governance

Every deployed agent should additionally publish a versioned capability card with:

- Stable agent ID and semantic version.
- Scientific domain and supported data modalities.
- Input and output schemas.
- Prediction targets and supported units, where relevant.
- Evidence and source-attribution requirements.
- Allowed tools and permissions.
- Human review and escalation conditions.
- Benchmark suite, validation dataset, and model-card references.
- Known limitations and out-of-domain behavior.
- Owner, deployment environment, and rollback version.

The permission model remains narrow: analysis and proposal generation are different from approval, and neither grants physical instrument authority. Promotion should depend on multidimensional benchmark evidence and scientist review.
