# Scientific Contracts and Workflow Invariants

This document records the software invariants that should remain stable as NEXUS grows from a local demonstrator into a distributed laboratory network.

## 1. Core identities

A production system should assign immutable IDs to:

- Laboratory and laboratory workspace.
- Scientific objective and objective version.
- Hypothesis and hypothesis revision.
- Candidate entity and candidate representation/version.
- Sample, aliquot, batch, and container.
- Experiment, protocol, and protocol version.
- Instrument and instrument capability manifest.
- Measurement and raw artifact.
- Dataset, feature set, model, and model evaluation.
- Agent profile, agent implementation, and agent run.
- Approval, audit event, and transformation record.

A human-readable code is useful for scientists, but it must not replace the immutable ID. A new sample batch should not reuse the identity of its parent material. An objective revision should not rewrite historical experiment context.

## 2. Objective contract

The Scientific Objective Compiler may extract intent from natural language, but it must output a typed, inspectable representation. The minimum fields are:

```yaml
objective_id: OBJ-EXAMPLE-001
version: 1
laboratory_code: SDL1
domain: inorganic_materials
description: Identify candidate solid-state electrolytes for further review.
optimization:
  objectives:
    - property: ionic_conductivity
      direction: maximize
      unit: S/cm
constraints:
  require_sample_identity: true
  require_measurement_provenance: true
evidence_requirements:
  require_uncertainty_estimates: true
  distinguish_prediction_from_measurement: true
governance:
  scientist_review_required: true
  physical_execution_requires_authorization: true
```

An incomplete or contradictory objective should return missing fields and warnings. It must not silently choose a scientific interpretation. Objective versions should preserve the original creator, reviewer, revision reason, and the experiments bound to each version.

## 3. Hypothesis contract

A hypothesis is a falsifiable statement linked to planned observations and competing explanations. Its lifecycle is:

`proposed -> under_review -> accepted_for_testing -> supported | partially_supported | contradicted | inconclusive -> superseded`

A hypothesis should retain:

- Statement and domain.
- Objective version.
- Predictions and expected directions.
- Testability and required methods.
- Supporting observations.
- Contradictory observations.
- Uncertainty and assumptions.
- Scientist decision and timestamp.

A model response that sounds scientific is not sufficient to mark a hypothesis as supported.

## 4. Candidate contract

A candidate record should be distinct from the evidence that describes it. For a material, useful fields may include:

- Composition and canonical formula.
- Structure reference and structure version.
- Phase or polymorph identity.
- Defect and substitution hypotheses.
- Synthesis route or processing family, when established.
- Predicted properties and uncertainty.
- Literature-derived values with source metadata.
- Experimentally measured properties.
- Sample and batch links.
- Feasibility and lifecycle state.
- Domain applicability and known limitations.

A molecular candidate in SDL2/SDL3, a polymer in SDL4, and a formulation in SDL5 should use domain-specific representations instead of being coerced into one generic material schema.

## 5. Experiment state invariants

- A draft is not validated.
- Validation is not approval.
- Approval is not execution.
- A scheduled experiment is not proof that a resource was reserved.
- An accepted command is not proof that the operation completed.
- Completion is not proof that the result passed scientific data quality.
- Data-quality acceptance is not a scientific conclusion.
- A failed or quarantined run must remain visible in history.
- A result file cannot cause a failed experiment to be rewritten as complete.

The state-machine implementation is a deterministic local baseline. A distributed worker system should preserve compare-and-swap semantics or equivalent optimistic concurrency protections when transitioning experiment state.

## 6. Command envelope and idempotency

A future edge-gateway command contract should include:

```json
{
  "command_id": "CMD-EXAMPLE-001",
  "idempotency_key": "IDEMPOTENCY-EXAMPLE-001",
  "experiment_id": "EXP-EXAMPLE-001",
  "instrument_id": "INST-EXAMPLE-001",
  "operation": "approved_operation_name",
  "protocol_version": "1.0.0",
  "authorization_ref": "APPROVAL-EXAMPLE-001",
  "expires_at": "2026-11-08T20:00:00Z"
}
```

Acknowledgements must be distinguishable:

1. Received — a gateway has received the envelope.
2. Validated — policy, capability, schema, and expiry checks passed.
3. Accepted — a local controller accepted the operation.
4. Completed — an operation finished and a result reference was recorded.

Retries must check the idempotency key. A network timeout does not prove an operation failed to start. The starter contains a command-envelope state model only; it does not send commands to hardware.

## 7. Measurement contract

Every measurement should carry:

- Measurement ID and immutable sample ID.
- Experiment ID and protocol version.
- Property name, numeric/string value, and unit.
- Method and instrument IDs.
- Acquisition timestamp and timezone/clock metadata.
- Uncertainty and detection limits, where applicable.
- Calibration reference.
- Replicate and batch identifiers.
- Raw artifact URI and content hash.
- Evidence origin.
- Data-quality checks and disposition.
- Operator/automation actor and software versions.

Original values must be preserved. Unit conversion, filtering, baseline subtraction, image segmentation, spectral fitting, and other transformations create separately identified derived artifacts.

## 8. Evidence-origin taxonomy

At minimum distinguish:

- Measured value.
- Computational result.
- Model prediction.
- Literature value.
- Human observation.
- Inferred value.
- Synthetic simulation output.

Evidence grade E0–E6 is a traceability aid rather than a universal ranking. Domain-specific thresholds and quality checks must be specified for each method. Synthetic records are ineligible for production scientific-model training.

## 9. Quality disposition

Quality systems should distinguish warnings from disqualifying defects. Missing sample identity, invalid units, untraceable raw source, invalid instrument state, or protocol mismatch may require quarantine. An unusual value is not necessarily an error: it may represent a rare or previously unknown phenomenon.

Never delete an anomaly automatically. Preserve the source record, record the reviewer decision, and create a new interpretation event if the status changes.

## 10. Model contract

A model should declare:

- Supported domains and modalities.
- Prediction targets and valid units.
- Training and evaluation dataset versions.
- Numeric and categorical applicability ranges.
- Calibration and uncertainty methods.
- Known failure modes and out-of-domain behavior.
- Model weights/checkpoint hash.
- Training code and dependency versions.
- Benchmark results and limitations.
- Approval status and owner.

The starter's model cards describe baselines and limitations. No trained scientific foundation model is bundled.

## 11. Cross-lab transfer

Transfer learning across SDLs must evaluate:

- Domain mismatch.
- Instrument model and calibration differences.
- Measurement method differences.
- Unit and normalization differences.
- Sample preparation and batch effects.
- Environmental and operating-range differences.
- Protocol and software versions.
- Whether source data were measured, predicted, simulated, or literature-derived.

A model trained on one domain must not silently advertise applicability to another.

## 12. Audit and reproducibility

The audit log should be append-only. Corrections are additional events that reference the event being corrected. A replayable experiment bundle should preserve objective version, hypothesis, candidate version, sample identity, protocol, instrument manifest, raw artifacts, calibration, transformations, model versions, approvals, agent run outputs, and all relevant timestamps.

## 13. Domain-specific evidence examples

| Lab | Distinct evidence and context that matter |
|---|---|
| SDL0 | Robot workspace state, calibration, reachability, collision report, simulation acceptance, operator review |
| SDL1 | Formula and crystal structure, phase identity, temperature, pressure, ionic transport method, electrode/sample state |
| SDL2 | Molecular identity, reaction graph, reagents, conditions, purification, analytical confirmation |
| SDL3 | Target and assay identity, controls, biological replicates, binding prediction vs measured binding, selectivity context |
| SDL4 | Molecular-weight distribution, thermal history, rheology method, specimen geometry, tensile/creep test conditions |
| SDL5 | Ingredient identities, composition, batch provenance, storage, particle attributes, stability conditions |
| SDL6 | Biological model provenance, passage, culture conditions, imaging, biochemical and functional measurements, biosafety review |
| SDL7 | Sensor calibration, time alignment, residence time, mixing, heat/mass transfer, process boundary conditions, scale relevance |

## 14. Release acceptance checklist

A new feature is not ready solely because its page renders. Require:

- Contract and schema tests.
- Valid and invalid input tests.
- Provenance and audit event tests.
- Failure and interruption tests.
- Permissions and role checks.
- Out-of-domain behavior.
- Unit and time-zone handling.
- Reproducible simulation fixtures.
- Explicit synthetic-vs-real labeling.
- Human approval path where required.
- Rollback or disable switch.
- Operator documentation.

This is the core reliability posture for scaling NEXUS across the laboratory network.
