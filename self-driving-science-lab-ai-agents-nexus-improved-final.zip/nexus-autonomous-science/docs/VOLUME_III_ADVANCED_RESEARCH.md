# NEXUS Volume III — Advanced Research, Digital Twins & Multi-Laboratory Learning

## Purpose

Volume III extends the existing NEXUS SDL0–SDL7 platform with computational research services for calibrated digital twins, uncertainty-aware experimental design, evidence synthesis, laboratory transferability, scientific method comparison, and cross-laboratory collaboration. It builds on the prior objective, sample, experiment, campaign, agent, data-quality, provenance, and orchestration contracts.

The implementation is an analysis and decision-support layer. It does not execute physical experiments, deploy model weights to production, or authorize laboratory equipment commands.

## New architectural capabilities

### 1. Digital-twin calibration and monitoring

- `twin_calibration.py` fits and validates affine calibration layers from paired reference/prediction records, retains model/domain/version metadata, and supports group-aware holdout splitting.
- `digital_twin_ensemble.py` combines multiple simulation predictions while surfacing disagreement and fidelity metadata.
- `twin_observability.py` provides health and synchronization diagnostics for a twin's expected and observed state.
- `multi_fidelity.py` estimates a low-to-high-fidelity bridge from paired computational evidence and provides corrected ranking helpers.
- `simulation_models.py` contains explicit simplified thermal, kinetic, battery-discharge, and CSTR demonstrations. These are illustrative equations, not validated process models.

### 2. Uncertainty-aware decisions

- `uncertainty_propagation.py` propagates input uncertainty by Monte Carlo sampling and exposes variance decomposition helpers.
- `uncertainty_ranking.py` ranks candidates using prediction intervals and interval-dominance checks.
- `value_of_information.py` estimates the expected value of additional information and provides transparent stopping-rule inputs.
- `bayesian_evidence.py` updates hypothesis probabilities from explicitly supplied likelihood evidence; independence assumptions must be stated rather than inferred.
- `sensitivity_analysis.py` computes local and one-at-a-time sensitivity summaries.
- `replication_planning.py` estimates replication requirements and summarizes replicate measurements.

### 3. Sequential and constrained design

- `sequential_design.py` proposes candidate batches using acquisition scores, cost, diversity, family caps, and hard constraints.
- `blocked_assignment.py` creates reproducible computational allocations for blocked comparisons and audits the resulting plan. It does not randomize or assign physical samples.
- `lab_capacity.py` previews capacity and resource conflicts without reserving real instrument time.
- `method_selection.py` recommends candidate analytical methods from a declared requirement set; final method selection remains a scientific decision.

### 4. Cross-laboratory evidence exchange

- `multi_lab_exchange.py` creates and verifies exchange envelopes with payload digests, declared provenance, consent scope, and optional shared-secret signatures.
- `data_interoperability.py` compares data contracts, validates mapping rules, and converts compatible measurement units through explicit conversion metadata.
- `model_transfer.py` examines source/target context and target validation information before proposing transfer-learning steps.
- `federated_aggregation.py` aggregates summary statistics subject to minimum-lab and record thresholds.
- `federated_model_updates.py` clips and aggregates parameter deltas only when lab identity, consent scope, model identity/version, and local validation status satisfy the declared policy. It returns a reviewable aggregate; it does not create, release, or deploy a model update.
- `privacy_ledger.py` tracks declared privacy budgets and duplicate release keys. A ledger is accounting infrastructure, not a complete differential-privacy proof or secure aggregation implementation.
- `lab_effects.py` summarizes between-lab differences with shrinkage-style diagnostics and explicit limits on causal interpretation.
- `repeatability.py` reports repeatability components and paired-method agreement summaries.

### 5. Scientific evidence and operations

- `evidence_synthesis.py` structures claims and evidence links while retaining contradictory support.
- `failure_attribution.py` ranks possible failure explanations and proposes discriminating checks; it does not diagnose hardware autonomously.
- `sensor_fusion.py` validates and aligns declared scalar sensor streams and provides simple fusion summaries.
- `sample_custody.py` records custody transitions and checks chain integrity.
- `protocol_diff.py` compares protocol versions and flags compatibility questions.
- `research_metrics.py` exposes analysis metrics for scientific workflow review.
- `linalg.py` contains shared numerical helpers used by the advanced research services.

## API surface

All routes are mounted below `/api/advanced-research` and documented by FastAPI OpenAPI. Important route families include:

| Route family | Purpose |
|---|---|
| `/digital-twins/*` | Calibration, calibrated predictions, validation, ensemble and twin health |
| `/uncertainty/*` | Propagation and interval construction |
| `/design/*` | Sequential batches and blocked computational allocation |
| `/multi-fidelity/*` | Fidelity bridge and corrected ranking |
| `/value-of-information/*` | Information value and action ranking |
| `/simulation/*` | Simplified deterministic computational examples |
| `/federated/*` | Summary statistics, model-delta aggregation and round comparison |
| `/privacy/*` | Privacy-budget ledger and release accounting |
| `/labs/*` | Lab-effect summaries |
| `/repeatability/*` | Replicate summaries and Bland–Altman-style agreement |
| `/data-interoperability/*` | Contract comparison, mappings and unit conversion |
| `/evidence/*` | Evidence synthesis and evidence matrix |
| `/sensors/*` | Sensor stream checks, fusion and event alignment |
| `/samples/custody*` | Custody chain records and verification |
| `/failure/*` | Failure hypothesis triage and discriminating checks |
| `/methods/*` | Analytical method recommendations |
| `/analyses` | Persisted advanced-analysis records |

## New API request/response principles

1. Inputs use strict request models where defined; unknown fields are rejected.
2. Numerical boundaries, array sizes, probabilities, and batch limits are constrained at the API edge.
3. Computational outputs are persisted as advanced-analysis records with request digests and synthetic/source metadata when the route supports persistence.
4. Synthetic input remains explicitly synthetic in the stored analysis record and output envelope.
5. A prediction or simulation is never silently relabelled as an instrument measurement.
6. Cross-laboratory model deltas are review artefacts only; no model is updated or deployed by aggregation endpoints.
7. Blocked assignments are computational plans only; no physical assignment or sample movement occurs.
8. Privacy-ledger release accounting does not, by itself, establish differential privacy. A reviewed noise mechanism, threat model, secure aggregation, and privacy audit are needed before real data release.

## Frontend extension

The `Advanced Research` workspace calls the advanced API for:

- digital-twin calibration and prediction review;
- uncertainty propagation;
- sequential experiment proposals;
- cross-lab exchange-envelope creation and verification;
- residual drift monitoring;
- illustrative simulation runs;
- federated model-update review;
- lab-effects summaries;
- blocked computational design assignment;
- repeatability and paired-method agreement.

The workspace is a research tool surface, not an instrument-control surface. If the API is unavailable, the frontend may display a local fallback state; fallback data must not be treated as persisted scientific evidence.

## Suggested next production milestones

1. Add Alembic migrations and versioned upgrade tests for every persistent entity introduced in previous volumes.
2. Replace shared-secret envelope signatures with an organization-managed asymmetric signing and key-rotation system.
3. Commission a complete differential-privacy design, including adjacency definition, calibrated noise, accountant, composition policy, and adversarial review.
4. Validate every digital-twin model on preregistered, lab-held-out datasets and report calibration, coverage, domain limits, and failure modes.
5. Integrate a durable event transport and OpenTelemetry traces across API, workers, and agent execution.
6. Establish governance for data-use agreements, ownership, retention, deletion, and cross-lab consent.
7. Require independent domain-scientist acceptance before any model, method, or workflow is used to guide consequential physical research.
8. Keep physical execution behind a separately deployed local edge gateway with hardware interlocks and qualified operator controls.

## Scientific cautions

- An affine calibration is a limited correction layer; it cannot repair a misspecified simulator or establish causal validity.
- Monte Carlo intervals are only as credible as their input distributions, dependency assumptions, and model form.
- A candidate acquisition score is not a probability of experimental success.
- Federated parameter averaging can be misleading under non-IID datasets or incompatible local objectives.
- Lab-effect summaries are descriptive unless a defensible causal design supports stronger claims.
- Bland–Altman limits require relevant distributional assumptions and a sufficiently representative paired sample.
- All simplified simulations and seeded examples must be distinguished from real-world observations.
