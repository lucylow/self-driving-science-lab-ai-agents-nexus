# NEXUS Autonomous Science Network — Volume II Engineering Expansion

This document describes the second implementation volume layered onto the original NEXUS foundation. It is an implementation guide for the code shipped in this repository, not a claim that the platform is connected to live scientific facilities.

## Scope of this volume

The expansion adds five engineering subsystems:

1. A domain-science calculation library for electrochemistry, diffraction, batteries, polymers, spectroscopy, kinetics, formulations, morphology and replicate summaries.
2. Scientific data and governance foundations: measurement contracts, unit semantics, schema version registry, provenance DAG validation, quality rules and model-release checks.
3. A durable workflow layer: hash-linked per-node checkpoints, conservative recovery planning and multi-stage research campaigns.
4. Agent and data intelligence: typed agent messages, capability-based dispatch, evidence-weighted review aggregation, CSV staging, dataset audits and eight-lab benchmark suites.
5. Event-delivery reliability: expiring outbox leases, claim-token acknowledgements, retry backoff, dead-letter handling and observability endpoints.

## Domain-science package

`backend/app/services/domain_science/` is deliberately separated from API handlers. The functions are pure or close to pure and return JSON-serializable calculations.

| Module | Scientific method | Key assumptions preserved |
|---|---|---|
| `electrochemistry.py` | Conductivity geometry conversion, EIS summary, Arrhenius fit | Geometry, temperature, frequency range and uncertainty |
| `diffraction.py` | Bragg spacing, cubic lattice estimate, reference peak comparison | Wavelength, diffraction angle and the limitation that a peak match is not phase proof |
| `battery.py` | Galvanostatic cycle metrics, discharge energy, retention | Supplied charge/discharge arrays, units and cycle indices |
| `polymer.py` | Dispersity, DSC crystallinity, tensile modulus | Reference enthalpy, polymer mass fraction, sample geometry and elastic range |
| `spectroscopy.py` | Baseline correction, normalization, peak detection and integration | Axis order, endpoints and peak thresholds |
| `kinetics.py` | First-order decay fit and mass balance | Positive concentrations, elapsed time and declared process boundary |
| `formulation.py` | Mixture closure and ideal linear blend | Fractions are not silently normalized; linear additivity is an explicit assumption |
| `morphology.py` | Binary-mask morphology | Pixel size and the fact that morphology does not prove biological function |
| `replicates.py` | Replicate summaries and group comparisons | Unit consistency and no implied inferential test |

All of these return `origin: derived_computational_result` or an equivalent explicit computational label. They are not instrument measurements.

## Scientific data contracts

The new data foundation distinguishes the following object types and boundaries:

- Raw artifact: source bytes or immutable external artifact reference.
- Validated measurement: a structured value with unit, sample identity, instrument or method and condition context.
- Derived result: an explicit transformation of source observations.
- Prediction: a model output with model/version, input references, uncertainty and applicability status.
- Scientific claim: an interpretation with supporting and contradictory references.

The measurement contract service validates required condition metadata and checks whether a reported origin is consistent with `synthetic`. The unit service supports a bounded catalogue of conversions; it does not claim to replace a full physical-units library. The schema registry stores semantic versions and reports removed/required field changes. The provenance graph validates missing parents and cycles, traces outputs to root artifacts and computes downstream impact.

## Checkpointed workflow execution

`workflow_checkpoints.py` stores append-only checkpoints with:

- workflow ID and sequential index;
- checkpoint key, node ID and node state;
- a state and output snapshot;
- an idempotency key;
- previous hash and current content hash;
- an explicit physical-side-effect marker.

The workflow supervisor now commits the initial checkpoint and each completed analytical node. A final checkpoint records when the graph is ready for scientist review. This gives a durable history even when an API request or worker is interrupted.

The recovery planner is conservative. It verifies the hash chain, requires a failed/interrupted/paused workflow, checks that the latest checkpoint has no physical side effects, and requires an explicit operator request. It returns a recommendation only; it does not resume the graph automatically.

### Checkpoint API

| Method | Route | Purpose |
|---|---|---|
| GET | `/api/orchestration/runs/{run_id}/checkpoints` | List checkpoints and verify integrity |
| POST | `/api/orchestration/runs/{run_id}/recovery-plan` | Produce an advisory recovery plan (`operator_requested`) |

## Research campaigns

A campaign groups one to six existing analytical workflow definitions into a persistent research programme. Campaign identity and domain must match the referenced objective. Each campaign is simulation-only.

### Lifecycle

`awaiting_approval → approved → running → awaiting_scientist_review → approved → ... → completed`

A rejected stage changes the campaign to `blocked`; cancellation changes it to `cancelled`. The campaign manager does not auto-approve a stage and will not launch a following stage until the current stage has been accepted by a named scientist.

### Campaign API

| Method | Route | Purpose |
|---|---|---|
| POST | `/api/research-campaigns` | Create a campaign and its stages |
| GET | `/api/research-campaigns` | List campaigns, optional lab/status filters |
| GET | `/api/research-campaigns/{id}` | Campaign and event integrity summary |
| POST | `/api/research-campaigns/{id}/approve` | Human approval |
| POST | `/api/research-campaigns/{id}/launch-next-stage` | Start the next analytical workflow |
| POST | `/api/research-campaigns/{id}/review-stage` | Accept or reject the current stage |
| POST | `/api/research-campaigns/{id}/cancel` | Cancel the programme with a reason |
| GET | `/api/research-campaigns/{id}/events` | Verify and inspect the hash-linked event history |

## Agent messages and dispatch

`agent_intelligence/message_protocol.py` defines bounded, typed messages with sender/receiver identity, task key, correlation ID, timestamp, expiry and payload hash. It rejects oversized messages, stale messages, missing identities and message cycles. The dispatch planner routes only to registered agents whose capability cards satisfy the task, and it explicitly blocks requested physical capabilities.

`agent_intelligence/consensus.py` aggregates reviewer votes without hiding abstentions or minority findings. The aggregation result is an advisory object; it does not mutate a scientific claim or promote a model.

## Domain benchmark suites

`agent_benchmark_suites.py` contains 24 starter benchmark cases: three per SDL0–SDL7. The cases cover:

- SDL0: permission boundaries, simulation-to-real limits and failure recovery.
- SDL1: formula parsing, diffraction comparison and EIS context.
- SDL2: reaction graphs, spectral assignments and synthesis feasibility.
- SDL3: assay context, matched pairs and out-of-domain requests.
- SDL4: molecular-weight distribution, DSC crystallinity and tensile mechanics.
- SDL5: mixture closure, stability evidence and batch comparability.
- SDL6: organoid morphometry, model provenance and independent replication.
- SDL7: sensor time alignment, mass balance and scale-up applicability.

Schema compliance, constraint compliance and evidence attribution can be checked deterministically. Scientific correctness is not inferred from model confidence; it requires a named reviewer and a recorded adjudication. Even a suite that passes returns `eligible_for_shadow_deployment_review`, never production promotion.

## Event outbox reliability

The outbox remains broker-neutral. The code prepares delivery envelopes but does not connect to a Kafka/NATS/RabbitMQ broker.

A worker claims one or more events with a lease and claim token. The token is required to acknowledge delivery. Failed events use exponential backoff, capped by a maximum delay. Events reaching the configured attempt limit are dead-lettered. Expired leases can be recovered without marking the event as published.

| Method | Route | Purpose |
|---|---|---|
| POST | `/api/outbox/prepare` | Claim a bounded batch |
| POST | `/api/outbox/{event_id}/prepare` | Claim one specific event |
| POST | `/api/outbox/{event_id}/acknowledge` | Acknowledge using the returned claim token |
| POST | `/api/outbox/recover-expired-leases` | Requeue or dead-letter stale claims |
| GET | `/api/outbox/metrics` | Inspect counts by state |

For multi-worker production use, deploy on PostgreSQL and preserve the row-locking semantics. SQLite is intended for local development; it does not provide equivalent row-level locking for concurrent workers.

## Frontend additions

The Next.js UI gains:

- **Science methods:** interactive access to the computational methods available in the domain-science API.
- **Research campaigns:** campaign creation, human approval, stage launch, per-stage review and a persistent stage timeline.
- **Model intelligence:** training snapshot/model evaluation views from the original extension.
- **Sample registry:** persistent sample identity and evidence links.

Campaign actions surface the API status and do not silently create a simulated result when the backend returns a real error. When the API is offline, existing local demo fallback behavior remains separate from persisted server records.

## Tests and validation

The second volume adds tests covering numerical methods, scientific contract validation, unit conversion, schema evolution, lineage, model release gates, workflow checkpoints, campaign transitions, event hash integrity, broker retry rules, benchmark adjudication and the eight-domain suite catalogue.

Run the backend checks from `backend/`:

```bash
python -m compileall -q app
pytest -o addopts='' -q
```

The TypeScript source can be syntax-transpiled with the project's TypeScript compiler. A full Next.js production build additionally requires installing frontend dependencies in a network-enabled environment.

## Remaining production work

- Add Alembic migrations for every new relational entity before upgrading a deployed database.
- Move local SQLite deployments to PostgreSQL for concurrent claims and workflow workers.
- Add authentication, role-based access and multi-tenant boundaries to campaign and event endpoints.
- Connect a production event broker and a worker with idempotent external acknowledgements.
- Use a distributed lease/capacity manager rather than process-local state for horizontally scaled services.
- Integrate real LLM/model providers behind validated contracts and measured benchmarks.
- Add actual persistent artifact storage and content-addressed manifests.
- Keep physical robotics disabled until local edge safety controls, vendor adapters, acceptance tests and qualified operator approval are independently implemented.
