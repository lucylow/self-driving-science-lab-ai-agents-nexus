# NEXUS Architecture: Current-State Assessment

**Assessment basis:** independent repository audits captured the pre-change baseline. Sections through the ranked risks preserve those findings; the post-audit addendum below supersedes any finding changed by this implementation tranche. All statements describe this workspace and tested commands, not an uninspected deployment.

## Executive assessment

NEXUS is a **development/demo foundation with persistent domain records and synchronous analytical workflows**, not a production-ready distributed platform. Its observed deployment is a two-container Docker Compose stack: a FastAPI/Uvicorn API and a Next.js web application, backed by SQLite on a named volume. SQLAlchemy persists domain, audit, outbox, workflow, and model-related records. Startup creates tables with `metadata.create_all`, seeds demo data, and exposes a fixed `/health` response.

The implementation includes useful foundations—typed validation on selected routes, domain safety checks, synthetic-data labels, audit/outbox writes in shared sessions, lease/retry logic, hash-linked workflow checkpoints, and a substantial backend test tree. These foundations do **not** establish authenticated tenant boundaries, durable asynchronous execution, HA, exactly-once delivery, production migration capability, immutable provenance, or PostgreSQL concurrency behavior. Scheduling endpoints make proposals rather than reservations; workflow and agent execution are synchronous in API requests; the outbox hands envelopes to an external adapter that is not present in this repository.

**Bottom line:** treat the current system as an isolated demo until identity/authorization and scientific-data trust boundaries are enforced. Next, make execution and delivery semantics explicit and recoverable, then establish a reproducible CI/deployment baseline. Do not infer public exposure merely from Compose port publication, but do not use the Compose configuration as a secured shared deployment.

## Observed stack and architecture classification

- **Backend:** Python 3.12; FastAPI, Uvicorn, SQLAlchemy, and Pydantic Settings. Dependency declarations use broad ranges; no dependency lock or PostgreSQL DBAPI driver was found in the inspected backend requirements.
- **Frontend:** Node 26 selected by `.nvmrc` (package engine allows Node >=20.9); Next.js 16.4.5, React 19.3.0, TypeScript 5.7. Its API URL is a build-time `NEXT_PUBLIC_API_URL` argument defaulting to `http://localhost:8000`.
- **Persistence:** SQLite by default (`sqlite:///./nexus.db`); Compose selects `sqlite:////data/nexus.db` on named volume `nexus-data`. PostgreSQL is described as configurable, but Compose has no PostgreSQL service and declared backend dependencies do not provision its driver.
- **Deployment:** Compose defines only `api` and `web`, publishes ports 8000 and 3000, enables demo mode, and starts web after API health. Uvicorn is launched without an explicit worker count. No production deployment manifest, replica/pool policy, or CI workflow was found.
- **Schema lifecycle:** startup calls `create_all`; no migration framework/configuration was found. This initializes missing tables but is not an upgrade strategy for existing schemas.

**Classification:** monolithic API/web application with a relational persistence layer and a local-demo deployment profile. Some interfaces and records are designed with future integrations in mind, but an interface/proposal is not an implemented broker, worker, reservation system, or distributed guarantee.

## Component inventory

| Component | Observed implementation | Boundary or limitation |
|---|---|---|
| API and domain routes | FastAPI router mounts experiment, governance, campaign, scheduling, orchestration, artifact, sample, and related routes. SQLAlchemy sessions are request-scoped. | No registered authentication/principal dependency; tenant filters are optional inputs, not caller-derived authorization. |
| Frontend | Next.js client/API layer distinguishes network, timeout, cancellation, HTTP, and invalid-response errors; 20-second request timeout and no-cache fetch behavior are present. Demo/offline state is labeled in the app. | A rejected write without an HTTP response can trigger local mutation fallback; if the server committed before connection loss, local and persisted state can diverge. |
| Database and entities | SQLAlchemy models persist experiments, measurements, samples, artifacts, audit/outbox rows, workflow and agent runs/checkpoints, datasets, models, and evaluations. | SQLite is default; no migration path; no DB-enforced immutability for scientific records. PostgreSQL path is not established by declared dependencies or verified tests. |
| Audit and outbox | Audit event and outbox row are added in the same SQLAlchemy session on representative audited writes. Outbox includes status, attempts, claim token, lease, retry/dead-letter logic and a `SKIP LOCKED` claim query. | No broker publisher, broker confirmation, consumer deduplication, or delivery adapter exists here. SQLite lacks equivalent row-level locking. Event key has an index, not a unique constraint. Semantics are not exactly-once. |
| Workflow/orchestration | Persisted runs and hash-linked checkpoints; nodes dispatch sequentially; successful analytical flow ends at scientist review. | Execution is inline in the request. No durable queue/worker, heartbeat/lease, cancel/pause/resume operation, or automatic recovery loop. Recovery endpoint returns a plan, not resumed execution. |
| Scheduler | Planner checks dependencies/capabilities and returns proposals/previews. | No resource reservation or conflict protection is created. |
| Scientific evidence/model pipeline | Synthetic-aware simulation and selected training filters; dataset snapshot contains source IDs, split manifest, quality report, and payload hash. | Client can self-set sample identity to verified; synthetic snapshot can reach training; artifact bytes/digest are not verified; lineage API validates rather than persisting a transformation record. |
| Operations | `/health` returns fixed status/service/version/demo-mode data. Compose polls it and gates web startup on API health. Logging uses basic text logging. | `/health` is process response only, not DB readiness. No explicit engine disposal at shutdown; request correlation is generated only in unexpected-error handling. |

## Data and communication boundaries

1. **Browser → API:** frontend calls the configured API origin. The build-time localhost default is appropriate only for a same-machine development context, not an arbitrary remote browser deployment. CORS defaults to localhost:3000; configurable CORS is not authentication and does not constrain non-browser clients.
2. **API → database:** request handlers use SQLAlchemy sessions. In representative audited writes, domain state, audit event, and outbox row share a session/commit. Startup creates schema and seeds demo data. Seed exits if any laboratory exists. No distributed transaction with an external service is present.
3. **Outbox → external delivery:** API claims and returns delivery envelopes; publication is explicitly outside this repository. A process failure after external publication but before acknowledgement can cause a retry/duplicate. Treat this design as **potentially at-least-once**, requiring idempotent consumers; do not describe it as exactly-once.
4. **Workflow → agents:** workflow nodes call deterministic demo handlers inline and sequentially. Persisted checkpoints support inspection and hash-chain verification, but are not a durable job queue or executable restart mechanism. A committed `running` workflow can remain stale after process interruption.
5. **Scheduler → resources:** scheduler communicates a proposed plan only. There is no persisted reservation, resource lock, or booking lifecycle.
6. **Scientific records → artifact storage:** artifact metadata stores a caller-provided URI/digest and parent references; the local storage adapter is process-memory-only and does not store/verify bytes. Therefore, the DB metadata is not proof of artifact integrity or durable blob storage.

## Ranked risks

Severity reflects the likely impact if the relevant API or workflow is used beyond an isolated synthetic demo, not evidence that an external deployment is currently exposed.

| Rank | Risk | Evidence-based distinction | Priority response |
|---:|---|---|---|
| 1 — Critical for shared use | **No authenticated identity or tenant/resource authorization.** | Audits found routes without principal dependencies; list/read and approval routes can be called without credentials in tests; caller-supplied reviewer/actor fields are recorded. This is an implementation gap, not merely missing documentation. | Keep isolated/demo-only until verified principals, route-level authorization and server-derived actor attribution are implemented and tested. |
| 2 — High | **Scientific training trust can be bypassed.** | Sample creation accepts client-supplied `verified`; dataset building allows synthetic inclusion; `train_baseline` does not reject synthetic snapshots. Promotion review later rejecting synthetic models does not enforce the documented training prohibition. | Enforce verification and synthetic eligibility at server-side service boundaries. |
| 3 — High | **Artifact identity/provenance is not verified or durable.** | Digest/URI are accepted as metadata; bytes are not checked; process-memory storage is not durable; global digest reuse precedes lab/domain validation; parent references are not fully validated on registration. | Verify content and scope deduplication/parent checks; persist provenance and storage guarantees before relying on artifacts scientifically. |
| 4 — High | **Workflow is not a durable job system.** | Synchronous API dispatch, no leases/heartbeats or stale-running reconciliation; recovery is advisory. Its recovery plan may select a failed checkpoint as the latest boundary. | Add an explicit queued/claimed lifecycle and test restart, failure, and replay boundaries. |
| 5 — High | **Outbox duplicate/race behavior is not controlled across supported deployments.** | `event_key` is not unique and enqueue is select-then-insert; SQLite does not provide the row-lock semantics expected by the claim query; broker confirmation/dedup is absent. | Enforce uniqueness and conflict-safe insert; define at-least-once semantics; test contention on each supported database. |
| 6 — High | **Ambiguous frontend write failures can produce success-looking divergent local state.** | Network errors without a response may invoke local mutation fallbacks; client writes have no server-enforced idempotency key. | Represent mutation result as unknown, reconcile before retry, and keep offline actions explicitly separate. |
| 7 — Medium | **Schema evolution and readiness are weakly defined.** | `create_all` is the only observed schema mechanism; `/health` does not access DB; no shutdown disposal. | Add migrations and distinguish process liveness from DB-aware readiness. |
| 8 — Medium | **Operational resource controls are absent/inconsistent.** | No global request-body limit or rate limiter; some flexible `dict` request bodies are unbounded; there is no production worker/replica policy. | Apply body/depth and rate budgets, then validate deployment topology under load. |
| 9 — Medium | **Reproducibility and baseline evidence are incomplete.** | No CI; historical test totals conflict; active environment lacked pytest and Docker; Docker frontend uses `npm install` rather than lockfile-based `npm ci`; documented PostgreSQL path lacks declared driver. | Establish reproducible CI and verified deployment jobs before asserting supported environments. |

Additional correctness defects worth including in focused tests: outbox request schema accepts batch sizes through 1000 while service rejects above 500 (501+ can escape as an unhandled error); acknowledgements do not check lease expiry or lock the row; concurrent experiment transitions lack compare-and-swap/versioning; and unexpected non-domain agent-handler exceptions may not persist failed history through the API path.

## Reliability, security, and scientific-integrity interpretation

- **Availability:** a single configured API and web container is observed, with no replica or failover policy. No HA property is demonstrated. Compose health polling confirms only that the fixed health route responds; it does not prove database usability.
- **Consistency/delivery:** outbox row creation is transactionally paired with audited writes in representative paths, but enqueue idempotency is not database-enforced. External delivery is absent. Claim/recovery correctness under concurrency is unproven, especially on SQLite. Neither exactly-once processing nor multi-worker safety should be claimed.
- **Workflow recovery:** hash-linked checkpoints provide integrity checks for stored snapshots, but not job execution recovery. Since execution is synchronous and recovery does not resume, do not claim durable orchestration or automatic restart.
- **Authorization:** CORS and Pydantic validation are present in selected areas; neither substitutes for API authentication, authorization, tenant isolation, or rate limits. Demo-mode and synthetic-data labels are helpful but do not create an access-control boundary.
- **Scientific provenance:** selected identifiers, sample/domain checks, source measurement IDs, split manifests, and synthetic flags exist. Immutability, verified raw bytes, transformation persistence, objective/protocol version snapshots, and complete model runtime provenance do not. A metadata digest is not proof that stored bytes match it.

## Baseline tests and measurement limitations

**Reported as verified in the audit environment:** frontend TypeScript validation passed; Next.js production build passed; 248 Python application/test/script files compiled in memory without syntax errors. The audit reports 28 backend test modules and 250 top-level `test_*` functions in the supplied tree.

**Not verified:** `python -m pytest -q` could not run because `pytest` was absent from the active Python environment. Docker/Compose build, startup, persistence, and health behavior could not be exercised because Docker was unavailable. PostgreSQL connection, locking, and multi-worker behavior were not demonstrated. Thus the current full backend test pass count and live deployment behavior are **unknown**, not zero and not the historical totals.

Repository documents report differing historical counts (README 207, Volume III 211, mock-data status 244; Volume II’s 146 is explicitly older). These are snapshot-specific claims. There is no CI workflow to identify the authoritative commit, command, environment, and current passing result. Frontend has no configured test framework/browser E2E suite; `lint` aliases TypeScript checking, and `lint-python` is syntax compilation. No load/soak, concurrency, browser partial-refresh, ambiguous-write, authentication, tenant-isolation, or deployed persistence tests were found.

## Recommended implementation increments

Ordered to reduce foundational risk; **five increments maximum**. Keep each bounded, reviewable, and independently testable. Do not implement deployment or science-scale claims until relevant tests pass.

1. **Establish a reproducible CI baseline.** Add CI jobs that install pinned/locked dependencies, run backend pytest on a fresh isolated SQLite database, frontend typecheck/build, and publish test counts with revision, command, and environment. Add lockfile-based frontend container installation. Add smoke coverage for create → approval → synthetic simulation and the frontend’s partial-refresh and ambiguous-write behavior. **Acceptance tests:** clean install succeeds; repeated backend runs pass from a fresh DB; failed overview does not hide other fulfilled resources; a write with lost response is shown as unknown/reconciled rather than silently successful local mutation. Reconcile stale validation counts.

2. **Close identity, authorization, and request-resource exposure.** Introduce verified principals, server-derived actor/reviewer identity, and enforced tenant/resource scoping on every list/read/mutation route; explicitly keep Compose development-only or bind published ports to loopback. Add request byte/depth and per-principal/IP rate controls after the authorization boundary. **Acceptance tests:** anonymous requests receive 401; disallowed roles receive 403; two-lab tests deny cross-tenant list, direct-ID read, approval and mutation; payload/body and burst limits return bounded errors; client-supplied reviewer cannot override principal identity.

3. **Enforce scientific-data trust at service boundaries.** New samples must be unverified regardless of request; verification must be a reviewer/evidence-backed transition; scientific training must reject synthetic snapshots. Verify artifact bytes against digests, validate parent links and ownership/domain at write time, and scope deduplication. **Acceptance tests:** API and direct service calls cannot create verified samples or train on synthetic data; invalid/mismatched digest, cross-lab deduplication, missing/cyclic parent, and unresolved evidence cases fail without partial persistence.

4. **Make workflow execution durable and resumable.** Add submission idempotency, queued status, atomic claim with lease/heartbeat/attempt, persisted per-node identity, stale-claim reconciliation, and resume only from the latest successful checkpoint. Separate error/failure checkpoint from completed resume boundary. Keep scheduling as proposals until transactional reservations are deliberately implemented. **Acceptance tests:** duplicate submissions reuse one logical run; concurrent workers claim each queued run at most once at a time; process-crash simulations after each commit reconcile and resume without skipping failed nodes; handler failure is persisted; stale lease and cancellation/retry policies are explicit.

5. **Harden persistence/outbox and prove supported database behavior.** Introduce versioned migrations; make `event_key` unique and enqueue conflict-safe; align batch-size validation; define expiry/ack/recovery state transitions and at-least-once consumer expectations. Decide whether SQLite supports concurrent workers; test only claimed guarantees. If PostgreSQL is supported, declare a driver and exercise migrations/locking on that server. Add readiness that checks database usability while retaining process liveness separately. **Acceptance tests:** upgrade from prior schema; parallel duplicate enqueue yields one logical event; claim/ack/recovery races and lease expiry behave as specified; SQLite and PostgreSQL tests are labeled by actual guarantees; batch boundaries 500/501 return documented responses; readiness reports DB failure while liveness remains available.

## Scope and claims to avoid

Until the increments above are implemented and verified, describe NEXUS as a **single API/web demo stack with SQLite persistence, synchronous synthetic analytical workflows, proposal-only scheduling, and an unimplemented external outbox delivery boundary**. Avoid claims of high availability, horizontally scalable workers, durable automatic workflow recovery, resource reservation, production tenant isolation, immutable scientific provenance, PostgreSQL support, or exactly-once event processing.


## Post-audit implementation update (2026-11-09)

The ranked risks and component table above describe the independent pre-change audit. The following changes were implemented in this workspace and supersede affected baseline statements:

1. **Outbox idempotency:** a unique database index now enforces `event_key` uniqueness. Same-key/same-content retries return the existing event; same-key/different-content requests fail. A safe startup compatibility check adds the index to a legacy SQLite DB only when there are no duplicate keys; duplicates cause a safe failure without deleting rows. A copy of the supplied DB upgraded with all **967 outbox rows preserved**.
2. **Outbox correctness:** request validation matches the service batch cap; stale acknowledgement after lease expiry is rejected. Delivery remains at-least-once with no broker, consumer inbox, or exactly-once claim. SQLite multi-claimer concurrency remains unsupported/unverified.
3. **Workflow recovery boundary:** recommendations now choose only a successful `completed` checkpoint, report a later failed checkpoint separately, refuse to recommend recovery where no completed boundary exists, and continue to refuse physical-side-effect chains. This is still advisory; it does not resume a workflow.
4. **Readiness/correlation:** `/health` remains process liveness; `/ready` probes the database and returns 503 on DB failure. Compose checks `/ready`. Validated request IDs propagate to responses and application logs.
5. **Scientific training trust:** `SampleCreate` permits only `unverified`, and `register_sample` rejects direct attempts to predeclare another status. The baseline training service rejects synthetic snapshots. The verification route still relies on unauthenticated reviewer text and does not resolve evidence references to stored proof, so this is a data-integrity improvement, not complete scientific identity assurance.
6. **Development network boundary:** Compose API/web host ports bind to `127.0.0.1` by default. Compose YAML parses, but container behavior was not run because Docker is unavailable.
7. **Frontend container dependency reproducibility:** the Dockerfile now copies `package-lock.json` and runs `npm ci` rather than unpinned `npm install`. The container build remains unverified because Docker is unavailable.
8. **Artifact record identity and lineage:** global checksum-only deduplication was removed. Exact artifact-code retries are idempotent; conflicting reuse fails. Identical hashes in different labs no longer return another lab's metadata. Registration validates parent existence, same-lab/domain ownership, duplicate parent IDs, cycles, and maximum lineage depth.

### Final verification

- Backend: **259 tests passed** on a fresh isolated SQLite database using the command documented in `docs/testing/distributed-systems-testing.md`.
- Backend source/test `compileall`: passed.
- Frontend: `npm run typecheck` and `npm run build`: passed; static routes `/` and `/_not-found` generated.
- Compose YAML parsing: passed; local-only API/web host ports and `/ready` probe confirmed.
- SQLite compatibility upgrade check: passed on a copy of the supplied DB, preserving 967 outbox rows.
- Docker container build/start, PostgreSQL concurrency/migration behavior, broker publication/consumer deduplication, production authentication, performance/load, and backup restore: **not verified**.

### Updated priority status

| Risk / requirement | Status after this tranche |
|---|---|
| Authentication and tenant/resource authorization | **Still unimplemented; hard blocker for shared or non-local deployment.** |
| Sample self-verification at registration | **Addressed at schema and service boundaries; evidence resolution and authenticated reviewer identity remain open.** |
| Synthetic snapshot reaching baseline model training | **Addressed at service boundary; no separate demo-training mode exists.** |
| Outbox duplicate event keys | **Database uniqueness and content-sensitive retry implemented; concurrent PostgreSQL contention is not tested.** |
| Stale outbox acknowledgement | **Expired lease rejection implemented; acknowledgement/recovery race behavior across concurrent processes remains unverified.** |
| Failed checkpoint treated as completed recovery boundary | **Addressed in advisory recovery plan; no durable executor or auto-resume exists.** |
| Database readiness and request correlation | **Addressed and tested locally; live container health behavior not tested.** |
| Artifact bytes/digest and scientific record immutability | **Still unverified/unimplemented. Parent ownership/existence/cycle checks and artifact-code idempotency are now enforced, but registered hashes/URIs are not checked against durable bytes.** |
| Migrations, durable async workers, broker/inbox, CI, performance/restore/security suites | **Unimplemented or not verified.** |

This tranche strengthens foundational correctness without changing the system's overall classification: NEXUS remains a single API/web demo stack with synchronous analytical workflows and an external outbox-delivery boundary that is not configured. The separate `docs/distributed-systems/100-page-distributed-systems-expansion.md` is an initial design/roadmap, **not** a completed 100-page technical specification.
