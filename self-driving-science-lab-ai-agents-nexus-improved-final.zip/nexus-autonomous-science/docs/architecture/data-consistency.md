# Data Consistency and Recovery Guide

## State ownership

All persistent product state shares one SQLAlchemy database. Logical modules are not independent write-owning services. The authoritative records include experiment/proposal state, objectives, samples, measurements, artifact metadata, model snapshots/evaluations, audit events, outbox entries, campaigns, agent runs, workflow runs, and workflow checkpoints.

| Data | Required consistency | Current mechanism | Remaining concern |
|---|---|---|---|
| Experiment identity and lifecycle | Strong for each committed transaction | Relational rows plus explicit transition validation | No optimistic version/CAS or conflict retry on concurrent transitions |
| Audit + outbox for event-producing writes | Atomic within one DB transaction | Same `Session` + caller commit in `record_event` paths | Not universal unless each API path is verified; no broker transaction |
| Outbox idempotency key | Strong uniqueness | Unique index, safe same-content retry, mismatch rejection | PostgreSQL concurrency not stress-tested; deployed DB migration must be run |
| Workflow checkpoints | Append/hash chain within DB | Unique key/index constraints and SHA-256 hash links | Hash chain does not make tables immutable; run launch is not idempotent |
| Artifact metadata | Strong per DB write | SQLAlchemy metadata row | Bytes/digest/URI are not verified by configured storage adapter |
| Scientific measurements | Preserve origin and synthetic label | Measurement row and experiment linkage in demo flow | Production instrument/protocol/calibration linkage is incomplete |
| Read models | Read-your-writes on same primary session | Single database | No replica or CQRS projection exists |

## Transaction boundaries

A write route should follow this form:

1. Validate the request and authorization (authentication is currently absent).
2. Read and validate referenced state.
3. Write domain state and related audit/outbox state using the same `Session`.
4. Commit once at the route boundary; rollback the whole unit on failure.
5. Return the persisted identity/status, not an inferred successful external side effect.

Long-running scientific execution must not hold a database transaction open. The present workflow supervisor commits a started checkpoint and each completed node; this is diagnostic persistence, not a distributed transaction or asynchronous job queue.

## Idempotency contract

For `enqueue_event`:

- Key must be nonblank; `_nexus_delivery` is reserved.
- First insertion creates the outbox event.
- Repeating the exact key and equivalent business content returns the original event.
- Reusing the key with different aggregate/type/payload fails loudly.
- A database unique index is the final arbiter under concurrent inserts.
- Delivery attempts remain at-least-once; consumers must deduplicate independently.

On startup, legacy DBs receive the unique index if no duplicate keys exist. If collisions are detected, startup fails without deleting or rewriting records. An operator must inspect and resolve the key collision while preserving scientific and audit history, then restart.

## Workflow consistency

Workflow execution is currently synchronous. A persisted run/checkpoint history aids diagnosis, but a process can stop after committing `running` and before recording failure. There is no stale-run heartbeat or executor to resume it. The recovery endpoint is advisory. It now selects the latest `completed` checkpoint as its boundary, identifies a later failure separately, and refuses recovery if no completed checkpoint exists or any checkpoint reports physical side effects. `automatic_resume` remains false.

## Database and replica policy

SQLite is the local default and the Compose deployment's DB. `check_same_thread=False` is not a distributed lock. Do not run multiple claimers against SQLite and call that supported HA. PostgreSQL URL support is present at the SQLAlchemy engine level, but Compose does not deploy PostgreSQL and no PostgreSQL driver/migration/test matrix was verified in the supplied baseline.

If read replicas are introduced later, route authoritative lifecycle and outbox reads to the primary until consistency semantics and replica lag are measured. No current replica exists; no RPO/RTO or zero-data-loss claim is made.

## Recovery rules

- Never delete or rewrite an experiment, failed result, measurement, audit row, or outbox row to make a dashboard appear clean.
- Keep raw artifacts immutable and create derived records with explicit parent lineage; current object storage does not yet enforce this.
- A lease expiry is evidence that ownership expired, not proof the previous worker stopped executing. Use idempotent consumers and explicit operator review.
- A failed scientific experiment may still contain useful partial observations. Separate scientific negative results from infrastructure failures.
- Any future repair must record who changed what, why, when, and which source row was superseded.
