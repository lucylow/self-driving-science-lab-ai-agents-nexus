# ADR 0001: Keep NEXUS a Modular Monolith Until Measured Need

- **Status:** Accepted
- **Date:** 2026-11-09

## Problem and context

The supplied repository contains one FastAPI backend with many domain-specific services and one Next.js frontend. It runs in a two-service Compose topology with SQLite. No independently deployable scientific service, queue broker, or worker cluster is present. The mission includes future multi-node capability but requires local development and preservation of existing functionality.

## Decision

Preserve the modular monolith and strengthen internal contracts, database transaction discipline, and test boundaries before extracting services. Treat logical domains (experiments, data/provenance, orchestration, model evaluation, governance, events) as modules with explicit APIs and state ownership. Keep SQLite for local demo; require a deliberate PostgreSQL/migration/operations phase before multi-instance queue claiming.

## Alternatives considered

1. Immediate microservices + Kafka/Kubernetes: rejected; no measured scale requirement, adds deployment/security/consistency complexity, and would not improve scientific correctness by itself.
2. Keep a loosely coupled monolith without contracts: rejected; makes transaction boundaries and future extraction harder to reason about.
3. Modular monolith with future extraction seams: selected; lowest operational cost while the product remains a deterministic starter.

## Consequences and trade-offs

- One deployment and database transaction can coordinate domain/audit/outbox writes simply.
- A process-wide deployment remains a scaling bottleneck; synchronous scientific workflows consume API request capacity.
- A single schema and shared DB require discipline because modules can still touch other domain tables.
- Production extraction is deferred until load, ownership, failure isolation, or security requirements demonstrate need.

## Security, migration, and verification

No new trust boundary is created. Authentication, tenant isolation, migrations, deployment, and backups remain prerequisites before production. Verify service contracts with route/service tests and preserve independent tests for state transitions, transaction rollback, and concurrency when a PostgreSQL environment is available.
