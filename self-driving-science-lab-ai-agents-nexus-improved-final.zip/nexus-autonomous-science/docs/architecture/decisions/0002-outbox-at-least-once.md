# ADR 0002: Transactional Outbox with At-Least-Once Publication

- **Status:** Accepted
- **Date:** 2026-11-09

## Context

Domain routes already write audit events and outbox rows using the same SQLAlchemy session. The outbox has claims, lease tokens, retry backoff, expired-lease recovery, and dead-letter status, but no broker adapter or inbox. A publisher can crash after a broker accepts a message and before the database acknowledgement.

## Decision

Use the relational outbox as durable publication intent, enforce uniqueness on `event_key`, and document delivery as **at-least-once**. Consumers must deduplicate using the stable event `id` or `event_key` and make side effects idempotent. Acknowledgements require the current claim token and an unexpired lease. No exactly-once, global ordering, or broker guarantee is claimed.

## Alternatives and trade-offs

- Exactly-once broker/database transaction: deferred; no broker exists and practical semantics depend on broker and consumer transaction support.
- Drop the outbox and publish inline: rejected because a process crash can lose the notification after committing domain state.
- Adopt Kafka immediately: rejected without demonstrated event volume or operational readiness.

## Operations and migration

A unique database index is added for new schemas and ensured at application schema initialization for existing schemas. Duplicate legacy keys stop startup with no row deletion. This bootstrap is not a substitute for versioned production migrations; add Alembic before production deployment.

## Verification

Tests cover same-content retries, conflicting content, unique fresh schema, safe legacy index creation, collision refusal without data loss, lease expiry rejection, retry/dead-letter behavior, and API parameter validation. PostgreSQL contention and real broker/consumer crash tests remain required before multi-worker deployment.
