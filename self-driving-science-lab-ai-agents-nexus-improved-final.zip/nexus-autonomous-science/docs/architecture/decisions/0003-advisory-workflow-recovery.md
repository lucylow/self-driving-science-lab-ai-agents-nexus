# ADR 0003: Recovery Plans Are Advisory and Resume Only After Completed Checkpoints

- **Status:** Accepted
- **Date:** 2026-11-09

## Context

NEXUS persists synchronous analytical workflow runs and SHA-256 hash-linked checkpoint rows. The supervisor records a failed checkpoint when a node raises. Earlier recovery logic selected the newest checkpoint without checking whether the node had completed, which could describe the failed node as the completion boundary.

## Decision

Recovery planning verifies the hash chain, rejects any chain containing physical side effects, and selects the newest `node_status=completed` checkpoint. A later failed checkpoint is returned separately. If no completed checkpoint exists, recovery is ineligible. The API remains advisory and never automatically replays execution.

## Alternatives and trade-offs

- Resume automatically from the newest row: rejected because a failure checkpoint is not a completion boundary and tools may have external side effects.
- Resume failed node in place: deferred until task-level idempotency, leases, attempt records, and an operator-confirmed replay contract exist.
- Disable all recovery information: rejected; an explicit safe checkpoint can still support diagnosis and future human-governed recovery.

## Security and verification

Physical lab execution stays disabled. Regression tests verify last-success selection, failed-node disclosure, no-completed-checkpoint rejection, and refusal when any checkpoint records physical side effects. A true executor, cancellation, heartbeat, or crash-recovery loop is not implemented.
