# ADR 0004: Distinguish Readiness from Liveness and Propagate Request IDs

- **Status:** Accepted
- **Date:** 2026-11-09

## Context

The previous `/health` response was unconditional and Compose used it as the only healthcheck, so a broken database could still appear healthy. Request IDs existed only on unexpected errors and were generated there, preventing normal client/log correlation.

## Decision

Keep `/health` as process liveness. Add `/ready` to run a minimal database `SELECT 1`; return 503 when that dependency is unavailable. Compose checks `/ready`. Add a validated `X-Request-ID` middleware: accept only 1–128 ASCII letters/digits/dot/underscore/hyphen, otherwise generate a UUID; propagate on HTTP responses and include a request ID in application log records. No broker/worker/instrument health is reported because these are not configured.

## Trade-offs and security

Client IDs are untrusted labels, so the strict alphabet/length limit avoids header/log injection. IDs are correlation, not authentication and not a trusted tenant/actor identity. DB readiness is intentionally narrow and does not validate all schema/data dependencies.

## Verification

Tests cover healthy and unavailable DB readiness and valid/invalid request IDs. Compose YAML is inspected separately; a live container healthcheck is not verified because Docker is unavailable in the current environment.
