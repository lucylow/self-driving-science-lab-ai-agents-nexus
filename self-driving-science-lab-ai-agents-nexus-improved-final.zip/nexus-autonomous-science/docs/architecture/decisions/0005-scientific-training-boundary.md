# ADR 0005: Sample Identity Requires Review and Synthetic Data Cannot Train Scientific Models

- **Status:** Accepted
- **Date:** 2026-11-09

## Context

Sample creation accepted caller-supplied `identity_status=verified`, bypassing the separate verification operation. Dataset construction can intentionally include synthetic measurements; the baseline trainer did not reject a snapshot marked synthetic despite the scientific contract excluding synthetic-only training.

## Decision

The sample-create contract accepts only `unverified`; the service rejects direct attempts to register with another status and always persists `unverified`. Status changes happen only via the verification service route. The model training service rejects any `TrainingDatasetSnapshot` with `synthetic=True` before processing its rows.

## Limitations

The verification route still accepts reviewer text and evidence references without authentication or checking those references resolve to stored artifacts. This protects against self-declared status at creation, not against an unauthenticated caller using the review route. Production identity verification remains a security blocker. No special demo training mode exists.

## Tests

Tests verify the schema rejects preverified sample requests, the service rejects them even when bypassing the schema, the review service can mark an existing sample verified, and the scientific training service rejects a synthetic snapshot.
