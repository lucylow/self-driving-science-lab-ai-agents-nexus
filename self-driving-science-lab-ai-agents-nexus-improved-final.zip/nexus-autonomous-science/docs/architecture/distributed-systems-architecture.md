# NEXUS Distributed-Systems Architecture

**Status:** Current-state architecture and staged target; not a claim that production distributed infrastructure is deployed.

## Executive summary

NEXUS is a **modular monolith**: a Next.js interface calls one FastAPI application; route modules delegate to Python services; SQLAlchemy persists state to one database. Docker Compose contains one API and one web container, with SQLite on a named volume. The application has no broker, independent worker service, service registry, object store, or production authentication provider. Its persisted workflow supervisor and transactional-outbox primitives are useful foundations, but neither creates a horizontally scalable job fleet by itself.

The immediate architecture objective is correctness and recoverability without premature microservices. Local SQLite remains a development/demo option. Before multiple API/publisher processes are supported, a production deployment needs PostgreSQL, versioned migrations, tested atomic claim semantics, and idempotent consumers. Before non-demo data is used, identity, authorization, retention, backups, and artifact integrity controls are mandatory.

## Current topology

```mermaid
flowchart LR
  Browser[Next.js / React browser client] -->|HTTP JSON| API[FastAPI modular monolith]
  API --> ORM[SQLAlchemy sessions]
  ORM --> DB[(SQLite default / PostgreSQL URL supported)]
  API --> Local[In-process domain and scientific services]
  API --> Outbox[(Outbox rows; no broker adapter)]
  API --> WF[(Workflow runs and hash-linked checkpoints)]
  Local --> Audit[(Audit events and provenance metadata)]
  UIFallback[Deterministic frontend demo fallback] -. offline-only .-> Browser
```

The frontend's offline fallback is for interface exploration; it is not authoritative persistence. The API starts by calling `create_all` and seeding demo records. `/health` is process liveness. `/ready` performs a database `SELECT 1` and is used by the Compose healthcheck. Neither endpoint claims that an external broker, object store, worker, or laboratory instrument is healthy.

## Logical service catalog and ownership

These are Python modules and route groups, not independently deployed microservices.

| Logical boundary | Implementation | State owner / present boundary |
|---|---|---|
| Identity and access | No production identity provider or principal middleware | Unimplemented; no tenant authorization boundary |
| Projects/objectives/hypotheses | `api/objectives.py`, `services/hypotheses.py`, research services | SQLAlchemy entities; API process owns writes |
| Experiments/governance | `api/experiments.py`, `api/governance.py`, `services/lifecycle.py` | Experiment and approval entities; human review is represented in demo flow |
| Samples/artifacts/data | `api/samples.py`, `api/artifacts.py`, ingestion/data routes | Relational metadata; actual artifact bytes are not stored by the in-memory adapter |
| Scientific analysis/models | `services/domain_science/`, `model_intelligence/`, `advanced_research/` | Local deterministic computations; no distributed compute cluster |
| Agent runtime/orchestration | `agent_runtime.py`, `workflow_supervisor.py`, `workflow_checkpoints.py` | Persisted runs/checkpoints, synchronous in-request execution; demo agent adapter |
| Events/audit | `services/audit.py`, `event_outbox.py`, `api/outbox.py` | Same database transaction on audited write paths; publisher is external/not configured |
| Scheduling/capacity | scheduler and capacity helpers | Proposal-only scheduling; local capacity helper is not a distributed reservation |
| Observability | Python logging, `/health`, `/ready`, outbox status endpoint | Request correlation and DB readiness exist; no metrics backend, tracing, alerting, or worker fleet |

## Communication policy

- Browser-to-API: synchronous HTTP/JSON. Long-running scientific jobs should eventually return a durable job ID, but present workflow orchestration still runs synchronously.
- API-to-database: SQLAlchemy session/transaction. Domain mutations, audit records, and outbox rows share a transaction where `record_event` is called on the same session and the route commits it.
- API-to-broker: not implemented. `POST /api/outbox/prepare` returns a leased envelope; an external publisher must send it and call acknowledge.
- API-to-object storage: no production implementation. The current storage adapter is process-memory-only and stores artifact metadata/URI rather than authoritative bytes.
- Workflow-to-agent: in-process deterministic demo adapter; sequential, not a distributed task dispatch protocol.

## Consistency and delivery guarantees

Outbox event keys are now protected by a unique index. Repeating a key with identical aggregate/type/payload returns the prior row; reusing it for different content raises a conflict. A startup compatibility step adds this index to legacy schemas without deleting rows and fails if it encounters duplicate historical keys.

This is **one durable outbox row per key**, not exactly-once message delivery. A publisher can publish and crash before acknowledgement; a recovered lease can cause the same event to be published again. Delivery should be treated as at-least-once and the consumer must deduplicate by stable event identity. SQLite does not implement PostgreSQL row-level `FOR UPDATE SKIP LOCKED` semantics; multi-worker claims on SQLite are not supported or verified.

Workflow checkpoints are hash-linked and persisted. Recovery recommendations now select only checkpoints with `node_status=completed`; a later failed checkpoint is reported separately. No automatic resume is performed. Physical-side-effect recovery is refused.

## Staged target architecture

1. **Local correctness (implemented in this tranche):** distinct liveness/readiness, validated request correlation, database uniqueness for outbox identity, conflict-safe idempotency, bounded HTTP batch validation, stale-lease acknowledgement rejection, safer checkpoint selection, sample identity review boundary, and synthetic-training rejection.
2. **Schema lifecycle:** add Alembic or another versioned migration tool, establish pre-deploy migration execution, and remove production dependence on startup `create_all`/seed behavior.
3. **Database-backed durable execution:** introduce a queue/job table with idempotent submission identity, atomic claim, lease owner/token, heartbeat, attempts, cancellation, and recoverable state transitions. Keep physical laboratory execution outside scope.
4. **Multi-process delivery:** support PostgreSQL-backed claim concurrency, prove duplicate claims are excluded under contention, connect a broker adapter, and build an inbox/deduplication contract for consumers.
5. **Data integrity:** enforce sample review, immutable artifact bytes and verified digests, lineage references, objective/protocol snapshots, optimistic concurrency for lifecycle transitions, and model build provenance.
6. **Production security and observability:** authenticated principal, lab/tenant authorization, trusted actor identity, request/body/rate limits, secret management, metrics/tracing, alerting, and incident procedures.
7. **Only then scale out:** run multiple API instances and worker pools with external object storage and tested PostgreSQL backups/failover. Do not introduce Kafka/Kubernetes or microservices without measured need.

## Deployment and failure boundaries

Current Compose is a single-machine development deployment. It is not a highly available topology. SQLite volume durability depends on host/volume durability and external backups. A process crash during a persisted workflow can leave a run `running`; no stale-run lease scanner resumes it. A broker outage cannot occur inside this app because no broker is configured, but the outbox can accumulate pending rows. An object-storage outage is not modeled by the in-memory adapter.

## Security boundary

The API has no authenticated principal or tenant-scoped authorization. Caller-supplied reviewer/actor values are not proof of identity. It must not be exposed to untrusted networks or used for non-synthetic confidential research until identity and authorization are implemented and tested. CORS is browser policy, not access control.

## Acceptance gates before claiming distributed production readiness

- Versioned migration from a copy of production-like data, with backup/rollback rehearsed.
- PostgreSQL integration and concurrent enqueue/claim/ack/recovery tests.
- Worker crash tests at every durable boundary; stale running jobs reconciled without replaying side effects.
- Idempotent consumer/inbox tests and poison-message/replay procedures.
- Artifact bytes hashed and verified, with immutable raw source and persistent object storage.
- Authentication, tenant isolation, audit attribution, resource limits, and security tests.
- Measured workload, failure-injection, backup restore, and alerting results tied to real dependencies.
