# NEXUS Event Catalog

## Current event path

`record_event` inserts an audit row and an outbox row through the caller's SQLAlchemy `Session`. The API caller commits both in the same database transaction. This is a local transactional-outbox pattern: the application can durably remember a publication intent with the domain write. It does not publish to a broker.

```mermaid
sequenceDiagram
  participant Client
  participant API as FastAPI route
  participant DB as SQLAlchemy database
  participant Publisher as External publisher (not configured)
  participant Consumer as Consumer (not configured)
  Client->>API: command
  API->>DB: domain write + audit + outbox row
  API->>DB: commit
  API-->>Client: response
  Publisher->>DB: prepare / claim lease
  Publisher->>Consumer: publish stable event envelope
  Publisher->>DB: acknowledge with claim token
```

## Event envelope

The prepare API returns:

| Field | Meaning |
|---|---|
| `id` | Stable outbox row/event identity; preferred consumer deduplication key |
| `event_key` | Producer-defined idempotency key; unique in the database after schema upgrade |
| `aggregate_type`, `aggregate_id` | Domain aggregate identifying context |
| `event_type` | Event type string chosen by producer |
| `payload` | Business event payload; internal `_nexus_delivery` metadata is omitted |
| `attempt` | Claim attempt number |
| `claim_token` | Opaque lease token required for acknowledgement |
| `lease_expires_at` | Claim deadline |

The record additionally persists status, attempts, last error, creation time, publication timestamp, and delivery metadata in JSON. Payloads should stay small; large artifacts should be represented by a durable immutable URI and digest, not embedded bytes.

## Known event families

Event type is a string, not an enforced enum. Examples emitted by current code include experiment state changes, simulation completion/failure, sample registration/identity review, campaign actions, workflow readiness/failure, artifact registration, and model/prediction events. The source call sites are the authoritative catalog; new events should be added to this table and include schema/version documentation before a broker consumer depends on them.

| Family | Producer / subject | Payload expectations |
|---|---|---|
| Experiment lifecycle | `api/experiments.py` | Experiment identity, prior/new state, actor label, correlation context |
| Sample registry | `services/sample_registry.py` | Sample code/domain, synthetic flag, evidence references on review |
| Artifact registry | `api/artifacts.py` | Artifact metadata and provenance references; bytes are not included |
| Workflow | `services/workflow_supervisor.py` | Workflow key/run identity, state summary, synthetic flag, error summary |
| Model/prediction | `api/model_intelligence.py` | Model/dataset/subject identity and synthetic/origin labels |

These examples are descriptive, not a complete versioned event schema. Event payload versioning, causation IDs, and consumer contracts remain future work.

## Status lifecycle

```mermaid
stateDiagram-v2
  [*] --> pending
  pending --> ready_for_delivery: claim; attempts increment
  ready_for_delivery --> published: valid success acknowledgement before expiry
  ready_for_delivery --> delivery_failed: valid failure acknowledgement
  delivery_failed --> ready_for_delivery: retry time reached and re-claimed
  ready_for_delivery --> delivery_failed: lease expired and recovery sweep
  delivery_failed --> dead_letter: retry limit reached
  ready_for_delivery --> dead_letter: expired lease at retry limit
```

A claim token fences an acknowledgement from a prior lease after a new claim replaces the token. Acknowledgement after the recorded lease expiry is now rejected. On PostgreSQL, the batch query asks for `FOR UPDATE SKIP LOCKED`; on SQLite, the source code explicitly does not claim equivalent row-lock safety.

## Idempotency, ordering, and delivery

- Database guarantee: one row per exact `event_key` after the unique index is present. Identical content retries return the same row. Content mismatch is a `ValueError`.
- Delivery guarantee: at-least-once when an external publisher is used. Publish-success followed by process death before DB acknowledgement can cause a duplicate publish.
- Consumer guarantee: absent. There is no inbox table or consumer deduplication implementation.
- Ordering: selection is ordered by `created_at` for the scan. There is no per-aggregate sequence column, strict aggregate ordering guarantee, or cross-process global ordering guarantee.
- Transactional outbox coverage: only producers that call `record_event` and commit the same SQLAlchemy session receive atomic domain+audit+outbox persistence. This must be checked per write path.

## Operational controls

The API exposes `GET /api/outbox`, `POST /api/outbox/prepare`, `POST /api/outbox/{event_id}/prepare`, `POST /api/outbox/{event_id}/acknowledge`, `POST /api/outbox/recover-expired-leases`, and `GET /api/outbox/metrics`. There is no default publisher, automatic drain loop, alert, or operator authentication. Do not expose these endpoints to untrusted clients.
