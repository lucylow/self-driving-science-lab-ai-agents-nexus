# NEXUS Service Catalog

**Interpretation:** Entries below are logical module boundaries inside one FastAPI process. Only the API and web application are separate deployable containers in the supplied Compose file.

| Boundary | Code / representative routes | State or data | External dependency | Current health / limitation |
|---|---|---|---|---|
| API application | `backend/app/main.py`, `api/router.py` | Request-scoped SQLAlchemy sessions | Database | `/health` is liveness; `/ready` verifies DB only. No global authentication. |
| Objectives and hypotheses | `api/objectives.py`, hypothesis services | Objective/hypothesis entities | None | Relational, single application transaction; no multi-tenant scope. |
| Experiment lifecycle | `api/experiments.py`, `services/lifecycle.py` | Experiment, approval, measurement, audit/outbox | DB | Explicit state machine and demo simulation; no compare-and-swap version guard. |
| Governance | `api/governance.py`, governance services | Approval/review records | Human reviewer represented by API input | Demonstration gate only; reviewer label is caller-supplied and unauthenticated. |
| Sample registry | `api/samples.py`, `services/sample_registry.py` | Sample identity and ancestry | DB | Creation now forces `unverified`; separate verify route requires reviewer text and evidence references, which are not resolved to verified stored artifacts. |
| Artifact registry | `api/artifacts.py`, `services/artifact_registry.py` | Metadata, digest, URI, parent references | Storage adapter | Idempotency is scoped by artifact code; parent existence, same-lab/domain ownership, cycles, and depth are checked. Bytes/digests remain unverified and storage is not durable. |
| Ingestion and data quality | `api/ingestion.py`, `services/ingestion_pipeline.py`, quality rules | Jobs, dataset metadata, measurements in applicable flows | DB / future file store | Schema/provenance checks exist; not a production ingest pipeline with durable raw-byte preservation. |
| Scientific computation | `services/domain_science/`, `advanced_research/` | Mostly request-time computation; selected results persisted by route | CPU in API process | Deterministic local operations, not distributed simulation/compute. |
| Agent runtime | `api/agent_runtime.py`, `services/agent_runtime.py` | Agent run history | Deterministic demo adapter | Inline synchronous handler; no model provider, worker process, queue, lease, cancellation, or horizontal dispatch. |
| Workflow supervisor | `api/orchestration.py`, `services/workflow_supervisor.py` | Workflow run and checkpoints | DB | Persisted synchronous runs and hash-linked checkpoints. Not a durable asynchronous job runner. |
| Workflow preview | `api/workflows.py`, `services/workflow_graph.py` | In-memory graph state | None | Preview/demonstration only; no persisted run semantics. |
| Scheduler/capacity | `api/scheduling.py`, scheduler and capacity services | Proposal data / local helper state | None | Produces advisory proposals; does not reserve shared capacity. |
| Audit and outbox | `services/audit.py`, `services/event_outbox.py`, `api/outbox.py` | `AuditEvent`, `OutboxEvent` | External broker not configured | Atomic with caller transaction on same session; unique event-key index and retries/leases. No publishing adapter or inbox. |
| Model snapshots/training | `api/model_intelligence.py`, dataset/model services | Snapshot/model/evaluation entities | Local CPU | Synthetic snapshots are rejected at training boundary. No production registry/artifact storage or verified code/environment digest. |
| Frontend | `frontend/src/` | Browser state and local demo fallback | FastAPI URL | Next.js app; fallback is not authoritative. No distributed state owner. |

## Shared data ownership

All persistent entities currently share one SQLAlchemy database. There are no separate service-owned databases and no service-to-service authentication. A single database transaction is the consistency boundary for writes that use one `Session`; this does not make a multi-step workflow a distributed transaction.

## Deployment inventory

- `api`: FastAPI/Uvicorn container, one service in Compose, SQLite at `/data/nexus.db` on a named volume.
- `web`: Next.js container, build-time API URL, exposed port 3000.
- Not present: queue broker, background worker service, cache, object store, tracing backend, metrics server, migration job, reverse proxy, production identity provider, Kubernetes/Helm, CI workflow.

## Service health

`/health` reports API process liveness. `/ready` executes a simple database query and reports 503 if that dependency is unavailable. No live worker or broker health can be reported because neither is configured. Outbox metrics are database counts only and are not a substitute for end-to-end broker health.
