# Synthetic data provenance

Every generated record is authored by the local NEXUS demo-data generator. The generator does not retrieve scientific papers, public datasets, private systems, customer records, or Discovery Loop internal materials. Synthetic literature entries use the reserved-looking local URI scheme `synthetic://` and must not be cited as publications. Computed scores, costs, durations, compute labels, and project narratives are illustrative values only.

The conceptual inspiration is limited to public descriptions of automating iterative scientific and engineering workflows: [Discovery Loop public site](https://www.discoveryloop.com/) and [public announcement](https://www.discoveryloop.com/blog/announcing-discovery-loop/). NEXUS is an independent demonstration and is not an official Discovery Loop product. The generated records do not describe Discovery Loop's projects, models, infrastructure, customers, or performance.

The bundle-level and per-record provenance markers are `synthetic: true` and `SYNTHETIC DEMONSTRATION DATA`. The frontend repeats the notice above the interactive project explorer. Synthetic values are not measured evidence and must not be used to validate scientific conclusions, train production models, or authorize physical experiments.
