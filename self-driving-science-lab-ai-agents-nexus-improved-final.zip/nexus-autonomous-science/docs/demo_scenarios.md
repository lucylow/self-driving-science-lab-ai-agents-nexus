# Synthetic research walkthroughs

These walkthroughs are fictional routes through the linked demo records. Use `/api/synthetic-research/records/{category}` to follow IDs from one stage to the next. No scenario describes work performed by Discovery Loop or a real laboratory.

1. **Transformer efficiency:** Start with Foundation Model Optimization, inspect its adaptive-training project, follow objective and hypothesis IDs into experiment proposals, then compare linked execution scores and compute hours.
2. **Reasoning evaluation:** Use Reasoning and Evaluation. Follow each evaluation's execution, benchmark, and model IDs; include inconclusive and negative outcomes when discussing the synthetic comparison.
3. **Inference optimization:** Explore Efficient Inference and compare synthetic latency/throughput objectives with model precision and benchmark records.
4. **Distributed training:** Start at Distributed Machine Learning and inspect compute jobs and resource records linked to executions. Costs and GPU-class labels are illustrative placeholders.
5. **Scientific discovery extension:** Explore Computational Materials Discovery or Energy Storage Materials. Follow the objective → hypothesis → proposal → simulated execution → observation → finding chain, while treating all outcomes as fictional computational examples.

Select a project in the dashboard to inspect its linked hypotheses, proposals ranked by an illustrative acquisition score, executions, observations, and findings. Hypotheses show their synthetic prior/posterior and evidence count. The dashboard currently offers live project search, program filtering, and paginated browsing; other categories are accessible through the paginated API.
