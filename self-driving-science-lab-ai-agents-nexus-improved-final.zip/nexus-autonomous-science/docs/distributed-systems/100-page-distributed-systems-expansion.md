# Distributed-Systems Expansion: Architecture and Implementation Plan

**Document state:** Initial architecture and implementation tranche, not the requested approximately 100-page final technical document. It is intentionally concise rather than padded. The remainder is a prioritized engineering program; items labeled planned or blocked are not implemented.

## 1. Executive summary

NEXUS is an existing scientific research application, not a blank service template. Its current topology is a Next.js client, one FastAPI modular monolith, SQLAlchemy ORM, and a local SQLite default. The codebase already contains substantial domain science, provenance helpers, governance gates, deterministic agents, persisted workflow runs/checkpoints, and a transactional-outbox primitive. These are valuable foundations, but they do not constitute a distributed worker fleet or production scientific infrastructure.

This tranche implements correctness-oriented changes at existing seams: durable outbox event-key uniqueness and safe key reuse; safe legacy index upgrade; aligned batch validation; stale lease acknowledgement rejection; DB-aware readiness; validated request correlation; advisory workflow recovery from only successful checkpoints; enforced unverified-on-create sample identity; and denial of synthetic data at model-training service boundary. Tests exercise these behaviors. Physical execution remains disabled.

The platform does **not** have a broker publisher, inbox, durable asynchronous workflow executor, worker leases/heartbeats, service authentication, tenant isolation, production object storage, database migrations, database replication, CI, or production backup/restore system. No HA, exactly-once, zero-data-loss, measured throughput, or production security claim is made.

## 2. Current architecture and inventory

### 2.1 Runtime

- Frontend: Next.js 16, React 19, TypeScript; browser API client and local synthetic fallback.
- Backend: Python 3.12, FastAPI, Pydantic 2, SQLAlchemy 2.
- Deployment: development Dockerfiles and Compose API/web services. Compose uses SQLite in a named volume and development/demo settings; host ports are now localhost-bound.
- Persistence: one relational database. `create_all` is called at startup and seed data is inserted when the laboratory table is empty. This is not a migration system.
- Scientific workflow: route and service modules for objectives, experiments, samples, data, artifacts, models, research campaigns, domain-specific science, evaluation, governance, and provenance.
- Execution: deterministic demo agent handlers called synchronously; stored workflow run records and checkpoint chain. No background worker service.
- Events: audit row plus outbox intent on paths using `record_event`; no external message bus.
- Storage: metadata/URI registry with in-memory local storage adapter; no durable object-storage implementation.

### 2.2 Architecture classification

```mermaid
flowchart TB
  Browser[Next.js web client] --> API[FastAPI modular monolith]
  API --> Services[Domain services and deterministic demo agents]
  API --> DB[(Single SQLAlchemy database)]
  Services --> Event[AuditEvent + OutboxEvent transaction]
  API --> Checkpoints[(WorkflowRun + hash-linked checkpoints)]
  FrontendFallback[Local synthetic fallback] -. demo only .-> Browser
  ExternalBroker[Broker: absent] -. not wired .-> Event
  Worker[Async worker fleet: absent] -. not wired .-> DB
  ObjectStore[Durable object storage: absent] -. metadata URI only .-> Services
```

This is a modular monolith with some internal event/checkpoint patterns. It is not a microservice deployment or event-sourced platform.

## 3. Architecture goals and non-goals

### Goals

1. Preserve experiment identity, provenance, and failed/partial results.
2. Make retry/idempotency semantics explicit and database-backed.
3. Make recovery observable and conservative.
4. Preserve local setup and demo usability.
5. Create a measured path from one DB-backed API to multiple API/worker processes.
6. Do not claim real worker health, queue depth, replication, or experiment execution from synthetic data.

### Non-goals for the current increment

- Do not add Kafka/Kubernetes/microservices before requirements justify them.
- Do not enable physical laboratory actions.
- Do not claim exactly-once delivery or automatic scientific workflow resumption.
- Do not present synthetic measurements or demo agent output as scientific evidence.

## 4. Service boundaries and ownership

All boundaries remain modules in one process and one database.

| Domain | Current owner | Interface | Consistency/failure note |
|---|---|---|---|
| Identity/authorization | Not implemented | None | No production trust boundary; deployment restricted to local demo. |
| Objectives/hypotheses | Objective/hypothesis APIs/services | HTTP/SQLAlchemy | Objective revision and experiment version snapshot need stronger binding. |
| Experiments/governance | Experiment and governance routes/services | HTTP/state-machine helper | State transition has no optimistic version guard; reviewer is not authenticated. |
| Samples | Sample registry | HTTP/SQLAlchemy | Creation forces unverified; verification evidence references are not yet resolved to stored proof. |
| Artifacts/data | Artifact registry/ingestion | HTTP/metadata | Bytes/digest not verified; object storage absent. |
| Agent execution | Agent runtime | In-process call | Deterministic demo adapter; inline execution; no queue/lease. |
| Workflow | Supervisor/checkpoints | Orchestration API | Per-step checkpoint persistence, but synchronous run and advisory recovery only. |
| Audit/events | Audit service/outbox | Same DB session | Unique key; at-least-once external delivery contract; no publisher/inbox. |
| Models/evaluations | Snapshot/training/prediction services | HTTP/local CPU | Synthetic training rejected; code/environment provenance incomplete. |
| Scheduling | Preview services | HTTP response | Advisory capacity proposal only; no reservations. |

## 5. Communication and event strategy

Current synchronous HTTP is appropriate for short requests and demo workflows. Long-running compute should eventually create a durable job and return its ID, with polling/SSE/WebSocket only when real status updates exist. Outbox envelopes provide a future broker boundary; no broker has been selected or wired.

### Event flow

```mermaid
sequenceDiagram
  participant R as Request handler
  participant D as Database
  participant P as Future publisher
  participant C as Future consumer
  R->>D: Domain state + audit + outbox in one Session
  R->>D: Commit
  P->>D: Claim pending rows with lease
  P->>C: Send envelope (may be repeated)
  P->>D: Acknowledge with token before lease expiry
  Note over P,C: Crash after send/before ack can produce duplicate delivery
```

Stable event identity must be used for deduplication. Event ordering is not strict per aggregate. Payload versioning, causation, inbox processing, poison-message quarantine, and broker auth are pending.

## 6. Database consistency and transaction model

The database is source of truth for relational state. Strong consistency is required for experiment identity/state, approvals, audit history, outbox identity, and workflow checkpoint chain. No read replica or CQRS projection exists. Read-your-writes is available through the primary DB path.

Domain write flow: validate → read/authorize (authorization pending) → mutate domain state → append audit/outbox on the same session → commit. External compute/publish must happen outside the transaction. The legacy outbox index upgrade is intentionally non-destructive: it creates a unique index only if no duplicate keys exist; collisions stop startup for operator review.

No global distributed transaction is proposed. Long-lived research programs should use a persisted saga/state machine with explicit compensation, idempotency per step, timeout, audit, cancellation, and manual intervention.

## 7. Queue, worker, and orchestration design (target)

Before an executor is added, specify a job table with: `job_id`, `submission_key`, `job_type`, `schema_version`, `aggregate_id`, `status`, `attempt`, `max_attempts`, `lease_owner`, `lease_token`, `lease_expires_at`, `heartbeat_at`, `available_at`, `started_at`, `finished_at`, `cancel_requested`, `error_class`, `error_summary`, and immutable input/output references. Add a unique key on `(tenant, submission_key)` when tenant identity exists.

Workers should claim with atomic compare-and-swap/`SKIP LOCKED` on PostgreSQL, heartbeat, commit short state transitions, and checkpoint only after completed idempotent steps. On lease expiry, mark interrupted and reconcile possible side effects before requeue. A disappeared heartbeat is not proof that a process stopped executing. Preserve partial artifacts. Shutdown stops new claims, then finishes or safely releases work.

Workflow DAG execution should persist a versioned plan, node identity, per-node input hash/output reference, attempt history, and dependency state. Start by serial sequential execution and add parallelism only after node idempotency, resource budgets, and order-independent aggregation are proven.

## 8. Storage, lineage, and scientific correctness

A production storage adapter must write immutable bytes, calculate SHA-256 from bytes, verify on read, and return a stable object version/URI. The current registry now keys idempotency by artifact code (not global digest) and validates parent existence, same-lab/domain ownership, cycles, duplicate references, and maximum depth. It still trusts the supplied digest/URI, does not verify bytes, and does not enforce record immutability or transformation identity. Raw input should remain unchanged; transformed outputs should become new records.

Measurements should bind sample identity, experiment, immutable objective/protocol version, method, instrument/calibration version, raw artifact digest, units/uncertainty, origin, timestamp, and synthetic flag. Dataset hashes should cover build configuration, selected source identities, transformations, units, splits, and row content. Model manifests should cover code/environment, dataset/split, checkpoint bytes, evaluation, limitations, and calibration status.

Synthetic samples/data may support deterministic UX demos, but should be rejected at scientific-model training and promotion boundaries unless an explicit, separately typed non-scientific demo-training mode is defined.

## 9. Scheduling and capacity

Present scheduling APIs are previews. A future reservation domain requires persisted resource/time slots, unique conflict constraints, expiry, cancellation, fairness, quotas, cost limits, and a compensating release action. Capacity cannot be inferred from registered agent profiles. Resource availability must be observed from real heartbeats/device APIs and marked stale when not current.

## 10. Resilience and failure handling

| Failure | Target response | Current implementation |
|---|---|---|
| API/DB loss | Readiness fail; no new jobs; committed state preserved | DB-aware `/ready`; no durable executor |
| Publish timeout | At-least-once retry; consumer deduplicates | Outbox state machinery only; broker absent |
| Worker crash | Lease expiry, partial preservation, safe requeue | No worker lease lifecycle |
| Workflow node exception | Persist failed checkpoint, retain completed nodes | Synchronous supervisor records failure; recovery advisory |
| Corrupt checkpoint | Refuse recovery, preserve evidence, escalate | Hash chain verification and failure rejection |
| Artifact store corruption | Check digest and retrieve immutable version | Not available; in-memory adapter only |
| Poison event | Quarantine/dead-letter, inspect and replay selectively | Outbox dead-letter state; no consumer inbox |
| Bad DB migration | Restore backup and rollback migration | No versioned migration system yet |

## 11. Observability and incident response

Implemented signals: process `/health`, DB `/ready`, validated `X-Request-ID`, DB outbox state counts, persisted workflow/checkpoint inspection. Not implemented: Prometheus/OpenTelemetry, traces, SLOs, alert routing, worker availability, broker queue depth, backlog drain time, database replica lag, cost telemetry, or paging.

Add metrics only when collected from real infrastructure. For every background operation record request/job/workflow ID, event/aggregate ID, attempt, worker ID, lease expiry, timestamps, config version, outcome, retry class, and artifact references. Avoid logging secrets and sensitive payload contents.

## 12. Security architecture

The application remains unauthenticated and unscoped. Required controls include identity provider, verified principals, per-route permission checks, server-derived actor attribution, tenant/lab query filtering, service identity, request-body caps, rate limits, secrets management, encrypted backup, artifact authorization, audit retention, and network restrictions. Current Compose binds API/web host ports to `127.0.0.1`; this is defense-in-depth for local usage, not a substitute for authentication.

## 13. Deployment architecture

**Now:** one-machine Compose, one API/web, SQLite volume, synthetic demo seed. 

**Near-term:** explicit Alembic migration step; config validation; pinned dependency lock; health/readiness smoke tests; backed-up PostgreSQL test environment if production-like concurrency is needed; separate API from CLI worker only after job lifecycle exists.

**Later:** multi-instance API behind TLS ingress, PostgreSQL primary and documented backup/failover, object storage, authenticated queue publisher/consumer, worker pools isolated by scientific capability and resource safety policy. Add Redis/Kafka/Kubernetes only when measurable throughput/failure isolation requires them.

## 14. Testing and performance engineering

Every guarantee should map to a test. Unit tests validate schemas/state transition math. Service tests assert idempotency, content conflicts, transaction rollback, and provenance. PostgreSQL integration tests validate claims, CAS and migration. Failure injection crashes processes at commit/publish/ack/checkpoint boundaries. Load tests measure API latency/throughput, DB query latency, queue wait and work duration, memory, CPU, retries, and recovery under bounded workloads. End-to-end tests distinguish partial/pending/complete/failed/reconciled scientific outputs.

Baseline commands/results and platform limitations are in `../testing/distributed-systems-testing.md`. Docker and PostgreSQL tests were not available in this execution environment. Do not turn a local benchmark into an HA claim.

## 15. Phased roadmap and gates

1. **Discovery:** architecture inventory and risk register; completed as a code-grounded first pass.
2. **Foundations:** liveness/readiness, request correlation, outbox key uniqueness, conflict semantics, sample/training trust gates, checkpoint boundary; implemented and locally tested.
3. **Migrations:** introduce versioned DB changes and production-safe initialization. Pending.
4. **Durable jobs:** submission idempotency, queued lifecycle, atomic claims/leases/heartbeats, crash recovery. Pending.
5. **Storage/provenance:** durable object bytes, verified digests, immutable lineage, experiment protocol snapshots. Pending.
6. **Resilience:** broker and worker failure injection, compensation, backpressure and manual recovery. Pending.
7. **Observability:** real metrics, tracing, alerts and operational diagnostics. Pending.
8. **Security:** authenticated tenant boundaries and route tests. Pending and a hard blocker for non-local deployments.
9. **Scale:** measured PostgreSQL/API/worker deployment. Pending.
10. **Verification:** CI, Postgres and Docker integration, load/security/restore tests. Pending.

## Appendix A: Acceptance matrix

| Requirement | Status | Evidence / blocker |
|---|---|---|
| Multiple API processes safely coordinate state | Not verified | SQLite only in Compose; no DB concurrency test |
| Durable async jobs | Not implemented | Workflow execution remains synchronous |
| Database outbox event key unique | Implemented locally | Unique index and safe legacy upgrade tests |
| Exactly-once broker delivery | Not claimed | Broker and consumer inbox absent |
| Workflow checkpoints survive process restart | Partially implemented | Rows persist; stale running reconciliation/resume absent |
| Recovery chooses completed checkpoint | Implemented locally | Failure-boundary tests |
| Artifact bytes and digests verified | Not implemented | Storage adapter is in-memory/metadata-oriented |
| Sample identity cannot be self-declared | Implemented locally | Service and schema tests; evidence resolver pending |
| Synthetic training blocked | Implemented locally | Service-boundary test |
| Request correlation and DB readiness | Implemented locally | API tests; real log backend not configured |
| Authentication/tenant authorization | Not implemented | Blocker for shared deployments |
| Backup/restore RPO/RTO | Not established | No automated/tested production system |
| 100-page technical document | Not complete | This first-stage design is concise and explicitly not padded |

## Appendix B: Glossary

- **Outbox:** durable DB record of an event to publish after the transaction commits.
- **Idempotency key:** stable caller identity for safely retrying a logical operation.
- **Lease:** time-bounded claim on work; expiry may not prove a previous process stopped.
- **Inbox:** consumer-side deduplication/processing ledger for repeated event deliveries.
- **Checkpoint:** persisted snapshot after a completed workflow step; hash linking detects edits/gaps but is not a WORM store.
- **Synthetic:** generated or simulated data that is not a physical measurement.
- **Readiness:** whether required configured dependencies can serve traffic now; distinct from process liveness.
