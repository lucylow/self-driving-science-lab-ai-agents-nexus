# Synthetic research data architecture

The backend owns the deterministic demo-data model in `backend/app/services/synthetic_research.py`. A single seeded generator builds a dataset bundle; category arrays are then exported as separate JSON files so fixture files remain modular. The bundle uses stable IDs, a fixed UTC epoch, `random.Random(seed)`, and explicit synthetic notices. Re-running with the same seed and counts reproduces the same records.

The default large bundle contains 15 programs, 60 projects, 180 objectives, 400 hypotheses, 800 proposals, 1,500 executions, 2,000 observations, 150 model configurations, 40 benchmarks, 1,000 evaluations, 30 agent profiles, 1,500 activity events, 1,200 compute jobs, 300 resource records, 300 findings, 250 insights, 150 fictional references, 80 datasets, 160 dataset versions, 400 iterations, 500 decisions, 150 technical-failure records, and 100 reports: 11,265 records across 23 categories.

## Generate and validate

From `backend/` run:

```bash
python scripts/generate_mock_data.py --seed 42 --scale large
python scripts/validate_mock_data.py
```

The output defaults to `backend/mock_data/generated/`; each category is written to its own JSON file. Scales `demo`, `small`, and `medium` are available for faster local work. To reset only that generated directory, run `python scripts/reset_mock_data.py --confirm`. The reset utility refuses paths outside `backend/mock_data/` and requires the explicit flag.

## API and dashboard

The read-only routes are `GET /api/synthetic-research` for metadata, `GET /api/synthetic-research/records/{category}` for category pages, `GET /api/synthetic-research/analysis/projects/{project_id}` for descriptive statistics and observation-quality flags, and `GET /api/synthetic-research/optimization/projects/{project_id}` for quality-versus-compute Pareto ranking with an optional hard cost cap. The records route supports `offset`, `limit` (maximum 100), `q`, `program_id`, `project_id`, `sort_by`, and `descending`. The research workflow dashboard displays calculated category counts, searchable project pages, and a selected-project drill-down linking hypotheses, proposals, executions, observations, findings, statistical analysis, and Pareto candidates. See [scientific analysis](scientific_analysis.md) and [Pareto optimization](pareto_optimization.md) for methods and caveats.

Hypothesis posterior values use a deliberately simplified Beta-Bernoulli demonstration update: successful/partially improved runs contribute positive evidence, negative results contribute negative evidence, and technical failures or inconclusive runs are excluded. Each hypothesis carries its prior, posterior, evidence count, and a description of this method. Experiment recommendations use expected information gain divided by estimated compute hours, exclude proposals marked completed, and display the reason and selected candidate ID. These are explainable demo heuristics, not validated scientific decision policies.

The API builds and caches the default dataset in process. Generated JSON is a portable fixture/export; it is not imported into the operational laboratory database and it cannot authorize physical execution.
