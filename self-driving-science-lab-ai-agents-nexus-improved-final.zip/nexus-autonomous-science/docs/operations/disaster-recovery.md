# Disaster Recovery Guide

## Recovery claims

No automated backup schedule, point-in-time recovery, cross-zone replication, tested disaster-recovery deployment, RPO, or RTO is configured in the supplied repository. The Compose named volume is persistence, not a backup. Set recovery objectives with the deployment owner before production use.

## Data to protect

Back up the authoritative SQL database (experiments, samples, measurements, audit events, workflow records/checkpoints, model metadata, and outbox rows), any separately configured artifact/object storage (not provided here), deployment configuration excluding plaintext secrets, and operational migration history. Demo/generated mock JSON is not a substitute for production data backups.

## SQLite backup

Prefer SQLite's online backup API over copying an actively written database file. Example local backup:

```bash
cd backend
python - <<'PY'
import sqlite3
source = sqlite3.connect("nexus.db")
destination = sqlite3.connect("nexus-backup.db")
source.backup(destination)
destination.close()
source.close()
PY
```

For Docker Compose, identify the `nexus-data` volume and arrange a tested export to independent storage. Do not assume a named volume survives host loss or accidental volume deletion. Restrict access because the DB may contain sensitive scientific data.

## Restore procedure

1. Stop API writers and any external publishers.
2. Preserve the original database and artifacts as a read-only incident copy; calculate a checksum.
3. Restore into an isolated environment, never over the only copy.
4. Confirm table integrity (`PRAGMA integrity_check` for SQLite); verify expected row counts and unique constraints.
5. Start the application against the restored DB, run readiness and domain-specific consistency checks, and verify the outbox uniqueness index.
6. Compare critical experiment IDs, audit history, workflow checkpoint hash chains, and artifact metadata to the backup manifest.
7. Reconcile any pending/leased outbox event with the downstream system before replay, because delivery may have succeeded before its acknowledgement.
8. Obtain operator approval, then route traffic back. Record recovery time, data loss, discrepancies, and follow-up actions.

## PostgreSQL

A PostgreSQL URL can be supplied at the SQLAlchemy layer, but the supplied requirements/Compose stack do not provision a PostgreSQL driver/server or establish backup/failover behavior. Do not apply generic `pg_dump`/restore instructions as proof of a supported topology. Before support is claimed, pin the driver and server version, define backup/PITR, retention/encryption, restore owner, migration order, and run restore tests.

## Evidence and recovery history

Recovery must be auditable. Preserve failed/partial scientific results and their provenance; do not delete rows to make restored state look clean. Record backup ID, timestamp, source DB identity, checksums, operator, migration version, validation results, and any reconciled event IDs.
