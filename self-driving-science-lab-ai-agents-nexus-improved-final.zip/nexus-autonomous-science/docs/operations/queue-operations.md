# Queue Operations Guide

## Current topology

There is no external queue broker, automatic publisher, consumer service, or inbox implementation. The only queue-like durable component is `outbox_events` in the application database. API actions can prepare leased event envelopes and acknowledge them, but the operator or an external adapter must perform the actual publish. The API is unauthenticated; do not expose these endpoints to untrusted clients.

## State and semantics

`pending` → `ready_for_delivery` → `published`, or `delivery_failed` → retry → `ready_for_delivery`, eventually `dead_letter`. Lease expiry is recovered to `delivery_failed` or dead-lettered when retry attempts are exhausted. A successful publish followed by a crash before acknowledgement may be published again; semantics are at-least-once, never exactly-once.

## Manual adapter contract

An external adapter, when deliberately deployed, must:

1. Authenticate to the API and broker using service credentials that are not present in this starter.
2. Call `POST /api/outbox/prepare` with a batch size from 1 to 500, or target a single event with `POST /api/outbox/{event_id}/prepare`.
3. Persist the envelope's stable `id`/`event_key` at the destination and use that identity for consumer deduplication.
4. Publish the complete event envelope, preserve event type and aggregate identifiers, avoid logging secrets/payload data indiscriminately, and record broker delivery result.
5. Acknowledge with the exact `claim_token` before `lease_expires_at`; success/failure is explicit. An expired lease cannot be acknowledged.
6. Use bounded retries, monitor dead-letter rows, and stop on schema/authentication/poison-message errors rather than infinite retry.
7. Treat the publish-then-crash-before-ack window as a possible duplicate.

No such adapter exists in this repository, so these are requirements, not verified operations.

## Inspection and recovery

- List recent rows with `GET /api/outbox?limit=100` (optional `status`).
- Query DB-backed counts at `GET /api/outbox/metrics`.
- Recover expired leases with `POST /api/outbox/recover-expired-leases` using `max_attempts` between 1 and 20.
- Use `POST /api/outbox/{event_id}/prepare` only for deliberate operator retry after checking status and external delivery outcome.
- Preserve `last_error`, attempts, and payload metadata. Do not delete a dead-letter record to clear a dashboard.

## Incident runbook

1. **Pending rows increasing:** confirm an adapter is intentionally configured. In this starter it is not; there is no automatic drain. If no adapter exists, pending state is expected and should be documented rather than treated as a broker outage.
2. **Repeated `delivery_failed`:** inspect last error, attempt count, retry timestamp, and destination health. Fix the cause before manual replay.
3. **Dead letter:** capture the row and related aggregate/audit history. Decide whether the external side effect happened. Replaying without consumer deduplication can duplicate an action.
4. **Expired lease:** assume the prior publisher may still have completed an external send; verify destination idempotency before retry.
5. **Duplicate event key on startup migration:** do not delete one row blindly. Back up, compare event payload/aggregate identity and audit history, then resolve through a reviewed migration.

## Future acceptance criteria

Add versioned event schemas, event sequence/causation/correlation identity, authenticated publisher role, broker health, a consumer inbox/unique dedup key, poison-message quarantine, aggregate ordering decision, concurrency tests against PostgreSQL, and broker crash/replay integration tests.
