# Reliability Guide

## Scope

This guide describes the supplied single-machine/demo application and the first correctness improvements. It does not declare high availability. The Compose topology contains one API, one web app, and one SQLite volume; no replication, broker, external object store, worker fleet, or alerting system is configured.

## Health signals

- `GET /health`: process liveness only. It must remain usable to distinguish an alive process from an available dependency.
- `GET /ready`: verifies the configured SQLAlchemy database with `SELECT 1`; failure returns HTTP 503. It does not test migrations, seeding correctness, broker availability, artifact bytes, worker activity, or scientific instrument health.
- `X-Request-ID`: valid caller IDs matching `[A-Za-z0-9._-]{1,128}` are echoed; invalid/missing IDs are replaced with a random ID. The ID is returned on responses and attached to application log records.
- `/api/outbox/metrics`: counts database outbox states only. It is not broker monitoring.

## Implemented local resilience

1. Domain/audit/outbox writes are committed through a shared SQLAlchemy session on audited route paths.
2. Outbox rows have bounded claim attempts, leases, exponential retry, expired-lease recovery, and dead-letter state.
3. Event-key uniqueness is enforced in the DB. Existing legacy schemas are upgraded without deleting rows; collisions stop startup for operator review.
4. Acknowledgements require the current claim token and are rejected after lease expiry.
5. Workflow checkpoints are hash-chain checked. Recovery uses only the newest successful `completed` node, reports later failure separately, and requires operator action.
6. Sample identity starts unverified; synthetic dataset snapshots are rejected by the model training service.

## Known failure modes and responses

| Failure | Current behavior | Safe operator response |
|---|---|---|
| API process stops | In-flight HTTP request fails; committed DB state remains; no worker drain exists | Restart API; inspect persistent workflow rows and outbox. Do not assume an interrupted synchronous workflow resumed. |
| DB unavailable | `/ready` returns 503; `/health` may remain 200 | Restore DB connectivity; preserve DB files; confirm readiness before enabling clients. |
| Duplicate outbox event key with same content | Returns existing row | Treat as idempotent retry; keep stable key generation. |
| Same event key with different content | Raises conflict/error | Do not silently choose a payload; inspect producer and audit history. |
| Legacy duplicate event keys | Startup rejects unique-index upgrade | Back up DB, inspect each duplicate's provenance, preserve records, coordinate key correction as a reviewed migration. |
| Publisher dies before acknowledgement | Lease eventually expires and event can be retried | Assume duplicate publication is possible; consumer must deduplicate. |
| Stale publisher acknowledges | Rejected after lease expiry/token change | Recover/reclaim via operator path; inspect external publish outcome before manual replay. |
| Workflow process dies | Persisted run may remain `running`; no stale lease scanner | Inspect run/checkpoint chain; do not claim automatic recovery. Use advisory recovery only for supported non-physical work. |
| Artifact object missing | In-memory adapter cannot provide durable bytes | Do not treat metadata URI/digest as proof of retrievable bytes; restore from an independently managed copy. |

## Retry and backpressure policy

Outbox retry delay is capped exponential backoff and attempts are bounded by the configured policy. A dead-letter row is not automatically discarded. Before reprocessing one, identify the recipient's effect and use a deduplication key. Queue depth/backlog-drain time and worker availability are not meaningful current metrics because no worker or broker is configured.

## Reliability SLOs and performance budgets

No production SLO, latency objective, RPO, or RTO is currently baselined. Do not invent a worker throughput or availability target. A deployment owner must define objectives from workload, run repeatable load/failure tests, and alert on measured signals before production service claims.

## Operational prohibitions

- Do not scale the SQLite Compose API to multiple claimers.
- Do not expose Compose ports to an untrusted network. Ports now bind to `127.0.0.1` by default.
- Do not publish outbox records to a real broker until consumer idempotency, authentication, serialization/versioning, and failure semantics are tested.
- Do not use synthetic/demo model outputs as scientific evidence or production training data.
