# Worker Operations Guide

## Current status

There is no separately deployed worker executable/service. Agent and workflow execution is synchronous inside FastAPI requests using a deterministic demo adapter. Workflow runs and checkpoints are persisted, but queue assignment, heartbeat, leases, cancellation, worker registration, graceful drain, and automatic recovery are not implemented. Scheduler outputs are proposals and do not reserve instruments or capacity.

Do not interpret an `Agent` row, capability profile, local capacity helper, workflow node, or UI status as a running worker process.

## Future lifecycle contract

```mermaid
stateDiagram-v2
  [*] --> queued
  queued --> leased: atomic claim with owner/token/expiry
  leased --> running: worker validates job version and policy
  running --> checkpointed: persist safe completed step
  checkpointed --> running: heartbeat / next safe step
  running --> succeeded: final result and provenance committed
  running --> failed: terminal failure or exhausted attempts
  leased --> queued: lease expires before execution
  running --> interrupted: lease expires; reconcile side effects first
  interrupted --> queued: operator-approved safe retry only
  queued --> cancelled: cancel before irreversible work
```

## Required worker controls before deployment

- A database-backed job record with submission idempotency key, schema/version, tenant/project, priority, timeout, attempts, status, and creation/update timestamps.
- Atomic claim semantics on the explicitly supported DB; lease owner/token, expiry, heartbeat, and compare-and-swap transitions.
- Worker identity, software/configuration version, restricted permissions, per-job resource budgets, and authenticated service identity.
- Idempotent task step identity and output artifact references. Preserve partial output on failure.
- Graceful shutdown: stop claiming new jobs; finish or safely release active jobs; never assume a timed-out process stopped making side effects.
- Reconciliation: mark stale leases interrupted, retain diagnostics, inspect last completed checkpoint, and require safe idempotency/operator permission before requeue.
- Queue metrics derived from real job rows and worker heartbeats, not synthetic counters.

## Operator response today

If a persisted workflow is `running` after API restart, inspect `/api/orchestration/runs/{id}` and its checkpoint chain. Do not mark it complete or invoke an automatic retry. The recovery endpoint is advisory; no worker will resume the work. For demo workflows, an operator may start a new separately identified run after reviewing prior completed steps and audit history.
