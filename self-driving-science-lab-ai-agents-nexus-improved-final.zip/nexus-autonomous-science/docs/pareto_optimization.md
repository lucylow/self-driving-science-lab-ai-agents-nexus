# Synthetic quality–compute Pareto analysis

A selected project can be analyzed at `GET /api/synthetic-research/optimization/projects/{project_id}`. Add `?max_compute_hours=16` to apply a hard per-experiment compute ceiling. The response includes the experiment candidates, feasible Pareto-front IDs, status and rationale for each candidate, the hard constraint, analysis timestamp, and a SHA-256 fingerprint of the input experiments and executions.

The two displayed objectives are descriptive mean quality (maximize) and consumed compute hours (minimize). A candidate is dominated only when another feasible, scored candidate is no worse on both objectives and strictly better on at least one. A useful quality/cost trade-off can remain on the frontier even if another candidate has a higher quality score. Hard-cap violations are marked `infeasible` and never enter the frontier. Experiments with missing or invalid cost are `invalid_cost`; candidates without eligible outcomes are `unscored`.

Quality uses finite scores in [0, 1] from `successful`, `partial_improvement`, and `negative_result` executions. `technical_failure` and `inconclusive` runs do not contribute to the quality mean. All valid compute usage—including failures and inconclusive attempts—is charged to cost. Exact or repeated configurations are not deduplicated, so replications remain visible.

This is an explainable two-objective demonstration heuristic over synthetic fixtures, not Bayesian optimization, a causal estimate, or a validated scientific optimum. Do not use its recommendations to authorize real experiments.
