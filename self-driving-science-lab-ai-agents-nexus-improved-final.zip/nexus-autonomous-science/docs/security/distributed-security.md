# Distributed Security Architecture

## Security classification

NEXUS is a development/demo foundation, not a production security boundary. FastAPI routes have no authenticated principal dependency or tenant-scoped authorization. List/read routes can expose records across laboratories, and approval endpoints accept reviewer labels from request payloads. CORS does not authenticate clients. The Compose ports are now bound to loopback by default, but that does not add authorization to a separately exposed deployment.

Do not expose the API to an untrusted network or store confidential/regulated research data until the controls below are implemented and tested.

## Assets and trust boundaries

- Scientific identity, raw observations, sample provenance, model/dataset lineage, and audit history.
- Approval decisions, lifecycle transitions, and human/operator attribution.
- Outbox event payloads and service credentials for any future publisher.
- SQLite/DB backups and object-store artifacts.
- Browser clients, API callers, DB engine, future workers, broker, and instrument adapters.

Current actual boundaries: browser→HTTP API; API→single SQLAlchemy DB. There is no verified principal between caller/API, no worker identity, and no broker connection.

## Threats

| Threat | Present exposure | Required control |
|---|---|---|
| Unauthenticated approval/state mutation | Caller can send reviewer/actor labels | OIDC/session/token principal, role checks, actor derived from verified identity |
| Cross-lab data access | Optional lab filters; no principal scope | Tenant/lab claims enforced on every list/read/write and object lookup |
| Forged scientific identity | Sample-create request previously accepted `verified`; now blocked at schema/service | Evidence-backed reviewer workflow; resolve evidence IDs to stored artifacts; audit identity transition |
| Synthetic-data leakage into research models | Snapshot could be marked synthetic and still trained; now rejected in `train_baseline` | Keep enforcement in service boundary and tests; isolate any future demonstration training path |
| Request exhaustion | No global request-body or rate ceiling | Edge/API byte limits, per-principal/IP rate limits, expensive-operation budgets |
| Forged event/actor context | Client-supplied values can be stored in several endpoints | Authenticated service identity and immutable server-side attribution |
| Artifact substitution | URI/digest trusted; in-memory storage adapter | Persistent content-addressed storage, byte hashing on ingest/read, access scope and retention |
| Secret leakage | No production secret manager in project | External secret store, rotation, redaction, least privilege |

## Implemented protections (limited)

- Request IDs are restricted to a safe 1–128 character alphabet and are emitted on responses/log records; this is correlation, not authentication.
- Domain safety gates prohibit physical execution in the demo workflow.
- New sample identities are forced to `unverified`; the separate verification operation is still only as trustworthy as its caller until authentication and evidence resolution exist.
- Synthetic snapshots cannot pass the baseline training service boundary.
- Compose host ports bind to `127.0.0.1` by default.
- FastAPI returns generic unexpected-error text instead of exception details.

## Required production sequence

1. Choose identity provider and principal contract; verify issuer, audience, expiry, signature, and key rotation.
2. Establish tenant/lab authorization policy; apply it in each DB query, including direct-ID operations; reject out-of-scope objects consistently.
3. Derive actor/reviewer identity from server-verified claims; retain client attribution only as separate non-authoritative metadata.
4. Add role separation for scientific proposal, review/approval, admin, data export, and future publisher/worker identities.
5. Add global request-size/timeouts and per-principal rate limits; validate nested dictionaries/arrays for expensive numerical endpoints.
6. Protect secrets, DB/broker access, backup encryption, and future artifact access; restrict service egress and permissions.
7. Add audit log retention/integrity controls and security incident procedures.
8. Test unauthenticated denial, role authorization, cross-tenant list/read/mutate, actor forgery, oversized body, rate limiting, secret redaction, and error-safe responses.

Until this sequence is complete, production authentication and tenant isolation are **not implemented**.
