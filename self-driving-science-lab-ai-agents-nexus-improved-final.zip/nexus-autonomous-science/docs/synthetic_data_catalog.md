# Synthetic data catalog

All records are generated fictional fixtures. Each row includes `synthetic: true` and a notice that distinguishes demonstration content from measured or published scientific results.

| Category | Large count | Main relationships |
|---|---:|---|
| Programs | 15 | Programs contain projects |
| Projects | 60 | Program, objectives, experiments, models, findings and reports |
| Objectives | 180 | Project |
| Hypotheses | 400 | Project, objective, prior/posterior beliefs, and supporting runs |
| Experiment proposals | 800 | Project, hypothesis, objective, and acquisition rationale |
| Experiment executions | 1,500 | Proposal and project; includes ordered times and outcome class |
| Observations | 2,000 | Execution, proposal, hypothesis, metric, value, and uncertainty |
| Model configurations | 150 | Project |
| Benchmarks | 40 | Referenced by evaluations |
| Evaluations | 1,000 | Execution, benchmark and model |
| Agent profiles | 30 | Used by activity records; `propose_only` permissions |
| Agent activity records | 1,500 | Agent and project |
| Compute jobs | 1,200 | Execution; simulated costs and resource labels |
| Compute resources | 300 | Fictional capacity/allocation units |
| Findings | 300 | Project and execution evidence |
| Insights | 250 | Finding |
| References | 150 | Fictional `synthetic://` reference and hypothesis |
| Datasets | 80 | Project |
| Dataset versions | 160 | Dataset |
| Research iterations | 400 | Project and loop stage |
| Decisions | 500 | Hypothesis and proposal |
| Failure records | 150 | Technical-failure execution |
| Reports | 100 | Project and source finding IDs |

Outcomes intentionally include successful and partial improvements, inconclusive runs, technical failures, and negative scientific results. The generator keeps technical errors separate from negative results. These labels and scores are test fixtures, not prevalence estimates or performance claims.
