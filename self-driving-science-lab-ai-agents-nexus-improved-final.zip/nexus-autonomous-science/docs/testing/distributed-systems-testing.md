# Distributed-Systems Testing Strategy

## Verification approach

Distributed claims require integration/failure evidence. A passing unit test of a class or successful UI render is not evidence of multi-instance HA, exactly-once delivery, broker health, or production security.

## Repeatable local checks

```bash
cd backend
python -m pytest -q
python -m compileall -q app tests
cd ../frontend
npm ci
npm run typecheck
npm run build
```

For isolated backend runs, set a fresh DB URL, for example `NEXUS_DATABASE_URL=sqlite:////tmp/nexus-tests.db`, and remove that file before a clean-schema run. The dependency environment used for the 2026-11-09 verification was Python 3.12.3 with declared backend requirements installed into an isolated venv, Node 22.23.4 and npm 10.9.2 (runtime pins vary in the project files).

## Layers and required cases

| Layer | Current coverage | Required next cases |
|---|---|---|
| Unit | Scientific math, lifecycle, schemas, lineage helpers, retry calculations | Property tests for state transitions, large payload bounds, serializer compatibility |
| Service/integration | Synthetic experiment flow, approvals, workflow checkpoints, outbox lease/retry, new identity/training checks | Transaction rollback of domain+audit+outbox; artifact byte/hash/provenance; objective/protocol snapshot stability |
| Concurrency | Database unique index and sequential duplicate path tested | PostgreSQL concurrent same-key enqueues; concurrent claims; stale ack vs recovery/claim races; conflicting experiment transitions |
| Failure injection | Expired outbox lease and failed checkpoint selection are unit tested | Crash after DB commit-before-publish; publisher crash after publish-before-ack; process death mid-workflow; DB restart and recovery |
| Security | Safe error response and physical safety guards | Authentication/authorization, two-tenant isolation, forged actor, request size/rate limit, secret redaction |
| Deployment | Frontend production build and readiness unit/API tests | Docker image/Compose smoke, restart persistence, migration rollback, supported Postgres version and connection pool |
| Load/soak | No production baseline | Bounded request tests; API throughput/latency, DB query latency, queue backlog under a real adapter; memory/CPU profiles |
| Frontend | TypeScript/build and local API client code | Automated unit/E2E for partial refresh, ambiguous mutations, offline/reconnect, accessible error states |

## New regression tests in this increment

`backend/tests/test_distributed_outbox_foundations.py` covers:

- Identical event-key retry and rejection of key reuse with changed payload.
- Unique index on fresh schema and safe legacy schema upgrade.
- Refusal to upgrade a legacy DB containing duplicate event keys without deleting rows.
- Batch-size upper-bound validation.
- Rejection of acknowledgements after lease expiry.
- Recovery after failure uses the last completed checkpoint, reports failure separately, refuses chains without a completed checkpoint, and rejects physical-side-effect chains.
- Liveness/readiness distinction, request ID validation/propagation, and DB-unavailable readiness.
- Sample identity cannot be predeclared verified; the separate review operation changes status.
- Synthetic datasets are rejected at model training boundary.
- Artifact-code retries are content-sensitive; equal digests across labs remain separate records; missing, cross-lab, and cyclic parent chains are rejected.

## Results for this supplied workspace (2026-11-09)

- Final backend suite: **259 tests passed** on a fresh isolated SQLite DB with `NEXUS_DATABASE_URL=sqlite:////tmp/nexus-final4.db /home/ubuntu/work/.venv/bin/python -m pytest -q`.
- Frontend `npm run typecheck` and `npm run build` both passed; Next.js generated static `/` and `/_not-found` routes.
- Python `compileall -q app tests` passed after code changes.
- Automatic schema upgrade was exercised against a copy of the supplied SQLite DB: 967 outbox rows were preserved and a unique `event_key` index was created.
- Compose YAML parsed successfully; API and web ports bind to `127.0.0.1`, and API healthcheck calls `/ready`. Docker/Compose binaries are not installed in the current task environment, so container build/start/health behavior is not verified.
- No PostgreSQL server or broker was available; concurrency and broker delivery claims are not verified.

## Test hygiene

Do not use the included `backend/nexus.db` as the only test DB; tests should use isolated temporary databases. Do not publish test counts without recording code revision, command, environment, and outcome. Historical counts in docs may describe earlier snapshots and should not be treated as current results.
