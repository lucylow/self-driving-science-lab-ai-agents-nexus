"use client";

import { useEffect } from "react";

type AppErrorProps = {
  error: Error & { digest?: string };
  reset: () => void;
};

export default function AppError({ error, reset }: AppErrorProps) {
  useEffect(() => {
    console.error("NEXUS page error", error.digest || error.name);
  }, [error]);

  return (
    <main role="alert" style={{ maxWidth: 620, margin: "12vh auto", padding: 24, fontFamily: "system-ui, sans-serif", color: "#18243a" }}>
      <p style={{ color: "#b45309", fontSize: 12, fontWeight: 700, letterSpacing: ".08em" }}>WORKSPACE ERROR</p>
      <h1 style={{ fontSize: 26, marginBottom: 8 }}>This view could not be loaded.</h1>
      <p style={{ color: "#64748b", lineHeight: 1.6 }}>Your other research data is unchanged. Retry the view, or reload the workspace if the issue continues.</p>
      {error.digest && <p style={{ color: "#64748b", fontSize: 12 }}>Reference: {error.digest}</p>}
      <div style={{ display: "flex", gap: 10, marginTop: 20 }}>
        <button onClick={reset} style={{ padding: "9px 14px", border: 0, borderRadius: 7, background: "#3449b8", color: "white", cursor: "pointer" }}>Retry view</button>
        <button onClick={() => window.location.reload()} style={{ padding: "9px 14px", border: "1px solid #cbd5e1", borderRadius: 7, background: "white", color: "#334155", cursor: "pointer" }}>Reload workspace</button>
      </div>
    </main>
  );
}
