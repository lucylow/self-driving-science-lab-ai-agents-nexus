import { Microscope } from "lucide-react";

export function EmptyState({ title, detail }: { title: string; detail: string }) {
  return <div className="empty-state"><Microscope size={22} /><strong>{title}</strong><p>{detail}</p></div>;
}
