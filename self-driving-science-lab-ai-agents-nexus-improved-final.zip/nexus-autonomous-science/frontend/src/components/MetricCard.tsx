import type { ReactNode } from "react";

export function MetricCard({ label, value, detail, icon, tone = "blue" }: {
  label: string; value: string | number; detail: string; icon: ReactNode; tone?: "blue" | "violet" | "green" | "amber";
}) {
  return (
    <article className="metric-card">
      <div className={`metric-icon tone-${tone}`}>{icon}</div>
      <div className="metric-copy">
        <span className="metric-label">{label}</span>
        <strong>{value}</strong>
        <small>{detail}</small>
      </div>
    </article>
  );
}
