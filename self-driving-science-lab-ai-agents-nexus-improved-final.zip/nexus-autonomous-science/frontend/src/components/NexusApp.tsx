"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import {
  Activity, AlertTriangle, ArrowRight, Atom, Bell, Boxes, BrainCircuit, CheckCircle2, ChevronDown,
  CircleHelp, ClipboardCheck, Command, Database, FlaskConical, Gauge,
  GitBranch, Layers3, Microscope, Network, Orbit, Plus, RefreshCw,
  Search, ShieldCheck, Sparkles, Workflow, Zap, Flag, LineChart, Menu, X,
} from "lucide-react";
import { api, ApiError } from "@/lib/api";
import {
  demoAgents, demoApprovals, demoCandidates, demoDatasets, demoEvents,
  demoExperiments, demoLabs, demoMeasurements, demoOverview, demoTwin,
} from "@/lib/demo";
import type {
  Agent, Approval, Candidate, Dataset, EventRecord, Experiment,
  Laboratory, Measurement, NavKey, Overview, TwinOverview,
} from "@/types";
import { StatusPill } from "@/components/StatusPill";
import { OverviewView } from "@/features/overview/OverviewView";
import { LabsView } from "@/features/labs/LabsView";
import { AgentOpsView } from "@/features/agents/AgentOpsView";
import { DiscoveryView } from "@/features/discovery/DiscoveryView";
import { ExperimentsView } from "@/features/experiments/ExperimentsView";
import { GovernanceView } from "@/features/governance/GovernanceView";
import { DataView } from "@/features/data/DataView";
import { TwinView } from "@/features/twin/TwinView";
import { ModelsView } from "@/features/models/ModelsView";
import { SamplesView } from "@/features/samples/SamplesView";
import { ResearchView } from "@/features/research/ResearchView";
import { ScienceToolsView } from "@/features/science-tools/ScienceToolsView";
import { CampaignsView } from "@/features/campaigns/CampaignsView";
import { AdvancedResearchView } from "@/features/advanced-research/AdvancedResearchView";

const navigation: { key: NavKey; label: string; icon: typeof Activity; group: string }[] = [
  { key: "overview", label: "Command center", icon: Gauge, group: "WORKSPACE" },
  { key: "labs", label: "Lab network", icon: Network, group: "WORKSPACE" },
  { key: "agents", label: "Agent operations", icon: BrainCircuit, group: "INTELLIGENCE" },
  { key: "discovery", label: "Materials discovery", icon: Atom, group: "INTELLIGENCE" },
  { key: "experiments", label: "Experiments", icon: FlaskConical, group: "EXECUTION" },
  { key: "governance", label: "Governance", icon: ShieldCheck, group: "EXECUTION" },
  { key: "data", label: "Scientific data", icon: Database, group: "INFRASTRUCTURE" },
  { key: "twin", label: "Digital twin", icon: Orbit, group: "INFRASTRUCTURE" },
  { key: "models", label: "Model intelligence", icon: BrainCircuit, group: "INTELLIGENCE" },
  { key: "research", label: "Research workflows", icon: GitBranch, group: "INTELLIGENCE" },
  { key: "samples", label: "Sample registry", icon: Boxes, group: "INFRASTRUCTURE" },
  { key: "calculators", label: "Science methods", icon: Microscope, group: "INTELLIGENCE" },
  { key: "campaigns", label: "Research campaigns", icon: Flag, group: "EXECUTION" },
  { key: "advanced", label: "Advanced research", icon: LineChart, group: "INTELLIGENCE" },
];

const titles: Record<NavKey, { title: string; subtitle: string }> = {
  overview: { title: "Autonomous science, under control.", subtitle: "A live view of the NEXUS research network and its governed discovery workflows." },
  labs: { title: "Eight labs. One connected system.", subtitle: "Explore the domain-specific laboratories connected by shared identity, data, and governance." },
  agents: { title: "Specialist intelligence, measurable work.", subtitle: "Inspect agent responsibilities, permissions, and task execution across the network." },
  discovery: { title: "From composition to candidate.", subtitle: "Explore the first SDL1 demonstrator: AI-assisted inorganic solid-state electrolyte screening." },
  experiments: { title: "Experiment control room.", subtitle: "Track lifecycle state, review proposals, and run the digital-twin demonstration." },
  governance: { title: "Human authority stays in the loop.", subtitle: "Review experimental proposals and make explicit approval decisions." },
  data: { title: "A scientific data fabric.", subtitle: "Preserve raw evidence, metadata, uncertainty, quality checks, and lineage." },
  twin: { title: "A mirror of the laboratory.", subtitle: "Inspect simulated instrument, workflow, and laboratory state before real integration." },
  models: { title: "Models with evidence, not mystery.", subtitle: "Build group-aware datasets, train transparent baselines, and inspect model limitations." },
  research: { title: "Coordinate the scientific reasoning loop.", subtitle: "Launch governed agent workflows, inspect claims, and design computational experiments." },
  samples: { title: "Identity before interpretation.", subtitle: "Track persistent sample identities, evidence references, and parent-child provenance." },
  calculators: { title: "Scientific methods with explicit assumptions.", subtitle: "Run transparent computational calculations for electrochemistry, diffraction, polymers, kinetics, spectra and morphology." },
  campaigns: { title: "Manage research as a programme.", subtitle: "Coordinate multi-stage analytical workflows with human review, durable history, and simulation-only execution." },
  advanced: { title: "Calibrate, quantify, and decide with evidence.", subtitle: "Advanced digital-twin calibration, uncertainty propagation, sequential design, drift monitoring, and governed cross-laboratory collaboration." },
};

type ToastKind = "success" | "warning" | "error";
type ToastState = { message: string; kind: ToastKind } | null;

function WorkspaceLanding({ onEnter }: { onEnter: () => void }) {
  return (
    <main className="landing-shell">
      <div className="landing-orbit landing-orbit-one" />
      <div className="landing-orbit landing-orbit-two" />
      <section className="landing-card" aria-labelledby="landing-title">
        <div className="landing-brand"><span className="landing-brand-mark"><Command size={19} /></span><span>NEXUS <small>SCIENCE NETWORK</small></span></div>
        <div className="landing-kicker"><span className="green-pulse" /> GOVERNED SCIENTIFIC WORKSPACE</div>
        <h1 id="landing-title">Move from research intent to evidence.</h1>
        <p className="landing-lede">A connected command centre for eight domain-specific laboratories, with transparent workflows, traceable data, and human review at every consequential step.</p>
        <div className="landing-actions">
          <button className="landing-primary" onClick={onEnter}>Enter workspace <ArrowRight size={16} /></button>
          <span className="landing-status"><ShieldCheck size={15} /> Demo mode · physical actions disabled</span>
        </div>
        <div className="landing-features">
          <div><span className="landing-feature-icon"><Network size={17} /></span><strong>See the network</strong><small>Labs, agents, experiments, and governance in one place.</small></div>
          <div><span className="landing-feature-icon feature-green"><GitBranch size={17} /></span><strong>Follow the evidence</strong><small>Keep provenance, uncertainty, and data quality visible.</small></div>
          <div><span className="landing-feature-icon feature-amber"><ShieldCheck size={17} /></span><strong>Stay in control</strong><small>Recommendations require review before consequential use.</small></div>
        </div>
        <div className="landing-footer"><span>SDL0–SDL7 connected foundation</span><span>v0.1.0 · synthetic seed data</span></div>
      </section>
    </main>
  );
}

export default function NexusApp() {
  const [active, setActive] = useState<NavKey>("overview");
  const [showLanding, setShowLanding] = useState(true);
  const [overview, setOverview] = useState<Overview>(demoOverview);
  const [labs, setLabs] = useState<Laboratory[]>(demoLabs);
  const [agents, setAgents] = useState<Agent[]>(demoAgents);
  const [candidates, setCandidates] = useState<Candidate[]>(demoCandidates);
  const [experiments, setExperiments] = useState<Experiment[]>(demoExperiments);
  const [approvals, setApprovals] = useState<Approval[]>(demoApprovals);
  const [datasets, setDatasets] = useState<Dataset[]>(demoDatasets);
  const [measurements, setMeasurements] = useState<Measurement[]>(demoMeasurements);
  const [events, setEvents] = useState<EventRecord[]>(demoEvents);
  const [twin, setTwin] = useState<TwinOverview>(demoTwin);
  const [apiOnline, setApiOnline] = useState(false);
  const [refreshErrors, setRefreshErrors] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const [toast, setToast] = useState<ToastState>(null);
  const [searchOpen, setSearchOpen] = useState(false);
  const [globalSearch, setGlobalSearch] = useState("");
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  const notify = useCallback((message: string, kind: ToastKind = "success") => {
    setToast({ message, kind });
    window.setTimeout(() => setToast(null), 4200);
  }, []);

  const refresh = useCallback(async () => {
    setBusy(true);
    const results = await Promise.allSettled([
      api.overview(), api.labs(), api.agents(), api.candidates(), api.experiments(),
      api.approvals(), api.datasets(), api.measurements(), api.events(), api.twin(),
    ]);
    const live = results[0].status === "fulfilled";
    const sectionNames = ["overview", "laboratories", "agents", "candidates", "experiments", "approvals", "datasets", "measurements", "events", "digital twin"];
    const failedSections = results.flatMap((result, index) => result.status === "rejected" ? [sectionNames[index]] : []);
    setApiOnline(live);
    setRefreshErrors(live ? failedSections : []);
    if (live) {
      const [o, l, a, c, e, ap, d, m, ev, t] = results;
      if (o.status === "fulfilled") setOverview(o.value);
      if (l.status === "fulfilled") setLabs(l.value);
      if (a.status === "fulfilled") setAgents(a.value);
      if (c.status === "fulfilled") setCandidates(c.value);
      if (e.status === "fulfilled") setExperiments(e.value);
      if (ap.status === "fulfilled") setApprovals(ap.value);
      if (d.status === "fulfilled") setDatasets(d.value);
      if (m.status === "fulfilled") setMeasurements(m.value);
      if (ev.status === "fulfilled") setEvents(ev.value);
      if (t.status === "fulfilled") setTwin(t.value);
    }
    setBusy(false);
  }, []);

  useEffect(() => { void refresh(); }, [refresh]);
  useEffect(() => {
    try {
      if (window.localStorage.getItem("nexus.workspace.entered") === "true") setShowLanding(false);
    } catch {
      // Storage can be unavailable in privacy-restricted browsers; the CTA still works.
    }
  }, []);
  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        setSearchOpen(true);
      }
      if (event.key === "Escape") {
        setSearchOpen(false);
        setMobileNavOpen(false);
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, []);

  const withApiFallback = useCallback(async <T,>(liveAction: () => Promise<T>, fallbackAction: () => T, successMessage: string): Promise<boolean> => {
    try {
      await liveAction();
      notify(successMessage, "success");
      await refresh();
      return true;
    } catch (error) {
      if (error instanceof ApiError && error.kind === "network") {
        try {
          fallbackAction();
          notify(`${successMessage} · local demo state`, "warning");
          return true;
        } catch {
          notify("The local demo action failed. Refresh the workspace and try again.", "error");
          return false;
        }
      }
      notify(error instanceof ApiError ? error.message : "Unexpected error. No local fallback was applied.", "error");
      return false;
    }
  }, [notify, refresh]);

  const runAgent = useCallback(async (agent: Agent, task: string) => {
    return withApiFallback(
      () => api.runAgent(agent.id, task),
      () => {
        setAgents((current) => current.map((item) => item.id === agent.id ? { ...item, run_count: item.run_count + 1, status: "idle", last_run_at: new Date().toISOString() } : item));
        setEvents((current) => [{ id: `EV-${Date.now()}`, event_type: "AGENT_DEMO_RUN_COMPLETED", actor: "local-demo", subject_type: "agent", subject_id: agent.id, created_at: new Date().toISOString(), payload: { task, synthetic: true } }, ...current]);
        return { status: "completed" };
      },
      `${agent.name} completed its review`,
    );
  }, [withApiFallback]);

  const createExperiment = useCallback(async (payload: Record<string, unknown>) => {
    return withApiFallback(
      () => api.createExperiment(payload),
      () => {
        const next: Experiment = {
          id: `EXP-${Date.now()}`, code: `EXP-${Math.floor(2402 + Math.random() * 500)}`,
          title: String(payload.title), laboratory_code: String(payload.laboratory_code || "SDL1"),
          objective_id: null, hypothesis_id: null, candidate_id: String(payload.candidate_id || "") || null,
          status: "draft", execution_mode: "simulation", protocol_id: "sdl1-screening-demo", protocol_version: "0.1.0",
          owner: "Workspace scientist", estimated_duration_minutes: Number(payload.estimated_duration_minutes || 60),
          resource_requirements: {}, governance: { approval_required: true, physical_execution: false },
          result_summary: { evidence_type: "synthetic_demo_record" }, created_at: new Date().toISOString(), updated_at: new Date().toISOString(), synthetic: true,
        };
        setExperiments((current) => [next, ...current]);
        return next;
      },
      "Experiment proposal created",
    );
  }, [withApiFallback]);

  const requestApproval = useCallback(async (experiment: Experiment) => {
    return withApiFallback(
      () => api.requestApproval(experiment.id, "Review scientific rationale, resource feasibility, and demo execution scope."),
      () => {
        const approval: Approval = { id: `APR-${Date.now()}`, experiment_id: experiment.id, requested_by: "Workspace scientist", reason: "Review scientific rationale, resource feasibility, and demo execution scope.", status: "pending", reviewer_note: "", requested_at: new Date().toISOString() };
        setApprovals((current) => [approval, ...current]);
        setExperiments((current) => current.map((item) => item.id === experiment.id ? { ...item, status: "awaiting_approval" } : item));
        return approval;
      },
      "Approval request submitted",
    );
  }, [withApiFallback]);

  const decideApproval = useCallback(async (approval: Approval, decision: "approved" | "rejected") => {
    return withApiFallback(
      () => api.decideApproval(approval.id, decision, decision === "approved" ? "Approved for the demo simulation workflow." : "Returned for further scientific review."),
      () => {
        const updatedApproval: Approval = { ...approval, status: decision, reviewer: "Workspace supervisor", reviewer_note: "Local demo decision", decided_at: new Date().toISOString() };
        const experimentStatus = decision === "approved" ? "approved" : "cancelled";
        setApprovals((current) => current.map((item) => item.id === approval.id ? updatedApproval : item));
        setExperiments((current) => current.map((item) => item.id === approval.experiment_id ? { ...item, status: experimentStatus } : item));
        return { approval: updatedApproval, experiment_status: experimentStatus };
      },
      decision === "approved" ? "Proposal approved" : "Proposal rejected",
    );
  }, [withApiFallback]);

  const simulate = useCallback(async (experiment: Experiment) => {
    return withApiFallback(
      () => api.simulateExperiment(experiment.id),
      () => {
        const result = { evidence_type: "synthetic_simulation_output", mode: "digital_twin_simulation", synthetic: true };
        const updatedExperiment: Experiment = { ...experiment, status: "completed", result_summary: result, updated_at: new Date().toISOString() };
        const sampleId = `SYN-${experiment.candidate_id || "SAMPLE"}`;
        const timestamp = Date.now();
        setExperiments((current) => current.map((item) => item.id === experiment.id ? updatedExperiment : item));
        setMeasurements((current) => [
          { id: `MEAS-${timestamp}-1`, experiment_id: experiment.id, sample_id: sampleId, property_name: "ionic_conductivity", value: 0.0028, unit: "S/cm", uncertainty: 0.00022, origin: "simulation", quality_status: "synthetic_or_derived", raw_artifact_uri: "demo://local-simulation/measurement-1", synthetic: true },
          { id: `MEAS-${timestamp}-2`, experiment_id: experiment.id, sample_id: sampleId, property_name: "stability_score", value: 79.4, unit: "score/100", uncertainty: 2.5, origin: "simulation", quality_status: "synthetic_or_derived", raw_artifact_uri: "demo://local-simulation/measurement-2", synthetic: true },
          ...current,
        ]);
        return { experiment: updatedExperiment, result };
      },
      "Digital-twin simulation completed",
    );
  }, [withApiFallback]);

  const activeTitle = titles[active];
  const filteredNavigation = useMemo(() => navigation, []);

  const pageContent = () => {
    switch (active) {
      case "overview": return <OverviewView overview={overview} labs={labs} experiments={experiments} agents={agents} events={events} onNavigate={setActive} />;
      case "labs": return <LabsView labs={labs} agents={agents} experiments={experiments} />;
      case "agents": return <AgentOpsView agents={agents} onRunAgent={runAgent} />;
      case "discovery": return <DiscoveryView candidates={candidates} onRefresh={refresh} apiOnline={apiOnline} />;
      case "experiments": return <ExperimentsView experiments={experiments} candidates={candidates} onCreate={createExperiment} onRequestApproval={requestApproval} onSimulate={simulate} />;
      case "governance": return <GovernanceView approvals={approvals} experiments={experiments} onDecision={decideApproval} />;
      case "data": return <DataView datasets={datasets} measurements={measurements} events={events} />;
      case "twin": return <TwinView twin={twin} labs={labs} />;
      case "models": return <ModelsView />;
      case "samples": return <SamplesView />;
      case "research": return <ResearchView />;
      case "calculators": return <ScienceToolsView />;
      case "campaigns": return <CampaignsView />;
      case "advanced": return <AdvancedResearchView />;
      default: return null;
    }
  };

  if (showLanding) {
    return <WorkspaceLanding onEnter={() => {
      setShowLanding(false);
      try { window.localStorage.setItem("nexus.workspace.entered", "true"); } catch { /* best effort */ }
    }} />;
  }

  return (
    <div className="app-frame">
      {mobileNavOpen && <button className="nav-scrim" aria-label="Close navigation" onClick={() => setMobileNavOpen(false)} />}
      <a className="skip-link" href="#main-content">Skip to main content</a>
      <aside className={`sidebar ${mobileNavOpen ? "mobile-open" : ""}`}>
        <div className="brand-lockup">
          <div className="brand-mark"><Command size={19} strokeWidth={2.4} /></div>
          <div><strong>NEXUS</strong><span>AUTONOMOUS SCIENCE</span></div>
        </div>
        <div className="workspace-select">
          <div className="workspace-avatar">NS</div>
          <div><strong>Network Workspace</strong><small>Research environment</small></div>
          <ChevronDown size={15} />
        </div>
        <nav className="main-nav" aria-label="Primary navigation">
          {filteredNavigation.map((item, index) => {
            const showGroup = index === 0 || item.group !== filteredNavigation[index - 1].group;
            const Icon = item.icon;
            return <div key={item.key}>
              {showGroup && <div className="nav-group-label">{item.group}</div>}
              <button className={`nav-item ${active === item.key ? "active" : ""}`} aria-current={active === item.key ? "page" : undefined} title={item.label} onClick={() => { setActive(item.key); setMobileNavOpen(false); }}>
                <Icon size={17} strokeWidth={1.8} /><span>{item.label}</span>
                {item.key === "governance" && approvals.filter((approval) => approval.status === "pending").length > 0 && <b className="nav-count">{approvals.filter((approval) => approval.status === "pending").length}</b>}
              </button>
            </div>;
          })}
        </nav>
        <div className="sidebar-bottom">
          <div className="network-health">
            <div className="network-health-top"><span className="green-pulse" />Network status</div>
            <strong>{apiOnline ? "API connected" : "Demo workspace"}</strong>
            <small>{apiOnline ? "Live backend · synthetic seed data" : "Local fallback data active"}</small>
          </div>
          <button className="nav-item subtle"><CircleHelp size={17} /><span>Documentation</span></button>
          <div className="profile-row"><div className="profile-avatar">DS</div><div><strong>Demo Scientist</strong><small>Research operator</small></div><ChevronDown size={14} /></div>
        </div>
      </aside>

      <main className="main-area" id="main-content">
        <header className="topbar">
          <div className="topbar-leading">
            <button className="mobile-nav-toggle" aria-label={mobileNavOpen ? "Close navigation" : "Open navigation"} aria-expanded={mobileNavOpen} onClick={() => setMobileNavOpen((value) => !value)}>{mobileNavOpen ? <X size={19} /> : <Menu size={19} />}</button>
            <div className="breadcrumb"><span>Workspace</span><span className="breadcrumb-slash">/</span><strong>{navigation.find((item) => item.key === active)?.label}</strong></div>
          </div>
          <div className="topbar-actions">
            <button className="search-trigger" onClick={() => setSearchOpen((value) => !value)}><Search size={15} /><span>Search NEXUS</span><kbd>⌘ K</kbd></button>
            <div className="topbar-divider" />
            <span className="environment-tag"><span /> DEMO ENVIRONMENT</span>
            <button className="icon-button" aria-label="Notifications" onClick={() => setActive("governance")}><Bell size={17} /><i /></button>
            <div className="topbar-avatar">DS</div>
          </div>
        </header>

        {searchOpen && <div className="command-search" role="search"><Search size={17} /><input aria-label="Search NEXUS" autoFocus value={globalSearch} onChange={(event) => setGlobalSearch(event.target.value)} placeholder="Search agents, experiments, labs, candidates..." /><button onClick={() => { const term = globalSearch.toLowerCase().trim(); const match = navigation.find((item) => item.label.toLowerCase().includes(term)); if (match) setActive(match.key); setSearchOpen(false); }}><span>Open result</span><kbd>↵</kbd></button><button className="search-close" onClick={() => setSearchOpen(false)}>Esc</button></div>}

        <div className="page-wrap">
          <div className="page-title-row">
            <div>
              <div className="page-kicker"><span className="kicker-line" /> SCIENTIFIC OPERATING SYSTEM <span className="kicker-version">v0.1.0</span></div>
              <h1>{activeTitle.title}</h1>
              <p>{activeTitle.subtitle}</p>
            </div>
            <div className="page-actions">
              <button className="button button-secondary" onClick={() => void refresh()} disabled={busy}><RefreshCw size={15} className={busy ? "spin" : ""} />Refresh data</button>
              <button className="button button-primary" onClick={() => setActive("experiments")}><Plus size={16} />New experiment</button>
            </div>
          </div>

          <div className="global-notice"><span className="notice-icon"><ShieldCheck size={15} /></span><div><strong>Governed demo mode</strong><span>All seed records and twin outputs are synthetic. AI agents can propose and analyze; physical laboratory actions remain disabled.</span></div><button onClick={() => setActive("governance")}>Review controls <ChevronDown size={13} /></button></div>
          {refreshErrors.length > 0 && <div className="global-notice refresh-warning" role="status"><span className="notice-icon"><AlertTriangle size={15} /></span><div><strong>Some data may be stale</strong><span>Could not refresh {refreshErrors.join(", ")}. Existing demo or previously loaded values remain visible.</span></div><button onClick={() => void refresh()} disabled={busy}>Retry <RefreshCw size={13} /></button></div>}
          {pageContent()}
        </div>
      </main>
      {toast && <div className={`toast toast-${toast.kind}`}><CheckCircle2 size={17} /><span>{toast.message}</span><button onClick={() => setToast(null)}>×</button></div>}
      <div className="build-stamp"><span className="green-pulse" />NEXUS CORE · DEMO BUILD</div>
    </div>
  );
}
