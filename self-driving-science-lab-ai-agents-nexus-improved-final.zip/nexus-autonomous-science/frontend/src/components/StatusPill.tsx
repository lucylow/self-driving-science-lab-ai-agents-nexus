import type { ReactNode } from "react";
import { CheckCircle2, Circle, Clock3, PauseCircle, ShieldAlert, XCircle } from "lucide-react";

const iconByStatus: Record<string, ReactNode> = {
  online: <CheckCircle2 size={12} />,
  idle: <Circle size={11} />,
  running: <span className="status-dot-pulse" />,
  completed: <CheckCircle2 size={12} />,
  approved: <CheckCircle2 size={12} />,
  awaiting_approval: <Clock3 size={12} />,
  pending: <Clock3 size={12} />,
  failed: <XCircle size={12} />,
  cancelled: <XCircle size={12} />,
  quarantined: <ShieldAlert size={12} />,
  standby: <PauseCircle size={12} />,
  simulated: <Circle size={11} />,
};

export function StatusPill({ status }: { status: string }) {
  const normalized = status.toLowerCase().replaceAll(" ", "_");
  return <span className={`status-pill status-${normalized}`}>{iconByStatus[normalized] || <Circle size={11} />}{status.replaceAll("_", " ")}</span>;
}
