"use client";

import { useMemo, useState, type ReactNode } from "react";
import {
  Activity, ArrowRight, Atom, CheckCircle2, CircleAlert, FlaskConical,
  GitBranch, LockKeyhole, Orbit, Play, RefreshCw, ShieldCheck,
} from "lucide-react";
import { Panel } from "@/components/Panel";
import { StatusPill } from "@/components/StatusPill";
import { api, ApiError } from "@/lib/api";

type Workspace = "calibration" | "design" | "uncertainty" | "collaboration" | "drift" | "battery" | "federation" | "repeatability";
type ResultMap = Record<string, unknown>;

const tabs: { key: Workspace; label: string; eyebrow: string }[] = [
  { key: "calibration", label: "Twin calibration", eyebrow: "MODEL FIDELITY" },
  { key: "design", label: "Sequential design", eyebrow: "ACTIVE LEARNING" },
  { key: "uncertainty", label: "Uncertainty", eyebrow: "PREDICTIVE CONFIDENCE" },
  { key: "collaboration", label: "Lab collaboration", eyebrow: "DATA EXCHANGE" },
  { key: "drift", label: "Drift monitoring", eyebrow: "MODEL OBSERVABILITY" },
  { key: "battery", label: "Battery twin", eyebrow: "SIMULATION ONLY" },
  { key: "federation", label: "Federated updates", eyebrow: "CROSS-LAB LEARNING" },
  { key: "repeatability", label: "Measurement quality", eyebrow: "REPRODUCIBILITY" },
];

function json(value: unknown): string {
  return JSON.stringify(value, null, 2);
}

function ResultPanel({ title, subtitle, result, error }: {
  title: string; subtitle: string; result?: ResultMap | null; error?: string | null;
}) {
  return (
    <Panel title={title} subtitle={subtitle}>
      {error ? <div className="advanced-inline-error"><CircleAlert size={15} /><span>{error}</span></div> : null}
      {result ? <pre className="advanced-result-json">{json(result)}</pre> :
        <div className="advanced-empty"><Orbit size={21} /><strong>Awaiting analysis</strong><span>Run a method to inspect its structured result, assumptions, and limitations.</span></div>}
    </Panel>
  );
}

function RunButton({ children, busy, onClick }: { children: ReactNode; busy: boolean; onClick: () => void }) {
  return <button className="button button-primary advanced-run-button" disabled={busy} onClick={onClick}>
    {busy ? <RefreshCw size={14} className="spin" /> : <Play size={14} />}{children}
  </button>;
}

function makeCalibrationRows(count: number, offset = 0) {
  return Array.from({ length: count }, (_, index) => {
    const i = index + offset;
    const rawPrediction = i / 42;
    const temperature = 278 + ((i * 7) % 47);
    return {
      features: { raw_prediction: rawPrediction, temperature_k: temperature },
      observed: 0.0007 + 1.14 * rawPrediction - 0.000003 * (temperature - 300),
      measurement_sigma: 0.00002,
      group_id: `SAMPLE-${Math.floor(i / 2)}`,
    };
  });
}

function makeCandidates() {
  const rows = [
    ["ARG-001", 300, .10, .0034, .00045, 2.1, "argyrodite"],
    ["GAR-004", 315, .14, .0038, .00028, 1.8, "garnet"],
    ["NAS-007", 330, .18, .0029, .00062, 1.2, "NASICON"],
    ["ARG-009", 345, .22, .0041, .00051, 2.7, "argyrodite"],
    ["LIS-002", 325, .08, .0031, .00039, 1.4, "lisicon"],
    ["GAR-011", 355, .25, .0036, .00073, 2.4, "garnet"],
  ] as const;
  return rows.map(([candidate_id, temperature, dopant_fraction, prediction_mean, prediction_std, estimated_cost, family]) => ({
    candidate_id, parameters: { temperature, dopant_fraction }, prediction_mean,
    prediction_std, estimated_cost, family,
  }));
}

export function AdvancedResearchView() {
  const [active, setActive] = useState<Workspace>("calibration");
  const [busy, setBusy] = useState<string | null>(null);
  const [results, setResults] = useState<Record<Workspace, ResultMap | null>>({
    calibration: null, design: null, uncertainty: null, collaboration: null, drift: null, battery: null, federation: null, repeatability: null,
  });
  const [errors, setErrors] = useState<Partial<Record<Workspace, string>>>({});
  const [calibrationId, setCalibrationId] = useState<string | null>(null);
  const [sourceLab, setSourceLab] = useState("SDL1");
  const [targetLab, setTargetLab] = useState("SDL7");

  const visibleTab = useMemo(() => tabs.find((tab) => tab.key === active)!, [active]);

  async function run(key: Workspace, action: () => Promise<ResultMap>) {
    setBusy(key);
    setErrors((current) => ({ ...current, [key]: undefined }));
    try {
      const response = await action();
      setResults((current) => ({ ...current, [key]: response }));
    } catch (error) {
      setErrors((current) => ({ ...current, [key]: error instanceof ApiError ? error.message : "The analysis could not be completed." }));
    } finally {
      setBusy(null);
    }
  }

  async function calibrateTwin() {
    await run("calibration", async () => {
      const calibration = await api.advancedCalibrateTwin({
        model_id: "nexus-sdl1-electrolyte-twin", model_version: "0.2.0",
        domain: "inorganic_materials", feature_names: ["raw_prediction", "temperature_k"],
        records: makeCalibrationRows(48), created_by: "NEXUS demo scientist", synthetic: true,
      });
      const id = String(calibration.id || "");
      setCalibrationId(id || null);
      let validation: Record<string, unknown> | null = null;
      if (id) {
        validation = await api.advancedValidateTwin(id, {
          validation_domain: "inorganic_materials", records: makeCalibrationRows(12, 48),
        });
      }
      return { calibration, validation, source: "synthetic frontend-generated calibration fixture",
        note: "Replace this fixture with independently measured, quality-controlled, paired observations before any scientific use." };
    });
  }

  async function proposeDesign() {
    await run("design", async () => api.advancedProposeBatch({
      candidates: makeCandidates(), feature_names: ["temperature", "dopant_fraction"],
      best_observed: .0032, direction: "maximize", strategy: "expected_improvement",
      batch_size: 4, max_per_family: 1, diversity_weight: .2, cost_exponent: .7,
      feature_ranges: { temperature: [290, 365], dopant_fraction: [0, .3] },
      constraints: [{ parameter: "temperature", minimum: 290, maximum: 360 },
        { parameter: "dopant_fraction", minimum: 0, maximum: .28 }],
    }));
  }

  async function propagate() {
    await run("uncertainty", async () => api.advancedPropagateUncertainty({
      means: { composition_score: .72, processing_temperature: 320, porosity_fraction: .08 },
      standard_deviations: { composition_score: .04, processing_temperature: 8, porosity_fraction: .015 },
      coefficients: { composition_score: .0012, processing_temperature: -.000003, porosity_fraction: -.0008 },
      intercept: .0018, samples: 10000, seed: 19,
      correlation: [[1, .15, -.1], [.15, 1, .25], [-.1, .25, 1]],
    }));
  }

  async function createExchange() {
    await run("collaboration", async () => {
      const created = await api.advancedCreateExchange({
        source_laboratory: sourceLab, target_laboratory: targetLab,
        subject_type: "dataset", subject_id: "SDL1-DEMO-DATASET-014",
        domain: "inorganic_materials", schema_version: "1.0.0",
        evidence_origin: "computational_result", synthetic: true,
        classification: "internal", consent_scope: "research_review_only",
        payload: { provenance_refs: ["EXP-DEMO-001", "MODEL-SDL1-BASELINE"],
          property: "ionic_conductivity", unit: "S/cm", record_count: 42,
          aggregate_summary: { median: .0029, interquartile_range: .0007 },
          operator_email: "redacted-by-policy@example.invalid" },
      });
      const envelope = (created.envelope || {}) as Record<string, unknown>;
      let verification: ResultMap | null = null;
      if (envelope.manifest) {
        verification = await api.advancedVerifyExchange({ envelope, require_signature: false });
      }
      return { created, verification,
        note: "Integrity verification does not grant scientific reuse. Destination-lab approval and applicability review remain separate." };
    });
  }

  async function monitorDrift() {
    await run("drift", async () => api.advancedMonitorResiduals({
      residuals: [0.02, -.01, .01, .03, -.02, .02, 0, .01, .04, .03, .02, .31, .35, .37, .41, .39],
      baseline_mean: 0, baseline_sd: .08, ewma_smoothing: .25,
      cusum_allowance: .35, cusum_threshold: 3.2,
    }));
  }

  async function simulateBattery() {
    await run("battery", async () => api.advancedSimulateBattery({
      capacity_ah: 3.2, initial_soc: .95, current_a: 1.1,
      internal_resistance_ohm: .035, nominal_voltage_v: 3.65,
      duration_seconds: 7200, time_step_seconds: 60,
    }));
  }

  async function aggregateFederatedUpdates() {
    await run("federation", async () => api.advancedFederatedModelUpdates({
      expected_model_id: "nexus-shared-material-property-baseline",
      expected_version: "0.1.0", parameter_names: ["conductivity_weight", "temperature_bias"],
      minimum_labs: 3, maximum_client_weight: .4, clip_norm: .75,
      updates: [
        { laboratory_code: "SDL1", base_model_id: "nexus-shared-material-property-baseline", base_model_version: "0.1.0", consent_scope: "approved_parameter_update", local_validation_status: "accepted_for_research", training_record_count: 64, parameter_delta: { conductivity_weight: .08, temperature_bias: -.02 } },
        { laboratory_code: "SDL2", base_model_id: "nexus-shared-material-property-baseline", base_model_version: "0.1.0", consent_scope: "approved_parameter_update", local_validation_status: "accepted_for_research", training_record_count: 48, parameter_delta: { conductivity_weight: .05, temperature_bias: .01 } },
        { laboratory_code: "SDL4", base_model_id: "nexus-shared-material-property-baseline", base_model_version: "0.1.0", consent_scope: "approved_parameter_update", local_validation_status: "accepted_for_research", training_record_count: 52, parameter_delta: { conductivity_weight: .07, temperature_bias: -.01 } },
      ],
      review_owner: "NEXUS federation review",
    }));
  }

  async function reviewRepeatability() {
    await run("repeatability", async () => {
      const replicates = [
        ["SDL1-SAMPLE-A", 0.0031], ["SDL1-SAMPLE-A", 0.0030], ["SDL1-SAMPLE-A", 0.0032],
        ["SDL1-SAMPLE-B", 0.0028], ["SDL1-SAMPLE-B", 0.0029], ["SDL1-SAMPLE-B", 0.0027],
        ["SDL2-SAMPLE-A", 0.0035], ["SDL2-SAMPLE-A", 0.0034], ["SDL2-SAMPLE-A", 0.0036],
        ["SDL2-SAMPLE-B", 0.0032], ["SDL2-SAMPLE-B", 0.0033], ["SDL2-SAMPLE-B", 0.0031],
      ].map(([sample_id, value]) => ({ sample_id, value }));
      const repeats = await api.advancedRepeatability({ replicates, synthetic: true, domain: "inorganic_materials" });
      const observations = [
        ...[0.0031, 0.0030, 0.0032, 0.0028, 0.0029, 0.0027].map((value) => ({ laboratory_code: "SDL1", value })),
        ...[0.0035, 0.0034, 0.0036, 0.0032, 0.0033, 0.0031].map((value) => ({ laboratory_code: "SDL2", value })),
      ];
      const labs = await api.advancedLabEffects({ observations, domain: "inorganic_materials", shrinkage: true });
      return { repeatability: repeats.repeatability, lab_effect_diagnostics: labs.diagnostics,
        provenance: "synthetic computational quality demo", note: "ICC is population-dependent. Between-laboratory differences are descriptive and not causal." };
    });
  }

  return (
    <div className="view-stack advanced-research-view">
      <div className="advanced-header-grid">
        <div className="advanced-intro-card">
          <div className="advanced-intro-kicker"><span className="green-pulse" /> ADVANCED RESEARCH TOOLCHAIN</div>
          <h2>Trust the model only within the evidence envelope.</h2>
          <p>Calibrate twin outputs, propagate uncertainty, select informative experiments, and exchange scientific summaries with traceable controls.</p>
          <div className="advanced-principles">
            <span><CheckCircle2 size={13} /> Domain scoped</span>
            <span><CheckCircle2 size={13} /> Provenance aware</span>
            <span><LockKeyhole size={13} /> Physical control disabled</span>
          </div>
        </div>
        <div className="advanced-stat-stack">
          <div className="advanced-mini-stat"><span>Calibration artifacts</span><strong>{calibrationId ? "1 active" : "Not yet created"}</strong><small>Research candidate only</small></div>
          <div className="advanced-mini-stat"><span>Analysis environment</span><strong>Deterministic API</strong><small>Reproducible seeded demo methods</small></div>
          <div className="advanced-mini-stat"><span>Instrument connectivity</span><strong>Disabled</strong><small>No physical endpoints configured</small></div>
        </div>
      </div>

      <div className="advanced-tabs" role="tablist" aria-label="Advanced research methods">
        {tabs.map((tab) => <button key={tab.key} role="tab" aria-selected={active === tab.key}
          className={active === tab.key ? "active" : ""} onClick={() => setActive(tab.key)}>
          <small>{tab.eyebrow}</small><span>{tab.label}</span>
        </button>)}
      </div>

      {active === "calibration" && <div className="advanced-work-grid">
        <Panel title="Digital-twin calibration" subtitle="Weighted affine correction · paired inputs and trusted observations">
          <div className="advanced-method-copy"><Orbit size={20} /><div><strong>Calibrate the model output against a target domain.</strong><span>The service estimates an intercept and feature coefficients, records the training-data digest, and exposes held-out validation as a separate step.</span></div></div>
          <div className="advanced-field-grid"><label>Target model <input value="nexus-sdl1-electrolyte-twin" readOnly /></label><label>Domain <input value="inorganic_materials" readOnly /></label><label>Calibration records <input value="48 paired synthetic rows" readOnly /></label><label>Calibration method <input value="Weighted affine least squares" readOnly /></label></div>
          <div className="advanced-action-row"><RunButton busy={busy === "calibration"} onClick={() => void calibrateTwin()}>Fit and validate demo twin</RunButton>
            {calibrationId && <span className="advanced-id">Calibration {calibrationId.slice(0, 13)}</span>}</div>
          <div className="advanced-note"><CircleAlert size={14} /><span>This demo fixture is synthetic. It verifies software behavior only and cannot establish real twin fidelity.</span></div>
        </Panel>
        <ResultPanel title="Calibration result" subtitle="Fit coefficients, validation metrics, range checks and limitations" result={results.calibration} error={errors.calibration} />
      </div>}

      {active === "design" && <div className="advanced-work-grid">
        <Panel title="Sequential experiment design" subtitle="Expected improvement · resource-aware · diversity-constrained batch">
          <div className="advanced-method-copy"><Atom size={20} /><div><strong>Choose the next computational candidates.</strong><span>Candidate ranking combines expected improvement, predicted uncertainty, estimated cost, parameter bounds, and family diversification.</span></div></div>
          <div className="advanced-field-grid"><label>Optimization target <input value="ionic_conductivity · maximize" readOnly /></label><label>Current best <input value="0.0032 S/cm" readOnly /></label><label>Proposal batch size <input value="4 candidates" readOnly /></label><label>Family cap <input value="1 per family" readOnly /></label></div>
          <RunButton busy={busy === "design"} onClick={() => void proposeDesign()}>Generate next candidate batch</RunButton>
          <div className="advanced-note"><ShieldCheck size={14} /><span>Proposals are not protocols. A domain scientist must validate candidates and define a safe experimental method.</span></div>
        </Panel>
        <ResultPanel title="Candidate batch" subtitle="Selected, rejected, scores, constraint checks and review status" result={results.design} error={errors.design} />
      </div>}

      {active === "uncertainty" && <div className="advanced-work-grid">
        <Panel title="Uncertainty propagation" subtitle="Monte Carlo propagation through a linear property model">
          <div className="advanced-method-copy"><Activity size={20} /><div><strong>Carry measurement and parameter uncertainty into the output.</strong><span>Input covariance is applied before drawing 10,000 seeded samples. The returned interval reflects the specified input distributions, not a calibrated model prediction interval.</span></div></div>
          <div className="advanced-equation-card"><span>Illustrative response function</span><code>y = β₀ + β₁x₁ + β₂x₂ + β₃x₃</code><small>Input correlation matrix supplied · Monte Carlo seed 19</small></div>
          <RunButton busy={busy === "uncertainty"} onClick={() => void propagate()}>Propagate uncertainty</RunButton>
          <div className="advanced-note"><CircleAlert size={14} /><span>Distributional assumptions and coefficients are illustrative. Calibrate and validate with independent domain data.</span></div>
        </Panel>
        <ResultPanel title="Propagated output distribution" subtitle="Mean, standard deviation, median and quantile interval" result={results.uncertainty} error={errors.uncertainty} />
      </div>}

      {active === "collaboration" && <div className="advanced-work-grid">
        <Panel title="Cross-laboratory exchange" subtitle="Integrity checked, field-filtered envelope · target scientist review required">
          <div className="advanced-method-copy"><GitBranch size={20} /><div><strong>Move scientific summaries with provenance intact.</strong><span>Payload fields are filtered, sensitive identifiers are removed, and a canonical digest is embedded in an exchange manifest.</span></div></div>
          <div className="advanced-field-grid"><label>Source laboratory<select value={sourceLab} onChange={(event) => setSourceLab(event.target.value)}>{Array.from({ length: 8 }, (_, i) => `SDL${i}`).map((lab) => <option key={lab}>{lab}</option>)}</select></label><label>Target laboratory<select value={targetLab} onChange={(event) => setTargetLab(event.target.value)}>{Array.from({ length: 8 }, (_, i) => `SDL${i}`).map((lab) => <option key={lab}>{lab}</option>)}</select></label></div>
          <RunButton busy={busy === "collaboration"} onClick={() => void createExchange()}>Create and verify exchange envelope</RunButton>
          <div className="advanced-note"><LockKeyhole size={14} /><span>Demo envelope is unsigned and internal. HMAC verification is supported by the API when a secret is managed securely server-side. This UI does not transmit secrets.</span></div>
        </Panel>
        <ResultPanel title="Exchange manifest and verification" subtitle="Payload digest, redaction and integrity status" result={results.collaboration} error={errors.collaboration} />
      </div>}

      {active === "drift" && <div className="advanced-work-grid">
        <Panel title="Residual drift monitor" subtitle="EWMA smoothing and two-sided CUSUM diagnostic">
          <div className="advanced-method-copy"><Activity size={20} /><div><strong>Monitor model residuals as new data arrive.</strong><span>The monitor standardizes residuals against a declared baseline, then calculates EWMA and CUSUM paths to identify a review signal.</span></div></div>
          <div className="advanced-field-grid"><label>Baseline mean <input value="0.00" readOnly /></label><label>Baseline standard deviation <input value="0.08" readOnly /></label><label>EWMA smoothing <input value="0.25" readOnly /></label><label>CUSUM threshold <input value="3.2" readOnly /></label></div>
          <RunButton busy={busy === "drift"} onClick={() => void monitorDrift()}>Run residual drift review</RunButton>
          <div className="advanced-note"><CircleAlert size={14} /><span>A detected signal triggers review only. It does not retrain or replace a model automatically.</span></div>
        </Panel>
        <ResultPanel title="Drift diagnostic" subtitle="Sequential monitoring paths and signal indices" result={results.drift} error={errors.drift} />
      </div>}

      {active === "battery" && <div className="advanced-work-grid">
        <Panel title="Battery digital-twin demonstration" subtitle="Idealized state-of-charge and ohmic-drop model">
          <div className="advanced-method-copy"><FlaskConical size={20} /><div><strong>Run a low-order battery discharge simulation.</strong><span>This demonstrates numerical stepping, bounded state updates, and structured trajectory output; it is not an electrochemical cell model or battery-management algorithm.</span></div></div>
          <div className="advanced-field-grid"><label>Capacity <input value="3.2 Ah" readOnly /></label><label>Initial SOC <input value="95%" readOnly /></label><label>Discharge current <input value="1.1 A" readOnly /></label><label>Internal resistance <input value="35 mΩ" readOnly /></label></div>
          <RunButton busy={busy === "battery"} onClick={() => void simulateBattery()}>Run idealized battery simulation</RunButton>
          <div className="advanced-note"><ShieldCheck size={14} /><span>Every point is synthetic. No hardware command or physical battery action is available.</span></div>
        </Panel>
        <ResultPanel title="Simulated trajectory" subtitle="SOC, terminal voltage and model assumptions" result={results.battery} error={errors.battery} />
      </div>}

      {active === "federation" && <div className="advanced-work-grid">
        <Panel title="Federated model-update review" subtitle="Clipped parameter deltas · three-laboratory prototype">
          <div className="advanced-method-copy"><GitBranch size={20} /><div><strong>Aggregate locally trained model deltas without pooling raw examples.</strong><span>Each client update must match the base-model version, approved consent scope, parameter schema, and local research-validation status.</span></div></div>
          <div className="advanced-field-grid"><label>Base model <input value="nexus-shared-material-property-baseline" readOnly /></label><label>Participating labs <input value="SDL1 · SDL2 · SDL4" readOnly /></label><label>Aggregation <input value="Clipped weighted mean" readOnly /></label><label>Minimum laboratories <input value="3" readOnly /></label></div>
          <RunButton busy={busy === "federation"} onClick={() => void aggregateFederatedUpdates()}>Prepare federation round</RunButton>
          <div className="advanced-note"><LockKeyhole size={14} /><span>This is not secure aggregation or a formal differential-privacy protocol. No model is updated or released automatically.</span></div>
        </Panel>
        <ResultPanel title="Federation review packet" subtitle="Client eligibility, clipping, weights, delta and release limitations" result={results.federation} error={errors.federation} />
      </div>}

      {active === "repeatability" && <div className="advanced-work-grid">
        <Panel title="Measurement repeatability and lab effects" subtitle="Replicate variance · ICC approximation · empirical-Bayes summary">
          <div className="advanced-method-copy"><Activity size={20} /><div><strong>Inspect within-sample and between-laboratory variation.</strong><span>The analysis estimates within-group repeatability and partially pooled laboratory means from an illustrative dataset. It does not establish instrument qualification.</span></div></div>
          <div className="advanced-field-grid"><label>Laboratories <input value="SDL1 and SDL2" readOnly /></label><label>Sample groups <input value="4" readOnly /></label><label>Replicates per group <input value="3" readOnly /></label><label>Evidence origin <input value="Synthetic demonstration" readOnly /></label></div>
          <RunButton busy={busy === "repeatability"} onClick={() => void reviewRepeatability()}>Run reproducibility review</RunButton>
          <div className="advanced-note"><CircleAlert size={14} /><span>ICC depends on population heterogeneity. Lab effects are descriptive and do not establish a causal equipment or laboratory effect.</span></div>
        </Panel>
        <ResultPanel title="Repeatability diagnostics" subtitle="Within-group variance, ICC approximation and cross-lab variation" result={results.repeatability} error={errors.repeatability} />
      </div>}

      <div className="advanced-footer-principles"><span><CheckCircle2 size={13} /> AI proposes</span><ArrowRight size={13} /><span><ShieldCheck size={13} /> Deterministic gates validate</span><ArrowRight size={13} /><span><FlaskConical size={13} /> Scientist decides</span><StatusPill status="physical control disabled" /></div>
      <div className="advanced-context-label">CURRENT WORKSPACE · {visibleTab.eyebrow}</div>
    </div>
  );
}
