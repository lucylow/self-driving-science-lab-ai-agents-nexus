"use client";

import { useMemo, useState } from "react";
import { Activity, ArrowUpRight, BrainCircuit, Check, CircleDot, Play, Search, ShieldCheck, SlidersHorizontal, Sparkles } from "lucide-react";
import { Panel } from "@/components/Panel";
import { StatusPill } from "@/components/StatusPill";
import type { Agent } from "@/types";

const departments = ["All departments", "Scientific Research", "Materials Discovery", "Organic Chemistry", "Medicinal Chemistry", "Polymer Science", "Formulation Science", "Biological Systems", "Process Engineering", "Data & Evidence", "Governance & Reliability"];

export function AgentOpsView({ agents, onRunAgent }: { agents: Agent[]; onRunAgent: (agent: Agent, task: string) => Promise<boolean> }) {
  const [query, setQuery] = useState("");
  const [department, setDepartment] = useState("All departments");
  const [running, setRunning] = useState<string | null>(null);
  const [actionError, setActionError] = useState("");
  const visibleAgents = useMemo(() => agents.filter((agent) => {
    const matchesQuery = `${agent.name} ${agent.purpose} ${agent.laboratory_code} ${agent.department}`.toLowerCase().includes(query.toLowerCase());
    const matchesDepartment = department === "All departments" || agent.department === department;
    return matchesQuery && matchesDepartment;
  }), [agents, query, department]);
  const runningCount = agents.filter((agent) => agent.status === "running").length;
  const departmentCount = new Set(agents.map((agent) => agent.department)).size;

  const triggerRun = async (agent: Agent) => {
    setRunning(agent.id);
    setActionError("");
    try {
      const succeeded = await onRunAgent(agent, `Perform a scoped ${agent.name.toLowerCase()} review. Return findings, limitations, uncertainty, and evidence references.`);
      if (!succeeded) setActionError(`The ${agent.name} review did not complete. Review the workspace error and retry.`);
    } catch {
      setActionError(`The ${agent.name} review failed unexpectedly. Retry the action.`);
    } finally { setRunning(null); }
  };

  return (
    <div className="view-stack">
      <div className="metric-grid metric-grid-four">
        <div className="compact-metric"><span className="compact-metric-icon"><BrainCircuit size={17} /></span><div><small>Registered profiles</small><strong>{agents.length || 100}</strong></div><span className="metric-footnote">10 departments</span></div>
        <div className="compact-metric"><span className="compact-metric-icon green"><Activity size={17} /></span><div><small>Running now</small><strong>{runningCount}</strong></div><span className="metric-footnote">Live task state</span></div>
        <div className="compact-metric"><span className="compact-metric-icon violet"><ShieldCheck size={17} /></span><div><small>Elevated permissions</small><strong>0</strong></div><span className="metric-footnote">No hardware controls</span></div>
        <div className="compact-metric"><span className="compact-metric-icon amber"><CircleDot size={17} /></span><div><small>Specialist departments</small><strong>{departmentCount || 10}</strong></div><span className="metric-footnote">Domain-separated</span></div>
      </div>

      <Panel title="Multi-agent operations" subtitle="Agent registry · capability-based task assignment" action={<div className="panel-live"><span /> PERMISSION-BOUNDED</div>}>
        {actionError && <div className="research-feedback error" role="alert">{actionError}</div>}
        <div className="agent-toolbar">
          <div className="inline-search"><Search size={15} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Find a specialist agent..." /></div>
          <div className="filter-select-wrap"><SlidersHorizontal size={14} /><select value={department} onChange={(event) => setDepartment(event.target.value)}>{departments.map((item) => <option key={item}>{item}</option>)}</select></div>
          <span className="results-count">{visibleAgents.length} profiles</span>
        </div>
        <div className="agent-table-wrap">
          <table className="data-table agent-table"><thead><tr><th>AGENT / SPECIALIZATION</th><th>DEPARTMENT</th><th>LAB NODE</th><th>PERMISSION</th><th>RUNS</th><th>STATUS</th><th /></tr></thead>
            <tbody>{visibleAgents.slice(0, 30).map((agent, index) => <tr key={agent.id}>
              <td><div className="agent-name-cell"><div className={`agent-table-avatar avatar-tone-${index % 5}`}><BrainCircuit size={15} /></div><div><strong>{agent.name}</strong><small>{agent.purpose}</small></div></div></td>
              <td><span className="department-label">{agent.department}</span></td>
              <td><span className="lab-code-mini">{agent.laboratory_code}</span></td>
              <td><span className={`permission-tag permission-${agent.permission_level}`}>{agent.permission_level.replaceAll("_", " ")}</span></td>
              <td className="run-count">{agent.run_count}</td>
              <td><StatusPill status={running === agent.id ? "running" : agent.status} /></td>
              <td><button className="table-action" disabled={running === agent.id} onClick={() => void triggerRun(agent)}>{running === agent.id ? <span className="button-spinner" /> : <Play size={13} />} Run review</button></td>
            </tr>)}</tbody>
          </table>
          {visibleAgents.length > 30 && <div className="table-overflow-note">Showing 30 of {visibleAgents.length}. Use the department filter to narrow the registry.</div>}
          {visibleAgents.length === 0 && <div className="empty-state">No agents match this filter.</div>}
        </div>
      </Panel>

      <div className="agent-principles-grid">
        <div className="agent-principle"><div className="principle-icon"><Sparkles size={18} /></div><div><strong>Specialized, not theatrical</strong><p>Each profile owns a measurable task: schema validation, evidence extraction, candidate ranking, quality assessment, or experiment review.</p></div></div>
        <div className="agent-principle"><div className="principle-icon green"><ShieldCheck size={18} /></div><div><strong>Permission-bounded by design</strong><p>Agent runs create proposals and analyses only. No profile can approve its own work or command physical laboratory equipment.</p></div></div>
        <div className="agent-principle"><div className="principle-icon violet"><Check size={18} /></div><div><strong>Evaluated by capability</strong><p>Track schema compliance, domain applicability, calibration, provenance, tool reliability, and human correction—not a single generic accuracy score.</p></div></div>
      </div>
    </div>
  );
}
