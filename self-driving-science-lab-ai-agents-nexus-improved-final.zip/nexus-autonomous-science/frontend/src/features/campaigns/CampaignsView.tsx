"use client";

import { useCallback, useEffect, useState } from "react";
import { Activity, ArrowRight, CheckCircle2, Flag, LockKeyhole, Play, Plus, RefreshCw, ShieldCheck, XCircle } from "lucide-react";
import { api, ApiError } from "@/lib/api";
import type { ResearchCampaign } from "@/types";
import { Panel } from "@/components/Panel";
import { StatusPill } from "@/components/StatusPill";

const WORKFLOW_OPTIONS = [
  { value: "sdl1_candidate_review", label: "SDL1 candidate review" },
  { value: "cross_lab_evidence_review", label: "Scientific evidence review" },
  { value: "dataset_quality_review", label: "Dataset quality review" },
];

export function CampaignsView() {
  const [campaigns, setCampaigns] = useState<ResearchCampaign[]>([]);
  const [title, setTitle] = useState("Battery electrolyte discovery programme");
  const [objectiveId, setObjectiveId] = useState("OBJ-0001");
  const [labCode, setLabCode] = useState("SDL1");
  const [workflowKey, setWorkflowKey] = useState("sdl1_candidate_review");
  const [reviewer, setReviewer] = useState("Workspace scientist");
  const [note, setNote] = useState("Review the scientific rationale, evidence and simulation scope.");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const refresh = useCallback(async () => {
    try {
      const rows = await api.campaigns();
      setCampaigns(rows);
      if (!selectedId && rows.length) setSelectedId(rows[0].id);
      setError("");
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not load research campaigns.");
    }
  }, [selectedId]);
  useEffect(() => { void refresh(); }, [refresh]);

  const selected = campaigns.find((item) => item.id === selectedId) || campaigns[0] || null;
  const act = async (operation: () => Promise<ResearchCampaign>, success: string) => {
    setBusy(true); setError(""); setMessage("");
    try {
      const updated = await operation();
      setSelectedId(updated.id);
      setMessage(success);
      await refresh();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Campaign operation failed.");
    } finally { setBusy(false); }
  };

  const create = () => void act(() => api.createCampaign({
    title, laboratory_code: labCode, objective_id: objectiveId,
    workflow_keys: [workflowKey], synthetic: true,
    description: "A staged research programme coordinated by NEXUS.",
    constraints: { physical_execution: false, simulation_only: true },
  }), "Campaign created and submitted for human approval.");

  const approve = () => selected && void act(() => api.approveCampaign(selected.id, reviewer, note), "Campaign approved for analytical workflow orchestration.");
  const launch = () => selected && void act(() => api.launchCampaignStage(selected.id, { requested_by: reviewer }), "The next analytical stage has been launched.");
  const review = (decision: "accepted" | "rejected") => selected && void act(
    () => api.reviewCampaignStage(selected.id, decision, reviewer, note),
    decision === "accepted" ? "Stage accepted. The next stage is ready when available." : "Stage rejected; campaign is blocked for revision.",
  );
  const cancel = () => selected && void act(() => api.cancelCampaign(selected.id, reviewer, note || "Cancelled by reviewer."), "Campaign cancelled.");

  const awaitingReview = selected?.status === "awaiting_scientist_review";
  const currentStage = selected?.stages[selected.current_stage_index];
  return (
    <div className="campaign-stack">
      <div className="campaign-stats">
        <div><span>CAMPAIGNS</span><strong>{campaigns.length}</strong><small>Persistent programmes</small></div>
        <div><span>AWAITING APPROVAL</span><strong>{campaigns.filter((item) => item.status === "awaiting_approval").length}</strong><small>Human authorization</small></div>
        <div><span>AWAITING REVIEW</span><strong>{campaigns.filter((item) => item.status === "awaiting_scientist_review").length}</strong><small>Stage-level review</small></div>
        <div><span>PHYSICAL EXECUTION</span><strong>OFF</strong><small>Not available in this build</small></div>
      </div>

      <div className="campaign-columns">
        <Panel title="Create research campaign" subtitle="Bundle one or more governed analysis workflows into a reviewable programme.">
          <div className="campaign-form">
            <label>Campaign title<input value={title} onChange={(event) => setTitle(event.target.value)} /></label>
            <label>Research objective ID<input value={objectiveId} onChange={(event) => setObjectiveId(event.target.value)} /></label>
            <div className="campaign-form-row">
              <label>Laboratory<select value={labCode} onChange={(event) => { setLabCode(event.target.value); setWorkflowKey(event.target.value === "SDL1" ? "sdl1_candidate_review" : "cross_lab_evidence_review"); }}><option>SDL0</option><option>SDL1</option><option>SDL2</option><option>SDL3</option><option>SDL4</option><option>SDL5</option><option>SDL6</option><option>SDL7</option></select></label>
              <label>First stage<select value={workflowKey} onChange={(event) => setWorkflowKey(event.target.value)}>{WORKFLOW_OPTIONS.filter((item) => item.value !== "sdl1_candidate_review" || labCode === "SDL1").map((item) => <option key={item.value} value={item.value}>{item.label}</option>)}</select></label>
            </div>
            <div className="campaign-guard"><LockKeyhole size={15} /><span>Every campaign is simulation-only. Creating a campaign does not authorize experiments or hardware.</span></div>
            <button className="button button-primary" onClick={create} disabled={busy || !title.trim() || !objectiveId.trim()}><Plus size={14} />Create campaign</button>
          </div>
        </Panel>

        <Panel title="Campaign review controls" subtitle="Approvals are assigned to a named human reviewer, not an AI agent.">
          <div className="campaign-form">
            <label>Human reviewer<input value={reviewer} onChange={(event) => setReviewer(event.target.value)} /></label>
            <label>Review note<textarea rows={3} value={note} onChange={(event) => setNote(event.target.value)} /></label>
            {selected ? <div className="campaign-action-row">
              {selected.status === "awaiting_approval" && <button className="button button-primary" onClick={approve} disabled={busy || !reviewer.trim()}><ShieldCheck size={14} />Approve programme</button>}
              {selected.status === "approved" && <button className="button button-primary" onClick={launch} disabled={busy}><Play size={14} />Launch next stage</button>}
              {awaitingReview && <><button className="button button-primary" onClick={() => review("accepted")} disabled={busy || !reviewer.trim()}><CheckCircle2 size={14} />Accept stage</button><button className="button button-danger" onClick={() => review("rejected")} disabled={busy || !reviewer.trim()}><XCircle size={14} />Reject stage</button></>}
              {!['completed', 'cancelled'].includes(selected.status) && <button className="button button-secondary" onClick={cancel} disabled={busy}><XCircle size={14} />Cancel</button>}
            </div> : <div className="campaign-empty">Select a campaign to see its allowed actions.</div>}
          </div>
        </Panel>
      </div>

      <Panel title="Research programme registry" subtitle="Each stage points to a separately persisted workflow run and checkpoint chain." action={<button className="button button-secondary" onClick={() => void refresh()}><RefreshCw size={13} />Refresh</button>}>
        {campaigns.length === 0 ? <div className="campaign-empty"><Flag size={22} /><strong>No research campaigns yet</strong><span>Create a governed programme to coordinate research workflows.</span></div> : <div className="campaign-list">{campaigns.map((campaign) => <button key={campaign.id} className={`campaign-row ${campaign.id === selected?.id ? "selected" : ""}`} onClick={() => setSelectedId(campaign.id)}><div className="campaign-row-icon"><Flag size={15} /></div><div className="campaign-row-copy"><strong>{campaign.title}</strong><small>{campaign.campaign_code} · {campaign.laboratory_code} · {campaign.stages.length} stage(s)</small></div><StatusPill status={campaign.status} /><ArrowRight size={14} /></button>)}</div>}
      </Panel>

      {selected && <Panel title={selected.title} subtitle={`${selected.campaign_code} · ${selected.domain} · ${selected.execution_mode}`}>
        <div className="campaign-stage-list">{selected.stages.map((stage, index) => <div className="campaign-stage" key={stage.stage_key}><div className="campaign-stage-index">{String(index + 1).padStart(2, "0")}</div><div className="campaign-stage-main"><strong>{stage.title}</strong><small>{stage.workflow_key.replace(/_/g, " ")}{stage.workflow_run_id ? ` · Run ${stage.workflow_run_id.slice(0, 12)}` : " · Not launched"}</small>{stage.review_note && <small>Review: {stage.review_note}</small>}</div><StatusPill status={stage.status} /></div>)}</div>
        <div className="campaign-integrity"><Activity size={14} /><span>Current stage: {currentStage?.title || "All stages completed"}. Workflow history and hash-linked checkpoints are preserved in the orchestration service.</span></div>
      </Panel>}
      {message && <div className="campaign-feedback success">{message}</div>}
      {error && <div className="campaign-feedback error">{error}</div>}
      <div className="campaign-footnote">Campaign approval authorizes only the declared analytical workflow stages. Each stage still waits for scientist review before the next begins. No physical execution or instrument command is exposed.</div>
    </div>
  );
}
