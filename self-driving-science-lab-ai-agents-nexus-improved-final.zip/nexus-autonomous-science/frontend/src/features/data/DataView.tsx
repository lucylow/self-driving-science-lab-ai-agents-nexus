"use client";

import { useMemo, useState } from "react";
import { ArrowDownToLine, CheckCircle2, Database, FileText, GitBranch, Layers3, Search, ShieldCheck, Sparkles } from "lucide-react";
import { Panel } from "@/components/Panel";
import { StatusPill } from "@/components/StatusPill";
import type { Dataset, EventRecord, Measurement } from "@/types";

const layerDescriptions = [
  ["raw", "Original artifacts", "Instrument exports, images, spectra, sensor streams, notebooks."],
  ["validated", "Validated records", "Schema, identity, units, calibration references, and quality flags."],
  ["processed", "Derived representations", "Normalized values, extracted features, transformations, and annotations."],
  ["scientific", "Scientific observations", "Measurements, experimental outcomes, and scientist interpretations."],
  ["ai", "AI learning data", "Features, training datasets, targets, predictions, and model evaluations."],
  ["knowledge", "Scientific knowledge", "Hypotheses, mechanisms, conclusions, and evidence relationships."],
];

export function DataView({ datasets, measurements, events }: { datasets: Dataset[]; measurements: Measurement[]; events: EventRecord[] }) {
  const [query, setQuery] = useState("");
  const filteredDatasets = useMemo(() => datasets.filter((dataset) => `${dataset.name} ${dataset.domain} ${dataset.data_layer}`.toLowerCase().includes(query.toLowerCase())), [datasets, query]);
  const syntheticCount = measurements.filter((item) => item.synthetic || item.origin !== "measured").length;
  const measuredCount = measurements.filter((item) => item.origin === "measured").length;
  const layersPresent = new Set(datasets.map((dataset) => dataset.data_layer));
  return (
    <div className="view-stack">
      <div className="data-integrity-banner"><div className="data-integrity-icon"><Database size={20} /></div><div><strong>Preserve the source. Enrich the context. Never erase provenance.</strong><p>Raw artifacts, validated observations, processed data, AI records, and scientific conclusions are separate linked layers—not one overwritten table.</p></div><span className="data-count-chip">{datasets.length} DATASETS</span></div>
      <div className="metric-grid metric-grid-four">
        <div className="compact-metric"><span className="compact-metric-icon"><Database size={17} /></span><div><small>Dataset registry</small><strong>{datasets.length}</strong></div><span className="metric-footnote">Versioned records</span></div>
        <div className="compact-metric"><span className="compact-metric-icon green"><FileText size={17} /></span><div><small>Measurement records</small><strong>{measurements.length}</strong></div><span className="metric-footnote">All origins retained</span></div>
        <div className="compact-metric"><span className="compact-metric-icon violet"><Sparkles size={17} /></span><div><small>Synthetic / derived</small><strong>{syntheticCount}</strong></div><span className="metric-footnote">Not experimental data</span></div>
        <div className="compact-metric"><span className="compact-metric-icon amber"><Layers3 size={17} /></span><div><small>Populated layers</small><strong>{layersPresent.size}/6</strong></div><span className="metric-footnote">Foundation stage</span></div>
      </div>

      <Panel title="Six-layer scientific data fabric" subtitle="A shared scientific language across all SDL nodes">
        <div className="data-layer-stack">
          {layerDescriptions.map(([layer, title, description], index) => <div className={`data-layer-row layer-${layer}`} key={layer}>
            <div className="data-layer-number">0{index + 1}</div><div className="data-layer-icon"><Layers3 size={17} /></div><div className="data-layer-copy"><strong>{title}</strong><span>{description}</span></div><div className="data-layer-status"><StatusPill status={layersPresent.has(layer) ? "available" : "standby"} /><small>{layersPresent.has(layer) ? `${datasets.filter((item) => item.data_layer === layer).length} dataset(s)` : "Adapter / service required"}</small></div>
          </div>)}
        </div>
        <div className="lineage-rule"><GitBranch size={15} /><span>Each derived record must reference its source artifact and the versioned transformation that created it.</span></div>
      </Panel>

      <div className="data-bottom-grid">
        <Panel title="Dataset registry" subtitle="Scientific dataset versions and readiness">
          <div className="inline-search dataset-search"><Search size={14} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search datasets..." /></div>
          <div className="dataset-list">
            {filteredDatasets.map((dataset) => <div className="dataset-row" key={dataset.id}><div className="dataset-file-icon"><FileText size={16} /></div><div className="dataset-copy"><strong>{dataset.name}</strong><span>{dataset.domain} · {dataset.record_count} records</span><small>v{dataset.version} · {dataset.data_layer}</small></div><StatusPill status={dataset.quality_status} /></div>)}
            {filteredDatasets.length === 0 && <div className="empty-state">No datasets match this search.</div>}
          </div>
        </Panel>
        <Panel title="Evidence integrity" subtitle="Record origin and measurement validity">
          <div className="evidence-summary"><div><span className="evidence-count evidence-synthetic">{syntheticCount}</span><div><strong>Synthetic / derived</strong><small>Simulated or model output</small></div></div><div><span className="evidence-count evidence-measured">{measuredCount}</span><div><strong>Measured</strong><small>Physical experiment record</small></div></div></div>
          <div className="measurement-list">
            {measurements.slice(0, 5).map((measurement) => <div className="measurement-row" key={measurement.id}><div className="measurement-copy"><strong>{measurement.property_name.replaceAll("_", " ")}</strong><span>{measurement.sample_id} · {measurement.experiment_id}</span></div><div className="measurement-value"><strong>{measurement.value.toPrecision(3)}</strong><small>{measurement.unit}</small></div><span className={`evidence-origin origin-${measurement.origin}`}>{measurement.origin}</span></div>)}
          </div>
          <div className="quality-note"><ShieldCheck size={14} /> Missing sample identity or units should quarantine a measurement from model-training datasets.</div>
        </Panel>
      </div>

      <Panel title="Audit event stream" subtitle="Append-only records from the scientific workflow">
        <div className="audit-table-wrap"><table className="data-table"><thead><tr><th>EVENT</th><th>ACTOR</th><th>SUBJECT</th><th>TIME</th><th>DATA</th></tr></thead><tbody>{events.slice(0, 8).map((event) => <tr key={event.id}><td><strong className="audit-event-name">{event.event_type.replaceAll("_", " ")}</strong></td><td>{event.actor}</td><td>{event.subject_type} · {event.subject_id}</td><td>{new Date(event.created_at).toLocaleString()}</td><td><span className="mode-tag">{Object.keys(event.payload || {}).length} fields</span></td></tr>)}</tbody></table></div>
      </Panel>
    </div>
  );
}
