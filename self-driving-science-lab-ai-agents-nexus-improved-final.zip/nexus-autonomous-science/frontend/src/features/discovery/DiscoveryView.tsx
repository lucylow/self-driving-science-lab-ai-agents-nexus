"use client";

import { useMemo, useState } from "react";
import { ArrowDownWideNarrow, ArrowUpRight, Atom, ExternalLink, Info, RefreshCw, SlidersHorizontal, Sparkles, Target } from "lucide-react";
import { Panel } from "@/components/Panel";
import { StatusPill } from "@/components/StatusPill";
import type { Candidate } from "@/types";

export function DiscoveryView({ candidates, onRefresh, apiOnline }: { candidates: Candidate[]; onRefresh: () => void; apiOnline: boolean }) {
  const [sort, setSort] = useState("rank");
  const [selected, setSelected] = useState(candidates[0]?.id || "MAT-00128");
  const ordered = useMemo(() => [...candidates].sort((a, b) => sort === "conductivity" ? (b.predicted_properties.ionic_conductivity || 0) - (a.predicted_properties.ionic_conductivity || 0) : sort === "stability" ? (b.predicted_properties.stability_score || 0) - (a.predicted_properties.stability_score || 0) : (b.ranking?.score || b.recommendation_score) - (a.ranking?.score || a.recommendation_score)), [candidates, sort]);
  const chosen = candidates.find((item) => item.id === selected) || ordered[0];
  const average = candidates.length ? candidates.reduce((sum, item) => sum + item.feasibility_score, 0) / candidates.length : 0;

  return (
    <div className="view-stack">
      <div className="discovery-hero">
        <div className="discovery-hero-copy">
          <div className="discovery-label"><Atom size={14} /> SDL1 · INORGANIC MATERIALS</div>
          <h2>AI battery materials<br /><em>discovery laboratory.</em></h2>
          <p>Screen candidate solid-state electrolytes across ionic transport, stability, uncertainty, and synthesis feasibility. This first workflow is a transparent simulation and data-structure demonstrator.</p>
          <div className="discovery-hero-meta"><span><i className="hero-meta-dot" /> Objective active</span><span><i className="hero-meta-dot purple" /> 6 synthetic candidates</span><span>Model baseline v0.1.0</span></div>
        </div>
        <div className="discovery-orbit-art" aria-hidden="true">
          <div className="orbit-ring orbit-ring-one" /><div className="orbit-ring orbit-ring-two" /><div className="orbit-ring orbit-ring-three" />
          <div className="orbit-core"><Atom size={43} strokeWidth={1.1} /></div>
          <span className="orbit-node orbit-node-a" /><span className="orbit-node orbit-node-b" /><span className="orbit-node orbit-node-c" />
          <div className="orbit-caption orbit-caption-a">Li⁺ transport</div><div className="orbit-caption orbit-caption-b">Crystal lattice</div>
        </div>
      </div>

      <div className="metric-grid metric-grid-four">
        <div className="compact-metric"><span className="compact-metric-icon"><Atom size={17} /></span><div><small>Candidate pool</small><strong>{candidates.length}</strong></div><span className="metric-footnote">Synthetic records</span></div>
        <div className="compact-metric"><span className="compact-metric-icon green"><Target size={17} /></span><div><small>Mean feasibility</small><strong>{average.toFixed(0)}%</strong></div><span className="metric-footnote">Heuristic score</span></div>
        <div className="compact-metric"><span className="compact-metric-icon violet"><Sparkles size={17} /></span><div><small>Optimization mode</small><strong>Multi-objective</strong></div><span className="metric-footnote">Weighted ranking</span></div>
        <div className="compact-metric"><span className="compact-metric-icon amber"><SlidersHorizontal size={17} /></span><div><small>Evidence grade</small><strong>E0–E1</strong></div><span className="metric-footnote">Predictions only</span></div>
      </div>

      <div className="discovery-grid">
        <Panel title="Candidate ranking" subtitle="Transparent multi-objective decision support" action={<button className="icon-text-button" onClick={onRefresh}><RefreshCw size={14} />Refresh</button>}>
          <div className="candidate-toolbar"><div className="candidate-sort"><ArrowDownWideNarrow size={14} /><select value={sort} onChange={(event) => setSort(event.target.value)}><option value="rank">Recommended rank</option><option value="conductivity">Ionic conductivity</option><option value="stability">Stability score</option></select></div><span className="results-count">{apiOnline ? "API dataset" : "Local demo dataset"}</span></div>
          <div className="candidate-list">
            {ordered.map((candidate, index) => {
              const score = candidate.ranking?.score ?? candidate.recommendation_score;
              return <button key={candidate.id} className={`candidate-row ${selected === candidate.id ? "selected" : ""}`} onClick={() => setSelected(candidate.id)}>
                <div className="candidate-rank">{String(index + 1).padStart(2, "0")}</div>
                <div className="candidate-formula-mark"><Atom size={17} /></div>
                <div className="candidate-main"><strong>{candidate.name}</strong><span>{candidate.formula} · {candidate.family}</span><div className="candidate-mini-bar"><i style={{ width: `${Math.min(100, score)}%` }} /></div></div>
                <div className="candidate-score"><strong>{Number(score).toFixed(1)}</strong><small>rank score</small></div>
              </button>;
            })}
          </div>
          <div className="candidate-footnote"><Info size={13} /> Scores are heuristic proposal rankings, not measured performance or validated model outputs.</div>
        </Panel>

        {chosen && <Panel title="Candidate intelligence" subtitle={chosen.code} className="candidate-detail-panel">
          <div className="candidate-detail-head"><div className="candidate-detail-symbol"><Atom size={30} /></div><div><h3>{chosen.name}</h3><p>{chosen.formula}</p></div><StatusPill status="synthetic" /></div>
          <div className="candidate-score-large"><div><small>DEMO RECOMMENDATION SCORE</small><strong>{(chosen.ranking?.score ?? chosen.recommendation_score).toFixed(1)}<span>/100</span></strong></div><div className="score-radial"><svg viewBox="0 0 88 88"><circle cx="44" cy="44" r="34" stroke="#edf0f7" strokeWidth="7" fill="none" /><circle cx="44" cy="44" r="34" stroke="#7188f8" strokeWidth="7" fill="none" strokeLinecap="round" strokeDasharray={`${2 * Math.PI * 34 * ((chosen.ranking?.score ?? chosen.recommendation_score) / 100)} ${2 * Math.PI * 34}`} transform="rotate(-90 44 44)" /></svg><Sparkles size={15} /></div></div>
          <div className="candidate-property-grid">
            <div><span>IONIC CONDUCTIVITY</span><strong>{(chosen.predicted_properties.ionic_conductivity || 0).toFixed(4)} <small>S/cm</small></strong><em>Predicted / synthetic</em></div>
            <div><span>STABILITY SCORE</span><strong>{chosen.predicted_properties.stability_score || "—"}<small>/100</small></strong><em>Predicted / synthetic</em></div>
            <div><span>FEASIBILITY</span><strong>{chosen.feasibility_score}<small>/100</small></strong><em>Heuristic review</em></div>
            <div><span>UNCERTAINTY</span><strong>{Math.round((chosen.uncertainty.conductivity || 0) * 100)}<small>%</small></strong><em>Illustrative relative value</em></div>
          </div>
          <div className="candidate-review-box"><div className="review-box-title"><ShieldCheckIcon /> Review before progression</div><p>Confirm composition validity, phase evidence, conditions, measurement method, model applicability, and sample provenance. Generated candidate status does not imply synthesis or analytical confirmation.</p></div>
          <button className="button button-primary button-block" onClick={() => window.dispatchEvent(new CustomEvent("nexus-open-experiment", { detail: { candidateId: chosen.id, candidateName: chosen.name } }))}>Create experiment proposal <ArrowUpRight size={15} /></button>
        </Panel>}
      </div>

      <div className="discovery-loop">
        <div className="discovery-loop-title"><span>THE DISCOVERY LOOP</span><small>Human-reviewed closed-loop demonstration</small></div>
        <div className="loop-steps">
          {["Research evidence", "Generate hypothesis", "Rank candidates", "Design experiment", "Scientist approval", "Twin simulation", "Quality review", "Update knowledge"].map((step, index) => <div className={`loop-step ${index === 4 ? "loop-step-gate" : ""}`} key={step}><span>{String(index + 1).padStart(2, "0")}</span><strong>{step}</strong>{index < 7 && <i />}</div>)}
        </div>
      </div>
    </div>
  );
}

function ShieldCheckIcon() { return <span className="review-shield">✓</span>; }
