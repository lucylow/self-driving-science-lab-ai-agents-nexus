"use client";

import { useEffect, useMemo, useState, type FormEvent } from "react";
import { ArrowRight, Clock3, Filter, FlaskConical, Plus, Search, ShieldCheck, Sparkles, X } from "lucide-react";
import { Panel } from "@/components/Panel";
import { StatusPill } from "@/components/StatusPill";
import type { Candidate, Experiment } from "@/types";

const states = ["all", "draft", "awaiting_approval", "approved", "executing", "data_validation", "completed", "failed", "quarantined"];

export function ExperimentsView({ experiments, candidates, onCreate, onRequestApproval, onSimulate }: {
  experiments: Experiment[];
  candidates: Candidate[];
  onCreate: (payload: Record<string, unknown>) => Promise<boolean>;
  onRequestApproval: (experiment: Experiment) => Promise<boolean>;
  onSimulate: (experiment: Experiment) => Promise<boolean>;
}) {
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState("all");
  const [showCreate, setShowCreate] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [actionError, setActionError] = useState("");
  const [title, setTitle] = useState("New SDL1 candidate screening proposal");
  const [candidateId, setCandidateId] = useState(candidates[0]?.id || "");
  const [duration, setDuration] = useState("60");
  const [detail, setDetail] = useState<Experiment | null>(null);

  useEffect(() => {
    const handler = (event: Event) => {
      const custom = event as CustomEvent<{ candidateId?: string; candidateName?: string }>;
      setCandidateId(custom.detail.candidateId || "");
      setTitle(custom.detail.candidateName ? `${custom.detail.candidateName} · screening proposal` : "New SDL1 candidate screening proposal");
      setShowCreate(true);
    };
    window.addEventListener("nexus-open-experiment", handler);
    return () => window.removeEventListener("nexus-open-experiment", handler);
  }, []);

  const visible = useMemo(() => experiments.filter((item) => {
    const matchesQuery = `${item.code} ${item.title} ${item.laboratory_code} ${item.status}`.toLowerCase().includes(query.toLowerCase());
    return matchesQuery && (status === "all" || item.status === status);
  }), [experiments, query, status]);
  const activeCount = experiments.filter((item) => ["executing", "data_acquisition", "data_validation", "scientific_interpretation"].includes(item.status)).length;

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setSubmitting(true);
    setActionError("");
    try {
      const succeeded = await onCreate({
        title, laboratory_code: "SDL1", candidate_id: candidateId || null,
        protocol_id: "sdl1-screening-demo", protocol_version: "0.1.0",
        estimated_duration_minutes: Number(duration), execution_mode: "simulation",
        governance: { approval_required: true, safety_review_required: true, physical_execution: false },
      });
      if (succeeded) setShowCreate(false);
      else setActionError("Proposal was not saved. Review the workspace error and retry.");
    } catch {
      setActionError("Proposal could not be saved. Check the connection and retry.");
    } finally { setSubmitting(false); }
  };

  return (
    <div className="view-stack">
      <div className="metric-grid metric-grid-four">
        <div className="compact-metric"><span className="compact-metric-icon"><FlaskConical size={17} /></span><div><small>Total experiments</small><strong>{experiments.length}</strong></div><span className="metric-footnote">All lifecycle states</span></div>
        <div className="compact-metric"><span className="compact-metric-icon green"><Clock3 size={17} /></span><div><small>Active workflows</small><strong>{activeCount}</strong></div><span className="metric-footnote">In progress</span></div>
        <div className="compact-metric"><span className="compact-metric-icon amber"><ShieldCheck size={17} /></span><div><small>Awaiting review</small><strong>{experiments.filter((item) => item.status === "awaiting_approval").length}</strong></div><span className="metric-footnote">Approval gate</span></div>
        <div className="compact-metric"><span className="compact-metric-icon violet"><Sparkles size={17} /></span><div><small>Execution policy</small><strong>Simulation</strong></div><span className="metric-footnote">No physical control</span></div>
      </div>

      <Panel title="Experiment registry" subtitle="Versioned protocols · traceable lifecycle · human approval" action={<button className="button button-primary button-small" onClick={() => setShowCreate(true)}><Plus size={14} />Create proposal</button>}>
        <div className="experiment-toolbar">
          <div className="inline-search"><Search size={15} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search experiment registry..." /></div>
          <div className="filter-select-wrap"><Filter size={14} /><select value={status} onChange={(event) => setStatus(event.target.value)}>{states.map((item) => <option key={item} value={item}>{item === "all" ? "All statuses" : item.replaceAll("_", " ")}</option>)}</select></div>
          <span className="results-count">{visible.length} records</span>
        </div>
        <div className="experiment-table-wrap"><table className="data-table"><thead><tr><th>EXPERIMENT</th><th>LAB</th><th>PROTOCOL</th><th>MODE</th><th>STATUS</th><th>UPDATED</th><th>ACTION</th></tr></thead>
          <tbody>{visible.map((item) => <tr key={item.id}>
            <td><div className="experiment-name-cell"><div className="experiment-icon"><FlaskConical size={15} /></div><div><strong>{item.title}</strong><small>{item.code} · {item.owner}</small></div></div></td>
            <td><span className="lab-code-mini">{item.laboratory_code}</span></td>
            <td><span className="protocol-label">{item.protocol_id}<small>v{item.protocol_version}</small></span></td>
            <td><span className="mode-tag">{item.execution_mode}</span></td>
            <td><StatusPill status={item.status} /></td>
            <td className="muted-cell">{new Date(item.updated_at || item.created_at).toLocaleDateString()}</td>
            <td><button className="table-link" onClick={() => setDetail(item)}>Inspect <ArrowRight size={13} /></button></td>
          </tr>)}</tbody>
        </table>{visible.length === 0 && <div className="empty-state">No experiments match this view.</div>}</div>
      </Panel>

      {detail && <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) setDetail(null); }}><div className="modal-card modal-detail">
        <div className="modal-header"><div><span className="eyebrow">EXPERIMENT DETAIL</span><h2>{detail.code}</h2></div><button className="icon-button" onClick={() => setDetail(null)}><X size={18} /></button></div>
        <h3>{detail.title}</h3><div className="detail-meta-grid"><div><small>LAB</small><strong>{detail.laboratory_code}</strong></div><div><small>STATUS</small><StatusPill status={detail.status} /></div><div><small>EXECUTION MODE</small><strong>{detail.execution_mode}</strong></div><div><small>PROTOCOL</small><strong>{detail.protocol_id} · {detail.protocol_version}</strong></div><div><small>ESTIMATED DURATION</small><strong>{detail.estimated_duration_minutes} minutes</strong></div><div><small>OWNER</small><strong>{detail.owner}</strong></div></div>
        <div className="candidate-review-box"><div className="review-box-title"><ShieldCheckIcon /> Governance checkpoint</div><p>Only a reviewed and approved experiment can proceed to the local digital-twin simulation. Physical laboratory execution is disabled in this starter project.</p></div>
        <div className="modal-actions">
          {actionError && <div className="research-feedback error" role="alert">{actionError}</div>}
          {detail.status !== "awaiting_approval" && !["approved", "completed", "cancelled", "failed", "quarantined"].includes(detail.status) && <button className="button button-secondary" onClick={async () => { setActionError(""); if (await onRequestApproval(detail)) setDetail(null); else setActionError("Approval request was not submitted. Review the workspace error and retry."); }}>Request approval</button>}
          {detail.status === "approved" && <button className="button button-primary" onClick={async () => { setActionError(""); if (await onSimulate(detail)) setDetail(null); else setActionError("Simulation was not completed. Review the workspace error and retry."); }}><Sparkles size={15} />Run twin simulation</button>}
          <button className="button button-ghost" onClick={() => setDetail(null)}>Close</button>
        </div>
      </div></div>}

      {showCreate && <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) setShowCreate(false); }}><form className="modal-card" onSubmit={submit}>
        <div className="modal-header"><div><span className="eyebrow">SDL1 · NEW PROPOSAL</span><h2>Create experiment</h2></div><button type="button" className="icon-button" onClick={() => setShowCreate(false)}><X size={18} /></button></div>
        <p className="modal-intro">Create a structured proposal. This does not schedule or execute laboratory equipment.</p>
        <label className="form-field"><span>Experiment title</span><input value={title} onChange={(event) => setTitle(event.target.value)} minLength={4} required /></label>
        <label className="form-field"><span>Candidate material</span><select value={candidateId} onChange={(event) => setCandidateId(event.target.value)}><option value="">Not linked yet</option>{candidates.map((candidate) => <option value={candidate.id} key={candidate.id}>{candidate.code} · {candidate.formula}</option>)}</select></label>
        <div className="form-grid-two"><label className="form-field"><span>Laboratory</span><input value="SDL1 · Inorganic Materials" readOnly /></label><label className="form-field"><span>Estimated duration (min)</span><input type="number" min="1" max="10080" value={duration} onChange={(event) => setDuration(event.target.value)} required /></label></div>
        <div className="simulation-callout"><ShieldCheck size={17} /><div><strong>Simulation-only by default</strong><span>Scientist review is required. Real instrument actions are not enabled.</span></div></div>
        {actionError && <div className="research-feedback error" role="alert">{actionError}</div>}
        <div className="modal-actions"><button type="button" className="button button-ghost" onClick={() => setShowCreate(false)}>Cancel</button><button className="button button-primary" type="submit" disabled={submitting}>{submitting ? "Creating..." : "Create proposal"}<ArrowRight size={15} /></button></div>
      </form></div>}
    </div>
  );
}

function ShieldCheckIcon() { return <span className="review-shield">✓</span>; }
