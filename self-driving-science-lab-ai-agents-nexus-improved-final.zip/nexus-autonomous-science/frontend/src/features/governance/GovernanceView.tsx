"use client";

import { useMemo, useState } from "react";
import { AlertTriangle, ArrowRight, Check, Clock3, FileCheck2, LockKeyhole, ShieldAlert, ShieldCheck, X } from "lucide-react";
import { Panel } from "@/components/Panel";
import { StatusPill } from "@/components/StatusPill";
import type { Approval, Experiment } from "@/types";

export function GovernanceView({ approvals, experiments, onDecision }: {
  approvals: Approval[]; experiments: Experiment[]; onDecision: (approval: Approval, decision: "approved" | "rejected") => Promise<boolean>;
}) {
  const [selected, setSelected] = useState<string | null>(null);
  const [processing, setProcessing] = useState<string | null>(null);
  const [actionError, setActionError] = useState("");
  const pending = useMemo(() => approvals.filter((item) => item.status === "pending"), [approvals]);
  const decided = approvals.filter((item) => item.status !== "pending");
  const selectedApproval = approvals.find((item) => item.id === selected) || pending[0] || null;
  const linkedExperiment = selectedApproval ? experiments.find((item) => item.id === selectedApproval.experiment_id) : null;

  const decide = async (approval: Approval, decision: "approved" | "rejected") => {
    setProcessing(approval.id);
    setActionError("");
    try {
      if (await onDecision(approval, decision)) setSelected(null);
      else setActionError("Decision was not saved. Review the workspace error and retry.");
    } catch {
      setActionError("Decision could not be saved. Check the connection and retry.");
    } finally { setProcessing(null); }
  };

  return (
    <div className="view-stack">
      <div className="governance-banner"><div className="governance-banner-icon"><LockKeyhole size={21} /></div><div><strong>AI proposes. Governance authorizes.</strong><p>Agent recommendations do not create permissions. Each experiment proposal must pass deterministic state, feasibility, and safety checks, then receive a human decision.</p></div><span className="governance-policy-tag">POLICY ACTIVE</span></div>
      <div className="metric-grid metric-grid-four">
        <div className="compact-metric"><span className="compact-metric-icon amber"><Clock3 size={17} /></span><div><small>Awaiting decision</small><strong>{pending.length}</strong></div><span className="metric-footnote">Requires reviewer</span></div>
        <div className="compact-metric"><span className="compact-metric-icon green"><Check size={17} /></span><div><small>Approved records</small><strong>{decided.filter((item) => item.status === "approved").length}</strong></div><span className="metric-footnote">Recorded decision</span></div>
        <div className="compact-metric"><span className="compact-metric-icon"><FileCheck2 size={17} /></span><div><small>Audit events</small><strong>Append-only</strong></div><span className="metric-footnote">Corrections are new events</span></div>
        <div className="compact-metric"><span className="compact-metric-icon violet"><ShieldAlert size={17} /></span><div><small>Physical actions</small><strong>Blocked</strong></div><span className="metric-footnote">No hardware gateway</span></div>
      </div>

      <div className="governance-grid">
        <Panel title="Approval queue" subtitle="Experiment proposals waiting for scientist review">
          {pending.length ? <div className="approval-queue">{pending.map((approval) => {
            const experiment = experiments.find((item) => item.id === approval.experiment_id);
            return <button className={`approval-queue-item ${selectedApproval?.id === approval.id ? "selected" : ""}`} key={approval.id} onClick={() => setSelected(approval.id)}>
              <div className="approval-priority"><Clock3 size={16} /></div>
              <div className="approval-item-copy"><div><strong>{experiment?.code || approval.experiment_id}</strong><StatusPill status="pending" /></div><span>{experiment?.title || "Experiment proposal"}</span><small>Requested by {approval.requested_by}</small></div>
              <ArrowRight size={16} />
            </button>;
          })}</div> : <div className="empty-state"><FileCheck2 size={22} /><strong>No pending decisions</strong><p>New experiment proposals will appear here.</p></div>}
          <div className="approval-queue-footer"><span>Decision records are versioned and attributable.</span><span>{approvals.length} total</span></div>
        </Panel>
        <Panel title="Review workspace" subtitle="Decision context and deterministic checks" className="review-panel">
          {selectedApproval && linkedExperiment ? <>
            <div className="review-context-top"><div><small>SELECTED PROPOSAL</small><h3>{linkedExperiment.code}</h3></div><StatusPill status={selectedApproval.status} /></div>
            <h4>{linkedExperiment.title}</h4>
            <p className="review-context-desc">{selectedApproval.reason}</p>
            <div className="review-facts">
              <div><span>LABORATORY</span><strong>{linkedExperiment.laboratory_code}</strong></div>
              <div><span>EXECUTION MODE</span><strong>{linkedExperiment.execution_mode}</strong></div>
              <div><span>PROTOCOL</span><strong>{linkedExperiment.protocol_id} · {linkedExperiment.protocol_version}</strong></div>
              <div><span>OWNER</span><strong>{linkedExperiment.owner}</strong></div>
            </div>
            <div className="review-checklist">
              <div className="review-check passed"><Check size={14} /><span>Experiment record exists and is versioned</span><b>PASS</b></div>
              <div className="review-check passed"><Check size={14} /><span>Demo execution mode is simulation-only</span><b>PASS</b></div>
              <div className="review-check passed"><Check size={14} /><span>Physical execution permission is disabled</span><b>PASS</b></div>
              <div className="review-check warning"><AlertTriangle size={14} /><span>Scientific validity still requires expert review</span><b>REVIEW</b></div>
            </div>
            {selectedApproval.status === "pending" && <div className="review-decision-actions"><button className="button button-danger-outline" disabled={processing === selectedApproval.id} onClick={() => void decide(selectedApproval, "rejected")}><X size={15} />Reject proposal</button><button className="button button-primary" disabled={processing === selectedApproval.id} onClick={() => void decide(selectedApproval, "approved")}><Check size={15} />Approve for demo</button></div>}
            {actionError && <div className="research-feedback error" role="alert">{actionError}</div>}
            <div className="review-footnote"><LockKeyhole size={13} /> Approval only unlocks the digital-twin simulation path; it does not authorize physical equipment.</div>
          </> : <div className="empty-state"><ShieldCheck size={22} /><strong>Select a proposal</strong><p>Choose an approval request from the queue to review its context.</p></div>}
        </Panel>
      </div>

      <Panel title="Governance principles" subtitle="System-wide invariants that must remain true across SDL0–SDL7">
        <div className="governance-principles">
          <div><span className="principle-index">01</span><strong>Separation of duties</strong><p>The proposing agent cannot approve its own proposal or grant itself new permissions.</p></div>
          <div><span className="principle-index">02</span><strong>Local safety authority</strong><p>Cloud application approvals never replace instrument interlocks, operator checks, or emergency procedures.</p></div>
          <div><span className="principle-index">03</span><strong>Traceable decisions</strong><p>Every state change records actor, timestamp, subject, reason, and related evidence references.</p></div>
          <div><span className="principle-index">04</span><strong>Evidence is typed</strong><p>Predictions, computational outputs, synthetic simulations, and experimental measurements remain distinct.</p></div>
        </div>
      </Panel>
    </div>
  );
}
