"use client";

import { useMemo, useState, type ComponentProps } from "react";
import { ArrowUpRight, Atom, Beaker, BrainCircuit, CircuitBoard, FlaskConical, Microscope, Orbit, Package, Settings2 } from "lucide-react";
import { Panel } from "@/components/Panel";
import { StatusPill } from "@/components/StatusPill";
import type { Agent, Experiment, Laboratory } from "@/types";

const icons = [BrainCircuit, Atom, Beaker, FlaskConical, Package, LayersIcon, Microscope, Settings2];
function LayersIcon(props: ComponentProps<typeof Atom>) { return <Orbit {...props} />; }
const researchPrograms: Record<string, string[]> = {
  SDL0: ["Agent research and evaluation", "Robotics simulation", "Instrument interoperability", "Safety and reliability"],
  SDL1: ["Atomic-scale materials discovery", "Defect chemistry and ionic transport", "Battery materials", "Catalysis and semiconductor materials"],
  SDL2: ["Molecular representations", "Reaction mechanisms", "Synthesis feasibility", "Purification and spectral analysis"],
  SDL3: ["Structure–activity relationships", "Binding and selectivity", "Assay quality", "Metabolic stability evidence"],
  SDL4: ["Polymer architecture", "Crystallization and phase behavior", "Rheology and mechanics", "Polymer degradation"],
  SDL5: ["Composition design", "Stability and compatibility", "Particle attributes", "Batch consistency"],
  SDL6: ["Organoid morphology", "Time-resolved imaging", "Biochemical and functional characterization", "Mechanobiology and replication"],
  SDL7: ["Reaction kinetics", "Heat and mass transfer", "Mixing and process telemetry", "Scale-up feasibility"],
};

export function LabsView({ labs, agents, experiments }: { labs: Laboratory[]; agents: Agent[]; experiments: Experiment[] }) {
  const [selected, setSelected] = useState("SDL1");
  const selectedLab = labs.find((lab) => lab.code === selected) || labs[0];
  const LabIcon = icons[Math.max(0, labs.findIndex((lab) => lab.code === selected))] || Atom;
  const labAgents = useMemo(() => agents.filter((agent) => agent.laboratory_code === selected), [agents, selected]);
  const labExperiments = experiments.filter((experiment) => experiment.laboratory_code === selected);
  return (
    <div className="view-stack">
      <div className="network-summary-strip">
        <div><span className="summary-strip-label">NETWORK TOPOLOGY</span><strong>8 <small>laboratories</small></strong></div>
        <div><span className="summary-strip-label">SHARED INTELLIGENCE</span><strong>100 <small>agent profiles</small></strong></div>
        <div><span className="summary-strip-label">COMMON FOUNDATION</span><strong>6 <small>scientific data layers</small></strong></div>
        <div><span className="summary-strip-label">EXECUTION POLICY</span><strong>Human <small>approval required</small></strong></div>
      </div>

      <div className="labs-layout">
        <Panel title="Laboratory directory" subtitle="Select a node to inspect its research scope" className="labs-directory-panel">
          <div className="lab-directory-list">
            {labs.map((lab, index) => {
              const Icon = icons[index] || Atom;
              return <button className={`lab-directory-item ${selected === lab.code ? "selected" : ""}`} key={lab.code} onClick={() => setSelected(lab.code)}>
                <div className={`lab-directory-icon lab-icon-${index}`}><Icon size={18} /></div>
                <div className="lab-directory-copy"><strong>{lab.code} <span>{lab.name}</span></strong><small>{lab.focus}</small></div>
                <StatusPill status={lab.status} />
              </button>;
            })}
          </div>
          <div className="directory-footer"><span><i className="legend-green" />Online</span><span><i className="legend-gray" />Standby</span><small>Standalone lab deployments can be connected later.</small></div>
        </Panel>

        <div className="lab-detail-column">
          <Panel title="Node overview" subtitle={`${selectedLab.code} · domain-specific research environment`}>
            <div className="lab-detail-hero">
              <div className={`lab-detail-emblem lab-icon-${labs.findIndex((lab) => lab.code === selected)}`}><LabIcon size={30} /></div>
              <div className="lab-detail-name"><div className="lab-detail-code">{selectedLab.code} / NEXUS NODE</div><h2>{selectedLab.name}</h2><p>{selectedLab.description}</p></div>
              <StatusPill status={selectedLab.status} />
            </div>
            <div className="lab-detail-stats">
              <div><span>AGENT PROFILES</span><strong>{labAgents.length || (selected === "SDL1" ? 10 : "—")}</strong></div>
              <div><span>EXPERIMENTS</span><strong>{labExperiments.length}</strong></div>
              <div><span>INSTRUMENT TWINS</span><strong>{selectedLab.instrument_count ?? 0}</strong></div>
              <div><span>NODE PRIORITY</span><strong className="priority-text">{selectedLab.priority}</strong></div>
            </div>
          </Panel>
          <div className="lab-detail-lower-grid">
            <Panel title="Research programs" subtitle="Scientific scope for this laboratory">
              <div className="research-program-list">
                {(researchPrograms[selectedLab.code] || []).map((program, index) => <div key={program}><span className="program-number">0{index + 1}</span><span>{program}</span><ArrowUpRight size={14} /></div>)}
              </div>
            </Panel>
            <Panel title="Connected capabilities" subtitle="Shared NEXUS infrastructure">
              <div className="capability-grid">
                {[
                  ["Scientific objectives", "Versioned research intent"], ["Agent orchestration", "Specialist proposal workflows"],
                  ["Scientific data", "Schema and provenance"], ["Governance", "Approval and audit trail"],
                  ["Digital twin", "Simulation boundary"], ["Experiment memory", "Historical results"],
                ].map(([name, detail]) => <div className="capability-item" key={name}><span className="capability-check">✓</span><div><strong>{name}</strong><small>{detail}</small></div></div>)}
              </div>
            </Panel>
          </div>
        </div>
      </div>
      <div className="interoperability-note"><CircuitBoard size={18} /><div><strong>Interoperability without scientific flattening</strong><span>All labs share identity, provenance, audit, and governance contracts. Domain methods, instruments, measurement schemas, and evidence standards remain laboratory-specific.</span></div></div>
    </div>
  );
}
