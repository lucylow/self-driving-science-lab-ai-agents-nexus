"use client";

import { useCallback, useEffect, useState } from "react";
import { BrainCircuit, Database, RefreshCw, Rocket, ShieldCheck, Sparkles } from "lucide-react";
import { api, ApiError } from "@/lib/api";
import type { ScientificModelRecord, TrainingDatasetSnapshot } from "@/types";
import { Panel } from "@/components/Panel";
import { StatusPill } from "@/components/StatusPill";

export function ModelsView() {
  const [models, setModels] = useState<ScientificModelRecord[]>([]);
  const [datasets, setDatasets] = useState<TrainingDatasetSnapshot[]>([]);
  const [domain, setDomain] = useState("inorganic_materials");
  const [target, setTarget] = useState("ionic_conductivity");
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");

  const refresh = useCallback(async () => {
    setBusy(true);
    try {
      const [nextModels, nextDatasets] = await Promise.all([api.scientificModels(), api.trainingDatasets()]);
      setModels(nextModels);
      setDatasets(nextDatasets);
      setError("");
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not load the model registry.");
    } finally {
      setBusy(false);
    }
  }, []);

  useEffect(() => { void refresh(); }, [refresh]);

  const createSnapshot = async () => {
    setBusy(true);
    setNotice("");
    setError("");
    try {
      const snapshot = await api.buildTrainingDataset({
        dataset_key: `nexus-${domain}-${target}-${Date.now()}`,
        domain,
        target_property: target,
        allowed_origins: ["measured"],
        include_synthetic: false,
        minimum_quality: "accepted",
        test_fraction: 0.2,
        random_seed: 17,
      });
      setDatasets((current) => [snapshot, ...current]);
      setNotice(`Dataset snapshot created with ${snapshot.row_count} eligible measurements.`);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Dataset snapshot could not be created.");
    } finally {
      setBusy(false);
    }
  };

  const train = async (snapshot: TrainingDatasetSnapshot) => {
    setBusy(true);
    setError("");
    setNotice("");
    try {
      const response = await api.trainScientificModel({
        dataset_id: snapshot.id,
        model_key: `nexus-${snapshot.domain}-${snapshot.target_property}-${Date.now()}`,
        model_name: `${snapshot.domain} ${snapshot.target_property} ridge baseline`,
        version: "0.1.0",
        alpha: 1.0,
        minimum_training_rows: 8,
      });
      setNotice(`Research-only model registered. Holdout RMSE: ${Number(response.evaluation.metrics?.rmse ?? 0).toPrecision(4)}.`);
      await refresh();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Model training failed validation.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="research-stack">
      <div className="research-stat-grid">
        <div className="research-stat"><span>REGISTERED MODELS</span><strong>{models.length}</strong><small>Versioned model records</small></div>
        <div className="research-stat"><span>DATASET SNAPSHOTS</span><strong>{datasets.length}</strong><small>Immutable training views</small></div>
        <div className="research-stat"><span>PRODUCTION MODELS</span><strong>0</strong><small>Promotion is disabled here</small></div>
        <div className="research-stat"><span>TRAINING POLICY</span><strong>REVIEW</strong><small>Scientist sign-off required</small></div>
      </div>

      <Panel title="Scientific model registry" subtitle="Model cards, applicability declarations, limitations and holdout evaluations." action={<button className="button button-secondary" onClick={() => void refresh()} disabled={busy}><RefreshCw size={13} />Refresh</button>}>
        {models.length === 0 ? <div className="research-empty"><BrainCircuit size={24} /><strong>No trained models registered yet</strong><span>Register eligible measured data and create an immutable training snapshot to begin.</span></div> : (
          <div className="research-table-wrap"><table className="research-table"><thead><tr><th>MODEL</th><th>DOMAIN</th><th>TARGETS</th><th>STATUS</th><th>ORIGIN</th></tr></thead><tbody>
            {models.map((model) => <tr key={model.id}><td><strong>{model.name}</strong><small>{model.model_key} · v{model.version}</small></td><td>{model.supported_domains.join(", ")}</td><td>{model.prediction_targets.join(", ")}</td><td><StatusPill status={model.status} /></td><td>{model.synthetic ? "Synthetic" : "Non-synthetic"}</td></tr>)}
          </tbody></table></div>
        )}
      </Panel>

      <div className="research-two-column">
        <Panel title="Build a training snapshot" subtitle="Only accepted, non-synthetic measured records are selected by default.">
          <div className="research-form-grid">
            <label>Scientific domain<select value={domain} onChange={(event) => setDomain(event.target.value)}><option value="inorganic_materials">SDL1 · Inorganic materials</option><option value="organic_chemistry">SDL2 · Organic chemistry</option><option value="medicinal_chemistry">SDL3 · Medicinal chemistry</option><option value="polymers">SDL4 · Polymers</option><option value="formulations">SDL5 · Formulations</option><option value="biological_systems">SDL6 · Biological systems</option><option value="process_engineering">SDL7 · Process engineering</option></select></label>
            <label>Target property<input value={target} onChange={(event) => setTarget(event.target.value)} /></label>
          </div>
          <div className="research-inline-notice"><ShieldCheck size={15} /><span>Group-aware sample holdout prevents the same sample identity from crossing train/test partitions.</span></div>
          <button className="button button-primary" onClick={() => void createSnapshot()} disabled={busy}><Database size={14} />Build immutable snapshot</button>
        </Panel>
        <Panel title="Training governance" subtitle="The included learner is a transparent baseline, not a universal scientific model.">
          <div className="research-check-list">
            <div><ShieldCheck size={15} /><span>Predictions stay distinct from measurements.</span></div>
            <div><ShieldCheck size={15} /><span>Group-aware holdout evaluation is recorded.</span></div>
            <div><ShieldCheck size={15} /><span>Uncertainty is labelled uncalibrated until separately reviewed.</span></div>
            <div><ShieldCheck size={15} /><span>Model promotion never occurs automatically.</span></div>
          </div>
          <div className="research-soft-note"><Sparkles size={14} /> Train only on reviewed, domain-matched datasets with traceable units and provenance.</div>
        </Panel>
      </div>

      <Panel title="Immutable training snapshots" subtitle="A snapshot locks its selected record identifiers, feature schema, split manifest and content hash.">
        {datasets.length === 0 ? <div className="research-empty"><Database size={22} /><strong>No training snapshots</strong><span>The dataset builder will explain which eligibility conditions are not met.</span></div> : (
          <div className="research-table-wrap"><table className="research-table"><thead><tr><th>DATASET</th><th>DOMAIN / TARGET</th><th>ROWS</th><th>STATUS</th><th>TRAIN</th></tr></thead><tbody>
            {datasets.map((snapshot) => <tr key={snapshot.id}><td><strong>{snapshot.dataset_key}</strong><small>{snapshot.id.slice(0, 14)} · v{snapshot.version}</small></td><td>{snapshot.domain}<small>{snapshot.target_property}</small></td><td>{snapshot.row_count}</td><td><StatusPill status={snapshot.status} /></td><td><button className="button button-secondary button-small" onClick={() => void train(snapshot)} disabled={busy || snapshot.row_count < 8}><Rocket size={12} />Train baseline</button></td></tr>)}
          </tbody></table></div>
        )}
      </Panel>
      {notice && <div className="research-feedback success">{notice}</div>}
      {error && <div className="research-feedback error">{error}</div>}
    </div>
  );
}
