"use client";

import type { ReactNode } from "react";
import {
  Activity, ArrowRight, Atom, BrainCircuit, CheckCircle2, Clock3,
  FlaskConical, Layers3, ShieldAlert, Sparkles, TrendingUp, Workflow,
} from "lucide-react";
import {
  Area, AreaChart, Bar, BarChart, CartesianGrid, ResponsiveContainer,
  Tooltip, XAxis, YAxis,
} from "recharts";
import { MetricCard } from "@/components/MetricCard";
import { Panel } from "@/components/Panel";
import { StatusPill } from "@/components/StatusPill";
import type { Agent, EventRecord, Experiment, Laboratory, NavKey, Overview } from "@/types";

const throughput = [
  { day: "Mon", proposals: 9, completed: 5 }, { day: "Tue", proposals: 13, completed: 8 },
  { day: "Wed", proposals: 11, completed: 7 }, { day: "Thu", proposals: 17, completed: 11 },
  { day: "Fri", proposals: 14, completed: 10 }, { day: "Sat", proposals: 19, completed: 13 },
  { day: "Sun", proposals: 16, completed: 12 },
];
const qualityTrend = [
  { day: "Mon", completeness: 82, provenance: 76 }, { day: "Tue", completeness: 84, provenance: 81 },
  { day: "Wed", completeness: 88, provenance: 83 }, { day: "Thu", completeness: 86, provenance: 87 },
  { day: "Fri", completeness: 91, provenance: 89 }, { day: "Sat", completeness: 93, provenance: 92 },
  { day: "Sun", completeness: 94, provenance: 94 },
];

function readableEvent(value: string) {
  return value.toLowerCase().replaceAll("_", " ").replace(/\b\w/g, (letter) => letter.toUpperCase());
}

export function OverviewView({ overview, labs, experiments, agents, events, onNavigate }: {
  overview: Overview; labs: Laboratory[]; experiments: Experiment[]; agents: Agent[]; events: EventRecord[]; onNavigate: (key: NavKey) => void;
}) {
  const activeLabs = labs.filter((lab) => lab.status === "online").length;
  const pending = overview.counts.pending_approvals;
  const statusEntries = Object.entries(overview.experiment_status || {});
  const totalStatus = statusEntries.reduce((sum, item) => sum + item[1], 0) || 1;
  const latestExperiments = [...experiments].slice(0, 4);
  const activeAgents = agents.filter((agent) => agent.status === "running");

  return (
    <div className="view-stack">
      <div className="metric-grid metric-grid-six">
        <MetricCard label="Laboratory nodes" value={`${activeLabs}/8`} detail="2 active · 6 on standby" icon={<Layers3 size={18} />} tone="blue" />
        <MetricCard label="Specialist profiles" value={overview.counts.agents} detail="Across 10 departments" icon={<BrainCircuit size={18} />} tone="violet" />
        <MetricCard label="Experiment records" value={overview.counts.experiments} detail="Lifecycle tracked" icon={<FlaskConical size={18} />} tone="green" />
        <MetricCard label="Discovery candidates" value={overview.counts.candidates} detail="SDL1 demo dataset" icon={<Atom size={18} />} tone="amber" />
        <MetricCard label="Pending approvals" value={pending} detail="Scientist action required" icon={<ShieldAlert size={18} />} tone="amber" />
        <MetricCard label="Data measurements" value={overview.counts.measurements} detail="Synthetic twin outputs" icon={<Activity size={18} />} tone="blue" />
      </div>

      <div className="overview-grid-main">
        <Panel title="Research activity" subtitle="Demo pipeline throughput · last 7 days" action={<span className="panel-live"><span /> SIMULATED SERIES</span>}>
          <div className="chart-wrap chart-large">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={throughput} margin={{ top: 8, right: 8, left: -22, bottom: 0 }}>
                <defs>
                  <linearGradient id="proposalFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#6987ff" stopOpacity={0.24} /><stop offset="95%" stopColor="#6987ff" stopOpacity={0.01} /></linearGradient>
                  <linearGradient id="completeFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#32c59a" stopOpacity={0.18} /><stop offset="95%" stopColor="#32c59a" stopOpacity={0.01} /></linearGradient>
                </defs>
                <CartesianGrid stroke="#edf0f6" vertical={false} />
                <XAxis dataKey="day" tickLine={false} axisLine={false} tick={{ fill: "#929bad", fontSize: 11 }} dy={10} />
                <YAxis tickLine={false} axisLine={false} tick={{ fill: "#929bad", fontSize: 11 }} />
                <Tooltip contentStyle={{ border: "1px solid #e8ebf2", borderRadius: 12, boxShadow: "0 10px 30px #1d2d5015" }} />
                <Area type="monotone" dataKey="proposals" name="Proposals" stroke="#7188f8" strokeWidth={2} fill="url(#proposalFill)" />
                <Area type="monotone" dataKey="completed" name="Completed" stroke="#32bd91" strokeWidth={2} fill="url(#completeFill)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <div className="chart-legend"><span><i className="legend-blue" />Candidate proposals</span><span><i className="legend-green" />Completed workflows</span><small>Illustrative data</small></div>
        </Panel>

        <Panel title="Workflow distribution" subtitle="Current experiment lifecycle" action={<button className="text-link" onClick={() => onNavigate("experiments")}>View all <ArrowRight size={13} /></button>}>
          <div className="status-distribution">
            <div className="donut-wrap">
              <svg viewBox="0 0 148 148" className="donut-chart" aria-label="Experiment workflow distribution">
                <circle cx="74" cy="74" r="55" fill="none" stroke="#eef1f6" strokeWidth="15" />
                {statusEntries.reduce((acc, [status, value], index) => {
                  const colors = ["#6e83f7", "#28b98c", "#e5ad53", "#8994a8", "#e16d7d", "#8e76d7"];
                  const circumference = 345.6;
                  const previous = statusEntries.slice(0, index).reduce((sum, row) => sum + row[1], 0);
                  const dash = (value / totalStatus) * circumference;
                  const offset = circumference - (previous / totalStatus) * circumference;
                  acc.push(<circle key={status} cx="74" cy="74" r="55" fill="none" stroke={colors[index % colors.length]} strokeWidth="15" strokeDasharray={`${dash} ${circumference - dash}`} strokeDashoffset={offset} transform="rotate(-90 74 74)" strokeLinecap="round" />);
                  return acc;
                }, [] as ReactNode[])}
                <text x="74" y="70" textAnchor="middle" className="donut-total">{overview.counts.experiments}</text>
                <text x="74" y="87" textAnchor="middle" className="donut-caption">records</text>
              </svg>
            </div>
            <div className="distribution-legend">
              {statusEntries.map(([status, count], index) => <div className="distribution-row" key={status}><span className={`distribution-dot dot-${index}`} /><span>{readableEvent(status)}</span><strong>{count}</strong></div>)}
            </div>
          </div>
          <div className="approval-callout"><div className="approval-callout-icon"><Clock3 size={16} /></div><div><strong>{pending} item needs review</strong><span>Proposals remain gated until reviewed.</span></div><button onClick={() => onNavigate("governance")}><ArrowRight size={15} /></button></div>
        </Panel>
      </div>

      <div className="overview-grid-bottom">
        <Panel title="Laboratory network" subtitle="SDL0–SDL7 · domain-specific research nodes" action={<button className="text-link" onClick={() => onNavigate("labs")}>Network view <ArrowRight size={13} /></button>}>
          <div className="lab-mini-grid">
            {labs.map((lab) => <button className="lab-mini-card" key={lab.code} onClick={() => onNavigate("labs")}>
              <div className="lab-mini-top"><span className={`lab-code-badge lab-${lab.code.toLowerCase()}`}>{lab.code}</span><StatusPill status={lab.status} /></div>
              <strong>{lab.name}</strong><small>{lab.focus}</small>
            </button>)}
          </div>
        </Panel>
        <Panel title="Agent activity" subtitle="Recent specialist activity" action={<button className="text-link" onClick={() => onNavigate("agents")}>Agent room <ArrowRight size={13} /></button>}>
          <div className="agent-activity-list">
            {(activeAgents.length ? activeAgents : agents.slice(0, 4)).slice(0, 4).map((agent, index) => <div className="agent-activity-row" key={agent.id}>
              <div className={`agent-avatar agent-avatar-${index}`}><BrainCircuit size={15} /></div>
              <div className="agent-activity-copy"><strong>{agent.name}</strong><span>{agent.department} · {agent.laboratory_code}</span></div>
              <StatusPill status={agent.status} />
            </div>)}
          </div>
          <div className="agent-room-footer"><span><span className="green-pulse" />{overview.active_agents} agent currently active</span><span>100 registered profiles</span></div>
        </Panel>
      </div>

      <div className="overview-grid-bottom">
        <Panel title="Data quality trajectory" subtitle="Completeness and provenance coverage · demo series" action={<button className="text-link" onClick={() => onNavigate("data")}>Data fabric <ArrowRight size={13} /></button>}>
          <div className="chart-wrap chart-small">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={qualityTrend} margin={{ top: 10, right: 5, left: -24, bottom: 0 }} barGap={5}>
                <CartesianGrid stroke="#edf0f6" vertical={false} />
                <XAxis dataKey="day" tickLine={false} axisLine={false} tick={{ fill: "#929bad", fontSize: 10 }} />
                <YAxis domain={[0, 100]} tickLine={false} axisLine={false} tick={{ fill: "#929bad", fontSize: 10 }} />
                <Tooltip contentStyle={{ border: "1px solid #e8ebf2", borderRadius: 10 }} />
                <Bar dataKey="completeness" name="Completeness" fill="#6e83f7" radius={[4, 4, 0, 0]} />
                <Bar dataKey="provenance" name="Provenance" fill="#32bd91" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Panel>
        <Panel title="Recent system events" subtitle="Append-only application activity" action={<button className="text-link" onClick={() => onNavigate("data")}>Audit trail <ArrowRight size={13} /></button>}>
          <div className="event-list">
            {events.slice(0, 4).map((event) => <div className="event-row" key={event.id}>
              <div className="event-marker"><Activity size={13} /></div>
              <div className="event-copy"><strong>{readableEvent(event.event_type)}</strong><span>{event.subject_type} · {event.subject_id}</span></div>
              <time>{new Date(event.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</time>
            </div>)}
          </div>
        </Panel>
      </div>

      <div className="bottom-principle"><Sparkles size={15} /><span>DISCOVER</span><i /> <span>DESIGN</span><i /> <span>EXECUTE</span><i /> <span>LEARN</span><p>Every conclusion stays connected to the evidence that supports it.</p></div>
    </div>
  );
}
