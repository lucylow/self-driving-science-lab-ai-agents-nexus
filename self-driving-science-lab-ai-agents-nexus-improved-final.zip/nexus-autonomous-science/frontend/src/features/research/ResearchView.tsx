"use client";

import { useCallback, useEffect, useState } from "react";
import { Activity, ChevronLeft, ChevronRight, GitBranch, Play, RefreshCw, Scale, Search, ShieldCheck } from "lucide-react";
import { api, ApiError, type SyntheticProjectAnalysis, type SyntheticProjectPareto, type SyntheticRecord, type SyntheticResearchSummary } from "@/lib/api";
import type { ResearchClaim, WorkflowRun } from "@/types";
import { Panel } from "@/components/Panel";
import { StatusPill } from "@/components/StatusPill";

export function ResearchView() {
  const [runs, setRuns] = useState<WorkflowRun[]>([]);
  const [claims, setClaims] = useState<ResearchClaim[]>([]);
  const [objectiveId, setObjectiveId] = useState("OBJ-0001");
  const [batchSize, setBatchSize] = useState(6);
  const [factorA, setFactorA] = useState("0, 1");
  const [factorB, setFactorB] = useState("10, 20");
  const [design, setDesign] = useState<Record<string, unknown> | null>(null);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");
  const [syntheticSummary, setSyntheticSummary] = useState<SyntheticResearchSummary | null>(null);
  const [syntheticPrograms, setSyntheticPrograms] = useState<SyntheticRecord[]>([]);
  const [syntheticProjects, setSyntheticProjects] = useState<SyntheticRecord[]>([]);
  const [selectedProject, setSelectedProject] = useState<SyntheticRecord | null>(null);
  const [projectRecords, setProjectRecords] = useState<Record<string, SyntheticRecord[]>>({});
  const [projectAnalysis, setProjectAnalysis] = useState<SyntheticProjectAnalysis | null>(null);
  const [projectPareto, setProjectPareto] = useState<SyntheticProjectPareto | null>(null);
  const [paretoCostLimit, setParetoCostLimit] = useState("none");
  const [paretoError, setParetoError] = useState("");
  const [projectDetailLoading, setProjectDetailLoading] = useState(false);
  const [syntheticQuery, setSyntheticQuery] = useState("");
  const [syntheticProgramId, setSyntheticProgramId] = useState("");
  const [syntheticOffset, setSyntheticOffset] = useState(0);
  const [syntheticTotal, setSyntheticTotal] = useState(0);
  const [syntheticError, setSyntheticError] = useState("");
  const [syntheticLoading, setSyntheticLoading] = useState(false);

  const refresh = useCallback(async () => {
    try {
      const [nextRuns, nextClaims] = await Promise.all([api.workflowRuns(), api.researchClaims()]);
      setRuns(nextRuns); setClaims(nextClaims); setError("");
    } catch (err) { setError(err instanceof ApiError ? err.message : "Could not load research intelligence records."); }
  }, []);
  useEffect(() => { void refresh(); }, [refresh]);
  useEffect(() => {
    let current = true;
    void Promise.all([api.syntheticResearchSummary(), api.syntheticResearchRecords("programs", { limit: 20 })])
      .then(([summary, programs]) => { if (current) { setSyntheticSummary(summary); setSyntheticPrograms(programs.items); } })
      .catch((err) => { if (current) setSyntheticError(err instanceof ApiError ? err.message : "Synthetic research data is unavailable."); });
    return () => { current = false; };
  }, []);
  useEffect(() => {
    let current = true;
    setSyntheticLoading(true);
    void api.syntheticResearchRecords("projects", { offset: syntheticOffset, limit: 10, q: syntheticQuery, program_id: syntheticProgramId || undefined, sort_by: "name" })
      .then((page) => { if (current) { setSyntheticProjects(page.items); setSyntheticTotal(page.total); setSyntheticError(""); } })
      .catch((err) => { if (current) setSyntheticError(err instanceof ApiError ? err.message : "Could not load synthetic projects."); })
      .finally(() => { if (current) setSyntheticLoading(false); });
    return () => { current = false; };
  }, [syntheticOffset, syntheticProgramId, syntheticQuery]);
  useEffect(() => {
    if (!selectedProject) { setProjectRecords({}); setProjectAnalysis(null); return; }
    let current = true;
    setProjectDetailLoading(true);
    const categories = ["hypotheses", "experiments", "executions", "observations", "findings"];
    void Promise.all([
      Promise.all(categories.map((category) => api.syntheticResearchRecords(category, {
        project_id: selectedProject.id, limit: 100,
        sort_by: category === "experiments" ? "acquisition_score" : category === "hypotheses" ? "posterior_probability" : "id",
        descending: category === "experiments" || category === "hypotheses",
      }))),
      api.syntheticResearchProjectAnalysis(selectedProject.id),
    ]).then(([pages, analysis]) => {
      if (current) {
        setProjectRecords(Object.fromEntries(categories.map((category, index) => [category, pages[index].items])));
        setProjectAnalysis(analysis);
      }
    }).catch((err) => { if (current) setSyntheticError(err instanceof ApiError ? err.message : "Could not load project evidence."); })
      .finally(() => { if (current) setProjectDetailLoading(false); });
    return () => { current = false; };
  }, [selectedProject]);
  useEffect(() => {
    if (!selectedProject) { setProjectPareto(null); return; }
    let current = true;
    setProjectPareto(null);
    setParetoError("");
    const limit = paretoCostLimit === "none" ? undefined : Number(paretoCostLimit);
    void api.syntheticProjectPareto(selectedProject.id, limit)
      .then((result) => { if (current) { setProjectPareto(result); setParetoError(""); } })
      .catch((err) => { if (current) setParetoError(err instanceof ApiError ? err.message : "Could not calculate the cost-constrained Pareto frontier."); });
    return () => { current = false; };
  }, [selectedProject, paretoCostLimit]);

  const launchWorkflow = async () => {
    setBusy(true); setNotice(""); setError("");
    try {
      const run = await api.startWorkflow({
        workflow_key: "sdl1_candidate_review", laboratory_code: "SDL1",
        objective_id: objectiveId, subject_id: "MAT-00128",
        context: { request: "Review seeded battery-material candidate", requested_by: "Workspace scientist" },
        synthetic: true,
      });
      setNotice(`Workflow ${run.id.slice(0, 8)} completed its analytical nodes and is awaiting scientist review.`);
      await refresh();
    } catch (err) { setError(err instanceof ApiError ? err.message : "Could not start the research workflow."); }
    finally { setBusy(false); }
  };

  const previewDesign = async () => {
    const parse = (text: string) => text.split(",").map((part) => Number(part.trim())).filter((value) => Number.isFinite(value));
    const levelsA = parse(factorA); const levelsB = parse(factorB);
    if (levelsA.length < 2 || levelsB.length < 2) { setError("Each factor needs at least two comma-separated numeric levels."); return; }
    setBusy(true); setError(""); setDesign(null);
    try {
      const result = await api.previewDesign({
        factors: [{ name: "factor_a", levels: levelsA }, { name: "factor_b", levels: levelsB }],
        maximum_runs: 128, center_points: 1, constraints: [],
      });
      setDesign(result.design as Record<string, unknown>);
      setNotice("Computational design matrix generated. It is not a laboratory protocol or execution authorization.");
    } catch (err) { setError(err instanceof ApiError ? err.message : "Design preview failed."); }
    finally { setBusy(false); }
  };

  const latest = runs.slice(0, 5);
  return (
    <div className="research-stack">
      <div className="research-stat-grid">
        <div className="research-stat"><span>WORKFLOW RUNS</span><strong>{runs.length}</strong><small>Persisted supervisor runs</small></div>
        <div className="research-stat"><span>AWAITING REVIEW</span><strong>{runs.filter((run) => run.status === "awaiting_scientist_review").length}</strong><small>Human decision required</small></div>
        <div className="research-stat"><span>SCIENTIFIC CLAIMS</span><strong>{claims.length}</strong><small>Evidence-linked records</small></div>
        <div className="research-stat"><span>AUTO EXECUTION</span><strong>OFF</strong><small>Analysis only</small></div>
      </div>
      <Panel title="Synthetic research universe" subtitle="A deterministic, searchable demonstration dataset. Fictional records only; not Discovery Loop data or scientific measurements.">
        <div className="synthetic-data-banner">{syntheticSummary?.notice || "Synthetic demonstration records are clearly labeled and are not real experimental results."}</div>
        <div className="synthetic-count-strip">
          {["projects", "hypotheses", "experiments", "executions", "observations", "evaluations", "findings"].map((key) => <div key={key}><small>{key.replace(/_/g, " ")}</small><strong>{(syntheticSummary?.record_counts[key] ?? 0).toLocaleString()}</strong></div>)}
        </div>
        <div className="synthetic-controls">
          <label className="synthetic-search"><Search size={14} /><input aria-label="Search synthetic projects" placeholder="Search projects" value={syntheticQuery} onChange={(event) => { setSyntheticQuery(event.target.value); setSyntheticOffset(0); }} /></label>
          <select aria-label="Filter by synthetic program" value={syntheticProgramId} onChange={(event) => { setSyntheticProgramId(event.target.value); setSyntheticOffset(0); }}><option value="">All programs</option>{syntheticPrograms.map((program) => <option key={program.id} value={program.id}>{String(program.name || program.id)}</option>)}</select>
        </div>
        <div className="research-table-wrap"><table className="research-table"><thead><tr><th>PROJECT</th><th>PROGRAM</th><th>DOMAIN</th><th>STATUS</th></tr></thead><tbody>
          {syntheticProjects.map((project) => <tr key={project.id}><td><button className="synthetic-project-link" onClick={() => setSelectedProject(project)}>{String(project.name || project.id)}</button><small>{String(project.objective || "Synthetic research objective")}</small></td><td>{String(project.program_id || "—")}</td><td>{String(project.domain || "—")}</td><td><StatusPill status={String(project.status || "demo")} /></td></tr>)}
          {syntheticProjects.length === 0 && <tr><td colSpan={4}>{syntheticLoading ? "Loading synthetic records…" : "No matching projects."}</td></tr>}
        </tbody></table></div>
        <div className="synthetic-pagination"><span>{syntheticLoading ? "Loading…" : `${syntheticTotal.toLocaleString()} matching projects`}{syntheticError ? ` · ${syntheticError}` : ""}</span><div><button className="button button-secondary" aria-label="Previous project page" disabled={syntheticOffset === 0 || syntheticLoading} onClick={() => setSyntheticOffset(Math.max(0, syntheticOffset - 10))}><ChevronLeft size={13} /></button><button className="button button-secondary" aria-label="Next project page" disabled={syntheticOffset + 10 >= syntheticTotal || syntheticLoading} onClick={() => setSyntheticOffset(syntheticOffset + 10)}><ChevronRight size={13} /></button></div></div>
      </Panel>
      {selectedProject && <Panel title={`Project detail · ${String(selectedProject.name || selectedProject.id)}`} subtitle={`${String(selectedProject.domain || "synthetic domain")} · ${String(selectedProject.program_id || "unassigned program")} · linked records from the generated research universe`} action={<button className="button button-secondary" onClick={() => setSelectedProject(null)}>Close</button>}>
        <div className="synthetic-detail-callout"><strong>Recommended next experiment:</strong> {String(selectedProject.recommended_next_experiment_id || "No linked proposal")} <span>{String(selectedProject.recommendation_rationale || "Recommendation unavailable")}</span></div>
        {projectDetailLoading ? <div className="research-empty">Loading linked project records and analysis…</div> : <>
        {projectAnalysis && <div className="synthetic-analysis-summary"><div><small>OBSERVATIONS (N)</small><strong>{projectAnalysis.analysis.n}</strong></div><div><small>MEAN QUALITY SCORE</small><strong>{projectAnalysis.analysis.mean?.toFixed(3) ?? "—"}</strong></div><div><small>MEDIAN</small><strong>{projectAnalysis.analysis.median?.toFixed(3) ?? "—"}</strong></div><div><small>SAMPLE SD</small><strong>{projectAnalysis.analysis.sample_standard_deviation?.toFixed(3) ?? "—"}</strong></div><div><small>95% MEAN CI</small><strong>{projectAnalysis.analysis.mean_confidence_interval_95?.map((value) => value.toFixed(3)).join(" – ") ?? "Not estimable"}</strong></div><div><small>DATA QUALITY</small><strong>{projectAnalysis.analysis.quality_status.toUpperCase()}</strong></div><p>{projectAnalysis.analysis.outlier_ids.length} potential outlier(s) flagged but retained · {projectAnalysis.analysis.missing_count} missing values · {projectAnalysis.analysis.missing_uncertainty_count} missing uncertainty · {projectAnalysis.analysis.high_uncertainty_ids.length} high uncertainty · {projectAnalysis.analysis.invalid_count} invalid · {projectAnalysis.analysis.duplicate_count} duplicates. Synthetic descriptive analysis only; not causal evidence.</p></div>}
        <section className="synthetic-pareto"><div className="synthetic-pareto-head"><div><strong>Quality vs. compute frontier</strong><small>Maximize mean quality; minimize consumed compute. Replicates stay visible.</small></div><label>Hard compute cap<select aria-label="Maximum total compute hours" value={paretoCostLimit} onChange={(event) => setParetoCostLimit(event.target.value)}><option value="none">No cap</option><option value="8">8 hours</option><option value="16">16 hours</option><option value="24">24 hours</option><option value="40">40 hours</option></select></label></div>
          {paretoError && <small className="synthetic-pareto-error">{paretoError}</small>}
          {projectPareto && <><div className="synthetic-pareto-list">{projectPareto.candidates.filter((candidate) => candidate.on_pareto_front).slice(0, 5).map((candidate) => <div className="synthetic-pareto-row" key={candidate.experiment_id}><strong>{candidate.name}</strong><span>{candidate.mean_quality?.toFixed(3) ?? "—"} quality · {candidate.compute_hours?.toFixed(2) ?? "—"} h · n={candidate.quality_run_count}</span></div>)}{!projectPareto.frontier_experiment_ids.length && <small>No scored candidates satisfy this limit.</small>}</div><small className="synthetic-pareto-foot">{projectPareto.frontier_experiment_ids.length} frontier candidates · {projectPareto.candidates.filter((candidate) => candidate.status === "infeasible").length} infeasible · technical-failure and inconclusive runs do not score quality, but their compute is charged. Synthetic heuristic, not a validated optimum.</small></>}
        </section>
        <div className="synthetic-detail-grid">
          {([ ["hypotheses", "Hypotheses"], ["experiments", "Experiment proposals"], ["executions", "Recent executions"], ["observations", "Observations"], ["findings", "Findings"] ] as const).map(([key, label]) => <section className="synthetic-detail-section" key={key}><h4>{label} <span>{projectRecords[key]?.length || 0}</span></h4>{(projectRecords[key] || []).slice(0, 6).map((record) => <div className="synthetic-detail-row" key={record.id}><strong>{String(record.name || record.statement || record.claim || record.metric || record.id)}</strong><small>{key === "hypotheses" ? `Posterior ${Number(record.posterior_probability || 0).toFixed(3)} · ${record.evidence_count} evidence records` : key === "experiments" ? `Acquisition score ${Number(record.acquisition_score || 0).toFixed(4)} · ${record.id}` : key === "executions" ? `${record.status} · score ${Number(record.quality_score || 0).toFixed(3)}` : key === "observations" ? `${record.value} ${String(record.unit || "")} · ${record.result_class}` : `Evidence: ${(record.evidence_refs as string[] | undefined)?.join(", ") || "—"}`}</small></div>)}{!(projectRecords[key] || []).length && <small>No linked records in this category.</small>}</section>)}
        </div></>}
      </Panel>}
      <div className="research-two-column">
        <Panel title="SDL1 candidate review workflow" subtitle="A traceable multi-agent sequence using registered specialist capabilities.">
          <div className="research-flow-list">
            {["Objective compiler", "Composition validation", "Candidate ranking", "Evidence review", "Governance summary"].map((label, index) => <div key={label}><span className="flow-step-number">0{index + 1}</span><span>{label}</span><i>{index === 4 ? "HUMAN REVIEW" : "ANALYSIS"}</i></div>)}
          </div>
          <label className="research-full-label">Research objective ID<input value={objectiveId} onChange={(event) => setObjectiveId(event.target.value)} /></label>
          <div className="research-inline-notice"><ShieldCheck size={15} /><span>The supervisor can propose and inspect. It cannot approve experiments or authorize hardware.</span></div>
          <button className="button button-primary" onClick={() => void launchWorkflow()} disabled={busy || !objectiveId.trim()}><Play size={13} />Run analytical workflow</button>
        </Panel>
        <Panel title="Computational experiment design" subtitle="Generate a bounded full-factorial parameter matrix for scientist review.">
          <div className="research-form-grid">
            <label>Factor A levels<input value={factorA} onChange={(event) => setFactorA(event.target.value)} /></label>
            <label>Factor B levels<input value={factorB} onChange={(event) => setFactorB(event.target.value)} /></label>
            <label>Target design batch<select value={batchSize} onChange={(event) => setBatchSize(Number(event.target.value))}><option value={4}>4 candidate runs</option><option value={6}>6 candidate runs</option><option value={8}>8 candidate runs</option><option value={12}>12 candidate runs</option></select></label>
          </div>
          <button className="button button-secondary" onClick={() => void previewDesign()} disabled={busy}><Scale size={13} />Preview design matrix</button>
          {design && <div className="design-preview"><strong>{String(design.run_count)} design points generated</strong><span>{String(design.design_type)} · {String(design.execution_status)}</span></div>}
        </Panel>
      </div>
      <Panel title="Workflow run history" subtitle="Each run preserves its agent nodes, correlation ID and synthetic status." action={<button className="button button-secondary" onClick={() => void refresh()}><RefreshCw size={13} />Refresh</button>}>
        {latest.length === 0 ? <div className="research-empty"><GitBranch size={22} /><strong>No research workflows launched</strong><span>Run the SDL1 candidate review to create the first workflow history record.</span></div> : (
          <div className="research-run-list">{latest.map((run) => <div className="research-run-row" key={run.id}><div className="research-run-icon"><GitBranch size={15} /></div><div className="research-run-copy"><strong>{run.workflow_key.replace(/_/g, " ")}</strong><small>{run.id.slice(0, 14)} · {run.node_history.length} nodes · {run.laboratory_code}</small></div><StatusPill status={run.status} /><span className="research-run-time">{new Date(run.created_at).toLocaleString()}</span></div>)}</div>
        )}
      </Panel>
      <Panel title="Scientific claims registry" subtitle="Claims stay distinct from publications, predictions and experimental observations.">
        {claims.length === 0 ? <div className="research-empty"><Activity size={22} /><strong>No scientific claims registered</strong><span>Register literature and measurement references before asking a scientist to review a claim.</span></div> : (
          <div className="research-claim-list">{claims.slice(0, 6).map((claim) => <div key={claim.id}><div><strong>{claim.statement}</strong><small>{claim.claim_key} · {claim.laboratory_code} · {claim.support_refs.length} supporting refs / {claim.contradiction_refs.length} contradictory refs</small></div><StatusPill status={claim.status} /></div>)}</div>
        )}
      </Panel>
      {notice && <div className="research-feedback success">{notice}</div>}
      {error && <div className="research-feedback error">{error}</div>}
      <div className="research-footnote">Design outputs are parameter-space proposals. Scientific review, protocol validation, resource checks and local safety controls remain independent prerequisites.</div>
    </div>
  );
}
