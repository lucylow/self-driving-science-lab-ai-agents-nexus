"use client";

import { useCallback, useEffect, useState } from "react";
import { CheckCircle2, FlaskConical, Plus, RefreshCw, ShieldCheck, Tags } from "lucide-react";
import { api, ApiError } from "@/lib/api";
import type { ScientificSample } from "@/types";
import { Panel } from "@/components/Panel";
import { StatusPill } from "@/components/StatusPill";

const LAB_DOMAINS: Record<string, string> = {
  SDL0: "autonomous_systems", SDL1: "inorganic_materials", SDL2: "organic_chemistry",
  SDL3: "medicinal_chemistry", SDL4: "polymers", SDL5: "formulations",
  SDL6: "biological_systems", SDL7: "process_engineering",
};

export function SamplesView() {
  const [samples, setSamples] = useState<ScientificSample[]>([]);
  const [code, setCode] = useState(`SAMPLE-${Date.now().toString().slice(-6)}`);
  const [name, setName] = useState("LLZO composition reference");
  const [lab, setLab] = useState("SDL1");
  const [sampleType, setSampleType] = useState("material");
  const [formula, setFormula] = useState("Li7La3Zr2O12");
  const [evidenceRef, setEvidenceRef] = useState("lab-notebook-entry-001");
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");

  const refresh = useCallback(async () => {
    try { setSamples(await api.samples()); setError(""); }
    catch (err) { setError(err instanceof ApiError ? err.message : "Could not load sample registry."); }
  }, []);
  useEffect(() => { void refresh(); }, [refresh]);

  const create = async () => {
    setBusy(true); setNotice(""); setError("");
    try {
      const composition = formula.trim() ? { formula: formula.trim() } : {};
      const sample = await api.createSample({
        code, name, laboratory_code: lab, domain: LAB_DOMAINS[lab],
        sample_type: sampleType, composition, identity_status: "unverified",
        preparation_metadata: {}, provenance: { registration_note: "Workspace-created registry record" },
        synthetic: true,
      });
      setNotice(`Registered ${sample.code}. Identity remains unverified until evidence is attached.`);
      setCode(`SAMPLE-${Date.now().toString().slice(-6)}`);
      await refresh();
    } catch (err) { setError(err instanceof ApiError ? err.message : "Sample registration failed."); }
    finally { setBusy(false); }
  };

  const verify = async (sample: ScientificSample) => {
    setBusy(true); setNotice(""); setError("");
    try {
      await api.verifySample(sample.id, "Workspace scientist", [evidenceRef]);
      setNotice(`${sample.code} identity marked verified with the supplied evidence reference.`);
      await refresh();
    } catch (err) { setError(err instanceof ApiError ? err.message : "Identity review failed."); }
    finally { setBusy(false); }
  };

  return (
    <div className="research-stack">
      <div className="research-stat-grid">
        <div className="research-stat"><span>REGISTERED SAMPLES</span><strong>{samples.length}</strong><small>Persistent identities</small></div>
        <div className="research-stat"><span>VERIFIED</span><strong>{samples.filter((item) => item.identity_status === "verified").length}</strong><small>Evidence reviewed</small></div>
        <div className="research-stat"><span>UNVERIFIED</span><strong>{samples.filter((item) => item.identity_status === "unverified").length}</strong><small>Not eligible for model data</small></div>
        <div className="research-stat"><span>SYNTHETIC RECORDS</span><strong>{samples.filter((item) => item.synthetic).length}</strong><small>Demo labels preserved</small></div>
      </div>
      <div className="research-two-column">
        <Panel title="Register a scientific sample" subtitle="Registration creates identity only; it does not assert composition, purity or scientific validity.">
          <div className="research-form-grid">
            <label>Sample code<input value={code} onChange={(event) => setCode(event.target.value)} /></label>
            <label>Display name<input value={name} onChange={(event) => setName(event.target.value)} /></label>
            <label>Laboratory<select value={lab} onChange={(event) => setLab(event.target.value)}>{Object.keys(LAB_DOMAINS).map((item) => <option key={item} value={item}>{item}</option>)}</select></label>
            <label>Sample type<select value={sampleType} onChange={(event) => setSampleType(event.target.value)}><option value="material">Material</option><option value="molecule">Molecule</option><option value="polymer">Polymer</option><option value="formulation">Formulation</option><option value="biological_model">Biological model</option><option value="reference">Reference</option><option value="control">Control</option></select></label>
            <label className="span-two">Composition formula / representation<input value={formula} onChange={(event) => setFormula(event.target.value)} placeholder="e.g. Li7La3Zr2O12" /></label>
          </div>
          <button className="button button-primary" onClick={() => void create()} disabled={busy || !code.trim() || !name.trim()}><Plus size={14} />Register sample</button>
        </Panel>
        <Panel title="Identity review" subtitle="A reviewer and evidence reference are required before sample records can enter eligible training snapshots.">
          <label className="research-full-label">Evidence reference<input value={evidenceRef} onChange={(event) => setEvidenceRef(event.target.value)} placeholder="Notebook, custody record, or characterization artifact ID" /></label>
          <div className="research-inline-notice"><ShieldCheck size={15} /><span>Identity verification does not certify material phase, purity, synthesis success or biological provenance.</span></div>
          <p className="research-muted-copy">Select an unverified sample below and apply this reference through the identity-review action.</p>
        </Panel>
      </div>
      <Panel title="Sample identity registry" subtitle="Parent-child sample lineage is preserved as a separate relationship.">
        {samples.length === 0 ? <div className="research-empty"><Tags size={22} /><strong>No samples registered</strong><span>Create the first sample identity record to begin scientific data lineage.</span></div> : (
          <div className="research-table-wrap"><table className="research-table"><thead><tr><th>SAMPLE</th><th>LAB / DOMAIN</th><th>TYPE</th><th>IDENTITY</th><th>ORIGIN</th><th>REVIEW</th></tr></thead><tbody>
            {samples.map((sample) => <tr key={sample.id}><td><strong>{sample.name}</strong><small>{sample.code}</small></td><td>{sample.laboratory_code}<small>{sample.domain}</small></td><td>{sample.sample_type}</td><td><StatusPill status={sample.identity_status} /></td><td>{sample.synthetic ? "Synthetic" : "Non-synthetic"}</td><td>{sample.identity_status === "unverified" ? <button className="button button-secondary button-small" onClick={() => void verify(sample)} disabled={busy || !evidenceRef.trim()}><CheckCircle2 size={12} />Verify identity</button> : <span className="research-muted-copy">Reviewed</span>}</td></tr>)}
          </tbody></table></div>
        )}
      </Panel>
      {notice && <div className="research-feedback success">{notice}</div>}
      {error && <div className="research-feedback error">{error}</div>}
    </div>
  );
}
