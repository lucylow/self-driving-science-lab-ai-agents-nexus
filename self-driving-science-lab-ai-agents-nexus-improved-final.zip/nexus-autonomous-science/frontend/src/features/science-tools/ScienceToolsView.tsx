"use client";

import { useState } from "react";
import { Activity, Atom, Calculator, FlaskConical, Gauge, Microscope, Ruler, Sigma } from "lucide-react";
import { api, ApiError } from "@/lib/api";
import { Panel } from "@/components/Panel";

type CalculatorKey = "conductivity" | "bragg" | "arrhenius" | "dispersity" | "crystallinity" | "massBalance";
type FieldSpec = { key: string; label: string; defaultValue: string; unit: string };
type ToolSpec = { key: CalculatorKey; title: string; subtitle: string; path: string; icon: typeof Calculator; fields: FieldSpec[]; description: string };

const TOOLS: ToolSpec[] = [
  { key: "conductivity", title: "Bulk ionic conductivity", subtitle: "SDL1 · Electrochemistry", path: "electrochemistry/conductivity", icon: Activity,
    fields: [{ key: "resistance_ohm", label: "Bulk resistance", defaultValue: "100", unit: "Ω" }, { key: "thickness_cm", label: "Pellet thickness", defaultValue: "0.1", unit: "cm" }, { key: "area_cm2", label: "Electrode area", defaultValue: "1", unit: "cm²" }],
    description: "Uses σ = L / (R × A). Geometry and resistance uncertainty can be added through the API." },
  { key: "bragg", title: "Bragg d-spacing", subtitle: "SDL1 · Diffraction", path: "diffraction/bragg", icon: Atom,
    fields: [{ key: "two_theta_degrees", label: "2θ", defaultValue: "30", unit: "degrees" }, { key: "wavelength_angstrom", label: "X-ray wavelength", defaultValue: "1.5406", unit: "Å" }],
    description: "Converts a diffraction angle and wavelength using nλ = 2d sin θ (first order by default)." },
  { key: "arrhenius", title: "Arrhenius activation energy", subtitle: "SDL1 · Temperature dependence", path: "electrochemistry/arrhenius", icon: Gauge,
    fields: [{ key: "temperature_k", label: "Temperatures (comma-separated)", defaultValue: "300,320,340,360,380", unit: "K" }, { key: "conductivity_s_cm", label: "Conductivities (comma-separated)", defaultValue: "0.0001,0.0002,0.0003,0.0005,0.0008", unit: "S/cm" }],
    description: "Fits ln(σT) against 1/T. This is a model fit, not proof of a transport mechanism." },
  { key: "dispersity", title: "Polymer dispersity", subtitle: "SDL4 · Polymer science", path: "polymers/dispersity", icon: Sigma,
    fields: [{ key: "number_average_molar_mass", label: "Number-average molar mass (Mn)", defaultValue: "10000", unit: "g/mol" }, { key: "weight_average_molar_mass", label: "Weight-average molar mass (Mw)", defaultValue: "18000", unit: "g/mol" }],
    description: "Computes Đ = Mw / Mn. Both inputs must use the same analytical basis and units." },
  { key: "crystallinity", title: "DSC crystallinity estimate", subtitle: "SDL4 · Thermal analysis", path: "polymers/crystallinity", icon: Ruler,
    fields: [{ key: "melting_enthalpy_j_g", label: "Measured melting enthalpy", defaultValue: "40", unit: "J/g" }, { key: "reference_enthalpy_j_g", label: "Reference enthalpy", defaultValue: "100", unit: "J/g" }, { key: "polymer_mass_fraction", label: "Polymer mass fraction", defaultValue: "1", unit: "fraction" }],
    description: "Uses ΔHm / (w × ΔHm⁰) × 100. Reference enthalpy and cold-crystallization corrections are material-specific." },
  { key: "massBalance", title: "Process mass balance", subtitle: "SDL7 · Process engineering", path: "process/mass-balance", icon: FlaskConical,
    fields: [{ key: "inlet_mass_g", label: "Inlet mass", defaultValue: "100", unit: "g" }, { key: "outlet_mass_g", label: "Outlet mass", defaultValue: "96", unit: "g" }, { key: "accumulated_mass_g", label: "Accumulated mass", defaultValue: "4", unit: "g" }, { key: "generated_mass_g", label: "Generated mass", defaultValue: "0", unit: "g" }, { key: "consumed_mass_g", label: "Consumed mass", defaultValue: "0", unit: "g" }],
    description: "Checks the declared inlet/generated versus outlet/accumulated/consumed mass terms." },
];

function formatValue(value: unknown): string {
  if (typeof value === "number") return Number.isFinite(value) ? value.toPrecision(6) : "—";
  if (typeof value === "string") return value;
  return JSON.stringify(value);
}

export function ScienceToolsView() {
  const [selected, setSelected] = useState<CalculatorKey>("conductivity");
  const [values, setValues] = useState<Record<string, string>>({});
  const [result, setResult] = useState<Record<string, unknown> | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const tool = TOOLS.find((item) => item.key === selected) ?? TOOLS[0];
  const currentValues = Object.fromEntries(tool.fields.map((field) => [field.key, values[`${selected}.${field.key}`] ?? field.defaultValue]));

  const run = async () => {
    setBusy(true); setError(""); setResult(null);
    try {
      const payload: Record<string, unknown> = {};
      for (const field of tool.fields) {
        const raw = currentValues[field.key];
        if (raw.includes(",")) payload[field.key] = raw.split(",").map((part) => Number(part.trim()));
        else payload[field.key] = Number(raw);
      }
      const response = await api.scienceCalculator(tool.path, payload);
      setResult(response);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Calculation could not be completed.");
    } finally { setBusy(false); }
  };

  const Icon = tool.icon;
  return (
    <div className="science-tools-layout">
      <Panel title="Scientific calculation library" subtitle="A shared calculation surface for selected SDL domains. Each output is derived from inputs; it is never stored as an instrument measurement.">
        <div className="science-tool-grid">
          {TOOLS.map((item) => {
            const ToolIcon = item.icon;
            return <button key={item.key} className={`science-tool-card ${selected === item.key ? "selected" : ""}`} onClick={() => { setSelected(item.key); setResult(null); setError(""); }}>
              <span className="science-tool-icon"><ToolIcon size={16} /></span><strong>{item.title}</strong><small>{item.subtitle}</small>
            </button>;
          })}
        </div>
      </Panel>
      <div className="science-tool-workspace">
        <Panel title={tool.title} subtitle={tool.description} action={<span className="science-derived-tag">DERIVED RESULT</span>}>
          <div className="science-tool-form">
            {tool.fields.map((field) => <label key={field.key}><span>{field.label}<small>{field.unit}</small></span><input inputMode="decimal" value={currentValues[field.key]} onChange={(event) => setValues((current) => ({ ...current, [`${selected}.${field.key}`]: event.target.value }))} /></label>)}
          </div>
          <div className="science-tool-actions"><span>Inputs are interpreted in the units shown; no hidden unit conversion.</span><button className="button button-primary" disabled={busy} onClick={() => void run()}><Calculator size={13} />{busy ? "Calculating…" : "Run calculation"}</button></div>
        </Panel>
        <Panel title="Calculation output" subtitle="Values and assumptions returned by the scientific calculation service.">
          {result ? <div className="science-result-grid">{Object.entries(result).filter(([key]) => !["limitations", "matches", "individual_estimates_angstrom", "engineering_strain", "engineering_stress_mpa"].includes(key)).map(([key, value]) => <div key={key}><span>{key.replace(/_/g, " ")}</span><strong>{formatValue(value)}</strong></div>)}{Array.isArray(result.limitations) && <div className="science-result-wide"><span>LIMITATIONS</span><ul>{result.limitations.map((item) => <li key={String(item)}>{String(item)}</li>)}</ul></div>}</div> : <div className="science-result-empty"><Microscope size={22} /><strong>No calculation executed</strong><span>Choose a method, review its units and assumptions, then run the calculation.</span></div>}
          {error && <div className="research-feedback error">{error}</div>}
        </Panel>
      </div>
      <div className="science-tool-warning"><Atom size={15} /><span>These utilities perform transparent arithmetic and simple fits. They do not validate sample identity, instrument calibration, phase assignment, biological validity, or a scientific mechanism. Store outputs with source data and versioned lineage.</span></div>
    </div>
  );
}
