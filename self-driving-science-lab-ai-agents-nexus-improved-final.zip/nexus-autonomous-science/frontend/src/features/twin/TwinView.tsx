"use client";

import { Activity, AlertTriangle, Atom, Bot, BrainCircuit, Cable, CheckCircle2, Cpu, Gauge, Network, Orbit, RadioTower, ShieldAlert, Workflow } from "lucide-react";
import { Panel } from "@/components/Panel";
import { StatusPill } from "@/components/StatusPill";
import type { Laboratory, TwinOverview } from "@/types";

const instruments = [
  { name: "XRD Twin 01", lab: "SDL1", type: "X-ray diffraction", status: "simulated", telemetry: "Pattern acquisition model" },
  { name: "EIS Twin 02", lab: "SDL1", type: "Electrochemical impedance", status: "simulated", telemetry: "Impedance sweep model" },
  { name: "Thermal Twin 03", lab: "SDL1", type: "Thermal analyzer", status: "simulated", telemetry: "Temperature profile model" },
  { name: "Robot Cell Twin 01", lab: "SDL0", type: "Robotic cell", status: "simulated", telemetry: "Workspace state model" },
  { name: "Rheometer Twin 01", lab: "SDL4", type: "Rheometer", status: "simulated", telemetry: "Rheology model" },
  { name: "Microscopy Twin 01", lab: "SDL6", type: "Microscope", status: "simulated", telemetry: "Image stream model" },
];

export function TwinView({ twin, labs }: { twin: TwinOverview; labs: Laboratory[] }) {
  return (
    <div className="view-stack">
      <div className="twin-status-banner"><div className="twin-status-icon"><Orbit size={21} /></div><div><strong>Digital-twin environment online</strong><p>All connected equipment shown below is a simulated representation. No physical instrument endpoints are configured.</p></div><StatusPill status="simulated" /></div>
      <div className="metric-grid metric-grid-four">
        <div className="compact-metric"><span className="compact-metric-icon"><Cpu size={17} /></span><div><small>Instrument twins</small><strong>{twin.instrument_twins}</strong></div><span className="metric-footnote">Simulated devices</span></div>
        <div className="compact-metric"><span className="compact-metric-icon green"><Workflow size={17} /></span><div><small>Workflow twins</small><strong>{twin.workflow_twins}</strong></div><span className="metric-footnote">Process graph models</span></div>
        <div className="compact-metric"><span className="compact-metric-icon violet"><Network size={17} /></span><div><small>Lab twins</small><strong>{twin.lab_twins}</strong></div><span className="metric-footnote">Initial SDL1 focus</span></div>
        <div className="compact-metric"><span className="compact-metric-icon amber"><ShieldAlert size={17} /></span><div><small>Physical control</small><strong>Disabled</strong></div><span className="metric-footnote">Local safety boundary</span></div>
      </div>

      <Panel title="NEXUS twin topology" subtitle="Shared intelligence layer · simulated laboratory edge">
        <div className="twin-topology">
          <div className="topology-layer topology-cloud"><div className="topology-node cloud-node"><div className="topology-node-icon"><BrainCircuit size={20} /></div><div><strong>NEXUS orchestrator</strong><span>Objectives · agents · experiment scheduler</span></div><StatusPill status="online" /></div></div>
          <div className="topology-connector"><i /><i /><i /><span>API / event stream / provenance</span></div>
          <div className="topology-layer topology-edge"><div className="topology-node edge-node"><div className="topology-node-icon"><RadioTower size={19} /></div><div><strong>Local edge gateway boundary</strong><span>Authentication · policy · idempotency · interlocks</span></div><StatusPill status="standby" /></div></div>
          <div className="topology-connector"><i /><i /><i /><span>Simulation adapters only in this build</span></div>
          <div className="topology-labs-grid">{labs.map((lab, index) => <div className={`topology-lab topology-lab-${index}`} key={lab.code}><span>{lab.code}</span><strong>{lab.name}</strong><small>{index < 2 ? "Twin connected" : "Future node"}</small></div>)}</div>
        </div>
      </Panel>

      <Panel title="Instrument twin registry" subtitle="Capability manifest and simulated state">
        <div className="instrument-grid">{instruments.map((instrument, index) => <div className="instrument-card" key={instrument.name}><div className="instrument-card-top"><div className={`instrument-icon instrument-tone-${index % 4}`}>{index === 3 ? <Bot size={19} /> : index === 5 ? <Activity size={19} /> : index === 4 ? <Gauge size={19} /> : <Atom size={19} />}</div><StatusPill status={instrument.status} /></div><strong>{instrument.name}</strong><span>{instrument.type}</span><div className="instrument-card-footer"><span>{instrument.lab}</span><small>{instrument.telemetry}</small></div></div>)}</div>
      </Panel>

      <div className="twin-warning"><AlertTriangle size={17} /><div><strong>Simulation fidelity has not been established.</strong><span>Each twin must carry model version, calibration date, validated operating range, known limitations, prediction error, and synchronization metadata. Simulation success is not real-world acceptance.</span></div></div>
    </div>
  );
}
