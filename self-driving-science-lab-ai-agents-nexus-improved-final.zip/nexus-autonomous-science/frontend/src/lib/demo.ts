import type {
  Agent, Approval, Candidate, Dataset, EventRecord, Experiment,
  Laboratory, Measurement, Overview, TwinOverview,
} from "@/types";

export const demoLabs: Laboratory[] = [
  { id: "sdl0", code: "SDL0", name: "AI & Robotics", focus: "Autonomous systems research", description: "Build and validate the intelligence, robotics, simulation, and reliability stack.", status: "online", priority: "critical", instrument_count: 1 },
  { id: "sdl1", code: "SDL1", name: "Inorganic Materials", focus: "Advanced materials and energy", description: "Crystal structures, ionic transport, catalysis, semiconductors, and battery materials.", status: "online", priority: "highest", instrument_count: 3 },
  { id: "sdl2", code: "SDL2", name: "Organic Chemistry", focus: "Molecular discovery and reaction science", description: "Molecular representations, reaction mechanisms, synthesis, and characterization.", status: "standby", priority: "high", instrument_count: 0 },
  { id: "sdl3", code: "SDL3", name: "Medicinal Chemistry", focus: "Structure–activity research", description: "Molecular recognition, binding, selectivity, and assay evidence.", status: "standby", priority: "high", instrument_count: 0 },
  { id: "sdl4", code: "SDL4", name: "Polymers", focus: "Polymer structure and performance", description: "Architecture, crystallization, rheology, mechanical response, and degradation.", status: "standby", priority: "high", instrument_count: 1 },
  { id: "sdl5", code: "SDL5", name: "Formulations", focus: "Formulation and product systems", description: "Composition, stability, particle attributes, and processability.", status: "standby", priority: "standard", instrument_count: 0 },
  { id: "sdl6", code: "SDL6", name: "Organoids & Organ-on-Chip", focus: "Biological structure–function research", description: "Biological model provenance, imaging, function, mechanobiology, and replication.", status: "standby", priority: "standard", instrument_count: 1 },
  { id: "sdl7", code: "SDL7", name: "Scale-up & Process Engineering", focus: "Multiscale process science", description: "Kinetics, heat and mass transfer, mixing, scale-up, and manufacturing feasibility.", status: "standby", priority: "high", instrument_count: 0 },
];

const agentNames = [
  ["Research Intelligence", "Hypothesis Generation", "Scientific Debate", "Objective Compiler", "Research Gap Mapper"],
  ["Crystal Structure Parser", "Composition Validator", "Defect Chemistry Analyst", "Ionic Transport Modeler", "Materials Candidate Ranker"],
  ["Molecular Structure Validator", "Reaction Classifier", "Retrosynthesis Planner", "Reaction Condition Analyst", "Purification Intelligence"],
  ["Target Evidence Curator", "Binding Model Analyst", "SAR Analyst", "Activity Cliff Detector", "Assay Quality Reviewer"],
];
export const demoAgents: Agent[] = agentNames.flatMap((names, group) => names.map((name, index) => ({
  id: `AG-${group * 10 + index + 1}`,
  agent_key: `demo-${group}-${index}`,
  name,
  department: ["Scientific Research", "Materials Discovery", "Organic Chemistry", "Medicinal Chemistry"][group],
  laboratory_code: ["SDL0", "SDL1", "SDL2", "SDL3"][group],
  purpose: "A domain-specific agent profile that proposes or reviews a measurable scientific task.",
  status: index === 0 && group === 0 ? "running" : "idle",
  permission_level: "propose_only",
  capabilities: ["evidence review", "schema-aware output", "uncertainty reporting"],
  run_count: index * 2,
  synthetic: true,
})));

export const demoCandidates: Candidate[] = [
  { id: "MAT-00128", code: "MAT-00128", name: "Argyrodite-like candidate A", formula: "Li₆PS₅Cl", family: "Thio-phosphate solid electrolyte", domain: "inorganic_materials", laboratory_code: "SDL1", predicted_properties: { ionic_conductivity: 0.0042, stability_score: 81 }, uncertainty: { conductivity: 0.17, stability: 0.08 }, feasibility_score: 84, recommendation_score: 79, lifecycle_stage: "model_candidate", evidence_type: "synthetic_model_prediction", synthetic: true, ranking: { score: 82.4, components: {}, explanation: "Synthetic demonstration" } },
  { id: "MAT-00129", code: "MAT-00129", name: "Garnet-like candidate B", formula: "Li₇La₃Zr₂O₁₂", family: "Oxide solid electrolyte", domain: "inorganic_materials", laboratory_code: "SDL1", predicted_properties: { ionic_conductivity: 0.0018, stability_score: 91 }, uncertainty: { conductivity: 0.11, stability: 0.08 }, feasibility_score: 68, recommendation_score: 75, lifecycle_stage: "model_candidate", evidence_type: "synthetic_model_prediction", synthetic: true, ranking: { score: 76.1, components: {}, explanation: "Synthetic demonstration" } },
  { id: "MAT-00130", code: "MAT-00130", name: "NASICON-like candidate C", formula: "Li₁.₃Al₀.₃Ti₁.₇(PO₄)₃", family: "Phosphate solid electrolyte", domain: "inorganic_materials", laboratory_code: "SDL1", predicted_properties: { ionic_conductivity: 0.0026, stability_score: 76 }, uncertainty: { conductivity: 0.14, stability: 0.08 }, feasibility_score: 78, recommendation_score: 73, lifecycle_stage: "model_candidate", evidence_type: "synthetic_model_prediction", synthetic: true, ranking: { score: 73.8, components: {}, explanation: "Synthetic demonstration" } },
  { id: "MAT-00131", code: "MAT-00131", name: "Halide candidate D", formula: "Li₃YCl₆", family: "Halide solid electrolyte", domain: "inorganic_materials", laboratory_code: "SDL1", predicted_properties: { ionic_conductivity: 0.0033, stability_score: 73 }, uncertainty: { conductivity: 0.21, stability: 0.08 }, feasibility_score: 72, recommendation_score: 71, lifecycle_stage: "model_candidate", evidence_type: "synthetic_model_prediction", synthetic: true },
  { id: "MAT-00132", code: "MAT-00132", name: "Oxide candidate E", formula: "Li₅La₃Ta₂O₁₂", family: "Oxide solid electrolyte", domain: "inorganic_materials", laboratory_code: "SDL1", predicted_properties: { ionic_conductivity: 0.0012, stability_score: 88 }, uncertainty: { conductivity: 0.10, stability: 0.08 }, feasibility_score: 61, recommendation_score: 66, lifecycle_stage: "model_candidate", evidence_type: "synthetic_model_prediction", synthetic: true },
];

export const demoExperiments: Experiment[] = [
  { id: "EXP-2401", code: "EXP-2401", title: "Candidate A · computational screening", laboratory_code: "SDL1", objective_id: "OBJ-0001", hypothesis_id: "HYP-0001", candidate_id: "MAT-00128", status: "executing", execution_mode: "simulation", protocol_id: "sdl1-screening-demo", protocol_version: "0.1.0", owner: "Dr. Demo Scientist", estimated_duration_minutes: 45, resource_requirements: {}, governance: {}, result_summary: {}, created_at: new Date().toISOString(), updated_at: new Date().toISOString(), synthetic: true },
  { id: "EXP-2398", code: "EXP-2398", title: "Candidate B · phase-stability comparison", laboratory_code: "SDL1", objective_id: "OBJ-0001", hypothesis_id: "HYP-0001", candidate_id: "MAT-00129", status: "data_validation", execution_mode: "computational", protocol_id: "sdl1-screening-demo", protocol_version: "0.1.0", owner: "Dr. Demo Scientist", estimated_duration_minutes: 75, resource_requirements: {}, governance: {}, result_summary: {}, created_at: new Date().toISOString(), updated_at: new Date().toISOString(), synthetic: true },
  { id: "EXP-2395", code: "EXP-2395", title: "Candidate C · uncertainty review", laboratory_code: "SDL1", objective_id: "OBJ-0001", hypothesis_id: "HYP-0001", candidate_id: "MAT-00130", status: "awaiting_approval", execution_mode: "simulation", protocol_id: "sdl1-screening-demo", protocol_version: "0.1.0", owner: "Dr. Demo Scientist", estimated_duration_minutes: 60, resource_requirements: {}, governance: {}, result_summary: {}, created_at: new Date().toISOString(), updated_at: new Date().toISOString(), synthetic: true },
  { id: "EXP-2389", code: "EXP-2389", title: "Reference dataset · metadata audit", laboratory_code: "SDL1", objective_id: "OBJ-0001", hypothesis_id: null, candidate_id: "MAT-00131", status: "completed", execution_mode: "computational", protocol_id: "metadata-audit", protocol_version: "0.1.0", owner: "Data Intelligence", estimated_duration_minutes: 30, resource_requirements: {}, governance: {}, result_summary: {}, created_at: new Date().toISOString(), updated_at: new Date().toISOString(), synthetic: true },
  { id: "EXP-2381", code: "EXP-2381", title: "Candidate D · twin feasibility run", laboratory_code: "SDL1", objective_id: "OBJ-0001", hypothesis_id: null, candidate_id: "MAT-00132", status: "failed", execution_mode: "simulation", protocol_id: "sdl1-screening-demo", protocol_version: "0.1.0", owner: "Digital Twin", estimated_duration_minutes: 50, resource_requirements: {}, governance: {}, result_summary: {}, created_at: new Date().toISOString(), updated_at: new Date().toISOString(), synthetic: true },
];

export const demoApprovals: Approval[] = [
  { id: "APR-0001", experiment_id: "EXP-2395", requested_by: "Dr. Demo Scientist", reason: "Review the proposed computational follow-up and verify resource assumptions.", status: "pending", reviewer_note: "", requested_at: new Date().toISOString() },
];
export const demoDatasets: Dataset[] = [
  { id: "DS-001", name: "SDL1 materials candidate register", domain: "inorganic_materials", data_layer: "validated", version: "0.1.0", record_count: 6, quality_status: "preliminary", lineage: ["seed://nexus-demo"], synthetic: true },
  { id: "DS-002", name: "NEXUS agent evaluation fixtures", domain: "cross_domain", data_layer: "ai", version: "0.1.0", record_count: 120, quality_status: "synthetic", lineage: ["seed://nexus-demo"], synthetic: true },
  { id: "DS-003", name: "Instrument capability manifests", domain: "cross_domain", data_layer: "knowledge", version: "0.1.0", record_count: 6, quality_status: "preliminary", lineage: ["seed://nexus-demo"], synthetic: true },
];
export const demoMeasurements: Measurement[] = [
  { id: "MEAS-001", experiment_id: "EXP-2389", sample_id: "SYN-REF-01", property_name: "ionic_conductivity", value: 0.0021, unit: "S/cm", uncertainty: 0.0002, origin: "simulation", quality_status: "synthetic_or_derived", raw_artifact_uri: "demo://measurements/1", synthetic: true },
  { id: "MEAS-002", experiment_id: "EXP-2389", sample_id: "SYN-REF-01", property_name: "stability_score", value: 78.2, unit: "score/100", uncertainty: 2.5, origin: "simulation", quality_status: "synthetic_or_derived", raw_artifact_uri: "demo://measurements/2", synthetic: true },
];
export const demoEvents: EventRecord[] = [
  { id: "EV-01", event_type: "SIMULATED_EXPERIMENT_COMPLETED", actor: "digital-twin", subject_type: "experiment", subject_id: "EXP-2389", created_at: new Date().toISOString(), payload: { synthetic: true } },
  { id: "EV-02", event_type: "APPROVAL_REQUESTED", actor: "Dr. Demo Scientist", subject_type: "experiment", subject_id: "EXP-2395", created_at: new Date().toISOString(), payload: {} },
  { id: "EV-03", event_type: "AGENT_DEMO_RUN_COMPLETED", actor: "demo-orchestrator", subject_type: "agent", subject_id: "AG-001", created_at: new Date().toISOString(), payload: {} },
];
export const demoOverview: Overview = {
  counts: { laboratories: 8, agents: 100, experiments: 5, candidates: 6, measurements: 2, pending_approvals: 1 },
  experiment_status: { executing: 1, data_validation: 1, awaiting_approval: 1, completed: 1, failed: 1 },
  active_agents: 1,
  network_status: "demo_online",
  execution_mode: "simulation_only",
  synthetic_data_notice: "Seeded records and digital-twin results are synthetic demonstrations.",
  recent_events: demoEvents,
};
export const demoTwin: TwinOverview = {
  mode: "simulation_only", synchronized: true, last_sync: "Demo clock · no hardware connected",
  instrument_twins: 6, workflow_twins: 8, lab_twins: 1, physical_control_enabled: false,
  calibration_status: "demo_model_unvalidated", warning: "A digital twin is a model, not a guarantee of physical behavior.",
};
