export type NavKey =
  | "overview"
  | "labs"
  | "agents"
  | "discovery"
  | "experiments"
  | "governance"
  | "data"
  | "twin"
  | "models"
  | "samples"
  | "research"
  | "calculators"
  | "campaigns"
  | "advanced";

export interface Laboratory {
  id: string;
  code: string;
  name: string;
  focus: string;
  description: string;
  status: string;
  priority: string;
  instrument_count?: number;
  execution_mode?: string;
}

export interface Agent {
  id: string;
  agent_key: string;
  name: string;
  department: string;
  laboratory_code: string;
  purpose: string;
  status: string;
  permission_level: string;
  capabilities: string[];
  run_count: number;
  last_run_at?: string | null;
  synthetic: boolean;
}

export interface Candidate {
  id: string;
  code: string;
  name: string;
  formula: string;
  family: string;
  domain: string;
  laboratory_code: string;
  predicted_properties: Record<string, number>;
  uncertainty: Record<string, number>;
  feasibility_score: number;
  recommendation_score: number;
  lifecycle_stage: string;
  evidence_type: string;
  synthetic: boolean;
  ranking?: { score: number; components: Record<string, number>; explanation: string };
}

export interface Experiment {
  id: string;
  code: string;
  title: string;
  laboratory_code: string;
  objective_id?: string | null;
  hypothesis_id?: string | null;
  candidate_id?: string | null;
  status: string;
  execution_mode: string;
  protocol_id: string;
  protocol_version: string;
  owner: string;
  estimated_duration_minutes: number;
  resource_requirements: Record<string, unknown>;
  governance: Record<string, unknown>;
  result_summary: Record<string, unknown>;
  created_at: string;
  updated_at: string;
  synthetic: boolean;
}

export interface Approval {
  id: string;
  experiment_id: string;
  requested_by: string;
  reviewer?: string | null;
  reason: string;
  status: string;
  reviewer_note: string;
  requested_at: string;
  decided_at?: string | null;
}

export interface Dataset {
  id: string;
  name: string;
  domain: string;
  data_layer: string;
  version: string;
  record_count: number;
  quality_status: string;
  lineage: string[];
  synthetic: boolean;
}

export interface EventRecord {
  id: string;
  event_type: string;
  actor: string;
  subject_type: string;
  subject_id: string;
  created_at: string;
  payload: Record<string, unknown>;
}

export interface Overview {
  counts: {
    laboratories: number;
    agents: number;
    experiments: number;
    candidates: number;
    measurements: number;
    pending_approvals: number;
  };
  experiment_status: Record<string, number>;
  active_agents: number;
  network_status: string;
  execution_mode: string;
  synthetic_data_notice: string;
  recent_events: EventRecord[];
}

export interface TwinOverview {
  mode: string;
  synchronized: boolean;
  last_sync: string;
  instrument_twins: number;
  workflow_twins: number;
  lab_twins: number;
  physical_control_enabled: boolean;
  calibration_status: string;
  warning: string;
}

export interface Measurement {
  id: string;
  experiment_id: string;
  sample_id: string;
  property_name: string;
  value: number;
  unit: string;
  uncertainty?: number | null;
  origin: string;
  quality_status: string;
  raw_artifact_uri: string;
  synthetic: boolean;
}

export interface ScientificSample {
  id: string;
  code: string;
  name: string;
  laboratory_code: string;
  domain: string;
  sample_type: string;
  composition: Record<string, unknown>;
  identity_status: string;
  lifecycle_status: string;
  synthetic: boolean;
  parent_sample_id?: string | null;
  created_at: string;
}

export interface TrainingDatasetSnapshot {
  id: string;
  dataset_key: string;
  version: string;
  domain: string;
  target_property: string;
  feature_names: string[];
  row_count: number;
  status: string;
  quality_report: Record<string, unknown>;
  synthetic: boolean;
  created_at: string;
}

export interface ScientificModelRecord {
  id: string;
  model_key: string;
  version: string;
  name: string;
  model_type: string;
  supported_domains: string[];
  supported_modalities: string[];
  prediction_targets: string[];
  metrics: Record<string, unknown>;
  uncertainty_profile: Record<string, unknown>;
  limitations: string[];
  status: string;
  synthetic: boolean;
  created_at: string;
}

export interface WorkflowRun {
  id: string;
  workflow_key: string;
  laboratory_code: string;
  objective_id?: string | null;
  status: string;
  current_node: string;
  state: Record<string, unknown>;
  node_history: Array<Record<string, unknown>>;
  error_summary: string;
  correlation_id: string;
  synthetic: boolean;
  created_at: string;
}

export interface ResearchClaim {
  id: string;
  claim_key: string;
  statement: string;
  domain: string;
  laboratory_code: string;
  status: string;
  support_refs: string[];
  contradiction_refs: string[];
  reviewer?: string | null;
}

export interface ResearchCampaignStage {
  index: number;
  stage_key: string;
  workflow_key: string;
  title: string;
  status: string;
  workflow_run_id?: string | null;
  started_at?: string | null;
  reviewed_at?: string | null;
  reviewer?: string | null;
  review_note?: string;
}

export interface ResearchCampaign {
  id: string;
  campaign_code: string;
  title: string;
  description: string;
  laboratory_code: string;
  domain: string;
  objective_id: string;
  status: string;
  execution_mode: string;
  stages: ResearchCampaignStage[];
  current_stage_index: number;
  constraints: Record<string, unknown>;
  approval: Record<string, unknown>;
  result_summary: Record<string, unknown>;
  synthetic: boolean;
  created_at: string;
  updated_at: string;
}
